Accounting Analytics: An Integrated Approach (2026 edition)
Companion files for Chapter 16: Audit Monitoring (a Power BI project)

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.xlsx SHA-256 185d42bd069fad177fae23c5e30df93edc7cf2669f687236c8a9f29435388e09

End of Chapter 16/Audit Monitoring/Audit Monitoring.pbip
Start of Tutorial 16.2/Audit Monitoring/Audit Monitoring.pbip
Start of Tutorial 16.3/Audit Monitoring/Audit Monitoring.pbip
Start of Tutorial 16.3/Charles River Reports/Charles River Reports.pbip (the end of Tutorial 15.3, which Tutorial 16.3 also uses)

How to use a start file:
1. Copy the folder Audit Monitoring from the folder of your tutorial into a folder of your own. It holds
   Audit Monitoring.pbip and two folders, which belong together.
2. Open Audit Monitoring.pbip in Power BI Desktop (the September 2026 release or later).
3. Its queries read C:\CharlesRiver\CharlesRiver.xlsx. Put your copy of CharlesRiver.xlsx there, or point the queries
   at your copy: Home > Transform data > Data source settings > Change Source.
4. Choose Home > Refresh. The project holds no data until you refresh it.
5. Choose File > Save as and save it as Audit Monitoring.pbix, the file the tutorials use.
6. Continue with the tutorial. The Notes page lists what the file holds; in DAX query view, the
   Checks tab checks every control total (choose Run).

More: https://aa.accountinganalyticshub.com/front-matter/companion-files.html
