/* Chapter 10: manufacturing variance, joined and summarized
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 10.2; dataset v2026.1
   Checks: 2026 closes equal the ledger; the trial balance nets to zero */

-- Tutorial 10.1: the closes joined to their work orders
SELECT woc.WorkOrderCloseID, woc.CloseDate, wo.WorkOrderNumber,
    wo.ItemID, woc.TotalVarianceAmount
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID;  -- Result: 12998 rows

-- Tutorial 10.1: the number of closes, to test the join
SELECT COUNT(*) AS Closes
FROM WorkOrderClose;  -- Result: 1 row (Closes = 12998)

-- Tutorial 10.1: the closes with their items
SELECT woc.WorkOrderCloseID, woc.CloseDate, i.ItemCode,
    i.ItemName, i.ItemGroup, woc.TotalVarianceAmount
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID;  -- Result: 12998 rows

-- Tutorial 10.1: the variance of fiscal 2026 by item group
SELECT i.ItemGroup, COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemGroup
ORDER BY TotalVariance DESC;  -- Result: 3 rows

-- Tutorial 10.1: the same variance in the ledger
SELECT ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS LedgerVariance
FROM GLEntry AS gl
WHERE gl.AccountID = 93 AND gl.FiscalYear = 2026
    AND gl.SourceDocumentType = 'WorkOrderClose';  -- Result: 1 row (LedgerVariance = 2265636.88)

-- Tutorial 10.1: the variance by item group and year
SELECT i.ItemGroup, SUBSTR(woc.CloseDate, 1, 4) AS CloseYear,
    COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance,
    ROUND(SUM(woc.OverheadVarianceAmount), 2) AS OverheadVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
GROUP BY i.ItemGroup, CloseYear
ORDER BY i.ItemGroup, CloseYear;  -- Result: 9 rows

-- Tutorial 10.1: items with more than $50,000 of variance in 2026
SELECT i.ItemID, i.ItemCode, i.ItemName, COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemID, i.ItemCode, i.ItemName
HAVING SUM(woc.TotalVarianceAmount) > 50000
ORDER BY TotalVariance DESC;  -- Result: 5 rows

-- Tutorial 10.1: every manufactured item with its closes of 2026
SELECT i.ItemCode, i.ItemName, i.LifecycleStatus,
    COUNT(woc.WorkOrderCloseID) AS Closes2026
FROM Item AS i
    LEFT JOIN WorkOrder AS wo ON wo.ItemID = i.ItemID
    LEFT JOIN WorkOrderClose AS woc ON woc.WorkOrderID = wo.WorkOrderID
        AND woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
WHERE i.SupplyMode = 'Manufactured'
GROUP BY i.ItemID, i.ItemCode, i.ItemName, i.LifecycleStatus
ORDER BY Closes2026, i.ItemCode;  -- Result: 88 rows

-- Tutorial 10.2: the closes and the ledger side by side
SELECT
    (SELECT ROUND(SUM(TotalVarianceAmount), 2)
     FROM WorkOrderClose
     WHERE CloseDate BETWEEN '2026-01-01' AND '2026-12-31') AS Closes,
    (SELECT ROUND(SUM(Debit) - SUM(Credit), 2)
     FROM GLEntry
     WHERE AccountID = 93 AND FiscalYear = 2026
         AND SourceDocumentType = 'WorkOrderClose') AS Ledger;  -- Result: 1 row (Closes = 2265636.88, Ledger = 2265636.88)

-- Tutorial 10.2: the pre-closing trial balance of fiscal 2026
SELECT a.AccountNumber, a.AccountName, a.AccountType,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.PostingDate <= '2026-12-31'
    AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
GROUP BY a.AccountID, a.AccountNumber, a.AccountName, a.AccountType
ORDER BY a.AccountNumber;  -- Result: 71 rows

-- Tutorial 10.2: the net of all the balances
SELECT COUNT(*) AS Accounts, ROUND(SUM(tb.Balance), 2) AS NetBalance
FROM (
    SELECT gl.AccountID,
        ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance
    FROM GLEntry AS gl
    WHERE gl.PostingDate <= '2026-12-31'
        AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
    GROUP BY gl.AccountID
) AS tb;  -- Result: 1 row (Accounts = 71, NetBalance = 0.0)

-- Tutorial 10.2: the total of the debit balances
SELECT COUNT(*) AS DebitAccounts,
    ROUND(SUM(tb.Balance), 2) AS DebitBalances
FROM (
    SELECT gl.AccountID,
        ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance
    FROM GLEntry AS gl
    WHERE gl.PostingDate <= '2026-12-31'
        AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
    GROUP BY gl.AccountID
) AS tb
WHERE tb.Balance > 0;  -- Result: 1 row (DebitAccounts = 46, DebitBalances = 67107722.36)

-- Tutorial 10.2: account 1090 by year and source
SELECT gl.FiscalYear, gl.SourceDocumentType,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
WHERE gl.AccountID = 92 AND gl.FiscalYear BETWEEN 2024 AND 2026
GROUP BY gl.FiscalYear, gl.SourceDocumentType
ORDER BY gl.FiscalYear, gl.SourceDocumentType;  -- Result: 12 rows

-- Tutorial 10.2: the labor and overhead parts by year
SELECT SUBSTR(CloseDate, 1, 4) AS CloseYear,
    ROUND(SUM(DirectLaborVarianceAmount), 2) AS LaborVariance,
    ROUND(SUM(OverheadVarianceAmount), 2) AS OverheadVariance,
    ROUND(SUM(ConversionVarianceAmount), 2) AS ConversionVariance
FROM WorkOrderClose
GROUP BY CloseYear
ORDER BY CloseYear;  -- Result: 3 rows

-- Tutorial 10.2: the journal entries posted to account 1090
SELECT gl.FiscalYear, je.EntryType,
    ROUND(SUM(gl.Debit), 2) AS Debits
FROM GLEntry AS gl
    INNER JOIN JournalEntry AS je
        ON gl.SourceDocumentType = 'JournalEntry'
        AND je.JournalEntryID = gl.SourceDocumentID
WHERE gl.AccountID = 92
GROUP BY gl.FiscalYear, je.EntryType
ORDER BY gl.FiscalYear, je.EntryType;  -- Result: 6 rows
