/* Chapter 10: manufacturing variance, joined and summarized
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 10.1; dataset v2026.1
   Checks: 2026 closes equal the ledger; the trial balance nets to zero */

-- Tutorial 10.1: the closes joined to their work orders
SELECT woc.WorkOrderCloseID, woc.CloseDate, wo.WorkOrderNumber,
    wo.ItemID, woc.TotalVarianceAmount
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID;  -- Result: 12998 rows

-- Tutorial 10.1: the number of closes, to test the join
SELECT COUNT(*) AS Closes
FROM WorkOrderClose;  -- Result: 1 row (Closes = 12998)

-- Tutorial 10.1: the closes with their items
SELECT woc.WorkOrderCloseID, woc.CloseDate, i.ItemCode,
    i.ItemName, i.ItemGroup, woc.TotalVarianceAmount
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID;  -- Result: 12998 rows

-- Tutorial 10.1: the variance of fiscal 2026 by item group
SELECT i.ItemGroup, COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemGroup
ORDER BY TotalVariance DESC;  -- Result: 3 rows

-- Tutorial 10.1: the same variance in the ledger
SELECT ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS LedgerVariance
FROM GLEntry AS gl
WHERE gl.AccountID = 93 AND gl.FiscalYear = 2026
    AND gl.SourceDocumentType = 'WorkOrderClose';  -- Result: 1 row (LedgerVariance = 2265636.88)

-- Tutorial 10.1: the variance by item group and year
SELECT i.ItemGroup, SUBSTR(woc.CloseDate, 1, 4) AS CloseYear,
    COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance,
    ROUND(SUM(woc.OverheadVarianceAmount), 2) AS OverheadVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
GROUP BY i.ItemGroup, CloseYear
ORDER BY i.ItemGroup, CloseYear;  -- Result: 9 rows

-- Tutorial 10.1: items with more than $50,000 of variance in 2026
SELECT i.ItemID, i.ItemCode, i.ItemName, COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemID, i.ItemCode, i.ItemName
HAVING SUM(woc.TotalVarianceAmount) > 50000
ORDER BY TotalVariance DESC;  -- Result: 5 rows

-- Tutorial 10.1: every manufactured item with its closes of 2026
SELECT i.ItemCode, i.ItemName, i.LifecycleStatus,
    COUNT(woc.WorkOrderCloseID) AS Closes2026
FROM Item AS i
    LEFT JOIN WorkOrder AS wo ON wo.ItemID = i.ItemID
    LEFT JOIN WorkOrderClose AS woc ON woc.WorkOrderID = wo.WorkOrderID
        AND woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
WHERE i.SupplyMode = 'Manufactured'
GROUP BY i.ItemID, i.ItemCode, i.ItemName, i.LifecycleStatus
ORDER BY Closes2026, i.ItemCode;  -- Result: 88 rows
