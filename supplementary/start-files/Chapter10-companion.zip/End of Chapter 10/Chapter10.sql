/* Chapter 10: manufacturing variance, joined and summarized
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 10.3; dataset v2026.1
   Checks: 2026 closes equal the ledger; the trial balance nets to zero */

-- Tutorial 10.1: the closes joined to their work orders
SELECT woc.WorkOrderCloseID, woc.CloseDate, wo.WorkOrderNumber,
    wo.ItemID, woc.TotalVarianceAmount
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID;  -- Result: 12998 rows

-- Tutorial 10.1: the number of closes, to test the join
SELECT COUNT(*) AS Closes
FROM WorkOrderClose;  -- Result: 1 row (Closes = 12998)

-- Tutorial 10.1: the closes with their items
SELECT woc.WorkOrderCloseID, woc.CloseDate, i.ItemCode,
    i.ItemName, i.ItemGroup, woc.TotalVarianceAmount
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID;  -- Result: 12998 rows

-- Tutorial 10.1: the variance of fiscal 2026 by item group
SELECT i.ItemGroup, COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemGroup
ORDER BY TotalVariance DESC;  -- Result: 3 rows

-- Tutorial 10.1: the same variance in the ledger
SELECT ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS LedgerVariance
FROM GLEntry AS gl
WHERE gl.AccountID = 93 AND gl.FiscalYear = 2026
    AND gl.SourceDocumentType = 'WorkOrderClose';  -- Result: 1 row (LedgerVariance = 2265636.88)

-- Tutorial 10.1: the variance by item group and year
SELECT i.ItemGroup, SUBSTR(woc.CloseDate, 1, 4) AS CloseYear,
    COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance,
    ROUND(SUM(woc.OverheadVarianceAmount), 2) AS OverheadVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
GROUP BY i.ItemGroup, CloseYear
ORDER BY i.ItemGroup, CloseYear;  -- Result: 9 rows

-- Tutorial 10.1: items with more than $50,000 of variance in 2026
SELECT i.ItemID, i.ItemCode, i.ItemName, COUNT(*) AS Closes,
    ROUND(SUM(woc.TotalVarianceAmount), 2) AS TotalVariance
FROM WorkOrderClose AS woc
    INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
    INNER JOIN Item AS i ON i.ItemID = wo.ItemID
WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemID, i.ItemCode, i.ItemName
HAVING SUM(woc.TotalVarianceAmount) > 50000
ORDER BY TotalVariance DESC;  -- Result: 5 rows

-- Tutorial 10.1: every manufactured item with its closes of 2026
SELECT i.ItemCode, i.ItemName, i.LifecycleStatus,
    COUNT(woc.WorkOrderCloseID) AS Closes2026
FROM Item AS i
    LEFT JOIN WorkOrder AS wo ON wo.ItemID = i.ItemID
    LEFT JOIN WorkOrderClose AS woc ON woc.WorkOrderID = wo.WorkOrderID
        AND woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
WHERE i.SupplyMode = 'Manufactured'
GROUP BY i.ItemID, i.ItemCode, i.ItemName, i.LifecycleStatus
ORDER BY Closes2026, i.ItemCode;  -- Result: 88 rows

-- Tutorial 10.2: the closes and the ledger side by side
SELECT
    (SELECT ROUND(SUM(TotalVarianceAmount), 2)
     FROM WorkOrderClose
     WHERE CloseDate BETWEEN '2026-01-01' AND '2026-12-31') AS Closes,
    (SELECT ROUND(SUM(Debit) - SUM(Credit), 2)
     FROM GLEntry
     WHERE AccountID = 93 AND FiscalYear = 2026
         AND SourceDocumentType = 'WorkOrderClose') AS Ledger;  -- Result: 1 row (Closes = 2265636.88, Ledger = 2265636.88)

-- Tutorial 10.2: the pre-closing trial balance of fiscal 2026
SELECT a.AccountNumber, a.AccountName, a.AccountType,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.PostingDate <= '2026-12-31'
    AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
GROUP BY a.AccountID, a.AccountNumber, a.AccountName, a.AccountType
ORDER BY a.AccountNumber;  -- Result: 71 rows

-- Tutorial 10.2: the net of all the balances
SELECT COUNT(*) AS Accounts, ROUND(SUM(tb.Balance), 2) AS NetBalance
FROM (
    SELECT gl.AccountID,
        ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance
    FROM GLEntry AS gl
    WHERE gl.PostingDate <= '2026-12-31'
        AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
    GROUP BY gl.AccountID
) AS tb;  -- Result: 1 row (Accounts = 71, NetBalance = 0.0)

-- Tutorial 10.2: the total of the debit balances
SELECT COUNT(*) AS DebitAccounts,
    ROUND(SUM(tb.Balance), 2) AS DebitBalances
FROM (
    SELECT gl.AccountID,
        ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance
    FROM GLEntry AS gl
    WHERE gl.PostingDate <= '2026-12-31'
        AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
    GROUP BY gl.AccountID
) AS tb
WHERE tb.Balance > 0;  -- Result: 1 row (DebitAccounts = 46, DebitBalances = 67107722.36)

-- Tutorial 10.2: account 1090 by year and source
SELECT gl.FiscalYear, gl.SourceDocumentType,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
WHERE gl.AccountID = 92 AND gl.FiscalYear BETWEEN 2024 AND 2026
GROUP BY gl.FiscalYear, gl.SourceDocumentType
ORDER BY gl.FiscalYear, gl.SourceDocumentType;  -- Result: 12 rows

-- Tutorial 10.2: the labor and overhead parts by year
SELECT SUBSTR(CloseDate, 1, 4) AS CloseYear,
    ROUND(SUM(DirectLaborVarianceAmount), 2) AS LaborVariance,
    ROUND(SUM(OverheadVarianceAmount), 2) AS OverheadVariance,
    ROUND(SUM(ConversionVarianceAmount), 2) AS ConversionVariance
FROM WorkOrderClose
GROUP BY CloseYear
ORDER BY CloseYear;  -- Result: 3 rows

-- Tutorial 10.2: the journal entries posted to account 1090
SELECT gl.FiscalYear, je.EntryType,
    ROUND(SUM(gl.Debit), 2) AS Debits
FROM GLEntry AS gl
    INNER JOIN JournalEntry AS je
        ON gl.SourceDocumentType = 'JournalEntry'
        AND je.JournalEntryID = gl.SourceDocumentID
WHERE gl.AccountID = 92
GROUP BY gl.FiscalYear, je.EntryType
ORDER BY gl.FiscalYear, je.EntryType;  -- Result: 6 rows

-- Tutorial 10.3: the output and its standard hours by year
SELECT SUBSTR(pc.CompletionDate, 1, 4) AS CompletionYear,
    ROUND(SUM(pcl.QuantityCompleted), 0) AS UnitsCompleted,
    ROUND(SUM(pcl.QuantityCompleted
        * i.StandardLaborHoursPerUnit), 0) AS StandardHours
FROM ProductionCompletionLine AS pcl
    INNER JOIN ProductionCompletion AS pc
        ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
GROUP BY CompletionYear
ORDER BY CompletionYear;  -- Result: 3 rows

-- Tutorial 10.3: the hours and pay of the manufacturing payroll
SELECT pp.FiscalYear, prl.LineType,
    ROUND(SUM(prl.Hours), 0) AS Hours,
    ROUND(SUM(prl.Amount), 2) AS Amount
FROM PayrollRegisterLine AS prl
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollRegisterID = prl.PayrollRegisterID
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing'
    AND prl.LineType IN ('Regular Earnings', 'Overtime Earnings')
    AND pp.FiscalYear BETWEEN 2024 AND 2026
GROUP BY pp.FiscalYear, prl.LineType
ORDER BY pp.FiscalYear, prl.LineType;  -- Result: 6 rows

-- Tutorial 10.3: the registers and the people they paid
SELECT pp.FiscalYear, COUNT(*) AS Registers,
    COUNT(DISTINCT pr.EmployeeID) AS Employees
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing'
    AND pp.FiscalYear BETWEEN 2024 AND 2026
GROUP BY pp.FiscalYear;  -- Result: 3 rows

-- Tutorial 10.3: a profile of the labor time entries
SELECT COUNT(*) AS Entries,
    COUNT(WorkOrderOperationID) AS WithOperation,
    COUNT(DISTINCT EmployeeID) AS Employees,
    MIN(WorkDate) AS FirstWorkDate, MAX(WorkDate) AS LastWorkDate
FROM LaborTimeEntry;  -- Result: 1 rows

-- Tutorial 10.3: a profile of the production completions
SELECT COUNT(*) AS Completions,
    MIN(CompletionDate) AS FirstCompletionDate,
    MAX(CompletionDate) AS LastCompletionDate
FROM ProductionCompletion;  -- Result: 1 row (Completions = 17352, FirstCompletionDate = 2024-01-21, LastCompletionDate = 2026-12-31)

-- Tutorial 10.3: the pay periods at the end of the data
SELECT PeriodNumber, PeriodStartDate, PeriodEndDate, PayDate, Status
FROM PayrollPeriod
WHERE PeriodEndDate >= '2026-12-01'
ORDER BY PeriodStartDate;  -- Result: 3 rows

-- Tutorial 10.3: hours per standard hour, by labor type
SELECT h.WorkYear, h.LaborType, h.Hours, o.StandardHours,
    ROUND(h.Hours / o.StandardHours, 2) AS HoursPerStandardHour
FROM (
    SELECT SUBSTR(lt.WorkDate, 1, 4) AS WorkYear, lt.LaborType,
        ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 0) AS Hours
    FROM LaborTimeEntry AS lt
    WHERE lt.LaborType <> 'NonManufacturing'
    GROUP BY WorkYear, lt.LaborType
) AS h
    INNER JOIN (
        SELECT SUBSTR(pc.CompletionDate, 1, 4) AS WorkYear,
            ROUND(SUM(pcl.QuantityCompleted
                * i.StandardLaborHoursPerUnit), 0) AS StandardHours
        FROM ProductionCompletionLine AS pcl
            INNER JOIN ProductionCompletion AS pc
                ON pc.ProductionCompletionID = pcl.ProductionCompletionID
            INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
        WHERE pc.CompletionDate
            <= (SELECT MAX(WorkDate) FROM LaborTimeEntry)
        GROUP BY WorkYear
    ) AS o ON o.WorkYear = h.WorkYear
ORDER BY h.WorkYear, h.LaborType;  -- Result: 6 rows

-- Tutorial 10.3: labor time with no work order operation
SELECT lt.LaborType, COUNT(*) AS Entries,
    ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 0) AS Hours
FROM LaborTimeEntry AS lt
    LEFT JOIN WorkOrderOperation AS op
        ON op.WorkOrderOperationID = lt.WorkOrderOperationID
WHERE op.WorkOrderOperationID IS NULL
GROUP BY lt.LaborType
ORDER BY lt.LaborType;  -- Result: 3 rows
