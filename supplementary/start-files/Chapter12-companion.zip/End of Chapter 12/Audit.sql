/* Audit.sql: tests of the records behind the manufacturing variance
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 12.3; dataset v2026.1; reviewed by: name, date
   Checks: populations tie to the ledger; exceptions listed by test */

-- Tutorial 12.1, test L1: journal entries against the ledger
-- Population: all journal entries; expected: counts and totals agree
SELECT
    (SELECT COUNT(*) FROM JournalEntry) AS Entries,
    (SELECT ROUND(SUM(TotalAmount), 2) FROM JournalEntry) AS EntryTotal,
    (SELECT COUNT(DISTINCT SourceDocumentID) FROM GLEntry
        WHERE SourceDocumentType = 'JournalEntry') AS PostedEntries,
    (SELECT ROUND(SUM(Debit), 2) FROM GLEntry
        WHERE SourceDocumentType = 'JournalEntry') AS PostedDebits;  -- Result: 1 rows

-- Tutorial 12.1, test L2: manufacturing payroll against the ledger
-- Population: Manufacturing registers; expected: no difference
SELECT reg.FiscalYear, reg.RegisterCost, gl.LedgerCost,
    ROUND(reg.RegisterCost - gl.LedgerCost, 2) AS Difference
FROM (
    SELECT pp.FiscalYear,
        ROUND(SUM(pr.GrossPay + pr.EmployerPayrollTax
            + pr.EmployerBenefits), 2) AS RegisterCost
    FROM PayrollRegister AS pr
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY pp.FiscalYear
) AS reg
    INNER JOIN (
        SELECT gl.FiscalYear, ROUND(SUM(gl.Debit), 2) AS LedgerCost
        FROM GLEntry AS gl
            INNER JOIN CostCenter AS cc
                ON cc.CostCenterID = gl.CostCenterID
        WHERE gl.SourceDocumentType = 'PayrollSummary'
            AND cc.CostCenterName = 'Manufacturing'
        GROUP BY gl.FiscalYear
    ) AS gl ON gl.FiscalYear = reg.FiscalYear
ORDER BY reg.FiscalYear;  -- Result: 3 rows

-- Tutorial 12.1, test L3: postings and documents traced both ways
-- Population: four document types; expected: no rows
SELECT 'Posting with no payroll payment' AS Test,
    gl.GLEntryID AS RecordID, gl.PostingDate AS RecordDate,
    gl.Debit + gl.Credit AS Amount
FROM GLEntry AS gl
    LEFT JOIN PayrollPayment AS pp
        ON pp.PayrollPaymentID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'PayrollPayment'
    AND pp.PayrollPaymentID IS NULL
UNION ALL
SELECT 'Posting with no supplier payment', gl.GLEntryID,
    gl.PostingDate, gl.Debit + gl.Credit
FROM GLEntry AS gl
    LEFT JOIN DisbursementPayment AS dp
        ON dp.DisbursementID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'DisbursementPayment'
    AND dp.DisbursementID IS NULL
UNION ALL
SELECT 'Sales invoice never posted', si.SalesInvoiceID,
    si.InvoiceDate, si.GrandTotal
FROM SalesInvoice AS si
    LEFT JOIN GLEntry AS gl ON gl.SourceDocumentType = 'SalesInvoice'
        AND gl.SourceDocumentID = si.SalesInvoiceID
WHERE gl.GLEntryID IS NULL
UNION ALL
SELECT 'Supplier invoice never posted', pi.PurchaseInvoiceID,
    pi.InvoiceDate, pi.GrandTotal
FROM PurchaseInvoice AS pi
    LEFT JOIN GLEntry AS gl ON gl.SourceDocumentType = 'PurchaseInvoice'
        AND gl.SourceDocumentID = pi.PurchaseInvoiceID
WHERE gl.GLEntryID IS NULL;  -- Result: 6 rows

-- Tutorial 12.1, test L4: approved registers with no payment
-- Population: all payroll registers; expected: no rows
SELECT pr.PayrollRegisterID, e.JobTitle,
    ec.CostCenterName AS EmployeeCenter,
    rc.CostCenterName AS RegisterCenter, e.TerminationDate,
    pp.PayDate, pr.GrossPay, pr.NetPay, pr.Status
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    INNER JOIN CostCenter AS ec ON ec.CostCenterID = e.CostCenterID
    INNER JOIN CostCenter AS rc ON rc.CostCenterID = pr.CostCenterID
    LEFT JOIN PayrollPayment AS pay
        ON pay.PayrollRegisterID = pr.PayrollRegisterID
WHERE pay.PayrollPaymentID IS NULL;  -- Result: 3 rows

-- Tutorial 12.1, test L5: revenue posted in the year of delivery
-- Population: all sales invoices; expected: no rows
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
),
Classified AS (
    SELECT si.SubTotal,
        strftime('%Y', sh.DeliveryDate) AS DeliveryYear,
        CASE
            WHEN strftime('%Y', p.PostingDate)
                    <> strftime('%Y', sh.DeliveryDate)
                THEN 'Revenue posted in another year'
            WHEN si.InvoiceDate < sh.ShipmentDate
                THEN 'Invoice dated before shipment'
            ELSE 'In the year of delivery'
        END AS Finding
    FROM SalesInvoice AS si
        INNER JOIN Shipped AS sh
            ON sh.SalesInvoiceID = si.SalesInvoiceID
        INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
)
SELECT Finding, DeliveryYear, COUNT(*) AS Invoices,
    ROUND(SUM(SubTotal), 2) AS SubTotal
FROM Classified
WHERE Finding <> 'In the year of delivery'
GROUP BY Finding, DeliveryYear
ORDER BY Finding, DeliveryYear;  -- Result: 5 rows

-- Tutorial 12.1, test L6: shipments never invoiced
-- Population: all shipment lines; expected: no rows
SELECT s.ShipmentNumber, s.ShipmentDate, s.DeliveryDate,
    ROUND(sl.ExtendedStandardCost, 2) AS StandardCost,
    ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
        AS SalesValue
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL
ORDER BY s.ShipmentDate;  -- Result: 9 rows

-- Tutorial 12.1, test L7: pay periods that cross a year-end
-- Population: all pay periods; expected: every period processed
SELECT pp.PeriodNumber, pp.PeriodStartDate, pp.PeriodEndDate,
    pp.PayDate, pp.Status, COALESCE(reg.Registers, 0) AS Registers,
    reg.PayrollCost
FROM PayrollPeriod AS pp
    LEFT JOIN (
        SELECT PayrollPeriodID, COUNT(*) AS Registers,
            ROUND(SUM(GrossPay + EmployerPayrollTax
                + EmployerBenefits), 2) AS PayrollCost
        FROM PayrollRegister
        GROUP BY PayrollPeriodID
    ) AS reg ON reg.PayrollPeriodID = pp.PayrollPeriodID
WHERE strftime('%Y', pp.PeriodStartDate) <> strftime('%Y', pp.PayDate)
ORDER BY pp.PeriodStartDate;  -- Result: 6 rows

-- Tutorial 12.1, test L8: accrued payroll at the year-end
-- Population: account 2030 to 2026-12-31; expected: unpaid wages
SELECT gl.SourceDocumentType, COUNT(*) AS Postings,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 2030 AND gl.PostingDate <= '2026-12-31'
GROUP BY gl.SourceDocumentType;  -- Result: 3 rows

-- Tutorial 12.2, test P1: three-way match by purchase order line
-- Population: all PO lines; expected: no exception statuses
WITH Received AS (
    SELECT POLineID, SUM(QuantityReceived) AS QtyReceived
    FROM GoodsReceiptLine
    GROUP BY POLineID
),
Invoiced AS (
    SELECT POLineID, SUM(Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine
    WHERE POLineID IS NOT NULL
    GROUP BY POLineID
),
Matched AS (
    SELECT pol.POLineID, pol.Quantity AS QtyOrdered,
        COALESCE(r.QtyReceived, 0) AS QtyReceived,
        COALESCE(i.QtyInvoiced, 0) AS QtyInvoiced
    FROM PurchaseOrderLine AS pol
        LEFT JOIN Received AS r ON r.POLineID = pol.POLineID
        LEFT JOIN Invoiced AS i ON i.POLineID = pol.POLineID
)
SELECT
    CASE
        WHEN QtyInvoiced > QtyReceived + 0.0001
            THEN 'Exception: invoiced above received'
        WHEN QtyReceived > QtyOrdered + 0.0001
            THEN 'Exception: received above ordered'
        WHEN QtyReceived = 0 THEN 'Not yet received'
        WHEN QtyInvoiced < QtyReceived - 0.0001
            THEN 'Received, not fully invoiced'
        WHEN QtyReceived < QtyOrdered - 0.0001 THEN 'Partly received'
        ELSE 'Matched'
    END AS MatchStatus,
    COUNT(*) AS POLines
FROM Matched
GROUP BY MatchStatus
ORDER BY POLines DESC;  -- Result: 4 rows

-- Tutorial 12.2, test P2: invoice prices against order prices
-- Population: invoice lines with a PO line; expected: none above 3%
SELECT COUNT(*) AS InvoiceLines,
    SUM(CASE WHEN ABS(pil.UnitCost - pol.UnitCost) / pol.UnitCost
        > 0.03 THEN 1 ELSE 0 END) AS AboveThreePercent,
    SUM(CASE WHEN ABS(pil.UnitCost - pol.UnitCost) / pol.UnitCost
        > 0.02 THEN 1 ELSE 0 END) AS AboveTwoPercent,
    ROUND(MAX((pil.UnitCost - pol.UnitCost) / pol.UnitCost), 4)
        AS LargestIncrease,
    ROUND(MIN((pil.UnitCost - pol.UnitCost) / pol.UnitCost), 4)
        AS LargestDecrease
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseOrderLine AS pol ON pol.POLineID = pil.POLineID;  -- Result: 1 rows

-- Tutorial 12.2, test P3: receipts not invoiced against account 2020
-- Population: open receipt lines; expected: equal to the ledger
WITH InvoicedByReceipt AS (
    SELECT GoodsReceiptLineID, SUM(Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine
    GROUP BY GoodsReceiptLineID
)
SELECT
    (SELECT ROUND(SUM(grl.ExtendedStandardCost
        * (1 - COALESCE(ibr.QtyInvoiced, 0) / grl.QuantityReceived)), 2)
     FROM GoodsReceiptLine AS grl
        LEFT JOIN InvoicedByReceipt AS ibr
            ON ibr.GoodsReceiptLineID = grl.GoodsReceiptLineID
     WHERE COALESCE(ibr.QtyInvoiced, 0) < grl.QuantityReceived - 0.0001)
        AS NotInvoicedValue,
    (SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
     FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 2020 AND gl.PostingDate <= '2026-12-31')
        AS LedgerBalance;  -- Result: 1 row (NotInvoicedValue = 1020992.8, LedgerBalance = 1020992.06)

-- Tutorial 12.2, test P4: purchase order approvals
-- Population: all purchase orders; expected: no rows
WITH ApprovalExceptions AS (
    SELECT 'Self-approved' AS Test, po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
    WHERE po.CreatedByEmployeeID = po.ApprovedByEmployeeID
    UNION ALL
    SELECT 'Above approver limit', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE po.OrderTotal > e.MaxApprovalAmount
    UNION ALL
    SELECT 'Approved after termination', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE e.TerminationDate IS NOT NULL
        AND po.OrderDate > e.TerminationDate
)
SELECT Test, COUNT(*) AS Orders, ROUND(SUM(OrderTotal), 2) AS OrderValue
FROM ApprovalExceptions
GROUP BY Test
ORDER BY Orders DESC;  -- Result: 3 rows

-- Tutorial 12.2, test P5: the orders behind the approval exceptions
-- Population: the orders flagged by test P4
WITH ApprovalExceptions AS (
    SELECT 'Self-approved' AS Test, po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
    WHERE po.CreatedByEmployeeID = po.ApprovedByEmployeeID
    UNION ALL
    SELECT 'Above approver limit', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE po.OrderTotal > e.MaxApprovalAmount
    UNION ALL
    SELECT 'Approved after termination', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE e.TerminationDate IS NOT NULL
        AND po.OrderDate > e.TerminationDate
),
Flagged AS (
    SELECT PONumber, GROUP_CONCAT(Test, '; ') AS Tests
    FROM ApprovalExceptions
    GROUP BY PONumber
)
SELECT f.PONumber, po.OrderDate, po.OrderTotal,
    c.JobTitle AS CreatedBy, a.JobTitle AS ApprovedBy,
    a.MaxApprovalAmount, a.TerminationDate, f.Tests
FROM Flagged AS f
    INNER JOIN PurchaseOrder AS po ON po.PONumber = f.PONumber
    INNER JOIN Employee AS c ON c.EmployeeID = po.CreatedByEmployeeID
    INNER JOIN Employee AS a ON a.EmployeeID = po.ApprovedByEmployeeID
ORDER BY po.OrderTotal DESC;  -- Result: 14 rows

-- Tutorial 12.2, test P6: who approves the purchase orders
-- Population: all purchase orders; expected: approval shared
SELECT e.EmployeeID, e.JobTitle, COUNT(*) AS OrdersApproved
FROM PurchaseOrder AS po
    INNER JOIN Employee AS e ON e.EmployeeID = po.ApprovedByEmployeeID
GROUP BY e.EmployeeID, e.JobTitle
ORDER BY OrdersApproved DESC;  -- Result: 9 rows

-- Tutorial 12.3, test H1: a profile of the time clock entries
-- Population: all clock entries; expected: approved and complete
SELECT COUNT(*) AS Entries,
    SUM(CASE WHEN ClockStatus <> 'Approved' THEN 1 ELSE 0 END)
        AS NotApproved,
    COUNT(*) - COUNT(ClockOutTime) AS NoClockOut,
    COUNT(DISTINCT EmployeeID) AS Employees,
    MIN(WorkDate) AS FirstWorkDate, MAX(WorkDate) AS LastWorkDate
FROM TimeClockEntry;  -- Result: 1 rows

-- Tutorial 12.3, test H2: clocked, recorded, and paid hours
-- Population: every pay period; expected: equal in every period
WITH Clocked AS (
    SELECT PayrollPeriodID, SUM(RegularHours + OvertimeHours) AS Hours
    FROM TimeClockEntry
    GROUP BY PayrollPeriodID
),
Recorded AS (
    SELECT PayrollPeriodID, SUM(RegularHours + OvertimeHours) AS Hours
    FROM LaborTimeEntry
    GROUP BY PayrollPeriodID
),
Paid AS (
    SELECT pr.PayrollPeriodID, SUM(prl.Hours) AS Hours
    FROM PayrollRegisterLine AS prl
        INNER JOIN PayrollRegister AS pr
            ON pr.PayrollRegisterID = prl.PayrollRegisterID
    WHERE prl.LineType IN ('Regular Earnings', 'Overtime Earnings')
    GROUP BY pr.PayrollPeriodID
)
SELECT COUNT(*) AS Periods,
    SUM(CASE WHEN ABS(c.Hours - r.Hours) > 0.001
        OR ABS(r.Hours - p.Hours) > 0.001 THEN 1 ELSE 0 END)
        AS PeriodsThatDiffer,
    ROUND(SUM(c.Hours), 1) AS Clocked,
    ROUND(SUM(r.Hours), 1) AS Recorded,
    ROUND(SUM(p.Hours), 1) AS Paid
FROM Clocked AS c
    INNER JOIN Recorded AS r ON r.PayrollPeriodID = c.PayrollPeriodID
    INNER JOIN Paid AS p ON p.PayrollPeriodID = c.PayrollPeriodID;  -- Result: 1 rows

-- Tutorial 12.3, test H3: the manufacturing hours of 2024 by kind
-- Population: manufacturing labor time; expected: every period recorded
SELECT pp.PeriodNumber, pp.PeriodStartDate,
    ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 0) AS Hours,
    ROUND(SUM(CASE lt.LaborType WHEN 'Direct Manufacturing'
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 0)
        AS DirectHours,
    ROUND(SUM(CASE lt.LaborType WHEN 'Indirect Manufacturing'
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 0)
        AS IndirectHours
FROM LaborTimeEntry AS lt
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = lt.PayrollPeriodID
WHERE lt.LaborType <> 'NonManufacturing' AND pp.FiscalYear = 2024
GROUP BY pp.PayrollPeriodID, pp.PeriodNumber, pp.PeriodStartDate
ORDER BY pp.PeriodStartDate;  -- Result: 24 rows

-- Tutorial 12.3, test H4: time paid to another person or unapproved
-- Population: all earnings lines; expected: no rows
SELECT 'Time paid to another employee' AS Test,
    pr.EmployeeID AS PaidID, pe.JobTitle AS PaidTitle,
    lt.EmployeeID AS WorkedID, we.JobTitle AS WorkedTitle,
    we.TerminationDate AS WorkerLeft, prl.Amount
FROM PayrollRegisterLine AS prl
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollRegisterID = prl.PayrollRegisterID
    INNER JOIN LaborTimeEntry AS lt
        ON lt.LaborTimeEntryID = prl.LaborTimeEntryID
    INNER JOIN Employee AS pe ON pe.EmployeeID = pr.EmployeeID
    INNER JOIN Employee AS we ON we.EmployeeID = lt.EmployeeID
WHERE lt.EmployeeID <> pr.EmployeeID
UNION ALL
SELECT 'Time paid on an unapproved clock entry',
    pr.EmployeeID, pe.JobTitle, lt.EmployeeID, we.JobTitle,
    we.TerminationDate, prl.Amount
FROM PayrollRegisterLine AS prl
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollRegisterID = prl.PayrollRegisterID
    INNER JOIN LaborTimeEntry AS lt
        ON lt.LaborTimeEntryID = prl.LaborTimeEntryID
    INNER JOIN Employee AS pe ON pe.EmployeeID = pr.EmployeeID
    INNER JOIN Employee AS we ON we.EmployeeID = lt.EmployeeID
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = lt.TimeClockEntryID
WHERE tc.ClockStatus <> 'Approved';  -- Result: 14 rows

-- Tutorial 12.3, test H5: earnings paid against hours and pay rates
-- Population: hourly earnings lines; expected: within a cent a line
WITH Expected AS (
    SELECT pp.FiscalYear, prl.Amount,
        prl.Hours * e.BaseHourlyRate
            * CASE prl.LineType WHEN 'Overtime Earnings'
                THEN 1.5 ELSE 1 END AS ExpectedAmount
    FROM PayrollRegisterLine AS prl
        INNER JOIN PayrollRegister AS pr
            ON pr.PayrollRegisterID = prl.PayrollRegisterID
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    WHERE prl.LineType IN ('Regular Earnings', 'Overtime Earnings')
)
SELECT FiscalYear, ROUND(SUM(Amount), 2) AS EarningsPaid,
    ROUND(SUM(ExpectedAmount), 2) AS Expected,
    ROUND(SUM(Amount) - SUM(ExpectedAmount), 2) AS Difference,
    SUM(CASE WHEN ABS(Amount - ExpectedAmount) > 0.01 THEN 1 ELSE 0 END)
        AS LinesAboveOneCent
FROM Expected
GROUP BY FiscalYear
ORDER BY FiscalYear;  -- Result: 3 rows

-- Tutorial 12.3, test H6: overtime and its approvals
-- Population: clock entries with overtime; expected: approved
SELECT
    CASE WHEN OvertimeHours <= 0.5 THEN 'Half an hour or less'
        ELSE 'More than half an hour' END AS OvertimeLength,
    COUNT(*) AS Entries,
    SUM(CASE WHEN OvertimeApprovalID IS NULL THEN 1 ELSE 0 END)
        AS WithoutApproval,
    ROUND(SUM(OvertimeHours), 1) AS OvertimeHours
FROM TimeClockEntry
WHERE OvertimeHours > 0
GROUP BY OvertimeLength;  -- Result: 2 rows

-- Tutorial 12.3, test H7: long overtime without an approval
-- Population: overtime above half an hour; expected: no rows
SELECT e.JobTitle, e.TerminationDate, tc.WorkDate,
    tc.OvertimeHours, tc.ClockOutTime, tc.ClockStatus,
    oa.OvertimeApprovalID AS UnlinkedApproval,
    ap.JobTitle AS ApprovedBy
FROM TimeClockEntry AS tc
    INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
    LEFT JOIN OvertimeApproval AS oa
        ON oa.EmployeeID = tc.EmployeeID AND oa.WorkDate = tc.WorkDate
    LEFT JOIN Employee AS ap ON ap.EmployeeID = oa.ApprovedByEmployeeID
WHERE tc.OvertimeHours > 0.5 AND tc.OvertimeApprovalID IS NULL;  -- Result: 3 rows

-- Tutorial 12.3, test H8: days when everyone clocked the same hours
-- Population: manufacturing clock entries; expected: no such days
WITH PlantDays AS (
    SELECT tc.WorkDate, COUNT(*) AS Employees,
        COUNT(DISTINCT tc.RegularHours + tc.OvertimeHours)
            AS HourPatterns,
        SUM(tc.OvertimeHours) AS OvertimeHours
    FROM TimeClockEntry AS tc
        INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY tc.WorkDate
)
SELECT strftime('%Y', WorkDate) AS WorkYear,
    SUM(CASE WHEN HourPatterns = 1 AND Employees > 1
        THEN 1 ELSE 0 END) AS SurgeDays,
    MAX(CASE WHEN HourPatterns = 1 AND Employees > 1
        THEN Employees END) AS EmployeesPerDay,
    ROUND(SUM(CASE WHEN HourPatterns = 1 AND Employees > 1
        THEN OvertimeHours ELSE 0 END), 0) AS SurgeOvertime,
    ROUND(SUM(CASE WHEN HourPatterns = 1 AND Employees > 1
        THEN OvertimeHours ELSE 0 END) / SUM(OvertimeHours), 3)
        AS SurgeShare
FROM PlantDays
GROUP BY WorkYear
ORDER BY WorkYear;  -- Result: 3 rows

-- Tutorial 12.3, test H9: direct time recorded after its operation
-- Population: direct labor time; expected: a small share
WITH SurgeDays AS (
    SELECT tc.WorkDate
    FROM TimeClockEntry AS tc
        INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY tc.WorkDate
    HAVING COUNT(DISTINCT tc.RegularHours + tc.OvertimeHours) = 1
        AND COUNT(*) > 1
)
SELECT strftime('%Y', lt.WorkDate) AS WorkYear,
    ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 0) AS DirectHours,
    ROUND(SUM(CASE WHEN lt.WorkDate > op.ActualEndDate
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 0)
        AS AfterEnd,
    ROUND(SUM(CASE WHEN lt.WorkDate > op.ActualEndDate
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END)
        / SUM(lt.RegularHours + lt.OvertimeHours), 3) AS ShareAfterEnd,
    ROUND(SUM(CASE WHEN lt.WorkDate > op.ActualEndDate
        AND sd.WorkDate IS NOT NULL
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 0)
        AS AfterEndOnSurgeDays
FROM LaborTimeEntry AS lt
    INNER JOIN WorkOrderOperation AS op
        ON op.WorkOrderOperationID = lt.WorkOrderOperationID
    LEFT JOIN SurgeDays AS sd ON sd.WorkDate = lt.WorkDate
WHERE lt.LaborType = 'Direct Manufacturing'
GROUP BY WorkYear
ORDER BY WorkYear;  -- Result: 3 rows

-- Tutorial 12.3, test H10: late direct time by work center, 2026
-- Population: direct labor time of 2026; expected: a small share
SELECT wc.WorkCenterName,
    ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 0) AS DirectHours,
    ROUND(SUM(CASE WHEN lt.WorkDate > op.ActualEndDate
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END)
        / SUM(lt.RegularHours + lt.OvertimeHours), 3) AS ShareAfterEnd
FROM LaborTimeEntry AS lt
    INNER JOIN WorkOrderOperation AS op
        ON op.WorkOrderOperationID = lt.WorkOrderOperationID
    INNER JOIN WorkCenter AS wc ON wc.WorkCenterID = op.WorkCenterID
WHERE lt.LaborType = 'Direct Manufacturing'
    AND lt.WorkDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY wc.WorkCenterID, wc.WorkCenterName
ORDER BY ShareAfterEnd DESC;  -- Result: 5 rows
