/* Audit.sql: tests of the records behind the manufacturing variance
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 12.2; dataset v2026.1; reviewed by: name, date
   Checks: populations tie to the ledger; exceptions listed by test */

-- Tutorial 12.1, test L1: journal entries against the ledger
-- Population: all journal entries; expected: counts and totals agree
SELECT
    (SELECT COUNT(*) FROM JournalEntry) AS Entries,
    (SELECT ROUND(SUM(TotalAmount), 2) FROM JournalEntry) AS EntryTotal,
    (SELECT COUNT(DISTINCT SourceDocumentID) FROM GLEntry
        WHERE SourceDocumentType = 'JournalEntry') AS PostedEntries,
    (SELECT ROUND(SUM(Debit), 2) FROM GLEntry
        WHERE SourceDocumentType = 'JournalEntry') AS PostedDebits;  -- Result: 1 rows

-- Tutorial 12.1, test L2: manufacturing payroll against the ledger
-- Population: Manufacturing registers; expected: no difference
SELECT reg.FiscalYear, reg.RegisterCost, gl.LedgerCost,
    ROUND(reg.RegisterCost - gl.LedgerCost, 2) AS Difference
FROM (
    SELECT pp.FiscalYear,
        ROUND(SUM(pr.GrossPay + pr.EmployerPayrollTax
            + pr.EmployerBenefits), 2) AS RegisterCost
    FROM PayrollRegister AS pr
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY pp.FiscalYear
) AS reg
    INNER JOIN (
        SELECT gl.FiscalYear, ROUND(SUM(gl.Debit), 2) AS LedgerCost
        FROM GLEntry AS gl
            INNER JOIN CostCenter AS cc
                ON cc.CostCenterID = gl.CostCenterID
        WHERE gl.SourceDocumentType = 'PayrollSummary'
            AND cc.CostCenterName = 'Manufacturing'
        GROUP BY gl.FiscalYear
    ) AS gl ON gl.FiscalYear = reg.FiscalYear
ORDER BY reg.FiscalYear;  -- Result: 3 rows

-- Tutorial 12.1, test L3: postings and documents traced both ways
-- Population: four document types; expected: no rows
SELECT 'Posting with no payroll payment' AS Test,
    gl.GLEntryID AS RecordID, gl.PostingDate AS RecordDate,
    gl.Debit + gl.Credit AS Amount
FROM GLEntry AS gl
    LEFT JOIN PayrollPayment AS pp
        ON pp.PayrollPaymentID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'PayrollPayment'
    AND pp.PayrollPaymentID IS NULL
UNION ALL
SELECT 'Posting with no supplier payment', gl.GLEntryID,
    gl.PostingDate, gl.Debit + gl.Credit
FROM GLEntry AS gl
    LEFT JOIN DisbursementPayment AS dp
        ON dp.DisbursementID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'DisbursementPayment'
    AND dp.DisbursementID IS NULL
UNION ALL
SELECT 'Sales invoice never posted', si.SalesInvoiceID,
    si.InvoiceDate, si.GrandTotal
FROM SalesInvoice AS si
    LEFT JOIN GLEntry AS gl ON gl.SourceDocumentType = 'SalesInvoice'
        AND gl.SourceDocumentID = si.SalesInvoiceID
WHERE gl.GLEntryID IS NULL
UNION ALL
SELECT 'Supplier invoice never posted', pi.PurchaseInvoiceID,
    pi.InvoiceDate, pi.GrandTotal
FROM PurchaseInvoice AS pi
    LEFT JOIN GLEntry AS gl ON gl.SourceDocumentType = 'PurchaseInvoice'
        AND gl.SourceDocumentID = pi.PurchaseInvoiceID
WHERE gl.GLEntryID IS NULL;  -- Result: 6 rows

-- Tutorial 12.1, test L4: approved registers with no payment
-- Population: all payroll registers; expected: no rows
SELECT pr.PayrollRegisterID, e.JobTitle,
    ec.CostCenterName AS EmployeeCenter,
    rc.CostCenterName AS RegisterCenter, e.TerminationDate,
    pp.PayDate, pr.GrossPay, pr.NetPay, pr.Status
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    INNER JOIN CostCenter AS ec ON ec.CostCenterID = e.CostCenterID
    INNER JOIN CostCenter AS rc ON rc.CostCenterID = pr.CostCenterID
    LEFT JOIN PayrollPayment AS pay
        ON pay.PayrollRegisterID = pr.PayrollRegisterID
WHERE pay.PayrollPaymentID IS NULL;  -- Result: 3 rows

-- Tutorial 12.1, test L5: revenue posted in the year of delivery
-- Population: all sales invoices; expected: no rows
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
),
Classified AS (
    SELECT si.SubTotal,
        strftime('%Y', sh.DeliveryDate) AS DeliveryYear,
        CASE
            WHEN strftime('%Y', p.PostingDate)
                    <> strftime('%Y', sh.DeliveryDate)
                THEN 'Revenue posted in another year'
            WHEN si.InvoiceDate < sh.ShipmentDate
                THEN 'Invoice dated before shipment'
            ELSE 'In the year of delivery'
        END AS Finding
    FROM SalesInvoice AS si
        INNER JOIN Shipped AS sh
            ON sh.SalesInvoiceID = si.SalesInvoiceID
        INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
)
SELECT Finding, DeliveryYear, COUNT(*) AS Invoices,
    ROUND(SUM(SubTotal), 2) AS SubTotal
FROM Classified
WHERE Finding <> 'In the year of delivery'
GROUP BY Finding, DeliveryYear
ORDER BY Finding, DeliveryYear;  -- Result: 5 rows

-- Tutorial 12.1, test L6: shipments never invoiced
-- Population: all shipment lines; expected: no rows
SELECT s.ShipmentNumber, s.ShipmentDate, s.DeliveryDate,
    ROUND(sl.ExtendedStandardCost, 2) AS StandardCost,
    ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
        AS SalesValue
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL
ORDER BY s.ShipmentDate;  -- Result: 9 rows

-- Tutorial 12.1, test L7: pay periods that cross a year-end
-- Population: all pay periods; expected: every period processed
SELECT pp.PeriodNumber, pp.PeriodStartDate, pp.PeriodEndDate,
    pp.PayDate, pp.Status, COALESCE(reg.Registers, 0) AS Registers,
    reg.PayrollCost
FROM PayrollPeriod AS pp
    LEFT JOIN (
        SELECT PayrollPeriodID, COUNT(*) AS Registers,
            ROUND(SUM(GrossPay + EmployerPayrollTax
                + EmployerBenefits), 2) AS PayrollCost
        FROM PayrollRegister
        GROUP BY PayrollPeriodID
    ) AS reg ON reg.PayrollPeriodID = pp.PayrollPeriodID
WHERE strftime('%Y', pp.PeriodStartDate) <> strftime('%Y', pp.PayDate)
ORDER BY pp.PeriodStartDate;  -- Result: 6 rows

-- Tutorial 12.1, test L8: accrued payroll at the year-end
-- Population: account 2030 to 2026-12-31; expected: unpaid wages
SELECT gl.SourceDocumentType, COUNT(*) AS Postings,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 2030 AND gl.PostingDate <= '2026-12-31'
GROUP BY gl.SourceDocumentType;  -- Result: 3 rows

-- Tutorial 12.2, test P1: three-way match by purchase order line
-- Population: all PO lines; expected: no exception statuses
WITH Received AS (
    SELECT POLineID, SUM(QuantityReceived) AS QtyReceived
    FROM GoodsReceiptLine
    GROUP BY POLineID
),
Invoiced AS (
    SELECT POLineID, SUM(Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine
    WHERE POLineID IS NOT NULL
    GROUP BY POLineID
),
Matched AS (
    SELECT pol.POLineID, pol.Quantity AS QtyOrdered,
        COALESCE(r.QtyReceived, 0) AS QtyReceived,
        COALESCE(i.QtyInvoiced, 0) AS QtyInvoiced
    FROM PurchaseOrderLine AS pol
        LEFT JOIN Received AS r ON r.POLineID = pol.POLineID
        LEFT JOIN Invoiced AS i ON i.POLineID = pol.POLineID
)
SELECT
    CASE
        WHEN QtyInvoiced > QtyReceived + 0.0001
            THEN 'Exception: invoiced above received'
        WHEN QtyReceived > QtyOrdered + 0.0001
            THEN 'Exception: received above ordered'
        WHEN QtyReceived = 0 THEN 'Not yet received'
        WHEN QtyInvoiced < QtyReceived - 0.0001
            THEN 'Received, not fully invoiced'
        WHEN QtyReceived < QtyOrdered - 0.0001 THEN 'Partly received'
        ELSE 'Matched'
    END AS MatchStatus,
    COUNT(*) AS POLines
FROM Matched
GROUP BY MatchStatus
ORDER BY POLines DESC;  -- Result: 4 rows

-- Tutorial 12.2, test P2: invoice prices against order prices
-- Population: invoice lines with a PO line; expected: none above 3%
SELECT COUNT(*) AS InvoiceLines,
    SUM(CASE WHEN ABS(pil.UnitCost - pol.UnitCost) / pol.UnitCost
        > 0.03 THEN 1 ELSE 0 END) AS AboveThreePercent,
    SUM(CASE WHEN ABS(pil.UnitCost - pol.UnitCost) / pol.UnitCost
        > 0.02 THEN 1 ELSE 0 END) AS AboveTwoPercent,
    ROUND(MAX((pil.UnitCost - pol.UnitCost) / pol.UnitCost), 4)
        AS LargestIncrease,
    ROUND(MIN((pil.UnitCost - pol.UnitCost) / pol.UnitCost), 4)
        AS LargestDecrease
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseOrderLine AS pol ON pol.POLineID = pil.POLineID;  -- Result: 1 rows

-- Tutorial 12.2, test P3: receipts not invoiced against account 2020
-- Population: open receipt lines; expected: equal to the ledger
WITH InvoicedByReceipt AS (
    SELECT GoodsReceiptLineID, SUM(Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine
    GROUP BY GoodsReceiptLineID
)
SELECT
    (SELECT ROUND(SUM(grl.ExtendedStandardCost
        * (1 - COALESCE(ibr.QtyInvoiced, 0) / grl.QuantityReceived)), 2)
     FROM GoodsReceiptLine AS grl
        LEFT JOIN InvoicedByReceipt AS ibr
            ON ibr.GoodsReceiptLineID = grl.GoodsReceiptLineID
     WHERE COALESCE(ibr.QtyInvoiced, 0) < grl.QuantityReceived - 0.0001)
        AS NotInvoicedValue,
    (SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
     FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 2020 AND gl.PostingDate <= '2026-12-31')
        AS LedgerBalance;  -- Result: 1 row (NotInvoicedValue = 1020992.8, LedgerBalance = 1020992.06)

-- Tutorial 12.2, test P4: purchase order approvals
-- Population: all purchase orders; expected: no rows
WITH ApprovalExceptions AS (
    SELECT 'Self-approved' AS Test, po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
    WHERE po.CreatedByEmployeeID = po.ApprovedByEmployeeID
    UNION ALL
    SELECT 'Above approver limit', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE po.OrderTotal > e.MaxApprovalAmount
    UNION ALL
    SELECT 'Approved after termination', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE e.TerminationDate IS NOT NULL
        AND po.OrderDate > e.TerminationDate
)
SELECT Test, COUNT(*) AS Orders, ROUND(SUM(OrderTotal), 2) AS OrderValue
FROM ApprovalExceptions
GROUP BY Test
ORDER BY Orders DESC;  -- Result: 3 rows

-- Tutorial 12.2, test P5: the orders behind the approval exceptions
-- Population: the orders flagged by test P4
WITH ApprovalExceptions AS (
    SELECT 'Self-approved' AS Test, po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
    WHERE po.CreatedByEmployeeID = po.ApprovedByEmployeeID
    UNION ALL
    SELECT 'Above approver limit', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE po.OrderTotal > e.MaxApprovalAmount
    UNION ALL
    SELECT 'Approved after termination', po.PONumber, po.OrderTotal
    FROM PurchaseOrder AS po
        INNER JOIN Employee AS e
            ON e.EmployeeID = po.ApprovedByEmployeeID
    WHERE e.TerminationDate IS NOT NULL
        AND po.OrderDate > e.TerminationDate
),
Flagged AS (
    SELECT PONumber, GROUP_CONCAT(Test, '; ') AS Tests
    FROM ApprovalExceptions
    GROUP BY PONumber
)
SELECT f.PONumber, po.OrderDate, po.OrderTotal,
    c.JobTitle AS CreatedBy, a.JobTitle AS ApprovedBy,
    a.MaxApprovalAmount, a.TerminationDate, f.Tests
FROM Flagged AS f
    INNER JOIN PurchaseOrder AS po ON po.PONumber = f.PONumber
    INNER JOIN Employee AS c ON c.EmployeeID = po.CreatedByEmployeeID
    INNER JOIN Employee AS a ON a.EmployeeID = po.ApprovedByEmployeeID
ORDER BY po.OrderTotal DESC;  -- Result: 14 rows

-- Tutorial 12.2, test P6: who approves the purchase orders
-- Population: all purchase orders; expected: approval shared
SELECT e.EmployeeID, e.JobTitle, COUNT(*) AS OrdersApproved
FROM PurchaseOrder AS po
    INNER JOIN Employee AS e ON e.EmployeeID = po.ApprovedByEmployeeID
GROUP BY e.EmployeeID, e.JobTitle
ORDER BY OrdersApproved DESC;  -- Result: 9 rows
