/* Audit.sql: tests of the records behind the manufacturing variance
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 12.1; dataset v2026.1; reviewed by: name, date
   Checks: populations tie to the ledger; exceptions listed by test */

-- Tutorial 12.1, test L1: journal entries against the ledger
-- Population: all journal entries; expected: counts and totals agree
SELECT
    (SELECT COUNT(*) FROM JournalEntry) AS Entries,
    (SELECT ROUND(SUM(TotalAmount), 2) FROM JournalEntry) AS EntryTotal,
    (SELECT COUNT(DISTINCT SourceDocumentID) FROM GLEntry
        WHERE SourceDocumentType = 'JournalEntry') AS PostedEntries,
    (SELECT ROUND(SUM(Debit), 2) FROM GLEntry
        WHERE SourceDocumentType = 'JournalEntry') AS PostedDebits;  -- Result: 1 rows

-- Tutorial 12.1, test L2: manufacturing payroll against the ledger
-- Population: Manufacturing registers; expected: no difference
SELECT reg.FiscalYear, reg.RegisterCost, gl.LedgerCost,
    ROUND(reg.RegisterCost - gl.LedgerCost, 2) AS Difference
FROM (
    SELECT pp.FiscalYear,
        ROUND(SUM(pr.GrossPay + pr.EmployerPayrollTax
            + pr.EmployerBenefits), 2) AS RegisterCost
    FROM PayrollRegister AS pr
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY pp.FiscalYear
) AS reg
    INNER JOIN (
        SELECT gl.FiscalYear, ROUND(SUM(gl.Debit), 2) AS LedgerCost
        FROM GLEntry AS gl
            INNER JOIN CostCenter AS cc
                ON cc.CostCenterID = gl.CostCenterID
        WHERE gl.SourceDocumentType = 'PayrollSummary'
            AND cc.CostCenterName = 'Manufacturing'
        GROUP BY gl.FiscalYear
    ) AS gl ON gl.FiscalYear = reg.FiscalYear
ORDER BY reg.FiscalYear;  -- Result: 3 rows

-- Tutorial 12.1, test L3: postings and documents traced both ways
-- Population: four document types; expected: no rows
SELECT 'Posting with no payroll payment' AS Test,
    gl.GLEntryID AS RecordID, gl.PostingDate AS RecordDate,
    gl.Debit + gl.Credit AS Amount
FROM GLEntry AS gl
    LEFT JOIN PayrollPayment AS pp
        ON pp.PayrollPaymentID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'PayrollPayment'
    AND pp.PayrollPaymentID IS NULL
UNION ALL
SELECT 'Posting with no supplier payment', gl.GLEntryID,
    gl.PostingDate, gl.Debit + gl.Credit
FROM GLEntry AS gl
    LEFT JOIN DisbursementPayment AS dp
        ON dp.DisbursementID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'DisbursementPayment'
    AND dp.DisbursementID IS NULL
UNION ALL
SELECT 'Sales invoice never posted', si.SalesInvoiceID,
    si.InvoiceDate, si.GrandTotal
FROM SalesInvoice AS si
    LEFT JOIN GLEntry AS gl ON gl.SourceDocumentType = 'SalesInvoice'
        AND gl.SourceDocumentID = si.SalesInvoiceID
WHERE gl.GLEntryID IS NULL
UNION ALL
SELECT 'Supplier invoice never posted', pi.PurchaseInvoiceID,
    pi.InvoiceDate, pi.GrandTotal
FROM PurchaseInvoice AS pi
    LEFT JOIN GLEntry AS gl ON gl.SourceDocumentType = 'PurchaseInvoice'
        AND gl.SourceDocumentID = pi.PurchaseInvoiceID
WHERE gl.GLEntryID IS NULL;  -- Result: 6 rows

-- Tutorial 12.1, test L4: approved registers with no payment
-- Population: all payroll registers; expected: no rows
SELECT pr.PayrollRegisterID, e.JobTitle,
    ec.CostCenterName AS EmployeeCenter,
    rc.CostCenterName AS RegisterCenter, e.TerminationDate,
    pp.PayDate, pr.GrossPay, pr.NetPay, pr.Status
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    INNER JOIN CostCenter AS ec ON ec.CostCenterID = e.CostCenterID
    INNER JOIN CostCenter AS rc ON rc.CostCenterID = pr.CostCenterID
    LEFT JOIN PayrollPayment AS pay
        ON pay.PayrollRegisterID = pr.PayrollRegisterID
WHERE pay.PayrollPaymentID IS NULL;  -- Result: 3 rows

-- Tutorial 12.1, test L5: revenue posted in the year of delivery
-- Population: all sales invoices; expected: no rows
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
),
Classified AS (
    SELECT si.SubTotal,
        strftime('%Y', sh.DeliveryDate) AS DeliveryYear,
        CASE
            WHEN strftime('%Y', p.PostingDate)
                    <> strftime('%Y', sh.DeliveryDate)
                THEN 'Revenue posted in another year'
            WHEN si.InvoiceDate < sh.ShipmentDate
                THEN 'Invoice dated before shipment'
            ELSE 'In the year of delivery'
        END AS Finding
    FROM SalesInvoice AS si
        INNER JOIN Shipped AS sh
            ON sh.SalesInvoiceID = si.SalesInvoiceID
        INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
)
SELECT Finding, DeliveryYear, COUNT(*) AS Invoices,
    ROUND(SUM(SubTotal), 2) AS SubTotal
FROM Classified
WHERE Finding <> 'In the year of delivery'
GROUP BY Finding, DeliveryYear
ORDER BY Finding, DeliveryYear;  -- Result: 5 rows

-- Tutorial 12.1, test L6: shipments never invoiced
-- Population: all shipment lines; expected: no rows
SELECT s.ShipmentNumber, s.ShipmentDate, s.DeliveryDate,
    ROUND(sl.ExtendedStandardCost, 2) AS StandardCost,
    ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
        AS SalesValue
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL
ORDER BY s.ShipmentDate;  -- Result: 9 rows

-- Tutorial 12.1, test L7: pay periods that cross a year-end
-- Population: all pay periods; expected: every period processed
SELECT pp.PeriodNumber, pp.PeriodStartDate, pp.PeriodEndDate,
    pp.PayDate, pp.Status, COALESCE(reg.Registers, 0) AS Registers,
    reg.PayrollCost
FROM PayrollPeriod AS pp
    LEFT JOIN (
        SELECT PayrollPeriodID, COUNT(*) AS Registers,
            ROUND(SUM(GrossPay + EmployerPayrollTax
                + EmployerBenefits), 2) AS PayrollCost
        FROM PayrollRegister
        GROUP BY PayrollPeriodID
    ) AS reg ON reg.PayrollPeriodID = pp.PayrollPeriodID
WHERE strftime('%Y', pp.PeriodStartDate) <> strftime('%Y', pp.PayDate)
ORDER BY pp.PeriodStartDate;  -- Result: 6 rows

-- Tutorial 12.1, test L8: accrued payroll at the year-end
-- Population: account 2030 to 2026-12-31; expected: unpaid wages
SELECT gl.SourceDocumentType, COUNT(*) AS Postings,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 2030 AND gl.PostingDate <= '2026-12-31'
GROUP BY gl.SourceDocumentType;  -- Result: 3 rows
