Accounting Analytics: An Integrated Approach (2026 edition)
Companion files for Chapter 8: AuditAnalytics.xlsx

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.xlsx SHA-256 185d42bd069fad177fae23c5e30df93edc7cf2669f687236c8a9f29435388e09

End of Chapter 8/AuditAnalytics.xlsx
Start of Tutorial 8.2/AuditAnalytics.xlsx
Start of Tutorial 8.3/AuditAnalytics.xlsx

How to use a start file:
1. Copy the workbook from the folder of your tutorial into a folder of your own.
2. Its queries read C:\CharlesRiver\CharlesRiver.xlsx. Put your copy of CharlesRiver.xlsx there, or open the workbook
   and point the queries at your copy: Data > Get Data > Data Source Settings > Change Source.
3. Choose Data > Refresh All. The Solution Notes worksheet then checks every control total.
4. Continue with the tutorial.

More: https://aa.accountinganalyticshub.com/front-matter/companion-files.html
