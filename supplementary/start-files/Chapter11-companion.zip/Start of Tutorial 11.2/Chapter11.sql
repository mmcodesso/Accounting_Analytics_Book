/* Chapter 11: the plant's hours, month by month
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 11.1; dataset v2026.1
   Checks: the payroll ties to the ledger; the measure has 36 months */

-- Tutorial 11.1: the manufacturing payroll of 2026 by category
SELECT
    CASE
        WHEN prl.LineType IN ('Regular Earnings', 'Overtime Earnings')
            THEN 'Hourly pay'
        WHEN prl.LineType = 'Salary Earnings' THEN 'Salaries'
        WHEN prl.LineType IN ('Employer Payroll Tax', 'Employer Benefits')
            THEN 'Employer taxes and benefits'
        ELSE 'Employee deductions'
    END AS Category,
    ROUND(SUM(prl.Amount), 2) AS Amount
FROM PayrollRegisterLine AS prl
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollRegisterID = prl.PayrollRegisterID
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing' AND pp.FiscalYear = 2026
GROUP BY Category
ORDER BY Amount DESC;  -- Result: 4 rows

-- Tutorial 11.1: the payroll charged to account 1090 in 2026
SELECT ROUND(SUM(Debit), 2) AS PayrollCharged
FROM GLEntry
WHERE AccountID = 92 AND FiscalYear = 2026
    AND SourceDocumentType = 'PayrollSummary';  -- Result: 1 row (PayrollCharged = 3815397.14)

-- Tutorial 11.1: manufacturing labor time by month
SELECT strftime('%Y-%m', lt.WorkDate) AS WorkMonth,
    COUNT(DISTINCT lt.WorkDate) AS DaysWithTime,
    ROUND(SUM(CASE lt.LaborType WHEN 'Direct Manufacturing'
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 0)
        AS DirectHours,
    ROUND(SUM(CASE lt.LaborType WHEN 'Indirect Manufacturing'
        THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 0)
        AS IndirectHours,
    ROUND(SUM(lt.OvertimeHours), 0) AS OvertimeHours
FROM LaborTimeEntry AS lt
WHERE lt.LaborType <> 'NonManufacturing'
GROUP BY WorkMonth
ORDER BY WorkMonth;  -- Result: 36 rows

-- Tutorial 11.1: how far the time records fall short of month-end
SELECT MAX(WorkDate) AS LastWorkDate,
    date(MAX(WorkDate), 'start of month', '+1 month', '-1 day')
        AS MonthEnd,
    julianday(date(MAX(WorkDate), 'start of month', '+1 month',
        '-1 day')) - julianday(MAX(WorkDate)) AS DaysNotRecorded
FROM LaborTimeEntry;  -- Result: 1 row (LastWorkDate = 2026-12-11, MonthEnd = 2026-12-31, DaysNotRecorded = 20.0)

-- Tutorial 11.1: the overtime share of each kind of labor by month
SELECT strftime('%Y-%m', lt.WorkDate) AS WorkMonth,
    ROUND(SUM(CASE lt.LaborType WHEN 'Direct Manufacturing'
            THEN lt.OvertimeHours ELSE 0 END)
        / SUM(CASE lt.LaborType WHEN 'Direct Manufacturing'
            THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 3)
        AS DirectOvertimeShare,
    ROUND(SUM(CASE lt.LaborType WHEN 'Indirect Manufacturing'
            THEN lt.OvertimeHours ELSE 0 END)
        / SUM(CASE lt.LaborType WHEN 'Indirect Manufacturing'
            THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END), 3)
        AS IndirectOvertimeShare
FROM LaborTimeEntry AS lt
WHERE lt.LaborType <> 'NonManufacturing'
GROUP BY WorkMonth
ORDER BY WorkMonth;  -- Result: 36 rows

-- Tutorial 11.1: days from release to completion and to close
SELECT strftime('%Y', ClosedDate) AS CloseYear,
    COUNT(*) AS WorkOrders,
    ROUND(AVG(julianday(CompletedDate) - julianday(ReleasedDate)), 1)
        AS DaysReleaseToComplete,
    ROUND(AVG(julianday(ClosedDate) - julianday(CompletedDate)), 1)
        AS DaysCompleteToClose
FROM WorkOrder
WHERE ClosedDate IS NOT NULL
GROUP BY CloseYear
ORDER BY CloseYear;  -- Result: 3 rows
