/* Chapter 9: manufacturing variance, first look
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 9.1; dataset v2026.1
   Checks: every close adds up; the 2026 postings exclude JE-2026-000296 */

-- Tutorial 9.1: every column of the chart of accounts
SELECT *
FROM Account;  -- Result: 104 rows

-- Tutorial 9.1: the columns that identify each account
SELECT AccountID, AccountNumber, AccountName,
    AccountType, AccountSubType
FROM Account;  -- Result: 104 rows

-- Tutorial 9.1: the parts of each variance and their check
SELECT WorkOrderCloseID, CloseDate,
    MaterialVarianceAmount AS Material,
    ConversionVarianceAmount AS Conversion,
    TotalVarianceAmount AS Total,
    ROUND(MaterialVarianceAmount + ConversionVarianceAmount
        - TotalVarianceAmount, 2) AS CheckDifference
FROM WorkOrderClose;  -- Result: 12998 rows
