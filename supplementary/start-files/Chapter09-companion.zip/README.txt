Accounting Analytics: An Integrated Approach (2026 edition)
Companion files for Chapter 9: Chapter09.sql

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.sqlite SHA-256 de861968e07412d71032b6ed6a0fb8eb9825cf6911886b1597c4a628a914474c

Start of Tutorial 9.2/Chapter09.sql         the script at the end of Tutorial 9.1
Start of Tutorial 9.3/Chapter09.sql         the script at the end of Tutorial 9.2
End of Chapter 9/Chapter09.sql              the script at the end of Tutorial 9.3

How to use a start file:
1. Make your working copy CharlesRiver_Work.sqlite of the downloaded CharlesRiver.sqlite,
   as Tutorial 9.1 describes, if you don't have one yet.
2. Copy Chapter09.sql from the folder of your tutorial into the folder of the working copy.
3. In DB Browser for SQLite, open CharlesRiver_Work.sqlite, go to the Execute SQL tab, and
   open the script with Open SQL file(s) (Ctrl+Shift+T).
4. Continue at the end of the script, as the tutorial says.

Each query ends with a comment that gives its result on this dataset release, and the line
numbers match the book's figures. With a different release, the results differ.
More: https://aa.accountinganalyticshub.com/front-matter/companion-files.html
