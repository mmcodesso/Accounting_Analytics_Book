/* Chapter 9: manufacturing variance, first look
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: companion file, end of Tutorial 9.3; dataset v2026.1
   Checks: every close adds up; the 2026 postings exclude JE-2026-000296 */

-- Tutorial 9.1: every column of the chart of accounts
SELECT *
FROM Account;  -- Result: 104 rows

-- Tutorial 9.1: the columns that identify each account
SELECT AccountID, AccountNumber, AccountName,
    AccountType, AccountSubType
FROM Account;  -- Result: 104 rows

-- Tutorial 9.1: the parts of each variance and their check
SELECT WorkOrderCloseID, CloseDate,
    MaterialVarianceAmount AS Material,
    ConversionVarianceAmount AS Conversion,
    TotalVarianceAmount AS Total,
    ROUND(MaterialVarianceAmount + ConversionVarianceAmount
        - TotalVarianceAmount, 2) AS CheckDifference
FROM WorkOrderClose;  -- Result: 12998 rows

-- Tutorial 9.2: the two manufacturing accounts by number
SELECT AccountID, AccountNumber, AccountName
FROM Account
WHERE AccountNumber IN (1090, 5080);  -- Result: 2 rows

-- Tutorial 9.2: the variance postings of fiscal 2026
SELECT GLEntryID, PostingDate, Debit, Credit,
    SourceDocumentType, VoucherNumber, Description
FROM GLEntry
WHERE AccountID = 93 AND FiscalYear = 2026;  -- Result: 7916 rows

-- Tutorial 9.2: the source document types of those postings
SELECT DISTINCT SourceDocumentType
FROM GLEntry
WHERE AccountID = 93 AND FiscalYear = 2026;  -- Result: 2 rows

-- Tutorial 9.2: the closing entry, left out of any analysis
SELECT GLEntryID, PostingDate, Debit, Credit,
    VoucherNumber, Description
FROM GLEntry
WHERE AccountID = 93 AND FiscalYear = 2026
    AND SourceDocumentType = 'JournalEntry';  -- Result: 1 rows

-- Tutorial 9.2: closes whose parts differ from their total
SELECT WorkOrderCloseID, TotalVarianceAmount
FROM WorkOrderClose
WHERE ROUND(MaterialVarianceAmount + ConversionVarianceAmount
    - TotalVarianceAmount, 2) <> 0;  -- Result: 0 rows

-- Tutorial 9.2: work orders not yet closed
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate,
    COALESCE(CompletedDate, 'not completed') AS Completed,
    CAST(SUBSTR(WorkOrderNumber, 4, 4) AS INTEGER) AS ReleaseYear
FROM WorkOrder
WHERE ClosedDate IS NULL;  -- Result: 670 rows

-- Tutorial 9.3: the ten largest variances of fiscal 2026
SELECT WorkOrderCloseID, WorkOrderID, CloseDate,
    MaterialVarianceAmount AS Material,
    DirectLaborVarianceAmount AS Labor,
    OverheadVarianceAmount AS Overhead,
    TotalVarianceAmount AS Total,
    ROUND(OverheadVarianceAmount / TotalVarianceAmount, 2)
        AS OverheadShare
FROM WorkOrderClose
WHERE CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
ORDER BY TotalVarianceAmount DESC
LIMIT 10;  -- Result: 10 rows

-- Tutorial 9.3: closes of 2026 above $1,000 either way
SELECT WorkOrderCloseID, CloseDate, TotalVarianceAmount
FROM WorkOrderClose
WHERE CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
    AND ABS(TotalVarianceAmount) > 1000
ORDER BY TotalVarianceAmount;  -- Result: 975 rows
