/* Ex 9.2.sql: the purchase price variance in the ledger
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: fiscal 2026 postings to 5060 net 176,011.36, the credit of close JE-2026-000296 */

-- Requirement (1): the AccountID of account 5060
-- Population: Account; expected: AccountID 55
SELECT AccountID, AccountNumber, AccountName
FROM Account
WHERE AccountNumber = 5060;  -- Result: 1 row (AccountID = 55, AccountNumber = 5060, AccountName = Purchase Price Variance)

-- Requirement (2): the source document types of 5060's postings in fiscal 2026
-- Population: GLEntry, AccountID 55, fiscal 2026; expected: JournalEntry and PurchaseInvoice
SELECT DISTINCT SourceDocumentType
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
ORDER BY SourceDocumentType;  -- Result: 2 rows

-- Requirement (2): the JournalEntry posting, which the analysis excludes
-- Population: GLEntry, AccountID 55, fiscal 2026, JournalEntry; expected: the close JE-2026-000296
SELECT GLEntryID, PostingDate, Debit, Credit, VoucherNumber,
    Description
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
    AND SourceDocumentType = 'JournalEntry';  -- Result: 1 rows

-- Requirement (3): the descriptions of the remaining postings
-- Population: GLEntry, AccountID 55, fiscal 2026, PurchaseInvoice; expected: three descriptions
SELECT DISTINCT Description
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
    AND SourceDocumentType = 'PurchaseInvoice'
ORDER BY Description;  -- Result: 3 rows

-- Requirement (4): the ten largest unfavorable purchase variances
-- Population: GLEntry, AccountID 55, fiscal 2026, unfavorable variances; expected: largest 796.29
SELECT GLEntryID, PostingDate, VoucherNumber, Debit, Description
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
    AND Description = 'Record unfavorable purchase variance'
ORDER BY Debit DESC, PostingDate, VoucherNumber
LIMIT 10;  -- Result: 10 rows

-- Requirement (5): the postings described as unfavorable purchase variance (count in the message pane)
-- Population: GLEntry, AccountID 55, fiscal 2026; expected: 12,389 debits, 167,063.83
SELECT GLEntryID, PostingDate, VoucherNumber, Debit, Credit
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
    AND Description = 'Record unfavorable purchase variance';  -- Result: 12389 rows

-- Requirement (5): the postings described as favorable purchase variance (count in the message pane)
-- Population: GLEntry, AccountID 55, fiscal 2026; expected: 7,270 credits, 57,497.25
SELECT GLEntryID, PostingDate, VoucherNumber, Debit, Credit
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
    AND Description = 'Record favorable purchase variance';  -- Result: 7270 rows

-- Requirement (5): the postings described as nonrecoverable purchase tax (count in the message pane)
-- Population: GLEntry, AccountID 55, fiscal 2026; expected: 3,897 debits, 66,444.78
SELECT GLEntryID, PostingDate, VoucherNumber, Debit, Credit
FROM GLEntry
WHERE AccountID = 55 AND FiscalYear = 2026
    AND Description = 'Record nonrecoverable purchase tax';  -- Result: 3897 rows

/* Model answer (Requirement (2))

   The postings of fiscal 2026 come from PurchaseInvoice and JournalEntry documents. The only JournalEntry row
   is the year-end close JE-2026-000296, a credit of 176,011.36 that brings the account back to zero for the
   new year. Including it would net the year's activity to zero, so an analysis of the account excludes it, as
   Tutorial 9.2 excluded the close of 5080.
*/

/* Model answer (Requirements (3) and (5))

   The 23,556 PurchaseInvoice postings carry three descriptions: unfavorable variances (12,389 debits,
   167,063.83), favorable variances (7,270 credits, 57,497.25), and nonrecoverable purchase tax (3,897 debits,
   66,444.78). Their net, 176,011.36, equals the close. The account records two kinds of cost: the difference
   between the supplier's invoice price and the purchase-order price at which the goods were received (the
   invoice clears goods received not invoiced, 2020, at the receipt value), and purchase tax that cannot be
   recovered. A credit means the supplier billed below the order price, a favorable variance; three one-cent
   credits and seven one-cent debits on lines billed at the order price are rounding.
*/

/* Model answer (Requirement (6))

   Purchase price variance arises when a supplier invoice is posted: the PurchaseInvoice documents compare the
   invoice price with the order price of the goods received. Manufacturing variance arises when a work order
   closes: the WorkOrderClose documents compare the actual cost charged to production with the standard cost
   released, so one measures buying and the other making.
*/

/* Notes

   Exercise 9.2: The Purchase Price Variance in the Ledger
   (1) Find the AccountID of account 5060.
   (2) List the distinct source document types of the account's postings in fiscal 2026, and identify the one
      that must be excluded from an analysis of the account. Explain why.
   (3) Use DISTINCT to list the descriptions of the remaining postings. Explain the two kinds of cost the
      account records.
   (4) List the postings of fiscal 2026 whose description records an unfavorable purchase variance, sorted by
      Debit from the largest down, and show the ten largest with their posting date and voucher number.
   (5) Using the message pane, count the postings of each description. Explain what a credit to this account
      means.
   (6) Write two or three sentences comparing how purchase price variance and manufacturing variance arise,
      based on the source documents that post to each account.
   Instructor note: 5060 Purchase Price Variance is AccountID 55. Fiscal 2026 source types: PurchaseInvoice
      and JournalEntry; the JournalEntry row is closing entry JE-2026-000296, a credit of 176,011.36, which
      clears the account. PurchaseInvoice postings: 23,556 rows with three descriptions: "Record unfavorable
      purchase variance" 12,389 debits (167,063.83), "Record favorable purchase variance" 7,270 credits
      (57,497.25), and "Record nonrecoverable purchase tax" 3,897 debits (66,444.78); the net, 176,011.36,
      equals the close. The purchase variance is the invoice price against the purchase-order price at which
      the goods were received (the invoice clears goods received not invoiced, account 2020, at the receipt
      value); a credit means the supplier billed below the order price (three one-cent credits and seven one-
      cent debits on lines billed at the order price are rounding). The account also absorbs purchase tax that
      cannot be recovered. Largest unfavorable variance 796.29 (2026-01-31, voucher V0101-2026-020853); next
      783.75 and 752.40. Purchase variance is recorded when a supplier invoice is posted; manufacturing
      variance when a work order closes, comparing actual with standard production cost.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   9.2: AccountID of 5060: 55
   9.2: its name: Purchase Price Variance
   9.2: source document types: ['JournalEntry', 'PurchaseInvoice']
   9.2: JournalEntry rows: 1
   9.2: its voucher: JE-2026-000296
   9.2: its credit: 176,011.36
   9.2: its debit: 0
   9.2: its date: 2026-12-31
   9.2: descriptions: ['Record favorable purchase variance', 'Record nonrecoverable purchase tax', 'Record
      unfavorable purchase variance']
   9.2: rows: 10
   9.2: largest Debit: 796.29
   9.2: its posting date: 2026-01-31
   9.2: its voucher: V0101-2026-020853
   9.2: the next two amounts: [783.75, 752.4]
   9.2: postings: 12389
   9.2: debits: 12389
   9.2: total Debit: 167,063.83
   9.2: total Credit: 0
   9.2: postings: 7270
   9.2: credits: 7270
   9.2: total Credit: 57,497.25
   9.2: total Debit: 0
   9.2: postings: 3897
   9.2: debits: 3897
   9.2: total Debit: 66,444.78
   9.2: total Credit: 0
*/
