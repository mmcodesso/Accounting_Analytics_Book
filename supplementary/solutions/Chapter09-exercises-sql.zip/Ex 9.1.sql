/* Ex 9.1.sql: reviewing the chart of accounts
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 104 accounts; 8 opposite normal balances; no posting to a header or inactive account */

-- Requirement (1): every account of the chart, sorted by number
-- Population: Account, every row; expected: 104 accounts, Asset 25, Liability 18, Equity 8, Revenue 13, Expense 40
SELECT AccountID, AccountNumber, AccountName, AccountType,
    AccountSubType, ParentAccountID, NormalBalance, IsActive
FROM Account
ORDER BY AccountNumber;  -- Result: 104 rows

-- Requirement (2): the account types
-- Population: Account; expected: 5 types
SELECT DISTINCT AccountType
FROM Account
ORDER BY AccountType;  -- Result: 5 rows

-- Requirement (2): the combinations of type and subtype
-- Population: Account; expected: 22 combinations of 18 subtypes, a Header subtype in every type
SELECT DISTINCT AccountType, AccountSubType
FROM Account
ORDER BY AccountType, AccountSubType;  -- Result: 22 rows

-- Requirement (3): the header accounts and their parents
-- Population: Account, AccountSubType Header; expected: 10 headers, 8 without a ParentAccountID
SELECT AccountID, AccountNumber, AccountName, AccountType,
    ParentAccountID
FROM Account
WHERE AccountSubType = 'Header'
ORDER BY AccountNumber;  -- Result: 10 rows

-- Requirement (3): postings to the header accounts
-- Population: GLEntry, the header accounts' AccountIDs; expected: no rows
SELECT GLEntryID, PostingDate, AccountID, Debit, Credit
FROM GLEntry
WHERE AccountID IN (1, 11, 21, 31, 35, 41, 49, 57, 80, 85);  -- Result: 0 rows

-- Requirement (4): accounts whose normal balance is opposite to their type
-- Population: Account; expected: 8 contra accounts
SELECT AccountID, AccountNumber, AccountName, AccountType,
    AccountSubType, NormalBalance
FROM Account
WHERE (AccountType IN ('Asset', 'Expense')
        AND NormalBalance = 'Credit')
    OR (AccountType IN ('Liability', 'Equity', 'Revenue')
        AND NormalBalance = 'Debit')
ORDER BY AccountNumber;  -- Result: 8 rows

-- Requirement (5): the inactive accounts
-- Population: Account, IsActive 0; expected: 8 accounts
SELECT AccountID, AccountNumber, AccountName, AccountType,
    AccountSubType
FROM Account
WHERE IsActive = 0
ORDER BY AccountNumber;  -- Result: 8 rows

-- Requirement (5): postings to the inactive accounts
-- Population: GLEntry, the inactive accounts' AccountIDs; expected: no rows
SELECT GLEntryID, PostingDate, AccountID, Debit, Credit
FROM GLEntry
WHERE AccountID IN (48, 56, 74, 94, 95, 80, 81, 84);  -- Result: 0 rows

-- Requirement (5): active accounts whose names mention manufacturing
-- Population: Account, IsActive 1; expected: 4 accounts, among them 1090 and 5080
SELECT AccountID, AccountNumber, AccountName, AccountType,
    AccountSubType
FROM Account
WHERE AccountName LIKE '%manufacturing%' AND IsActive = 1
ORDER BY AccountNumber;  -- Result: 4 rows

-- Requirement (5): the source documents that post to 1090
-- Population: GLEntry, AccountID 92; expected: JournalEntry, PayrollSummary, ProductionCompletion and WorkOrderClose
SELECT DISTINCT SourceDocumentType
FROM GLEntry
WHERE AccountID = 92
ORDER BY SourceDocumentType;  -- Result: 4 rows

-- Requirement (6): postings to 1030 Allowance for Doubtful Accounts
-- Population: GLEntry, AccountID 4; expected: no rows
SELECT GLEntryID, PostingDate, Debit, Credit, Description
FROM GLEntry
WHERE AccountID = 4;  -- Result: 0 rows

/* Model answer (Requirement (2))

   The chart has 104 accounts of 5 types (Asset 25, Liability 18, Equity 8, Revenue 13, Expense 40) and 18
   subtypes. Every type has its own Header subtype for its header accounts, and the other subtypes divide the
   types as a balance sheet and an income statement do: Asset into Contra Current Asset (1), Contra Fixed
   Asset (4), Current Asset (11), Fixed Asset (5) and Noncurrent Asset (2); Liability into Current Liability
   (13) and Long-Term Liability (3); Equity into Closing (1), Contra Equity (1) and Equity (4); Revenue into
   Contra Revenue (2), Operating Revenue (6), Other Income (1) and Other Income or Expense (2); Expense into
   COGS (8), Operating Expense (29) and Other Expense (1).
*/

/* Model answer (Requirement (3))

   Ten accounts are headers. Eight of them (1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000) have no
   ParentAccountID and head a section of the chart. 1100 Fixed Assets and 2100 Long-Term Liabilities have a
   parent (1000 and 2000), so they are sub-headers and the chart has two levels of headers. A header only
   groups the accounts below it: none has a posting, and none should, because balances belong to the detail
   accounts.
*/

/* Model answer (Requirement (4))

   Eight accounts carry a normal balance opposite to their type, and all are contra accounts: 1030 Allowance
   for Doubtful Accounts and the accumulated depreciation accounts 1150, 1160, 1170, 1186 reduce assets with a
   credit; 3040 Dividends or Owner Distributions reduces equity with a debit; 4060 Sales Returns and
   Allowances and 4070 Sales Discounts reduce revenue with a debit. AND binds before OR, so the parentheses do
   not change this result, but they make the two conditions explicit to a reviewer, and the query no longer
   depends on the default order.
*/

/* Model answer (Requirement (5))

   Eight accounts are inactive and none has a posting: 4070 Sales Discounts, 5070 Inventory Adjustments, 6170
   Bad Debt Expense, 6260 Salaries Expense - Manufacturing, 6270 Factory Overhead Expense, 7000 Other Income
   and Expense, 7010 Interest Income, 7040 Foreign Exchange Gain or Loss. Manufacturing salaries and factory
   overhead are not expensed: they are charged to 1090 Manufacturing Cost Clearing (AccountID 92), whose
   postings come from JournalEntry, PayrollSummary, ProductionCompletion and WorkOrderClose documents. Payroll
   and overhead entries debit it, production completions release standard cost to inventory, and work order
   closes clear what is left to 5080 Manufacturing Variance, so the costs reach cost of goods sold through
   inventory and the variance.
*/

/* Model answer (Requirement (6), memo to the controller)

   The chart of accounts holds 104 accounts in 5 types and 18 subtypes, organized under eight top-level
   headers with two sub-headers, so it reads like the financial statements. Eight contra accounts carry the
   opposite normal balance, as they should, and 8 inactive accounts have no postings, so nothing is posted
   where it should not be. Manufacturing salaries and factory overhead are recorded through 1090 Manufacturing
   Cost Clearing rather than the inactive 6260 and 6270, so manufacturing cost reaches cost of goods sold
   through inventory and 5080 Manufacturing Variance.

   Before year-end, two points deserve review. First, 1030 Allowance for Doubtful Accounts has no postings at
   all, so no allowance for credit losses has ever been recorded against the receivables (Chapter 8 estimates
   one). Second, 4070 Sales Discounts is inactive, so promotion discounts are netted in revenue rather than
   shown separately (the Part II case); the presentation should be a decision, not a default. The inactive
   accounts should stay closed to posting.
*/

/* Notes

   Exercise 9.1: Reviewing the Chart of Accounts
   (1) List every account with its AccountID, AccountNumber, AccountName, AccountType, AccountSubType,
      ParentAccountID, NormalBalance, and IsActive, sorted by AccountNumber.
   (2) Use DISTINCT to list the account types and, in a second query, the combinations of AccountType and
      AccountSubType. Describe how the subtypes divide each type.
   (3) List the header accounts, whose AccountSubType is Header. Identify the ones that have no
      ParentAccountID and the ones that do, and explain what the difference means for the structure of the
      chart.
   (4) List the accounts whose NormalBalance is Credit although their type is Asset or Expense, or Debit
      although their type is Liability, Equity, or Revenue. Use parentheses to group the conditions. Explain
      what kind of account each one is.
   (5) List the inactive accounts (IsActive is 0). Two of them are named for manufacturing salaries and
      factory overhead. Use LIKE to find the active accounts whose names mention manufacturing, and suggest
      which of them records those costs instead.
   (6) Write a short memo (one half page) to the controller summarizing the structure of the chart and
      anything that should be reviewed before year-end.
   Instructor note: 104 accounts: Asset 25, Liability 18, Equity 8, Revenue 13, Expense 40. Eighteen subtypes,
      including Header (10), Current Asset (11), Fixed Asset (5), Contra Fixed Asset (4), Contra Current Asset
      (1), Current Liability (13), Long-Term Liability (3), Operating Revenue (6), Contra Revenue (2), COGS
      (8), Operating Expense (29), Closing (1). Header accounts: 10; eight top-level headers (1000, 2000,
      3000, 4000, 5000, 6000, 7000, 8000) have a NULL ParentAccountID, while 1100 Fixed Assets and 2100 Long-
      Term Liabilities are sub-headers under 1000 and 2000, so the chart has two levels of headers. No header
      account has a posting. Opposite normal balances (8): 1030 Allowance for Doubtful Accounts,
      1150/1160/1170/1186 accumulated depreciation (contra assets, credit); 3040 Dividends or Owner
      Distributions (contra equity, debit); 4060 Sales Returns and Allowances and 4070 Sales Discounts (contra
      revenue, debit). The query needs parentheses: (AccountType IN ('Asset','Expense') AND NormalBalance =
      'Credit') OR (AccountType IN ('Liability','Equity','Revenue') AND NormalBalance = 'Debit'). Inactive
      (8), none with any posting: 4070 Sales Discounts, 5070 Inventory Adjustments, 6170 Bad Debt Expense,
      6260 Salaries Expense - Manufacturing, 6270 Factory Overhead Expense, 7000 Other Income and Expense
      (header), 7010 Interest Income, 7040 Foreign Exchange Gain or Loss. Manufacturing salaries and factory
      overhead are charged to 1090 Manufacturing Cost Clearing (AccountID 92) and reach cost of goods sold
      through inventory and 5080 Manufacturing Variance. Memo points: 1030 has no postings, so no allowance
      has ever been recorded (Chapter 8); 4070 is inactive, so discounts are netted in revenue (Part II case).

   Checks (each agreed on dataset release v2026.1 when this file was built):
   9.1: accounts: 104
   9.1: Asset accounts: 25
   9.1: Liability accounts: 18
   9.1: Equity accounts: 8
   9.1: Revenue accounts: 13
   9.1: Expense accounts: 40
   9.1: Header subtype accounts: 10
   9.1: Current Asset subtype accounts: 11
   9.1: Fixed Asset subtype accounts: 5
   9.1: Contra Fixed Asset subtype accounts: 4
   9.1: Contra Current Asset subtype accounts: 1
   9.1: Current Liability subtype accounts: 13
   9.1: Long-Term Liability subtype accounts: 3
   9.1: Operating Revenue subtype accounts: 6
   9.1: Contra Revenue subtype accounts: 2
   9.1: COGS subtype accounts: 8
   9.1: Operating Expense subtype accounts: 29
   9.1: Closing subtype accounts: 1
   9.1: account types: ['Asset', 'Equity', 'Expense', 'Liability', 'Revenue']
   9.1: type and subtype combinations: 22
   9.1: distinct subtypes: 18
   9.1: types with a Header subtype: 5
   9.1: header accounts: 10
   9.1: top-level headers (no ParentAccountID): [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000]
   9.1: 1100 sits under: 1000
   9.1: 2100 sits under: 2000
   9.1: postings to header accounts: 0
   9.1: accounts with an opposite normal balance: 8
   9.1: their account numbers: [1030, 1150, 1160, 1170, 1186, 3040, 4060, 4070]
   9.1: every one a contra subtype: True
   9.1: inactive accounts: 8
   9.1: their account numbers: [4070, 5070, 6170, 6260, 6270, 7000, 7010, 7040]
   9.1: postings to inactive accounts: 0
   9.1: active manufacturing accounts: [1090, 1185, 1186, 5080]
   9.1: 1090 is: Manufacturing Cost Clearing
   9.1: 1090's AccountID: 92
   9.1: 5080 is: Manufacturing Variance
   9.1: source types posting to 1090: ['JournalEntry', 'PayrollSummary', 'ProductionCompletion',
      'WorkOrderClose']
   9.1: postings to 1030: 0
*/
