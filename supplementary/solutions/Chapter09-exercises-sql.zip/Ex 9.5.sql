/* Ex 9.5.sql: shipments that need follow-up
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 392 shipments without a tracking number; 739 In Transit past their delivery date */

-- Requirement (1): the values of Status
-- Population: Shipment; expected: Delivered and In Transit
SELECT DISTINCT Status
FROM Shipment
ORDER BY Status;  -- Result: 2 rows

-- Requirement (1): the shipments with Status Delivered (count in the message pane)
-- Population: Shipment; expected: 8,967 shipments
SELECT ShipmentID, ShipmentNumber, ShipmentDate, Status
FROM Shipment
WHERE Status = 'Delivered';  -- Result: 8967 rows

-- Requirement (1): the shipments with Status In Transit (count in the message pane)
-- Population: Shipment; expected: 740 shipments
SELECT ShipmentID, ShipmentNumber, ShipmentDate, Status
FROM Shipment
WHERE Status = 'In Transit';  -- Result: 740 rows

-- Requirement (1): the values of ShippedBy
-- Population: Shipment; expected: 4 carriers
SELECT DISTINCT ShippedBy
FROM Shipment
ORDER BY ShippedBy;  -- Result: 4 rows

-- Requirement (2): shipments with no tracking number
-- Population: Shipment, TrackingNumber NULL; expected: 392 shipments, 2024-01-16 to 2026-12-31
SELECT ShipmentNumber, ShipmentDate, ShippedBy, Status
FROM Shipment
WHERE TrackingNumber IS NULL
ORDER BY ShipmentDate;  -- Result: 392 rows

-- Requirement (3): shipments In Transit with a DeliveryDate before 2026-12-31
-- Population: Shipment, Status In Transit; expected: 739 shipments, oldest 2024-01-10
SELECT ShipmentNumber, ShipmentDate, DeliveryDate, ShippedBy,
    TrackingNumber, Status
FROM Shipment
WHERE Status = 'In Transit' AND DeliveryDate < '2026-12-31'
ORDER BY DeliveryDate;  -- Result: 739 rows

-- Requirement (3): the other In Transit shipments, delivered on or after 2026-12-31
-- Population: Shipment, Status In Transit; expected: 1 shipment
SELECT ShipmentNumber, ShipmentDate, DeliveryDate, Status
FROM Shipment
WHERE Status = 'In Transit' AND DeliveryDate >= '2026-12-31';  -- Result: 1 rows

/* Model answer (Requirement (4))

   The SQL results equal the Excel filters of Tutorial 2.1: the blank TrackingNumber filter shows the same 392
   shipments (NULL in the database, dated 2024-01-16 to 2026-12-31), and the Status filter shows the same 740
   In Transit shipments, of which 739 have a DeliveryDate before 2026-12-31, the oldest 2024-01-10; one more
   has a DeliveryDate on or after 2026-12-31. In Excel the date comparison was left to the eye; in SQL it is
   part of the condition. The SQL tests are easier to rerun because the conditions are written down: the saved
   script reruns them on next year's data in one click, and a reviewer can read exactly which rows were kept,
   where an Excel filter has to be rebuilt by hand and leaves no record of itself.
*/

/* Model answer (Requirement (5))

   The missing tracking number is a completeness test: ask the shipping team why these shipments left without
   a tracking number recorded, and whether the carrier's records hold one that was never entered. The In
   Transit status after the delivery date is a consistency (or timeliness) test, a status that contradicts the
   delivery date: ask who updates the status on delivery and why these shipments were never marked Delivered.
*/

/* Notes

   Exercise 9.5: Shipments That Need Follow-Up
   (1) Use DISTINCT to list the values of Status and of ShippedBy in the Shipment table.
   (2) List the shipments with no TrackingNumber, with their ShipmentNumber, ShipmentDate, ShippedBy, and
      Status, sorted by ShipmentDate. Report the number of rows and the range of dates.
   (3) List the shipments whose Status is In Transit and whose DeliveryDate is before 2026-12-31, the last day
      of the data, sorted by DeliveryDate. Report the number of rows and the oldest DeliveryDate.
   (4) Compare your results with your findings from Tutorial 2.1, and explain why the SQL version of the tests
      is easier to rerun.
   (5) For each test, name the data quality dimension it addresses and suggest one question to ask the
      shipping team.
   Instructor note: Status values Delivered (8,967) and In Transit (740); ShippedBy DHL Supply Chain, FedEx
      Freight, Private Fleet, UPS Freight. No TrackingNumber (NULL): 392 shipments, dated 2024-01-16 to
      2026-12-31. In Transit with DeliveryDate before 2026-12-31: 739, the oldest delivered 2024-01-10 (one
      more In Transit shipment has a DeliveryDate on or after 2026-12-31). The SQL results equal the Excel
      filters of Tutorial 2.1. Dimensions: completeness (tracking number) and consistency or timeliness
      (status that contradicts the delivery date). The tests are saved as text and rerun with one click.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   9.5: statuses: ['Delivered', 'In Transit']
   9.5: Delivered shipments: 8967
   9.5: In Transit shipments: 740
   9.5: carriers: ['DHL Supply Chain', 'FedEx Freight', 'Private Fleet', 'UPS Freight']
   9.5: shipments without tracking: 392
   9.5: first date: 2024-01-16
   9.5: last date: 2026-12-31
   9.5: stale In Transit shipments: 739
   9.5: oldest DeliveryDate: 2024-01-10
   9.5: In Transit, delivered on or after the end: 1
*/
