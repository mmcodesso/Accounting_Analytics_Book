/* Ex 9.4.sql: open work orders at year-end
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 670 work orders without a ClosedDate; 471 due on or before 2026-12-31 */

-- Requirement (1): the work orders with no ClosedDate
-- Population: WorkOrder, ClosedDate NULL; expected: 670 work orders (Released 558, In Progress 27, Completed 85)
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate,
    CompletedDate, PlannedQuantity
FROM WorkOrder
WHERE ClosedDate IS NULL;  -- Result: 670 rows

-- Requirement (2): the release year and the completion date or a label
-- Population: as (1); expected: every release year 2026, not completed on 585 work orders
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate,
    COALESCE(CompletedDate, 'not completed') AS Completed,
    PlannedQuantity,
    CAST(SUBSTR(WorkOrderNumber, 4, 4) AS INTEGER) AS ReleaseYear
FROM WorkOrder
WHERE ClosedDate IS NULL;  -- Result: 670 rows

-- Requirement (3): the statuses of the open work orders
-- Population: as (1); expected: Released, In Progress, Completed
SELECT DISTINCT Status
FROM WorkOrder
WHERE ClosedDate IS NULL;  -- Result: 3 rows

-- Requirement (3): the open work orders with Status Released (count in the message pane)
-- Population: as (1); expected: 558 work orders
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate
FROM WorkOrder
WHERE ClosedDate IS NULL AND Status = 'Released';  -- Result: 558 rows

-- Requirement (3): the open work orders with Status In Progress (count in the message pane)
-- Population: as (1); expected: 27 work orders
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate
FROM WorkOrder
WHERE ClosedDate IS NULL AND Status = 'In Progress';  -- Result: 27 rows

-- Requirement (3): the open work orders with Status Completed (count in the message pane)
-- Population: as (1); expected: 85 work orders
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate
FROM WorkOrder
WHERE ClosedDate IS NULL AND Status = 'Completed';  -- Result: 85 rows

-- Requirement (4): the open work orders due on or before 2026-12-31
-- Population: as (1); expected: 471 work orders, the oldest WO-2026-011512
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate,
    COALESCE(CompletedDate, 'not completed') AS Completed
FROM WorkOrder
WHERE ClosedDate IS NULL AND DueDate <= '2026-12-31'
ORDER BY DueDate, WorkOrderNumber;  -- Result: 471 rows

-- Requirement (5): those still Released, where work has not started
-- Population: the work orders of (4); expected: 406 work orders
SELECT WorkOrderNumber, Status, ReleasedDate, DueDate,
    PlannedQuantity
FROM WorkOrder
WHERE ClosedDate IS NULL AND DueDate <= '2026-12-31'
    AND Status = 'Released'
ORDER BY DueDate, WorkOrderNumber;  -- Result: 406 rows

/* Model answer (Requirement (2))

   The release year is 2026 on every open work order (released 2026-05-23 to 2026-12-31), so nothing from
   earlier years is still open. COALESCE shows not completed for the 585 Released and In Progress work orders
   and a date for the 85 that were completed but not closed.
*/

/* Model answer (Requirement (6), memo to the production manager)

   At 2026-12-31, 670 work orders had no ClosedDate: Released 558, In Progress 27, Completed 85. All were
   released in 2026. Of them, 471 were due on or before 2026-12-31 (Released 406, Completed 64, In Progress
   1). The oldest, WO-2026-011512, was released on 2026-05-23 and due on 2026-06-07, and it was still Released
   at the end of the data; the next are WO-2026-011742 (due 2026-06-21) and WO-2026-012609 (due 2026-08-30).
   Of the past-due work orders, 406 have not been started, a backlog worth reviewing: are they still needed,
   or should they be cancelled? The 85 completed work orders should be closed.

   A work order's variance is recorded only when it closes, when the WorkOrderClose document posts the
   difference between actual and standard cost to 5080. The cost of these work orders sits in work in process
   and 1090 until then, so their variance is not in the fiscal 2026 results and will be recorded when they
   close, after the data ends. (Counting each status takes one query and the message pane; COUNT comes in
   Chapter 10.)
*/

/* Notes

   Exercise 9.4: Open Work Orders at Year-End
   (1) List the work orders with no ClosedDate, with their WorkOrderNumber, Status, ReleasedDate, DueDate,
      CompletedDate, and PlannedQuantity.
   (2) Add two calculated columns: the year in each WorkOrderNumber, extracted with SUBSTR and converted with
      CAST, and the CompletedDate with the text not completed in place of a missing value, using COALESCE.
      Describe what the two columns show about the open work orders.
   (3) Use DISTINCT to list the statuses of the open work orders. For each status, count the work orders with
      a separate query and the message pane.
   (4) List the open work orders whose DueDate is on or before 2026-12-31, sorted by DueDate. Identify the
      oldest.
   (5) Among them, list the work orders whose Status is Released, meaning that work has not started. Describe
      what you find.
   (6) Write a short memo (one half page) to the production manager on the open work orders, and explain why
      their variance is not yet in the fiscal 2026 results.
   Instructor note: 670 work orders have a NULL ClosedDate: Released 558, In Progress 27, Completed 85
      (completed but not closed). Every WorkOrderNumber carries the year of its ReleasedDate, and every open
      work order is a 2026 work order (released 2026-05-23 to 2026-12-31); COALESCE shows not completed for
      the 585 released or in progress and a date for the 85 completed. Due on or before 2026-12-31: 471
      (Released 406, Completed 64, In Progress 1). The oldest is WO-2026-011512, released 2026-05-23 and due
      2026-06-07, still Released at the end of the data; the next are WO-2026-011742 (due 2026-06-21) and
      WO-2026-012609 (due 2026-08-30). Hundreds of released work orders are past due without being started, a
      backlog worth raising with production. Their variance will be recorded when they close, after the data
      ends. Counting needs one query per status (COUNT comes in Chapter 10).

   Checks (each agreed on dataset release v2026.1 when this file was built):
   9.4: open work orders: 670
   9.4: Released work orders: 558
   9.4: In Progress work orders: 27
   9.4: Completed work orders: 85
   9.4: release years: [2026]
   9.4: not completed: 585
   9.4: completed but not closed: 85
   9.4: first release date: 2026-05-23
   9.4: last release date: 2026-12-31
   9.4: statuses: ['Completed', 'In Progress', 'Released']
   9.4: Released work orders: 558
   9.4: In Progress work orders: 27
   9.4: Completed work orders: 85
   9.4: work orders due: 471
   9.4: the oldest: WO-2026-011512
   9.4: its release date: 2026-05-23
   9.4: its due date: 2026-06-07
   9.4: its status: Released
   9.4: the next two: [('WO-2026-011742', '2026-06-21'), ('WO-2026-012609', '2026-08-30')]
   9.4: Released among them: 406
   9.4: Completed among them: 64
   9.4: In Progress among them: 1
   9.4: released and past due: 406
   9.4: the oldest: WO-2026-011512
*/
