/* Ex 9.3.sql: standard cost components of manufactured items
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 88 manufactured items; labor + overhead = conversion cost on every item */

-- Requirement (1): the manufactured items and their standards
-- Population: Item, SupplyMode Manufactured; expected: 88 items (Furniture 56, Lighting 26, Textiles 5, Accessories 1)
SELECT ItemCode, ItemName, ItemGroup, StandardCost,
    StandardLaborHoursPerUnit, StandardDirectLaborCost,
    StandardVariableOverheadCost, StandardFixedOverheadCost,
    StandardConversionCost
FROM Item
WHERE SupplyMode = 'Manufactured'
ORDER BY ItemCode;  -- Result: 88 rows

-- Requirement (2): the same list with the standard material cost
-- Population: as (1); expected: material cost from 10.43 to 558.40
SELECT ItemCode, ItemName, ItemGroup, StandardCost,
    StandardLaborHoursPerUnit, StandardDirectLaborCost,
    StandardVariableOverheadCost, StandardFixedOverheadCost,
    StandardConversionCost,
    ROUND(StandardCost - StandardConversionCost, 2)
        AS StandardMaterialCost
FROM Item
WHERE SupplyMode = 'Manufactured'
ORDER BY ItemCode;  -- Result: 88 rows

-- Requirement (3): items whose conversion components do not add up
-- Population: Item, SupplyMode Manufactured; expected: no rows
SELECT ItemCode, ItemName, StandardDirectLaborCost,
    StandardVariableOverheadCost, StandardFixedOverheadCost,
    StandardConversionCost
FROM Item
WHERE SupplyMode = 'Manufactured'
    AND ROUND(StandardDirectLaborCost
        + StandardVariableOverheadCost
        + StandardFixedOverheadCost, 2)
        <> ROUND(StandardConversionCost, 2);  -- Result: 0 rows

-- Requirement (4): the list with the labor rate per standard hour, sorted by it
-- Population: as (1); expected: rates from 23.27 to 31.82
SELECT ItemCode, ItemName, ItemGroup, StandardCost,
    StandardLaborHoursPerUnit, StandardDirectLaborCost,
    StandardVariableOverheadCost, StandardFixedOverheadCost,
    StandardConversionCost,
    ROUND(StandardCost - StandardConversionCost, 2)
        AS StandardMaterialCost,
    ROUND(StandardDirectLaborCost / StandardLaborHoursPerUnit, 2)
        AS LaborRatePerHour
FROM Item
WHERE SupplyMode = 'Manufactured'
ORDER BY LaborRatePerHour, ItemCode;  -- Result: 88 rows

-- Requirement (5): the ten items with the highest standard conversion cost
-- Population: Item, SupplyMode Manufactured; expected: FUR-TBL-0017 first (112.43), all Furniture
SELECT ItemCode, ItemName, ItemGroup, StandardConversionCost
FROM Item
WHERE SupplyMode = 'Manufactured'
ORDER BY StandardConversionCost DESC
LIMIT 10;  -- Result: 10 rows

/* Model answer (How the standards are built)

   Charles River makes 88 items (Furniture 56, Lighting 26, Textiles 5, Accessories 1). Each standard cost is
   material plus conversion cost: the material part, StandardCost less StandardConversionCost, runs from 10.43
   to 558.40 a unit, and the conversion part is direct labor plus variable and fixed overhead. The component
   check returns no rows, so the three parts add up to the conversion cost on every item. Direct labor is the
   standard hours times an item-specific rate: the rate per standard hour runs from 23.27 to 31.82, with 81
   different rates, so there is no single plant rate. The highest conversion costs are FUR-TBL-0017 Mason
   Dining Table Ash Natural 84 in (112.43), FUR-CON-0077 (106.38) and FUR-CTB-0014 (105.58), and all ten of
   the highest are Furniture items.
*/

/* Notes

   Exercise 9.3: Standard Cost Components of Manufactured Items
   (1) List the items whose SupplyMode is Manufactured, with ItemCode, ItemName, ItemGroup, StandardCost,
      StandardLaborHoursPerUnit, StandardDirectLaborCost, StandardVariableOverheadCost,
      StandardFixedOverheadCost, and StandardConversionCost.
   (2) Add a calculated column for the standard material cost, the part of StandardCost that is not conversion
      cost, and round it to two decimals.
   (3) Write a query that returns any manufactured item whose direct labor, variable overhead, and fixed
      overhead do not add up to its standard conversion cost, after rounding to two decimals. Report the
      result.
   (4) Add a calculated column for the standard labor rate per hour, StandardDirectLaborCost divided by
      StandardLaborHoursPerUnit, rounded to two decimals, and sort the items by it. Describe the range of
      rates.
   (5) List the ten items with the highest standard conversion cost, and state which item groups they belong
      to.
   Instructor note: 88 manufactured items (Furniture 56, Lighting 26, Textiles 5, Accessories 1). Material
      cost = StandardCost - StandardConversionCost, from 10.43 to 558.40. The component check returns no rows:
      labor + variable overhead + fixed overhead = conversion for every item. Labor rate per standard hour
      ranges from 23.27 to 31.82, so rates are item-specific, not one plant rate. Highest conversion cost:
      FUR-TBL-0017 Mason Dining Table Ash Natural 84 in (112.43), FUR-CON-0077 (106.38), FUR-CTB-0014
      (105.58); the top ten are Furniture.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   9.3: manufactured items: 88
   9.3: Furniture items: 56
   9.3: Lighting items: 26
   9.3: Textiles items: 5
   9.3: Accessories items: 1
   9.3: items: 88
   9.3: lowest material cost: 10.43
   9.3: highest material cost: 558.40
   9.3: items failing the component check: 0
   9.3: items: 88
   9.3: lowest rate (first row): 23.27
   9.3: highest rate (last row): 31.82
   9.3: distinct rates: 81
   9.3: rows: 10
   9.3: rank 1: ('FUR-TBL-0017', 112.43)
   9.3: rank 2: ('FUR-CON-0077', 106.38)
   9.3: rank 3: ('FUR-CTB-0014', 105.58)
   9.3: item groups of the ten: ['Furniture']
*/
