/* Ex 9.6.sql: missing values in time and labor records
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 3 direct rows without an operation; 3 clock entries without a clock-out; terminations consistent */

-- Requirement (1): direct labor time with no work order operation
-- Population: LaborTimeEntry, Direct Manufacturing; expected: three rows (213, 26171, 48261)
SELECT LaborTimeEntryID, EmployeeID, WorkOrderID, WorkDate,
    RegularHours, OvertimeHours,
    RegularHours + OvertimeHours AS Hours
FROM LaborTimeEntry
WHERE LaborType = 'Direct Manufacturing'
    AND WorkOrderOperationID IS NULL
ORDER BY LaborTimeEntryID;  -- Result: 3 rows

-- Requirement (1): the employees on those rows
-- Population: Employee; expected: 17, 18, assemblers
SELECT EmployeeID, EmployeeName, JobTitle, CostCenterID
FROM Employee
WHERE EmployeeID IN (17, 18);  -- Result: 2 rows

-- Requirement (2): the values of ClockStatus
-- Population: TimeClockEntry; expected: Approved and Pending
SELECT DISTINCT ClockStatus
FROM TimeClockEntry
ORDER BY ClockStatus;  -- Result: 2 rows

-- Requirement (2): the time clock entries with ClockStatus Approved (count in the message pane)
-- Population: TimeClockEntry; expected: 52,962 entries
SELECT TimeClockEntryID, EmployeeID, WorkDate, ClockStatus
FROM TimeClockEntry
WHERE ClockStatus = 'Approved';  -- Result: 52962 rows

-- Requirement (2): the time clock entries with ClockStatus Pending (count in the message pane)
-- Population: TimeClockEntry; expected: 5 entries
SELECT TimeClockEntryID, EmployeeID, WorkDate, ClockStatus
FROM TimeClockEntry
WHERE ClockStatus = 'Pending';  -- Result: 5 rows

-- Requirement (2): time clock entries with no ClockOutTime
-- Population: TimeClockEntry, ClockOutTime NULL; expected: 3 entries, employee 85, Pending
SELECT TimeClockEntryID, EmployeeID, WorkDate, ClockInTime,
    COALESCE(ClockOutTime, 'missing') AS ClockOut,
    RegularHours, OvertimeHours, ClockStatus
FROM TimeClockEntry
WHERE ClockOutTime IS NULL
ORDER BY WorkDate;  -- Result: 3 rows

-- Requirement (2): employee 85
-- Population: Employee; expected: an Inventory Specialist
SELECT EmployeeID, EmployeeName, JobTitle, EmploymentStatus,
    TerminationDate
FROM Employee
WHERE EmployeeID = 85;  -- Result: 1 rows

-- Requirement (3): employees with a TerminationDate
-- Population: Employee, TerminationDate not NULL; expected: 13 employees, all Terminated and inactive
SELECT EmployeeID, EmployeeName, TerminationDate,
    EmploymentStatus, IsActive
FROM Employee
WHERE TerminationDate IS NOT NULL
ORDER BY TerminationDate;  -- Result: 13 rows

-- Requirement (3): employees without a TerminationDate who are Terminated or inactive
-- Population: Employee, TerminationDate NULL; expected: no rows
SELECT EmployeeID, EmployeeName, EmploymentStatus, IsActive
FROM Employee
WHERE TerminationDate IS NULL
    AND (EmploymentStatus = 'Terminated' OR IsActive = 0);  -- Result: 0 rows

/* Model answer (Requirement (4), findings and follow-up questions)

   1. Three Direct Manufacturing rows have no WorkOrderOperationID: 213 (employee 17, work order 1,
   2024-01-17, 3.74 hours); 26171 (employee 17, work order 5328, 2025-01-02, 1.55 hours); 48261 (employee 18,
   work order 9897, 2026-01-02, 0.50 hours); the employees are assemblers. Their cost was charged as direct
   labor but cannot be traced to an operation, so it reaches the work order's actual cost (and the variance)
   without a routing step to compare it with. Ask production which operation the time belongs to, and why the
   time entry system accepted direct time without one.

   2. ClockStatus is Approved (52,962) and Pending (5). Three entries have no ClockOutTime, all for employee
   85 (an Inventory Specialist) on January 1 of 2024, 2025 and 2026, all Pending, yet each records regular and
   overtime hours, and two of them fall after the employee's termination on 2024-09-13. Hours without a
   complete time record cannot be verified, and if they were paid they reach labor cost without support. Ask
   payroll who entered the hours, on what support, and whether they were paid, and to whom.

   3. Thirteen employees have a TerminationDate; all are Terminated with IsActive 0, and no employee without
   one is Terminated or inactive, so the three columns agree. Ask payroll to confirm that no time or pay was
   recorded for these employees after their termination dates (Chapter 12 tests it).
*/

/* Notes

   Exercise 9.6: Missing Values in Time and Labor Records
   (1) List the LaborTimeEntry rows whose LaborType is Direct Manufacturing and whose WorkOrderOperationID is
      missing. Show the employee, work order, work date, and hours.
   (2) Use DISTINCT to list the values of ClockStatus in the TimeClockEntry table, and list the time clock
      entries with no ClockOutTime, showing COALESCE(ClockOutTime, 'missing') in place of the empty value.
   (3) List the employees with a TerminationDate, with their EmploymentStatus and IsActive flag, and check
      whether the three columns agree.
   (4) For each finding, explain why a missing value matters for the labor cost that reaches the manufacturing
      variance, and what you would ask the payroll or production team.
   Instructor note: three Direct Manufacturing labor rows have no WorkOrderOperationID: LaborTimeEntryIDs 213
      (employee 17, work order 1, 2024-01-17, 3.74 hours), 26171 (employee 17, work order 5328, 2025-01-02,
      1.55 hours), and 48261 (employee 18, work order 9897, 2026-01-02, 0.50 hours); employees 17 and 18 are
      assemblers. They are planted anomalies (invalid direct labor operation link). ClockStatus values:
      Approved (52,962) and Pending (5). Three entries have no ClockOutTime, all for employee 85 (an Inventory
      Specialist) on January 1 of 2024, 2025, and 2026, with Pending status (planted missing clock-out).
      Thirteen employees have a TerminationDate; all are Terminated with IsActive 0, so the three columns
      agree. Missing links mean labor cost that cannot be traced to an operation; missing clock-outs mean paid
      hours without a complete time record.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   9.6: rows: 3
   9.6: the entries: [(213, 17, 1, '2024-01-17'), (26171, 17, 5328, '2025-01-02'), (48261, 18, 9897,
      '2026-01-02')]
   9.6: hours of entry 213: 3.74
   9.6: hours of entry 26171: 1.55
   9.6: hours of entry 48261: 0.50
   9.6: employees: 2
   9.6: employee 17's job title: Assembler
   9.6: employee 18's job title: Assembler
   9.6: clock statuses: ['Approved', 'Pending']
   9.6: Approved entries: 52962
   9.6: Pending entries: 5
   9.6: entries without a clock-out: 3
   9.6: their employees: [85]
   9.6: their work dates: ['2024-01-01', '2025-01-01', '2026-01-01']
   9.6: their statuses: ['Pending']
   9.6: ClockOut shows: ['missing']
   9.6: job title: Inventory Specialist
   9.6: termination date: 2024-09-13
   9.6: terminated employees: 13
   9.6: EmploymentStatus values: ['Terminated']
   9.6: IsActive values: [0]
   9.6: inconsistent employees: 0
*/
