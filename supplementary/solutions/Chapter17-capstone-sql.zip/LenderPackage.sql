/* LenderPackage.sql: the lender package: trial balances, accrued expenses, cutoff, and the note schedules
   Database: CharlesRiver_Capstone.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: each trial balance balances and ties to Chapter 6; 2040 rebuilt to the ledger at each year-end; cutoff reruns Audit.sql L5-L8; each note schedule ties to the ledger */

-- Requirement 1: the trial balance at 2026-12-31, one query with its as-of date in a Params CTE
-- Population: GLEntry to 2026-12-31, a close left out only when dated then; expected: 71 accounts, 4 at zero, debit and credit balances of 67,107,722.36
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
)
SELECT a.AccountNumber, a.AccountName, a.AccountType,
    a.AccountSubType,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance,
    CASE WHEN SUM(gl.Debit) - SUM(gl.Credit) > 0
        THEN ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2)
        ELSE 0 END AS DebitBalance,
    CASE WHEN SUM(gl.Debit) - SUM(gl.Credit) < 0
        THEN ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
        ELSE 0 END AS CreditBalance,
    COUNT(*) AS Postings
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
    AND NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = (SELECT AsOfDate FROM Params))
GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
    a.AccountType, a.AccountSubType
ORDER BY a.AccountNumber;  -- Result: 71 rows

-- Requirement 1: the trial balance at 2025-12-31, one query with its as-of date in a Params CTE
-- Population: GLEntry to 2025-12-31, a close left out only when dated then; expected: 71 accounts, 4 at zero, debit and credit balances of 58,143,212.29
WITH Params AS (
    SELECT '2025-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
)
SELECT a.AccountNumber, a.AccountName, a.AccountType,
    a.AccountSubType,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance,
    CASE WHEN SUM(gl.Debit) - SUM(gl.Credit) > 0
        THEN ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2)
        ELSE 0 END AS DebitBalance,
    CASE WHEN SUM(gl.Debit) - SUM(gl.Credit) < 0
        THEN ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
        ELSE 0 END AS CreditBalance,
    COUNT(*) AS Postings
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
    AND NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = (SELECT AsOfDate FROM Params))
GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
    a.AccountType, a.AccountSubType
ORDER BY a.AccountNumber;  -- Result: 71 rows

-- Requirement 1: the trial balance at 2024-12-31, one query with its as-of date in a Params CTE
-- Population: GLEntry to 2024-12-31, a close left out only when dated then; expected: 69 accounts, 2 at zero, debit and credit balances of 47,565,211.56
WITH Params AS (
    SELECT '2024-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
)
SELECT a.AccountNumber, a.AccountName, a.AccountType,
    a.AccountSubType,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Balance,
    CASE WHEN SUM(gl.Debit) - SUM(gl.Credit) > 0
        THEN ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2)
        ELSE 0 END AS DebitBalance,
    CASE WHEN SUM(gl.Debit) - SUM(gl.Credit) < 0
        THEN ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
        ELSE 0 END AS CreditBalance,
    COUNT(*) AS Postings
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
    AND NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = (SELECT AsOfDate FROM Params))
GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
    a.AccountType, a.AccountSubType
ORDER BY a.AccountNumber;  -- Result: 69 rows

-- Requirement 1: net income of each fiscal year against its Income Summary close to retained earnings
-- Population: revenue and expense postings, closes excluded; expected: 5,110,308.27, 5,134,354.71, 4,503,611.24, each equal to its close (JE-2024-000265/266, JE-2025-000287/288, JE-2026-000296/297)
WITH Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Closed AS (
    SELECT gl.FiscalYear,
        SUM(gl.Credit - gl.Debit) AS ClosedToRetainedEarnings
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
        INNER JOIN JournalEntry AS je
            ON je.EntryNumber = gl.VoucherNumber
    WHERE gl.SourceDocumentType = 'JournalEntry'
        AND je.EntryType LIKE 'Year-End Close - Income Summary%'
        AND a.AccountNumber = 3030
    GROUP BY gl.FiscalYear
),
Income AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountSubType = 'Operating Revenue'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS OperatingRevenue,
        SUM(CASE WHEN a.AccountSubType = 'Contra Revenue'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS Returns,
        SUM(CASE WHEN a.AccountSubType = 'COGS'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS CostOfGoodsSold,
        SUM(CASE WHEN a.AccountSubType = 'Operating Expense'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS OperatingExpense,
        SUM(CASE WHEN a.AccountSubType = 'Other Expense'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS InterestExpense,
        SUM(CASE WHEN a.AccountNumber = 7020
            THEN gl.Debit - gl.Credit ELSE 0 END) AS LossOnDisposal,
        SUM(gl.Credit - gl.Debit) AS NetIncome
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountType IN ('Revenue', 'Expense')
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY gl.FiscalYear
)
SELECT i.FiscalYear, ROUND(i.NetIncome, 2) AS NetIncome,
    ROUND(c.ClosedToRetainedEarnings, 2) AS ClosedToRetainedEarnings
FROM Income AS i
    INNER JOIN Closed AS c ON c.FiscalYear = i.FiscalYear
ORDER BY i.FiscalYear;  -- Result: 3 rows

-- Requirement 1: the recorded balance sheet totals at the three year-ends
-- Population: the trial balances of the three year-ends; expected: total assets 23,742,720.31, 31,838,684.00, 39,328,524.11
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
)
SELECT AsOfDate,
    ROUND(SUM(CASE WHEN AccountType = 'Asset'
        THEN Balance ELSE 0 END), 2) AS TotalAssets,
    ROUND(SUM(CASE WHEN AccountSubType IN ('Current Asset',
        'Contra Current Asset') THEN Balance ELSE 0 END), 2)
        AS CurrentAssets,
    ROUND(-SUM(CASE WHEN AccountSubType = 'Current Liability'
        THEN Balance ELSE 0 END), 2) AS CurrentLiabilities,
    ROUND(-SUM(CASE WHEN AccountNumber = 2110
        THEN Balance ELSE 0 END), 2) AS NotesPayable,
    ROUND(-SUM(CASE WHEN AccountNumber = 3030
        THEN Balance ELSE 0 END), 2) AS RetainedEarnings,
    ROUND(-SUM(CASE WHEN AccountNumber = 3010
        THEN Balance ELSE 0 END), 2) AS CommonStock
FROM Balances
GROUP BY AsOfDate
ORDER BY AsOfDate;  -- Result: 3 rows

-- Requirement 1: the recorded statements of income, 2025 and 2026, by AccountSubType
-- Population: revenue and expense postings, closes excluded; expected: operating income 5,195,867.83 and 4,625,057.71
WITH Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Income AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountSubType = 'Operating Revenue'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS OperatingRevenue,
        SUM(CASE WHEN a.AccountSubType = 'Contra Revenue'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS Returns,
        SUM(CASE WHEN a.AccountSubType = 'COGS'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS CostOfGoodsSold,
        SUM(CASE WHEN a.AccountSubType = 'Operating Expense'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS OperatingExpense,
        SUM(CASE WHEN a.AccountSubType = 'Other Expense'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS InterestExpense,
        SUM(CASE WHEN a.AccountNumber = 7020
            THEN gl.Debit - gl.Credit ELSE 0 END) AS LossOnDisposal,
        SUM(gl.Credit - gl.Debit) AS NetIncome
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountType IN ('Revenue', 'Expense')
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY gl.FiscalYear
)
SELECT FiscalYear, ROUND(OperatingRevenue, 2) AS OperatingRevenue,
    ROUND(Returns, 2) AS Returns,
    ROUND(OperatingRevenue - Returns, 2) AS NetRevenue,
    ROUND(CostOfGoodsSold, 2) AS CostOfGoodsSold,
    ROUND(OperatingRevenue - Returns - CostOfGoodsSold, 2)
        AS GrossMargin,
    ROUND(OperatingExpense, 2) AS OperatingExpense,
    ROUND(OperatingRevenue - Returns - CostOfGoodsSold
        - OperatingExpense, 2) AS OperatingIncome,
    ROUND(InterestExpense, 2) AS InterestExpense,
    ROUND(LossOnDisposal, 2) AS LossOnDisposal,
    ROUND(NetIncome, 2) AS NetIncome
FROM Income
WHERE FiscalYear IN (2025, 2026)
ORDER BY FiscalYear;  -- Result: 2 rows

-- Requirement 1: the accounts never posted, with an anti-join
-- Population: the chart without its headers; expected: 23 accounts, 16 active and 7 inactive
SELECT a.AccountNumber, a.AccountName, a.AccountType, a.IsActive
FROM Account AS a
    LEFT JOIN GLEntry AS gl ON gl.AccountID = a.AccountID
WHERE gl.GLEntryID IS NULL
    AND a.AccountSubType <> 'Header'
ORDER BY a.AccountNumber;  -- Result: 23 rows

-- Requirement 1: the accounts named for taxes, to see what the chart lacks
-- Population: the chart; expected: sales tax and payroll taxes only, no income tax account
SELECT AccountNumber, AccountName, AccountType, AccountSubType
FROM Account
WHERE AccountName LIKE '%Tax%'
ORDER BY AccountNumber;  -- Result: 4 rows

-- Milestone 1: the checkpoints of the ledger as it stands, at each year-end
-- Population: the trial balances of the three year-ends and the year's postings; expected: 69, 71, 71 accounts; net income 5,110,308.27, 5,134,354.71, 4,503,611.24
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
)
SELECT b.AsOfDate, COUNT(*) AS Accounts,
    SUM(CASE WHEN ROUND(b.Balance, 2) = 0 THEN 1 ELSE 0 END)
        AS AtZero,
    ROUND(SUM(CASE WHEN b.Balance > 0 THEN b.Balance ELSE 0 END), 2)
        AS DebitBalances,
    ROUND(-SUM(CASE WHEN b.Balance < 0 THEN b.Balance ELSE 0 END), 2)
        AS CreditBalances,
    ROUND(SUM(CASE WHEN b.AccountType = 'Asset'
        THEN b.Balance ELSE 0 END), 2) AS TotalAssets,
    ROUND(-SUM(CASE WHEN b.AccountType IN ('Revenue', 'Expense')
        THEN b.Balance ELSE 0 END), 2) AS NetIncome
FROM Balances AS b
GROUP BY b.AsOfDate
ORDER BY b.AsOfDate;  -- Result: 3 rows

-- Requirement 2: the controller's materiality, 5% of income before income taxes as the ledger records it
-- Population: revenue and expense postings, closes excluded (no income tax is recorded); expected: 256,717.74 (2025) and 225,180.56 (2026)
WITH Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Income AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountSubType = 'Operating Revenue'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS OperatingRevenue,
        SUM(CASE WHEN a.AccountSubType = 'Contra Revenue'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS Returns,
        SUM(CASE WHEN a.AccountSubType = 'COGS'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS CostOfGoodsSold,
        SUM(CASE WHEN a.AccountSubType = 'Operating Expense'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS OperatingExpense,
        SUM(CASE WHEN a.AccountSubType = 'Other Expense'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS InterestExpense,
        SUM(CASE WHEN a.AccountNumber = 7020
            THEN gl.Debit - gl.Credit ELSE 0 END) AS LossOnDisposal,
        SUM(gl.Credit - gl.Debit) AS NetIncome
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountType IN ('Revenue', 'Expense')
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY gl.FiscalYear
)
SELECT FiscalYear,
    ROUND(NetIncome, 2) AS IncomeBeforeIncomeTaxes,
    ROUND(NetIncome * 0.05, 2) AS Materiality
FROM Income
WHERE FiscalYear IN (2025, 2026)
ORDER BY FiscalYear;  -- Result: 2 rows

-- Requirement 2: the changes from 2025-12-31 to 2026-12-31 above the 2026 materiality
-- Population: the two trial balances, retained earnings aside; expected: 8 accounts, 1045, 2050, 1040, 1010, 2010, 4020, 5080, 5020
WITH YearEnds AS (
    SELECT '2025-12-31' AS AsOfDate
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
),
Changes AS (
    SELECT AccountNumber, AccountName,
        SUM(CASE WHEN AsOfDate = '2026-12-31' THEN Balance ELSE 0 END)
        - SUM(CASE WHEN AsOfDate = '2025-12-31' THEN Balance ELSE 0 END)
            AS Change
    FROM Balances
    WHERE AccountNumber <> 3030
    GROUP BY AccountID, AccountNumber, AccountName
)
SELECT AccountNumber, AccountName, ROUND(Change, 2) AS Change
FROM Changes
WHERE ABS(Change) > 225180.56
ORDER BY ABS(Change) DESC;  -- Result: 8 rows

-- Requirement 2: the balances that rest on the opening entry JE-2024-000001
-- Population: the opening entry's 18 lines and every other posting to their accounts; expected: 1050 60,000.00 alone, 2030 95,000.00 with the rest netting to zero
WITH Opening AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType = 'Opening'
)
SELECT a.AccountNumber, a.AccountName,
    ROUND(SUM(CASE WHEN gl.VoucherNumber IN (SELECT EntryNumber FROM Opening)
        THEN gl.Debit - gl.Credit ELSE 0 END), 2) AS OpeningLine,
    SUM(CASE WHEN gl.VoucherNumber IN (SELECT EntryNumber FROM Opening)
        THEN 0 ELSE 1 END) AS OtherPostings,
    ROUND(SUM(CASE WHEN gl.VoucherNumber IN (SELECT EntryNumber FROM Opening)
        THEN 0 ELSE gl.Debit - gl.Credit END), 2) AS OtherNet
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.AccountID IN (
    SELECT AccountID
    FROM GLEntry
    WHERE VoucherNumber IN (SELECT EntryNumber FROM Opening))
GROUP BY a.AccountID, a.AccountNumber, a.AccountName
ORDER BY a.AccountNumber;  -- Result: 18 rows

-- Requirement 3: the populations behind 2040, accrual entries, the invoice lines and adjustments that clear them
-- Population: JournalEntry, PurchaseInvoiceLine, and their 2040 postings; expected: 396 accruals, 4,052,446.62; 355 lines clearing 3,646,702.22; 149 adjustments
SELECT
    (SELECT COUNT(*)
     FROM JournalEntry
     WHERE EntryType = 'Accrual') AS AccrualEntries,
    (SELECT ROUND(SUM(gl.Credit), 2)
     FROM GLEntry AS gl
         INNER JOIN JournalEntry AS je
             ON je.JournalEntryID = gl.SourceDocumentID
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE gl.SourceDocumentType = 'JournalEntry'
         AND je.EntryType = 'Accrual'
         AND a.AccountNumber = 2040) AS Accrued,
    (SELECT COUNT(*)
     FROM PurchaseInvoiceLine
     WHERE AccrualJournalEntryID IS NOT NULL) AS LinesReferring,
    (SELECT COUNT(DISTINCT AccrualJournalEntryID)
     FROM PurchaseInvoiceLine) AS AccrualsReferred,
    (SELECT ROUND(SUM(gl.Debit), 2)
     FROM PurchaseInvoiceLine AS pil
         INNER JOIN GLEntry AS gl
             ON gl.SourceDocumentType = 'PurchaseInvoice'
             AND gl.SourceDocumentID = pil.PurchaseInvoiceID
             AND gl.SourceLineID = pil.PILineID
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE pil.AccrualJournalEntryID IS NOT NULL
         AND a.AccountNumber = 2040) AS ClearedByInvoices,
    (SELECT COUNT(*)
     FROM PurchaseInvoiceLine
     WHERE AccrualJournalEntryID IS NULL) AS LinesWithout,
    (SELECT COUNT(*)
     FROM JournalEntry
     WHERE EntryType = 'Accrual Adjustment') AS AdjustmentEntries,
    (SELECT COUNT(DISTINCT ReversesJournalEntryID)
     FROM JournalEntry
     WHERE EntryType = 'Accrual Adjustment') AS AdjustmentTargets,
    (SELECT ROUND(SUM(gl.Debit), 2)
     FROM GLEntry AS gl
         INNER JOIN JournalEntry AS je
             ON je.JournalEntryID = gl.SourceDocumentID
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE gl.SourceDocumentType = 'JournalEntry'
         AND je.EntryType = 'Accrual Adjustment'
         AND a.AccountNumber = 2040) AS ClearedByAdjustments;  -- Result: 1 rows

-- Requirement 3: invoice lines that cleared an accrual, the excess charged to expense by fiscal year
-- Population: the referring invoice lines' expense postings; expected: 24,489.89, 26,702.96, 34,364.32 on 60, 65, 84 lines
SELECT gl.FiscalYear, COUNT(DISTINCT pil.PILineID) AS Lines,
    ROUND(SUM(gl.Debit), 2) AS ExcessToExpense
FROM PurchaseInvoiceLine AS pil
    INNER JOIN GLEntry AS gl
        ON gl.SourceDocumentType = 'PurchaseInvoice'
        AND gl.SourceDocumentID = pil.PurchaseInvoiceID
        AND gl.SourceLineID = pil.PILineID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE pil.AccrualJournalEntryID IS NOT NULL
    AND a.AccountType = 'Expense'
    AND gl.Debit > 0
GROUP BY gl.FiscalYear
ORDER BY gl.FiscalYear;  -- Result: 3 rows

-- Requirement 3: how long invoices took to clear the accruals
-- Population: accruals cleared by an invoice; expected: 15 to 62 days, median 39, four at the longest
WITH Accruals AS (
    SELECT je.JournalEntryID, je.EntryNumber, je.PostingDate,
        MAX(CASE WHEN gl.Debit > 0 THEN a.AccountNumber END)
            AS ExpenseAccount,
        SUM(CASE WHEN a.AccountNumber = 2040 THEN gl.Credit ELSE 0 END)
            AS Amount
    FROM JournalEntry AS je
        INNER JOIN GLEntry AS gl
            ON gl.SourceDocumentType = 'JournalEntry'
            AND gl.SourceDocumentID = je.JournalEntryID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE je.EntryType = 'Accrual'
    GROUP BY je.JournalEntryID, je.EntryNumber, je.PostingDate
),
Clearing AS (
    SELECT pil.AccrualJournalEntryID AS JournalEntryID,
        gl.PostingDate, gl.Debit AS Amount, 'Invoice' AS Kind
    FROM PurchaseInvoiceLine AS pil
        INNER JOIN GLEntry AS gl
            ON gl.SourceDocumentType = 'PurchaseInvoice'
            AND gl.SourceDocumentID = pil.PurchaseInvoiceID
            AND gl.SourceLineID = pil.PILineID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE pil.AccrualJournalEntryID IS NOT NULL
        AND a.AccountNumber = 2040
    UNION ALL
    SELECT je.ReversesJournalEntryID, je.PostingDate, gl.Debit,
        'Adjustment'
    FROM JournalEntry AS je
        INNER JOIN GLEntry AS gl
            ON gl.SourceDocumentType = 'JournalEntry'
            AND gl.SourceDocumentID = je.JournalEntryID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE je.EntryType = 'Accrual Adjustment'
        AND a.AccountNumber = 2040
),
Lags AS (
    SELECT ac.JournalEntryID,
        julianday(MIN(cl.PostingDate)) - julianday(ac.PostingDate)
            AS LagDays
    FROM Accruals AS ac
        INNER JOIN Clearing AS cl ON cl.JournalEntryID = ac.JournalEntryID
    WHERE cl.Kind = 'Invoice'
    GROUP BY ac.JournalEntryID, ac.PostingDate
),
Ranked AS (
    SELECT LagDays,
        ROW_NUMBER() OVER (ORDER BY LagDays) AS Position,
        COUNT(*) OVER () AS Accruals
    FROM Lags
)
SELECT MAX(Accruals) AS Accruals, MIN(LagDays) AS Shortest,
    MAX(LagDays) AS Longest,
    MAX(CASE WHEN Position = Accruals / 2 + 1 THEN LagDays END)
        AS Median,
    SUM(CASE WHEN LagDays = (SELECT MAX(LagDays) FROM Lags)
        THEN 1 ELSE 0 END) AS AtLongest
FROM Ranked;  -- Result: 1 rows

-- Requirement 3: the open accruals at each year-end saved as a view, aged against the longest wait
-- Population: Accrual entries less what cleared them by each year-end; expected: the view OpenAccruals
DROP VIEW IF EXISTS OpenAccruals;
CREATE VIEW OpenAccruals AS
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Accruals AS (
    SELECT je.JournalEntryID, je.EntryNumber, je.PostingDate,
        MAX(CASE WHEN gl.Debit > 0 THEN a.AccountNumber END)
            AS ExpenseAccount,
        SUM(CASE WHEN a.AccountNumber = 2040 THEN gl.Credit ELSE 0 END)
            AS Amount
    FROM JournalEntry AS je
        INNER JOIN GLEntry AS gl
            ON gl.SourceDocumentType = 'JournalEntry'
            AND gl.SourceDocumentID = je.JournalEntryID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE je.EntryType = 'Accrual'
    GROUP BY je.JournalEntryID, je.EntryNumber, je.PostingDate
),
Clearing AS (
    SELECT pil.AccrualJournalEntryID AS JournalEntryID,
        gl.PostingDate, gl.Debit AS Amount, 'Invoice' AS Kind
    FROM PurchaseInvoiceLine AS pil
        INNER JOIN GLEntry AS gl
            ON gl.SourceDocumentType = 'PurchaseInvoice'
            AND gl.SourceDocumentID = pil.PurchaseInvoiceID
            AND gl.SourceLineID = pil.PILineID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE pil.AccrualJournalEntryID IS NOT NULL
        AND a.AccountNumber = 2040
    UNION ALL
    SELECT je.ReversesJournalEntryID, je.PostingDate, gl.Debit,
        'Adjustment'
    FROM JournalEntry AS je
        INNER JOIN GLEntry AS gl
            ON gl.SourceDocumentType = 'JournalEntry'
            AND gl.SourceDocumentID = je.JournalEntryID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE je.EntryType = 'Accrual Adjustment'
        AND a.AccountNumber = 2040
),
Lags AS (
    SELECT ac.JournalEntryID,
        julianday(MIN(cl.PostingDate)) - julianday(ac.PostingDate)
            AS LagDays
    FROM Accruals AS ac
        INNER JOIN Clearing AS cl ON cl.JournalEntryID = ac.JournalEntryID
    WHERE cl.Kind = 'Invoice'
    GROUP BY ac.JournalEntryID, ac.PostingDate
),
Cleared AS (
    SELECT ye.AsOfDate, ac.JournalEntryID,
        SUM(CASE WHEN cl.PostingDate <= ye.AsOfDate
            THEN cl.Amount ELSE 0 END) AS Cleared
    FROM YearEnds AS ye
        INNER JOIN Accruals AS ac ON ac.PostingDate <= ye.AsOfDate
        LEFT JOIN Clearing AS cl
            ON cl.JournalEntryID = ac.JournalEntryID
    GROUP BY ye.AsOfDate, ac.JournalEntryID
)
SELECT c.AsOfDate, ac.JournalEntryID, ac.EntryNumber,
    ac.PostingDate, ac.ExpenseAccount, ac.Amount, c.Cleared,
    ROUND(ac.Amount - c.Cleared, 2) AS OpenAmount,
    julianday(c.AsOfDate) - julianday(ac.PostingDate) AS AgeDays,
    CASE WHEN julianday(c.AsOfDate) - julianday(ac.PostingDate)
        > (SELECT MAX(LagDays) FROM Lags)
        THEN 1 ELSE 0 END AS IsOld,
    CASE WHEN ac.JournalEntryID IN (
        SELECT JournalEntryID FROM Clearing WHERE Kind = 'Invoice')
        THEN 1 ELSE 0 END AS Invoiced
FROM Cleared AS c
    INNER JOIN Accruals AS ac ON ac.JournalEntryID = c.JournalEntryID
WHERE ROUND(ac.Amount - c.Cleared, 2) > 0;  -- Result: creates the view OpenAccruals

-- Requirement 3: the open accruals at each year-end, within the clearing window and older
-- Population: the view OpenAccruals; expected: old items 39,028.43, 96,049.58, 157,346.79 (7, 15, 22)
SELECT AsOfDate,
    SUM(CASE WHEN IsOld = 0 THEN 1 ELSE 0 END) AS YoungItems,
    ROUND(SUM(CASE WHEN IsOld = 0 THEN OpenAmount ELSE 0 END), 2)
        AS Young,
    SUM(IsOld) AS OldItems,
    ROUND(SUM(CASE WHEN IsOld = 1 THEN OpenAmount ELSE 0 END), 2)
        AS Old
FROM OpenAccruals
GROUP BY AsOfDate
ORDER BY AsOfDate;  -- Result: 3 rows

-- Requirement 3: the accruals a rule of older than the last two month-ends would flag inside the window
-- Population: the view OpenAccruals, accruals dated before November and within the window; expected: JE-2025-000188 at 2025-12-31, 61 days old, invoiced on 2026-01-01
SELECT oa.AsOfDate, oa.EntryNumber, oa.PostingDate, oa.AgeDays,
    oa.OpenAmount,
    (SELECT MIN(gl.PostingDate)
     FROM PurchaseInvoiceLine AS pil
         INNER JOIN GLEntry AS gl
             ON gl.SourceDocumentType = 'PurchaseInvoice'
             AND gl.SourceDocumentID = pil.PurchaseInvoiceID
             AND gl.SourceLineID = pil.PILineID
     WHERE pil.AccrualJournalEntryID = oa.JournalEntryID)
        AS InvoicedOn
FROM OpenAccruals AS oa
WHERE oa.IsOld = 0
    AND oa.PostingDate < date(oa.AsOfDate, 'start of month',
        '-1 month')
ORDER BY oa.AsOfDate, oa.EntryNumber;  -- Result: 1 rows

-- Requirement 3: the freight accrued on shipments and the settlements that pay the carriers
-- Population: postings to 2040 and 5050, closes excluded; expected: shipment credits 1,477,398.06 equal to the 5050 debits; 35 settlements, 1,432,974.19
SELECT
    (SELECT ROUND(SUM(gl.Credit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 2040
         AND gl.SourceDocumentType = 'Shipment') AS ShipmentCredits,
    (SELECT ROUND(SUM(gl.Debit - gl.Credit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 5050
         AND gl.VoucherNumber NOT IN (
             SELECT EntryNumber
             FROM JournalEntry
             WHERE EntryType LIKE 'Year-End Close%')) AS FreightOut5050,
    (SELECT COUNT(*)
     FROM JournalEntry
     WHERE EntryType = 'Freight Settlement') AS Settlements,
    (SELECT ROUND(SUM(TotalAmount), 2)
     FROM JournalEntry
     WHERE EntryType = 'Freight Settlement') AS Settled,
    (SELECT MAX(PostingDate)
     FROM JournalEntry
     WHERE EntryType = 'Freight Settlement') AS LastSettlement;  -- Result: 1 rows

-- Requirement 3: account 2040 at each year-end split into its parts and reconciled to the ledger
-- Population: the opening line, shipment freight less settlements, the view OpenAccruals, and 2040's balance; expected: 325,172.77, 396,988.71, 480,552.36, no difference
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Postings AS (
    SELECT gl.PostingDate, gl.SourceDocumentType, gl.Debit,
        gl.Credit, je.EntryType
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
        LEFT JOIN JournalEntry AS je
            ON gl.SourceDocumentType = 'JournalEntry'
            AND je.JournalEntryID = gl.SourceDocumentID
    WHERE a.AccountNumber = 2040
),
Parts AS (
    SELECT ye.AsOfDate,
        SUM(CASE WHEN p.EntryType = 'Opening'
            THEN p.Credit - p.Debit ELSE 0 END) AS Opening,
        SUM(CASE WHEN p.SourceDocumentType = 'Shipment'
            THEN p.Credit ELSE 0 END)
        - SUM(CASE WHEN p.EntryType = 'Freight Settlement'
            THEN p.Debit ELSE 0 END) AS Freight,
        SUM(CASE WHEN p.SourceDocumentType = 'Shipment'
            AND p.PostingDate >= date(ye.AsOfDate, 'start of month')
            THEN p.Credit ELSE 0 END) AS DecemberFreight,
        SUM(p.Credit - p.Debit) AS Ledger
    FROM YearEnds AS ye
        INNER JOIN Postings AS p ON p.PostingDate <= ye.AsOfDate
    GROUP BY ye.AsOfDate
)
SELECT pa.AsOfDate, ROUND(pa.Opening, 2) AS Opening,
    ROUND(pa.Freight, 2) AS FreightNotSettled,
    ROUND(pa.DecemberFreight, 2) AS DecemberFreight,
    ROUND(SUM(CASE WHEN oa.IsOld = 0 THEN oa.OpenAmount ELSE 0 END), 2)
        AS YoungAccruals,
    ROUND(SUM(CASE WHEN oa.IsOld = 1 THEN oa.OpenAmount ELSE 0 END), 2)
        AS OldAccruals,
    ROUND(pa.Opening + pa.Freight + SUM(oa.OpenAmount), 2) AS Parts,
    ROUND(pa.Ledger, 2) AS Ledger,
    ROUND(pa.Opening + pa.Freight + SUM(oa.OpenAmount)
        - pa.Ledger, 2) AS Difference
FROM Parts AS pa
    INNER JOIN OpenAccruals AS oa ON oa.AsOfDate = pa.AsOfDate
GROUP BY pa.AsOfDate, pa.Opening, pa.Freight, pa.DecemberFreight,
    pa.Ledger
ORDER BY pa.AsOfDate;  -- Result: 3 rows

-- Requirement 3: the accruals older than the window at 2026-12-31, the items to reverse
-- Population: the view OpenAccruals at 2026-12-31; expected: 22 items, 157,346.79, none ever invoiced
SELECT EntryNumber, PostingDate, ExpenseAccount,
    ROUND(Amount, 2) AS Amount, ROUND(Cleared, 2) AS Cleared,
    OpenAmount, AgeDays, Invoiced
FROM OpenAccruals
WHERE AsOfDate = '2026-12-31'
    AND IsOld = 1
ORDER BY PostingDate, EntryNumber;  -- Result: 22 rows

-- Requirement 3: accruals young at 2024-12-31 or 2025-12-31 that no invoice ever cleared, and what of them is open at 2026-12-31
-- Population: the view OpenAccruals; expected: 32,929.99 of 2024's young items and 5,590.35 of 2025's still open at 2026-12-31
SELECT y.AsOfDate, y.EntryNumber, y.PostingDate,
    y.OpenAmount AS OpenThen,
    COALESCE(c.OpenAmount, 0) AS OpenAt2026
FROM OpenAccruals AS y
    LEFT JOIN OpenAccruals AS c
        ON c.JournalEntryID = y.JournalEntryID
        AND c.AsOfDate = '2026-12-31'
WHERE y.AsOfDate IN ('2024-12-31', '2025-12-31')
    AND y.IsOld = 0
    AND y.Invoiced = 0
ORDER BY y.AsOfDate, y.EntryNumber;  -- Result: 5 rows

-- Requirement 4: test L5, invoices posted in another year than the latest delivery they bill (LateInvoices)
-- Population: every sales invoice with shipped lines; expected: 15 for 2024 deliveries (90,138.93) and 8 for 2025 (19,540.86)
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
)
SELECT si.InvoiceNumber, si.InvoiceDate, p.PostingDate,
    sh.DeliveryDate, c.CustomerSegment, si.SubTotal,
    si.TaxAmount, si.FreightAmount,
    ROUND(SUM(CASE WHEN i.ItemGroup = 'Furniture'
        THEN sil.LineTotal ELSE 0 END), 2) AS Furniture,
    ROUND(SUM(CASE WHEN i.ItemGroup = 'Lighting'
        THEN sil.LineTotal ELSE 0 END), 2) AS Lighting,
    ROUND(SUM(CASE WHEN i.ItemGroup = 'Textiles'
        THEN sil.LineTotal ELSE 0 END), 2) AS Textiles,
    ROUND(SUM(CASE WHEN i.ItemGroup = 'Accessories'
        THEN sil.LineTotal ELSE 0 END), 2) AS Accessories
FROM SalesInvoice AS si
    INNER JOIN Shipped AS sh ON sh.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Customer AS c ON c.CustomerID = si.CustomerID
    INNER JOIN SalesInvoiceLine AS sil
        ON sil.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Item AS i ON i.ItemID = sil.ItemID
WHERE strftime('%Y', p.PostingDate) <> strftime('%Y', sh.DeliveryDate)
GROUP BY si.SalesInvoiceID, si.InvoiceNumber, si.InvoiceDate,
    p.PostingDate, sh.DeliveryDate, c.CustomerSegment,
    si.SubTotal, si.TaxAmount, si.FreightAmount
ORDER BY p.PostingDate, si.InvoiceNumber;  -- Result: 23 rows

-- Requirement 4: test L6, shipment lines never invoiced, at order price less discount (UnbilledLines)
-- Population: every shipment line; expected: 9 December 2026 lines, 44,481.11 at order price, standard cost 22,895.78
SELECT sl.ShipmentLineID, s.ShipmentNumber, s.ShipmentDate,
    s.DeliveryDate, i.ItemCode, i.ItemGroup, c.CustomerSegment,
    sl.QuantityShipped, sol.UnitPrice, sol.Discount,
    sl.ExtendedStandardCost,
    ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
        AS Value
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    INNER JOIN Item AS i ON i.ItemID = sl.ItemID
    INNER JOIN SalesOrder AS so ON so.SalesOrderID = s.SalesOrderID
    INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL
ORDER BY sl.ShipmentLineID;  -- Result: 9 rows

-- Requirement 4: the revenue account each item group's invoice lines are credited to (GroupAccounts)
-- Population: SalesInvoice postings joined to their invoice lines and items; expected: 5 item groups, one account each
SELECT i.ItemGroup, a.AccountNumber AS RevenueAccount
FROM GLEntry AS gl
    INNER JOIN SalesInvoiceLine AS sil
        ON sil.SalesInvoiceID = gl.SourceDocumentID
        AND sil.SalesInvoiceLineID = gl.SourceLineID
    INNER JOIN Item AS i ON i.ItemID = sil.ItemID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND a.AccountSubType = 'Operating Revenue'
GROUP BY i.ItemGroup, a.AccountID, a.AccountNumber
ORDER BY CASE i.ItemGroup
        WHEN 'Furniture' THEN 1 WHEN 'Lighting' THEN 2
        WHEN 'Textiles' THEN 3 WHEN 'Accessories' THEN 4
        ELSE 5 END,
    i.ItemGroup;  -- Result: 5 rows

-- Requirement 4: test L7 of Audit.sql rerun, the pay periods that cross each year-end
-- Population: every pay period; expected: the periods of 2024-12-16 and 2024-12-30, 2025-12-15 and 2025-12-29, and two 2026 periods with no registers
SELECT pp.PeriodNumber, pp.PeriodStartDate, pp.PeriodEndDate,
    pp.PayDate, pp.Status, COALESCE(reg.Registers, 0) AS Registers,
    reg.PayrollCost
FROM PayrollPeriod AS pp
    LEFT JOIN (
        SELECT PayrollPeriodID, COUNT(*) AS Registers,
            ROUND(SUM(GrossPay + EmployerPayrollTax
                + EmployerBenefits), 2) AS PayrollCost
        FROM PayrollRegister
        GROUP BY PayrollPeriodID
    ) AS reg ON reg.PayrollPeriodID = pp.PayrollPeriodID
WHERE strftime('%Y', pp.PeriodStartDate) <> strftime('%Y', pp.PayDate)
ORDER BY pp.PeriodStartDate;  -- Result: 6 rows

-- Requirement 4: test L8 of Audit.sql rerun, account 2030 at the year-end by source document type
-- Population: account 2030 to 2026-12-31; expected: the opening 95,000.00 alone, the payroll postings netting to zero, so no year-end has accrued wages
SELECT gl.SourceDocumentType, COUNT(*) AS Postings,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 2030 AND gl.PostingDate <= '2026-12-31'
GROUP BY gl.SourceDocumentType;  -- Result: 3 rows

-- Requirement 4: the payroll owed at 2024-12-31 and 2025-12-31, the registers of the periods paid after the year-end prorated by working day
-- Population: PayrollPeriod and PayrollRegister, WorkCenterCalendar; expected: 302,568.90 and 365,921.19
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
),
Periods AS (
    SELECT ye.AsOfDate, pp.PayrollPeriodID,
        (SELECT COUNT(DISTINCT c.CalendarDate)
         FROM WorkCenterCalendar AS c
         WHERE c.IsWorkingDay = 1
             AND c.CalendarDate BETWEEN pp.PeriodStartDate
                 AND pp.PeriodEndDate
             AND c.CalendarDate <= ye.AsOfDate) AS DaysInYear,
        (SELECT COUNT(DISTINCT c.CalendarDate)
         FROM WorkCenterCalendar AS c
         WHERE c.IsWorkingDay = 1
             AND c.CalendarDate BETWEEN pp.PeriodStartDate
                 AND pp.PeriodEndDate) AS WorkingDays
    FROM YearEnds AS ye
        INNER JOIN PayrollPeriod AS pp
            ON pp.PeriodStartDate <= ye.AsOfDate
            AND pp.PayDate > ye.AsOfDate
)
SELECT p.AsOfDate, COUNT(DISTINCT p.PayrollPeriodID) AS Periods,
    ROUND(SUM((pr.GrossPay + pr.EmployerPayrollTax
        + pr.EmployerBenefits) * p.DaysInYear / p.WorkingDays), 2)
        AS PayrollOwed,
    ROUND(SUM(pr.GrossPay * p.DaysInYear / p.WorkingDays), 2)
        AS GrossPay,
    ROUND(SUM(pr.EmployerPayrollTax * p.DaysInYear / p.WorkingDays), 2)
        AS EmployerTaxes,
    ROUND(SUM(pr.EmployerBenefits * p.DaysInYear / p.WorkingDays), 2)
        AS Benefits,
    ROUND(SUM(CASE WHEN cc.CostCenterName = 'Manufacturing'
        THEN (pr.GrossPay + pr.EmployerPayrollTax
            + pr.EmployerBenefits) * p.DaysInYear / p.WorkingDays
        ELSE 0 END), 2) AS Manufacturing
FROM Periods AS p
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollPeriodID = p.PayrollPeriodID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
GROUP BY p.AsOfDate
ORDER BY p.AsOfDate;  -- Result: 2 rows

-- Requirement 4: the payroll owed at 2026-12-31, the last eight processed periods' cost per working day
-- Population: the last eight processed pay periods, WorkCenterCalendar; expected: 2,298,268.90 over 78 working days x 13 days = 383,044.82
WITH LastEight AS (
    SELECT PayrollPeriodID, PeriodStartDate, PeriodEndDate
    FROM PayrollPeriod
    WHERE Status = 'Processed'
    ORDER BY PeriodEndDate DESC
    LIMIT 8
),
Days AS (
    SELECT
        (SELECT COUNT(DISTINCT CalendarDate)
         FROM WorkCenterCalendar
         WHERE IsWorkingDay = 1
             AND CalendarDate
                 BETWEEN (SELECT MIN(PeriodStartDate) FROM LastEight)
                 AND (SELECT MAX(PeriodEndDate) FROM LastEight)) AS PeriodDays,
        (SELECT COUNT(DISTINCT CalendarDate)
         FROM WorkCenterCalendar
         WHERE IsWorkingDay = 1
             AND CalendarDate > (SELECT MAX(PeriodEndDate) FROM LastEight)
             AND CalendarDate <= '2026-12-31') AS DaysLeft
),
Cost AS (
    SELECT SUM(pr.GrossPay) AS GrossPay,
        SUM(pr.EmployerPayrollTax) AS EmployerTaxes,
        SUM(pr.EmployerBenefits) AS Benefits,
        SUM(CASE WHEN cc.CostCenterName = 'Manufacturing'
            THEN pr.GrossPay + pr.EmployerPayrollTax
                + pr.EmployerBenefits ELSE 0 END) AS Manufacturing
    FROM PayrollRegister AS pr
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
    WHERE pr.PayrollPeriodID IN (SELECT PayrollPeriodID FROM LastEight)
)
SELECT ROUND(GrossPay + EmployerTaxes + Benefits, 2) AS PeriodCost,
    (SELECT PeriodDays FROM Days) AS PeriodDays,
    (SELECT DaysLeft FROM Days) AS DaysLeft,
    ROUND((GrossPay + EmployerTaxes + Benefits)
        / (SELECT PeriodDays FROM Days), 2) AS CostPerDay,
    ROUND((GrossPay + EmployerTaxes + Benefits)
        / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days), 2) AS PayrollOwed,
    ROUND(GrossPay / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days), 2) AS GrossPay,
    ROUND(EmployerTaxes / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days), 2) AS EmployerTaxes,
    ROUND(Benefits / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days), 2) AS Benefits,
    ROUND(Manufacturing / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days), 2) AS Manufacturing
FROM Cost;  -- Result: 1 rows

-- Requirement 4: the account each cost center's gross pay is debited to (PayrollAccounts)
-- Population: PayrollSummary debits of 2026 other than 6060; expected: Manufacturing to 1090, the others to their salary accounts
SELECT cc.CostCenterName, a.AccountNumber AS PayrollAccount
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = gl.CostCenterID
WHERE gl.SourceDocumentType = 'PayrollSummary'
    AND gl.Debit > 0
    AND a.AccountNumber <> 6060
    AND gl.FiscalYear = 2026
GROUP BY cc.CostCenterID, cc.CostCenterName, a.AccountID,
    a.AccountNumber
ORDER BY cc.CostCenterName;  -- Result: 10 rows

-- Requirement 4: the interest each note had accrued at each year-end, from DebtScheduleLine
-- Population: DebtAgreement and DebtScheduleLine; each payment's interest covers the days since the one before, counted from that day; expected: 1,838.58, 1,369.27, 2,007.26
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Notes AS (
    SELECT ye.AsOfDate, da.DebtAgreementID, da.AgreementNumber,
        COALESCE(
            (SELECT MAX(dl.PaymentDate)
             FROM DebtScheduleLine AS dl
             WHERE dl.DebtAgreementID = da.DebtAgreementID
                 AND dl.PaymentDate <= ye.AsOfDate),
            da.OriginationDate) AS PreviousDate,
        (SELECT MIN(dl.PaymentDate)
         FROM DebtScheduleLine AS dl
         WHERE dl.DebtAgreementID = da.DebtAgreementID
             AND dl.PaymentDate > ye.AsOfDate) AS NextPaymentDate
    FROM YearEnds AS ye
        INNER JOIN DebtAgreement AS da
            ON da.OriginationDate <= ye.AsOfDate
)
SELECT n.AsOfDate, n.AgreementNumber, n.PreviousDate,
    n.NextPaymentDate, dl.InterestAmount AS NextInterest,
    julianday(n.NextPaymentDate) - julianday(n.PreviousDate)
        AS DaysInPeriod,
    julianday(n.AsOfDate) - julianday(n.PreviousDate) + 1
        AS DaysAccrued,
    ROUND(dl.InterestAmount
        * CASE WHEN julianday(n.AsOfDate) + 1
                < julianday(n.NextPaymentDate)
            THEN julianday(n.AsOfDate) - julianday(n.PreviousDate) + 1
            ELSE julianday(n.NextPaymentDate)
                - julianday(n.PreviousDate) END
        / (julianday(n.NextPaymentDate) - julianday(n.PreviousDate)),
        2) AS InterestAccrued
FROM Notes AS n
    INNER JOIN DebtScheduleLine AS dl
        ON dl.DebtAgreementID = n.DebtAgreementID
        AND dl.PaymentDate = n.NextPaymentDate
ORDER BY n.AsOfDate, n.AgreementNumber;  -- Result: 4 rows

-- Requirement 5: the open receivables at 2025-12-31 and 2026-12-31 saved as a view, aged in Exercise 8.1's buckets
-- Population: each invoice dated by the year-end less the receipts applied and the credit memos dated by then, rounded, kept if greater than zero; expected: the view OpenReceivables
DROP VIEW IF EXISTS OpenReceivables;
CREATE VIEW OpenReceivables AS
WITH YearEnds AS (
    SELECT '2025-12-31' AS AsOfDate
    UNION ALL
    SELECT '2026-12-31'
),
Applied AS (
    SELECT ye.AsOfDate, a.SalesInvoiceID,
        SUM(a.AppliedAmount) AS Applied
    FROM YearEnds AS ye
        INNER JOIN CashReceiptApplication AS a
            ON a.ApplicationDate <= ye.AsOfDate
    GROUP BY ye.AsOfDate, a.SalesInvoiceID
),
Credited AS (
    SELECT ye.AsOfDate, cm.OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(cm.GrandTotal) AS Credited
    FROM YearEnds AS ye
        INNER JOIN CreditMemo AS cm
            ON cm.CreditMemoDate <= ye.AsOfDate
    GROUP BY ye.AsOfDate, cm.OriginalSalesInvoiceID
),
Balances AS (
    SELECT ye.AsOfDate, si.SalesInvoiceID, si.CustomerID,
        ROUND(si.GrandTotal - COALESCE(ap.Applied, 0)
            - COALESCE(cr.Credited, 0), 2) AS Balance,
        julianday(ye.AsOfDate) - julianday(si.DueDate)
            AS DaysPastDue
    FROM YearEnds AS ye
        INNER JOIN SalesInvoice AS si
            ON si.InvoiceDate <= ye.AsOfDate
        LEFT JOIN Applied AS ap
            ON ap.AsOfDate = ye.AsOfDate
            AND ap.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS cr
            ON cr.AsOfDate = ye.AsOfDate
            AND cr.SalesInvoiceID = si.SalesInvoiceID
)
SELECT AsOfDate, SalesInvoiceID, CustomerID, Balance, DaysPastDue,
    CASE
        WHEN DaysPastDue <= 0 THEN 1
        WHEN DaysPastDue <= 30 THEN 2
        WHEN DaysPastDue <= 60 THEN 3
        WHEN DaysPastDue <= 90 THEN 4
        ELSE 5
    END AS BucketOrder
FROM Balances
WHERE Balance > 0;  -- Result: creates the view OpenReceivables

-- Requirement 5: the receivables aging at the two year-ends (ReceivableAging)
-- Population: the view OpenReceivables; expected: 1,120 and 1,079 open invoices, 4,360,706.74 and 4,418,804.32
SELECT CASE BucketOrder
        WHEN 1 THEN 'Current' WHEN 2 THEN '1-30 days'
        WHEN 3 THEN '31-60 days' WHEN 4 THEN '61-90 days'
        ELSE 'Over 90 days'
    END AS Bucket,
    ROUND(SUM(CASE WHEN AsOfDate = '2025-12-31'
        THEN Balance ELSE 0 END), 2) AS Balance2025,
    SUM(CASE WHEN AsOfDate = '2025-12-31' THEN 1 ELSE 0 END)
        AS Invoices2025,
    ROUND(SUM(CASE WHEN AsOfDate = '2026-12-31'
        THEN Balance ELSE 0 END), 2) AS Balance2026,
    SUM(CASE WHEN AsOfDate = '2026-12-31' THEN 1 ELSE 0 END)
        AS Invoices2026
FROM OpenReceivables
GROUP BY BucketOrder
ORDER BY BucketOrder;  -- Result: 5 rows

-- Requirement 5: passed item P1, an allowance at Exercise 8.1's rates at each year-end
-- Population: the view OpenReceivables; rates 0.5%, 2%, 5%, 15%, 40%; expected: 34,659.34 (2025) and 34,106.25 (2026)
WITH Buckets AS (
    SELECT AsOfDate, BucketOrder,
        ROUND(SUM(Balance), 2) AS Balance
    FROM OpenReceivables
    GROUP BY AsOfDate, BucketOrder
)
SELECT AsOfDate,
    ROUND(SUM(ROUND(Balance * CASE BucketOrder
        WHEN 1 THEN 0.005 WHEN 2 THEN 0.02 WHEN 3 THEN 0.05
        WHEN 4 THEN 0.15 ELSE 0.40 END, 2)), 2) AS Allowance
FROM Buckets
GROUP BY AsOfDate
ORDER BY AsOfDate;  -- Result: 2 rows

-- Requirement 5: passed item P2, returns made in a later year than the delivery (ReturnsAfterYearEnd)
-- Population: returns, each dated by the delivery of its first line, their credit memos, and the returned lines' standard cost; expected: 14 returns in 2026, 16,319.03 less 9,545.90
WITH FirstLine AS (
    SELECT SalesReturnID, MIN(ShipmentLineID) AS ShipmentLineID
    FROM SalesReturnLine
    GROUP BY SalesReturnID
),
Returned AS (
    SELECT CAST(strftime('%Y', sr.ReturnDate) AS INTEGER)
            AS ReturnYear,
        CAST(strftime('%Y', s.DeliveryDate) AS INTEGER)
            AS DeliveryYear,
        COUNT(DISTINCT sr.SalesReturnID) AS Returns,
        ROUND(SUM(cm.SubTotal), 2) AS CreditMemoRevenue
    FROM SalesReturn AS sr
        INNER JOIN CreditMemo AS cm
            ON cm.SalesReturnID = sr.SalesReturnID
        INNER JOIN FirstLine AS fl
            ON fl.SalesReturnID = sr.SalesReturnID
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = fl.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    WHERE strftime('%Y', sr.ReturnDate)
        <> strftime('%Y', s.DeliveryDate)
    GROUP BY ReturnYear, DeliveryYear
),
LineCost AS (
    SELECT CAST(strftime('%Y', sr.ReturnDate) AS INTEGER)
            AS ReturnYear,
        ROUND(SUM(srl.ExtendedStandardCost), 2) AS StandardCost
    FROM SalesReturn AS sr
        INNER JOIN SalesReturnLine AS srl
            ON srl.SalesReturnID = sr.SalesReturnID
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = srl.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    WHERE strftime('%Y', sr.ReturnDate)
        <> strftime('%Y', s.DeliveryDate)
    GROUP BY ReturnYear
)
SELECT r.ReturnYear, r.DeliveryYear, r.Returns,
    r.CreditMemoRevenue, COALESCE(lc.StandardCost, 0) AS StandardCost
FROM Returned AS r
    LEFT JOIN LineCost AS lc ON lc.ReturnYear = r.ReturnYear
ORDER BY r.ReturnYear, r.DeliveryYear;  -- Result: 2 rows

-- Requirement 5: passed item P3, returns put back into stock at full standard cost, and the Damaged and Quality Concern ones
-- Population: return lines by return year, and the SalesReturn debits to 1040; expected: 24,429.94, 52,030.49, 61,146.00 restocked damaged or of concern
WITH Restocked AS (
    SELECT CAST(strftime('%Y', sr.ReturnDate) AS INTEGER) AS FiscalYear,
        SUM(srl.ExtendedStandardCost) AS ReturnedCost,
        SUM(CASE WHEN sr.ReasonCode IN ('Damaged', 'Quality Concern')
            THEN srl.ExtendedStandardCost ELSE 0 END) AS WriteDownCandidates
    FROM SalesReturn AS sr
        INNER JOIN SalesReturnLine AS srl
            ON srl.SalesReturnID = sr.SalesReturnID
    GROUP BY FiscalYear
),
Ledger AS (
    SELECT gl.FiscalYear, SUM(gl.Debit) AS RestockedToInventory
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'SalesReturn'
        AND a.AccountNumber = 1040
    GROUP BY gl.FiscalYear
)
SELECT r.FiscalYear, ROUND(r.ReturnedCost, 2) AS ReturnedCost,
    ROUND(l.RestockedToInventory, 2) AS RestockedToInventory,
    ROUND(r.WriteDownCandidates, 2) AS DamagedOrOfConcern
FROM Restocked AS r
    INNER JOIN Ledger AS l ON l.FiscalYear = r.FiscalYear
ORDER BY r.FiscalYear;  -- Result: 3 rows

-- Requirement 5: reclassification R1, the principal of the notes due within a year of each year-end
-- Population: DebtScheduleLine of the notes originated by each year-end; expected: 89,243.61 (2025) and 147,503.76 (2026)
WITH YearEnds AS (
    SELECT '2025-12-31' AS AsOfDate
    UNION ALL
    SELECT '2026-12-31'
)
SELECT ye.AsOfDate,
    ROUND(SUM(dl.PrincipalAmount), 2) AS CurrentPortion,
    COUNT(DISTINCT dl.DebtAgreementID) AS Notes
FROM YearEnds AS ye
    INNER JOIN DebtScheduleLine AS dl
        ON dl.PaymentDate > ye.AsOfDate
        AND dl.PaymentDate <= date(ye.AsOfDate, '+1 year')
    INNER JOIN DebtAgreement AS da
        ON da.DebtAgreementID = dl.DebtAgreementID
        AND da.OriginationDate <= ye.AsOfDate
GROUP BY ye.AsOfDate
ORDER BY ye.AsOfDate;  -- Result: 2 rows

-- Requirement 5: reclassification R2, the credit balance of 1090 and work in process at both year-ends
-- Population: the trial balances at 2025-12-31 and 2026-12-31; expected: 1090 -49,102.81 and -46,730.55, 1046 63,392.97 and 61,095.34
WITH YearEnds AS (
    SELECT '2025-12-31' AS AsOfDate
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
)
SELECT AsOfDate,
    ROUND(SUM(CASE WHEN AccountNumber = 1090
        THEN Balance ELSE 0 END), 2) AS ClearingAccount1090,
    ROUND(SUM(CASE WHEN AccountNumber = 1046
        THEN Balance ELSE 0 END), 2) AS WorkInProcess1046
FROM Balances
WHERE AccountNumber IN (1046, 1090)
GROUP BY AsOfDate
ORDER BY AsOfDate;  -- Result: 2 rows

-- Requirement 6: the change in cash and the interest paid each year, which no adjustment changes
-- Population: postings to 1010 and the Interest Payment entries; expected: cash 5,888,974.24, 9,383,566.10, 8,442,255.80; interest paid 19,513.12 and 28,946.47
WITH Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Cash AS (
    SELECT gl.FiscalYear, SUM(gl.Debit - gl.Credit) AS Change
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 1010
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY gl.FiscalYear
),
Interest AS (
    SELECT gl.FiscalYear, SUM(gl.Debit) AS InterestPaid
    FROM GLEntry AS gl
        INNER JOIN JournalEntry AS je
            ON je.JournalEntryID = gl.SourceDocumentID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'JournalEntry'
        AND je.EntryType = 'Interest Payment'
        AND a.AccountNumber = 7030
    GROUP BY gl.FiscalYear
)
SELECT c.FiscalYear, ROUND(c.Change, 2) AS ChangeInCash,
    ROUND((SELECT SUM(c2.Change) FROM Cash AS c2
        WHERE c2.FiscalYear <= c.FiscalYear), 2) AS CashAtYearEnd,
    ROUND(COALESCE(i.InterestPaid, 0), 2) AS InterestPaid
FROM Cash AS c
    LEFT JOIN Interest AS i ON i.FiscalYear = c.FiscalYear
WHERE c.FiscalYear <= 2026
ORDER BY c.FiscalYear;  -- Result: 3 rows

-- Requirement 6: the investing events that moved no cash, equipment financed by a note and disposals with no proceeds
-- Population: FixedAssetEvent; expected: equipment financed by notes 360,000.00 in 2024, 280,000.00 in 2026
SELECT strftime('%Y', fe.EventDate) AS FiscalYear, fe.EventType,
    fe.FinancingType, fa.AssetCode, fe.Amount, fe.ProceedsAmount
FROM FixedAssetEvent AS fe
    INNER JOIN FixedAsset AS fa ON fa.FixedAssetID = fe.FixedAssetID
WHERE fe.FinancingType IN ('Note', 'None')
ORDER BY fe.EventDate;  -- Result: 4 rows

-- Requirement 7: property and equipment, the cost rolled forward by class from FixedAsset
-- Population: FixedAsset by cost account; expected: cost 4,027,000.00 -> 4,284,000.00 -> 4,354,000.00
WITH Register AS (
    SELECT fa.AssetCode, ca.AccountNumber AS CostAccount,
        aa.AccountNumber AS DepreciationAccount, fa.InServiceDate,
        fa.DisposalDate, fa.OriginalCost, fa.UsefulLifeMonths,
        fa.ResidualValue,
        ROUND(fa.OriginalCost * 1.0 / fa.UsefulLifeMonths, 2) AS Monthly,
        CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
            + CAST(strftime('%m', fa.InServiceDate) AS INTEGER) AS FirstMonth,
        CASE
            WHEN fa.DisposalDate IS NULL
                OR CAST(strftime('%Y', fa.DisposalDate) AS INTEGER) * 12
                    + CAST(strftime('%m', fa.DisposalDate) AS INTEGER) - 2
                    > CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
                    + CAST(strftime('%m', fa.InServiceDate) AS INTEGER) - 1
                    + fa.UsefulLifeMonths
                THEN CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
                    + CAST(strftime('%m', fa.InServiceDate) AS INTEGER) - 1
                    + fa.UsefulLifeMonths
            ELSE CAST(strftime('%Y', fa.DisposalDate) AS INTEGER) * 12
                + CAST(strftime('%m', fa.DisposalDate) AS INTEGER) - 2
        END AS LastMonth
    FROM FixedAsset AS fa
        INNER JOIN Account AS ca ON ca.AccountID = fa.AssetAccountID
        INNER JOIN Account AS aa
            ON aa.AccountID = fa.AccumulatedDepreciationAccountID
)
SELECT CostAccount,
    SUM(CASE WHEN InServiceDate <= '2024-12-31'
        AND (DisposalDate IS NULL OR DisposalDate > '2024-12-31')
        THEN OriginalCost ELSE 0 END) AS Cost2024,
    SUM(CASE WHEN InServiceDate BETWEEN '2025-01-01' AND '2025-12-31'
        THEN OriginalCost ELSE 0 END) AS Additions2025,
    SUM(CASE WHEN DisposalDate BETWEEN '2025-01-01' AND '2025-12-31'
        THEN OriginalCost ELSE 0 END) AS Disposals2025,
    SUM(CASE WHEN InServiceDate <= '2025-12-31'
        AND (DisposalDate IS NULL OR DisposalDate > '2025-12-31')
        THEN OriginalCost ELSE 0 END) AS Cost2025,
    SUM(CASE WHEN InServiceDate BETWEEN '2026-01-01' AND '2026-12-31'
        THEN OriginalCost ELSE 0 END) AS Additions2026,
    SUM(CASE WHEN DisposalDate BETWEEN '2026-01-01' AND '2026-12-31'
        THEN OriginalCost ELSE 0 END) AS Disposals2026,
    SUM(CASE WHEN InServiceDate <= '2026-12-31'
        AND (DisposalDate IS NULL OR DisposalDate > '2026-12-31')
        THEN OriginalCost ELSE 0 END) AS Cost2026,
    MIN(UsefulLifeMonths) AS ShortestLife,
    MAX(UsefulLifeMonths) AS LongestLife,
    SUM(ResidualValue) AS ResidualValue
FROM Register
GROUP BY CostAccount
ORDER BY CostAccount;  -- Result: 4 rows

-- Requirement 7: depreciation by class and year, the register against the ledger
-- Population: FixedAsset (each asset's cost over its life in months, from the month after it is placed in service through the month before disposal) and the Depreciation entries; expected: 542,423.80 (2025) and 576,245.19 (2026)
WITH Register AS (
    SELECT fa.AssetCode, ca.AccountNumber AS CostAccount,
        aa.AccountNumber AS DepreciationAccount, fa.InServiceDate,
        fa.DisposalDate, fa.OriginalCost, fa.UsefulLifeMonths,
        fa.ResidualValue,
        ROUND(fa.OriginalCost * 1.0 / fa.UsefulLifeMonths, 2) AS Monthly,
        CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
            + CAST(strftime('%m', fa.InServiceDate) AS INTEGER) AS FirstMonth,
        CASE
            WHEN fa.DisposalDate IS NULL
                OR CAST(strftime('%Y', fa.DisposalDate) AS INTEGER) * 12
                    + CAST(strftime('%m', fa.DisposalDate) AS INTEGER) - 2
                    > CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
                    + CAST(strftime('%m', fa.InServiceDate) AS INTEGER) - 1
                    + fa.UsefulLifeMonths
                THEN CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
                    + CAST(strftime('%m', fa.InServiceDate) AS INTEGER) - 1
                    + fa.UsefulLifeMonths
            ELSE CAST(strftime('%Y', fa.DisposalDate) AS INTEGER) * 12
                + CAST(strftime('%m', fa.DisposalDate) AS INTEGER) - 2
        END AS LastMonth
    FROM FixedAsset AS fa
        INNER JOIN Account AS ca ON ca.AccountID = fa.AssetAccountID
        INNER JOIN Account AS aa
            ON aa.AccountID = fa.AccumulatedDepreciationAccountID
),
Ledger AS (
    SELECT a.AccountNumber, gl.FiscalYear,
        SUM(gl.Credit - gl.Debit) AS Depreciation
    FROM GLEntry AS gl
        INNER JOIN JournalEntry AS je
            ON je.JournalEntryID = gl.SourceDocumentID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'JournalEntry'
        AND je.EntryType = 'Depreciation'
        AND a.AccountSubType = 'Contra Fixed Asset'
    GROUP BY a.AccountNumber, gl.FiscalYear
),
Months AS (
    SELECT DISTINCT CAST(strftime('%Y', CalendarDate) AS INTEGER)
            AS CalendarYear,
        CAST(strftime('%Y', CalendarDate) AS INTEGER) * 12
            + CAST(strftime('%m', CalendarDate) AS INTEGER) - 1
            AS MonthIndex
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2025-01-01' AND '2026-12-31'
),
Schedule AS (
    SELECT r.DepreciationAccount,
        SUM(CASE WHEN m.CalendarYear = 2025
            THEN r.Monthly ELSE 0 END) AS Register2025,
        SUM(CASE WHEN m.CalendarYear = 2026
            THEN r.Monthly ELSE 0 END) AS Register2026
    FROM Register AS r
        INNER JOIN Months AS m
            ON m.MonthIndex BETWEEN r.FirstMonth AND r.LastMonth
    GROUP BY r.DepreciationAccount
)
SELECT s.DepreciationAccount,
    ROUND(s.Register2025, 2) AS Register2025,
    ROUND(lp.Depreciation, 2) AS Ledger2025,
    ROUND(s.Register2026, 2) AS Register2026,
    ROUND(lc.Depreciation, 2) AS Ledger2026
FROM Schedule AS s
    LEFT JOIN Ledger AS lp
        ON lp.AccountNumber = s.DepreciationAccount
        AND lp.FiscalYear = 2025
    LEFT JOIN Ledger AS lc
        ON lc.AccountNumber = s.DepreciationAccount
        AND lc.FiscalYear = 2026
ORDER BY s.DepreciationAccount;  -- Result: 4 rows

-- Requirement 7: where depreciation is charged, 6130 and 1090
-- Population: Depreciation entries' debits; expected: 6130 246,923.80 and 272,578.56, 1090 295,500.00 and 303,666.63
SELECT a.AccountNumber,
    ROUND(SUM(CASE WHEN gl.FiscalYear = 2025
        THEN gl.Debit ELSE 0 END), 2) AS Debits2025,
    ROUND(SUM(CASE WHEN gl.FiscalYear = 2026
        THEN gl.Debit ELSE 0 END), 2) AS Debits2026
FROM GLEntry AS gl
    INNER JOIN JournalEntry AS je
        ON je.JournalEntryID = gl.SourceDocumentID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType = 'JournalEntry'
    AND je.EntryType = 'Depreciation'
    AND gl.Debit > 0
GROUP BY a.AccountID, a.AccountNumber
ORDER BY a.AccountNumber;  -- Result: 2 rows

-- Requirement 7: accumulated depreciation at the three year-ends and net book value by class
-- Population: the trial balances; expected: accumulated depreciation 1,359,087.47 -> 1,803,511.27 -> 2,262,256.46
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
),
Classes AS (
    SELECT AsOfDate, AccountNumber, AccountSubType, Balance,
        CASE AccountNumber
            WHEN 1150 THEN 1110 WHEN 1160 THEN 1120
            WHEN 1170 THEN 1130 WHEN 1186 THEN 1185
            ELSE AccountNumber END AS CostAccount
    FROM Balances
    WHERE AccountSubType IN ('Fixed Asset', 'Contra Fixed Asset')
)
SELECT CostAccount,
    ROUND(-SUM(CASE WHEN AccountSubType = 'Contra Fixed Asset'
        AND AsOfDate = '2024-12-31' THEN Balance ELSE 0 END), 2)
        AS Accumulated2024,
    ROUND(-SUM(CASE WHEN AccountSubType = 'Contra Fixed Asset'
        AND AsOfDate = '2025-12-31' THEN Balance ELSE 0 END), 2)
        AS Accumulated2025,
    ROUND(-SUM(CASE WHEN AccountSubType = 'Contra Fixed Asset'
        AND AsOfDate = '2026-12-31' THEN Balance ELSE 0 END), 2)
        AS Accumulated2026,
    ROUND(SUM(CASE WHEN AsOfDate = '2026-12-31'
        THEN Balance ELSE 0 END), 2) AS NetBookValue2026
FROM Classes
GROUP BY CostAccount
ORDER BY CostAccount;  -- Result: 4 rows

-- Requirement 7: the disposals, cost removed, depreciation written off, proceeds, and loss
-- Population: the Asset Disposal entries; expected: WH-0001 (loss 42,000.00, proceeds 28,000.00) and MFG-0004 (loss 92,500.00, no proceeds)
SELECT je.EntryNumber, je.PostingDate,
    ROUND(SUM(CASE WHEN a.AccountSubType = 'Fixed Asset'
        THEN gl.Credit - gl.Debit ELSE 0 END), 2) AS CostRemoved,
    ROUND(SUM(CASE WHEN a.AccountSubType = 'Contra Fixed Asset'
        THEN gl.Debit - gl.Credit ELSE 0 END), 2)
        AS DepreciationWrittenOff,
    ROUND(SUM(CASE WHEN a.AccountNumber = 1010
        THEN gl.Debit - gl.Credit ELSE 0 END), 2) AS Proceeds,
    ROUND(SUM(CASE WHEN a.AccountNumber = 7020
        THEN gl.Debit - gl.Credit ELSE 0 END), 2) AS Loss
FROM JournalEntry AS je
    INNER JOIN GLEntry AS gl
        ON gl.SourceDocumentType = 'JournalEntry'
        AND gl.SourceDocumentID = je.JournalEntryID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE je.EntryType = 'Asset Disposal'
GROUP BY je.JournalEntryID, je.EntryNumber, je.PostingDate
ORDER BY je.PostingDate;  -- Result: 2 rows

-- Requirement 7: the notes payable, their terms, the asset each finances, and the balance at each year-end
-- Population: DebtAgreement and DebtScheduleLine; expected: 389,304.68 at 2026-12-31, equal to 2110
SELECT da.AgreementNumber, fa.AssetCode, da.OriginationDate,
    da.PrincipalAmount, da.AnnualInterestRate, da.TermMonths,
    da.PaymentStartDate, da.ScheduledPaymentAmount,
    CASE WHEN da.OriginationDate <= '2025-12-31'
        THEN ROUND(SUM(CASE WHEN dl.PaymentDate > '2025-12-31'
            THEN dl.PrincipalAmount ELSE 0 END), 2) END
        AS Outstanding2025,
    ROUND(SUM(CASE WHEN dl.PaymentDate > '2026-12-31'
        THEN dl.PrincipalAmount ELSE 0 END), 2) AS Outstanding2026,
    (SELECT ROUND(SUM(gl.Credit - gl.Debit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 2110
         AND gl.PostingDate <= '2026-12-31') AS Ledger2110
FROM DebtAgreement AS da
    LEFT JOIN FixedAsset AS fa ON fa.FixedAssetID = da.FixedAssetID
    INNER JOIN DebtScheduleLine AS dl
        ON dl.DebtAgreementID = da.DebtAgreementID
GROUP BY da.DebtAgreementID, da.AgreementNumber, fa.AssetCode,
    da.OriginationDate, da.PrincipalAmount, da.AnnualInterestRate,
    da.TermMonths, da.PaymentStartDate, da.ScheduledPaymentAmount
ORDER BY da.OriginationDate, da.DebtAgreementID;  -- Result: 2 rows

-- Requirement 7: the principal due in each of the five years after 2026
-- Population: DebtScheduleLine after 2026-12-31; expected: 2027 147,503.76, 2028 114,200.83, 2029 59,133.22, 2030 63,030.74, 2031 5,436.13
SELECT CAST(strftime('%Y', PaymentDate) AS INTEGER) AS DueYear,
    ROUND(SUM(PrincipalAmount), 2) AS PrincipalDue
FROM DebtScheduleLine
WHERE PaymentDate > '2026-12-31'
GROUP BY DueYear
ORDER BY DueYear;  -- Result: 5 rows

-- Requirement 7: invoice lines by customer segment and the year their invoice was posted (SegmentRevenue)
-- Population: SalesInvoiceLine with its invoice, customer, and first posting, 2025 and 2026; expected: 10 rows
WITH Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
)
SELECT c.CustomerSegment,
    CAST(strftime('%Y', p.PostingDate) AS INTEGER) AS PostingYear,
    ROUND(SUM(sil.LineTotal), 2) AS Revenue
FROM SalesInvoiceLine AS sil
    INNER JOIN SalesInvoice AS si
        ON si.SalesInvoiceID = sil.SalesInvoiceID
    INNER JOIN Customer AS c ON c.CustomerID = si.CustomerID
    INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
WHERE p.PostingDate BETWEEN '2025-01-01' AND '2026-12-31'
GROUP BY c.CustomerSegment, PostingYear
ORDER BY c.CustomerSegment, PostingYear;  -- Result: 10 rows

-- Requirement 7: revenue by product line on the adjusted basis, the ledger plus the cutoff by delivery year
-- Population: revenue postings by item group's account, closes excluded, and the cutoff items of Requirement 4; expected: Furniture 17,418,046.62 (2025) and 17,420,791.79 (2026); design services 1,261,365.95 and 1,213,344.00
WITH Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Shipped AS (
    SELECT sil.SalesInvoiceID, MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
),
GroupAccounts AS (
    SELECT DISTINCT i.ItemGroup, gl.AccountID
    FROM GLEntry AS gl
        INNER JOIN SalesInvoiceLine AS sil
            ON sil.SalesInvoiceID = gl.SourceDocumentID
            AND sil.SalesInvoiceLineID = gl.SourceLineID
        INNER JOIN Item AS i ON i.ItemID = sil.ItemID
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'SalesInvoice'
        AND a.AccountSubType = 'Operating Revenue'
),
Ledger AS (
    SELECT ga.ItemGroup, gl.FiscalYear,
        SUM(gl.Credit - gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN GroupAccounts AS ga ON ga.AccountID = gl.AccountID
    WHERE gl.FiscalYear IN (2025, 2026)
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY ga.ItemGroup, gl.FiscalYear
),
Late AS (
    SELECT i.ItemGroup, sil.LineTotal,
        CAST(strftime('%Y', sh.DeliveryDate) AS INTEGER)
            AS DeliveryYear,
        CAST(strftime('%Y', p.PostingDate) AS INTEGER) AS PostingYear
    FROM SalesInvoiceLine AS sil
        INNER JOIN Shipped AS sh
            ON sh.SalesInvoiceID = sil.SalesInvoiceID
        INNER JOIN Posted AS p ON p.SalesInvoiceID = sil.SalesInvoiceID
        INNER JOIN Item AS i ON i.ItemID = sil.ItemID
    WHERE strftime('%Y', p.PostingDate)
        <> strftime('%Y', sh.DeliveryDate)
),
Cutoff AS (
    SELECT ItemGroup, DeliveryYear AS FiscalYear, LineTotal AS Amount
    FROM Late
    UNION ALL
    SELECT ItemGroup, PostingYear, -LineTotal
    FROM Late
    UNION ALL
    SELECT i.ItemGroup,
        CAST(strftime('%Y', s.DeliveryDate) AS INTEGER),
        ROUND(sl.QuantityShipped * sol.UnitPrice
            * (1 - sol.Discount), 2)
    FROM ShipmentLine AS sl
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
        INNER JOIN SalesOrderLine AS sol
            ON sol.SalesOrderLineID = sl.SalesOrderLineID
        INNER JOIN Item AS i ON i.ItemID = sl.ItemID
        INNER JOIN SalesOrder AS so ON so.SalesOrderID = s.SalesOrderID
        INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
        LEFT JOIN SalesInvoiceLine AS sil
            ON sil.ShipmentLineID = sl.ShipmentLineID
    WHERE sil.SalesInvoiceLineID IS NULL
),
Adjusted AS (
    SELECT l.ItemGroup, l.FiscalYear,
        l.Revenue + COALESCE((SELECT SUM(cu.Amount)
            FROM Cutoff AS cu
            WHERE cu.ItemGroup = l.ItemGroup
                AND cu.FiscalYear = l.FiscalYear), 0) AS Revenue
    FROM Ledger AS l
)
SELECT ItemGroup,
    ROUND(SUM(CASE WHEN FiscalYear = 2025 THEN Revenue ELSE 0 END), 2)
        AS Revenue2025,
    ROUND(SUM(CASE WHEN FiscalYear = 2026 THEN Revenue ELSE 0 END), 2)
        AS Revenue2026
FROM Adjusted
GROUP BY ItemGroup
ORDER BY CASE ItemGroup
        WHEN 'Furniture' THEN 1 WHEN 'Lighting' THEN 2
        WHEN 'Textiles' THEN 3 WHEN 'Accessories' THEN 4
        ELSE 5 END;  -- Result: 5 rows

-- Requirement 7: freight billed, the revenue with no invoice line, and the timing of transfer
-- Population: SalesInvoice postings to revenue with no SourceLineID, closes excluded; expected: 213,499.96 (2025) and 212,820.03 (2026)
SELECT a.AccountNumber, a.AccountName,
    ROUND(SUM(CASE WHEN gl.FiscalYear = 2025
        THEN gl.Credit - gl.Debit ELSE 0 END), 2) AS Revenue2025,
    ROUND(SUM(CASE WHEN gl.FiscalYear = 2026
        THEN gl.Credit - gl.Debit ELSE 0 END), 2) AS Revenue2026
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountID IN (
        SELECT g2.AccountID
        FROM GLEntry AS g2
            INNER JOIN Account AS a2 ON a2.AccountID = g2.AccountID
        WHERE g2.SourceDocumentType = 'SalesInvoice'
            AND a2.AccountSubType = 'Operating Revenue'
            AND g2.SourceLineID IS NULL)
    AND gl.FiscalYear IN (2025, 2026)
    AND gl.VoucherNumber NOT IN (
        SELECT EntryNumber
        FROM JournalEntry
        WHERE EntryType LIKE 'Year-End Close%')
GROUP BY a.AccountID, a.AccountNumber, a.AccountName;  -- Result: 1 rows

-- Requirement 7: contract balances, customer credits in 2060 and contract liabilities in 2070
-- Population: the trial balances and CreditMemo; expected: 2060 3,105.75, 1,008.67, 3,413.46; 3 Issued credit memos; 2070 unused
WITH YearEnds AS (
    SELECT '2024-12-31' AS AsOfDate
    UNION ALL
    SELECT '2025-12-31'
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
)
SELECT AsOfDate,
    ROUND(-SUM(CASE WHEN AccountNumber = 2060
        THEN Balance ELSE 0 END), 2) AS CustomerCredits2060,
    ROUND(-SUM(CASE WHEN AccountNumber = 2070
        THEN Balance ELSE 0 END), 2) AS DeferredRevenue2070,
    (SELECT COUNT(*) FROM CreditMemo WHERE Status = 'Issued')
        AS IssuedCreditMemos,
    (SELECT ROUND(SUM(GrandTotal), 2)
     FROM CreditMemo
     WHERE Status = 'Issued') AS IssuedAmount
FROM Balances
GROUP BY AsOfDate
ORDER BY AsOfDate;  -- Result: 3 rows

-- Requirement 7: design services worked and not billed, the engagements not fully billed
-- Population: ServiceEngagement, ServiceTimeEntry, ServiceBillingLine; expected: 19,627.49 billable hours, all billed; engagement 209 billed every hour worked
WITH Worked AS (
    SELECT ServiceEngagementID, SUM(BillableHours) AS Worked,
        MAX(WorkDate) AS LastWorkDate
    FROM ServiceTimeEntry
    GROUP BY ServiceEngagementID
),
Billed AS (
    SELECT ServiceEngagementID, SUM(BilledHours) AS Billed
    FROM ServiceBillingLine
    GROUP BY ServiceEngagementID
)
SELECT se.ServiceEngagementID, se.Status, se.EndDate,
    se.PlannedHours, ROUND(w.Worked, 2) AS Worked,
    ROUND(b.Billed, 2) AS Billed, w.LastWorkDate,
    (SELECT ROUND(SUM(BillableHours), 2) FROM ServiceTimeEntry)
        AS AllBillable,
    (SELECT ROUND(SUM(BilledHours), 2) FROM ServiceBillingLine)
        AS AllBilled
FROM ServiceEngagement AS se
    LEFT JOIN Worked AS w
        ON w.ServiceEngagementID = se.ServiceEngagementID
    LEFT JOIN Billed AS b
        ON b.ServiceEngagementID = se.ServiceEngagementID
WHERE se.Status <> 'Billed'
ORDER BY se.ServiceEngagementID;  -- Result: 1 rows

-- Requirement 7: inventories and accrued liabilities as recorded, by component, at both year-ends
-- Population: the trial balances at 2025-12-31 and 2026-12-31; expected: finished goods 10,829,820.22 and 12,169,701.74; materials 4,334,722.56 and 11,751,653.92
WITH YearEnds AS (
    SELECT '2025-12-31' AS AsOfDate
    UNION ALL
    SELECT '2026-12-31'
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
),
Balances AS (
    SELECT ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        SUM(gl.Debit - gl.Credit) AS Balance
    FROM YearEnds AS ye
        INNER JOIN GLEntry AS gl ON gl.PostingDate <= ye.AsOfDate
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE NOT (gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
        AND gl.PostingDate = ye.AsOfDate)
    GROUP BY ye.AsOfDate, a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
)
SELECT AsOfDate,
    ROUND(SUM(CASE WHEN AccountNumber = 1040
        THEN Balance ELSE 0 END), 2) AS FinishedGoods,
    ROUND(SUM(CASE WHEN AccountNumber = 1045
        THEN Balance ELSE 0 END), 2) AS MaterialsAndPackaging,
    ROUND(SUM(CASE WHEN AccountNumber IN (1046, 1090)
        THEN Balance ELSE 0 END), 2) AS WorkInProcessNet,
    ROUND(-SUM(CASE WHEN AccountNumber BETWEEN 2030 AND 2033
        THEN Balance ELSE 0 END), 2) AS PayrollRecorded,
    ROUND(-SUM(CASE WHEN AccountNumber = 2034
        THEN Balance ELSE 0 END), 2) AS Commissions,
    ROUND(-SUM(CASE WHEN AccountNumber = 2040
        THEN Balance ELSE 0 END), 2) AS AccruedExpenses2040
FROM Balances
GROUP BY AsOfDate
ORDER BY AsOfDate;  -- Result: 2 rows

-- Requirement 8: the records dated after fiscal 2026
-- Population: GLEntry after 2026-12-31; expected: 526 supplier-payment rows, 1 January to 23 February 2027, debiting 2010 and crediting 1010
SELECT gl.SourceDocumentType, a.AccountNumber,
    COUNT(*) AS Postings,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits,
    MIN(gl.PostingDate) AS FirstDate, MAX(gl.PostingDate) AS LastDate
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.PostingDate > '2026-12-31'
GROUP BY gl.SourceDocumentType, a.AccountID, a.AccountNumber
ORDER BY a.AccountNumber;  -- Result: 2 rows

-- Requirement 8: the 2027 supplier payments and the invoices they paid, a search for unrecorded liabilities
-- Population: DisbursementPayment after 2026-12-31; expected: 263 payments, 271,327.17, 262 invoices of 78 suppliers received by 2026-12-31, 238 paid in full
WITH Paid AS (
    SELECT dp.PurchaseInvoiceID, COUNT(*) AS Payments,
        SUM(dp.Amount) AS Amount
    FROM DisbursementPayment AS dp
    WHERE dp.PaymentDate > '2026-12-31'
    GROUP BY dp.PurchaseInvoiceID
)
SELECT SUM(p.Payments) AS Payments, ROUND(SUM(p.Amount), 2) AS Amount,
    COUNT(*) AS Invoices,
    COUNT(DISTINCT pi.SupplierID) AS Suppliers,
    MIN(pi.ReceivedDate) AS FirstReceived,
    MAX(pi.ReceivedDate) AS LastReceived,
    SUM(CASE WHEN ABS(pi.GrandTotal - p.Amount) < 0.005
        THEN 1 ELSE 0 END) AS PaidInFull,
    (SELECT COUNT(*)
     FROM PurchaseInvoice
     WHERE ReceivedDate > '2026-12-31') AS ReceivedAfterYearEnd
FROM Paid AS p
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = p.PurchaseInvoiceID;  -- Result: 1 rows

-- Requirement 8: the same weeks of 2026, and the payables at 2026-12-31 due in the weeks the extract covers
-- Population: DisbursementPayment and PurchaseInvoice; expected: 2,530 payments, 3,040,077.15 in 2026; 2,665,014.91 due in January and February 2027
SELECT
    (SELECT COUNT(*)
     FROM DisbursementPayment
     WHERE PaymentDate BETWEEN '2026-01-01' AND '2026-02-23')
        AS PaymentsSameWeeks,
    (SELECT ROUND(SUM(Amount), 2)
     FROM DisbursementPayment
     WHERE PaymentDate BETWEEN '2026-01-01' AND '2026-02-23')
        AS AmountSameWeeks,
    (SELECT ROUND(SUM(pi.GrandTotal - COALESCE(
        (SELECT SUM(dp.Amount)
         FROM DisbursementPayment AS dp
         WHERE dp.PurchaseInvoiceID = pi.PurchaseInvoiceID
             AND dp.PaymentDate <= '2026-12-31'), 0)), 2)
     FROM PurchaseInvoice AS pi
     WHERE pi.ReceivedDate <= '2026-12-31'
         AND pi.DueDate BETWEEN '2027-01-01'
             AND date('2027-02-23', 'start of month', '+1 month',
                 '-1 day')) AS PayablesDue;  -- Result: 1 row (PaymentsSameWeeks = 2530, AmountSameWeeks = 3040077.15, PayablesDue = 2665014.91)

-- Requirement 8: what the extract cannot contain, the pay dates and note payments it covers
-- Population: PayrollPeriod and DebtScheduleLine from 2027-01-01 to 2027-02-23; expected: pay periods 78, 79 with no registers; note payments on 2027-01-01, 01-04, 02-01, 02-02, all Scheduled
SELECT 'Pay period' AS Record, pp.PeriodNumber AS Reference,
    pp.PayDate AS DueDate, pp.Status,
    (SELECT COUNT(*)
     FROM PayrollRegister AS pr
     WHERE pr.PayrollPeriodID = pp.PayrollPeriodID) AS Recorded
FROM PayrollPeriod AS pp
WHERE pp.PayDate BETWEEN '2027-01-01' AND '2027-02-23'
UNION ALL
SELECT 'Note payment', da.AgreementNumber, dl.PaymentDate,
    dl.Status,
    CASE WHEN dl.JournalEntryID IS NULL THEN 0 ELSE 1 END
FROM DebtScheduleLine AS dl
    INNER JOIN DebtAgreement AS da
        ON da.DebtAgreementID = dl.DebtAgreementID
WHERE dl.PaymentDate BETWEEN '2027-01-01' AND '2027-02-23'
ORDER BY Record DESC, DueDate;  -- Result: 6 rows

-- Requirement 8: materials on hand at 2026-12-31 against twelve months of issues
-- Population: account 1045; expected: 11,751,653.92 on hand against 10,161,204.64 issued in 2026
SELECT
    (SELECT ROUND(SUM(gl.Debit - gl.Credit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 1045
         AND gl.PostingDate <= '2026-12-31') AS MaterialsOnHand,
    (SELECT ROUND(SUM(gl.Credit - gl.Debit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 1045
         AND gl.SourceDocumentType = 'MaterialIssue'
         AND gl.FiscalYear = 2026) AS IssuedInYear;  -- Result: 1 row (MaterialsOnHand = 11751653.92, IssuedInYear = 10161204.64)

-- Requirement 9: rent paid each year, straight from cash with no lease recorded
-- Population: the Rent entries; expected: 467,525.63, 484,969.91, 504,245.32
SELECT gl.FiscalYear, a.AccountNumber, a.AccountName,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
    INNER JOIN JournalEntry AS je
        ON je.JournalEntryID = gl.SourceDocumentID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType = 'JournalEntry'
    AND je.EntryType = 'Rent'
GROUP BY gl.FiscalYear, a.AccountID, a.AccountNumber, a.AccountName
ORDER BY gl.FiscalYear, a.AccountNumber;  -- Result: 9 rows

-- Requirement 9: sales tax payable, what credits and debits it, and its balance at 2026-12-31
-- Population: account 2050 to 2026-12-31; expected: credits only from invoices, debits only from credit memos (38,587.80), balance 5,620,840.66
SELECT gl.SourceDocumentType, COUNT(*) AS Postings,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits,
    ROUND(SUM(gl.Credit - gl.Debit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 2050
    AND gl.PostingDate <= '2026-12-31'
GROUP BY gl.SourceDocumentType
ORDER BY gl.SourceDocumentType;  -- Result: 2 rows

-- Requirement 9: the opening balances no document supports, and the equity effect if none is real
-- Population: the opening entry's lines to 1020, 1050, 2010, 2030, 2040; expected: assets 440,000.00, liabilities 2,276,371.12, equity +1,836,371.12
SELECT
    ROUND(SUM(CASE WHEN a.AccountNumber IN (1020, 1050)
        THEN gl.Debit - gl.Credit ELSE 0 END), 2) AS Assets,
    ROUND(SUM(CASE WHEN a.AccountNumber IN (2010, 2030, 2040)
        THEN gl.Credit - gl.Debit ELSE 0 END), 2) AS Liabilities,
    ROUND(SUM(CASE WHEN a.AccountNumber IN (2010, 2030, 2040)
        THEN gl.Credit - gl.Debit ELSE 0 END)
        - SUM(CASE WHEN a.AccountNumber IN (1020, 1050)
        THEN gl.Debit - gl.Credit ELSE 0 END), 2)
        AS EquityIfNoneIsReal
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    INNER JOIN JournalEntry AS je
        ON gl.SourceDocumentType = 'JournalEntry'
        AND je.JournalEntryID = gl.SourceDocumentID
WHERE je.EntryType = 'Opening';  -- Result: 1 row (Assets = 440000.0, Liabilities = 2276371.12, EquityIfNoneIsReal = 1836371.12)

-- Milestone 4: the checkpoints of what the data cannot settle
-- Population: DisbursementPayment after 2026-12-31, account 2050, the opening entry; expected: 263 payments (271,327.17), sales tax payable 5,620,840.66, equity +1,836,371.12 if no opening balance is real
SELECT
    (SELECT COUNT(*)
     FROM DisbursementPayment
     WHERE PaymentDate > '2026-12-31') AS PaymentsAfterYearEnd,
    (SELECT ROUND(SUM(Amount), 2)
     FROM DisbursementPayment
     WHERE PaymentDate > '2026-12-31') AS AmountAfterYearEnd,
    (SELECT ROUND(SUM(gl.Credit - gl.Debit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 2050
         AND gl.PostingDate <= '2026-12-31') AS SalesTaxPayable,
    (SELECT ROUND(SUM(CASE
            WHEN a.AccountNumber IN (1020, 1050, 2010, 2030, 2040)
                THEN gl.Credit - gl.Debit
            ELSE 0 END), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
         INNER JOIN JournalEntry AS je
             ON gl.SourceDocumentType = 'JournalEntry'
             AND je.JournalEntryID = gl.SourceDocumentID
     WHERE je.EntryType = 'Opening') AS OpeningEquityEffect;  -- Result: 1 rows

/* Model answer (Requirement 1)

   The trial balance is one query with its as-of date in a Params CTE, rerun for each year-end. It keeps every
   posting dated on or before the date and leaves out only the closes dated on it: the closes of earlier years
   moved those years' income into retained earnings, so leaving them out would count that income twice. At
   2024-12-31, 2025-12-31, 2026-12-31 it lists 69, 71, 71 accounts with debit and credit balances of
   47,565,211.56, 58,143,212.29, 67,107,722.36; the last is Chapter 6's pre-closing trial balance, and each
   year's net income equals its Income Summary close to 3030.

   Never posted: 23 accounts (16 active: 1030 Allowance for Doubtful Accounts, 1060, 1070, 1080, 1140
   Leasehold Improvements, 1180, 1190, 2070 Deferred Revenue, 2080 Interest Payable, 2090, 2120 Lease
   Liability, 2130, 3020, 3040 Dividends or Owner Distributions, 3050, 8020; 7 inactive: 4070, 5070, 6170 Bad
   Debt Expense, 6260, 6270, 7010 Interest Income, 7040). The chart has no income tax account at all, neither
   an expense nor a payable: the accounts named for taxes are sales tax and payroll taxes. The unused 2080,
   2120, 1140, 1030, and 7010 each lead to a later requirement.
*/

/* Model answer (Requirement 2)

   Materiality is 225,180.56 for 2026 and 256,717.74 for 2025. At a year-end a revenue or expense account's
   balance is that year's activity, because the prior close zeroed it, so the change for those accounts is
   this year's activity less last year's. The changes above 2026 materiality, on each account's normal side,
   are 1045 +7,416,931.36, 2050 +1,932,519.29, 1040 +1,339,881.52, 1010 -941,310.30, 2010 +769,657.14, 4020
   +498,432.37, 5080 +403,686.80, 5020 +246,456.24; retained earnings moves by 2025's net income, closed into
   it. The opening entry (JE-2024-000001, 18 lines) supports nothing with a document: 1050 Prepaid Expenses
   60,000.00 is its only posting, 2030 Accrued Payroll keeps 95,000.00 because every payroll posting to it
   nets to zero, and parts of 1020 (380,000.00), 2010 (2,096,371.12, equal to the opening cash to the cent),
   and 2040 (85,000.00) rest on it. The questions go to the Questions table of the Review file, each with the
   requirement that answers it.
*/

/* Model answer (Requirement 3)

   Account 2040 at 2024-12-31, 2025-12-31, 2026-12-31 is the opening line 85,000.00 (no document), the freight
   accrued on shipments and not yet settled (48,797.21, 47,290.49, 44,423.87), the accruals open 62 days or
   less (152,347.13, 168,648.64, 193,781.70), and the accruals open longer (39,028.43, 96,049.58, 157,346.79):
   in total 325,172.77, 396,988.71, 480,552.36, equal to the ledger. Invoices cleared accruals in 15 to 62
   days (median 39), and four cleared at exactly 62 days, so "older than 62 days" is the rule.

   An accrual past the invoicing window at a year-end should have been reversed then, because the facts
   existed: the old items are corrections of errors at each year-end (retained earnings at 1 January 2025
   +39,028.43; 2025 expense -57,021.15; 2026 expense -61,297.21). An accrual within the window is an estimate,
   and one that later proves unneeded is a change in estimate in the year it goes stale. Keep the 193,781.70
   of young 2026 accruals, and leave the 85,000.00 to Requirement 9.
*/

/* Model answer (Requirement 4)

   Revenue, by the latest delivery of each invoice's shipments against the year of its posting (SubTotal;
   these invoices carry no freight): 15 invoices for 2024 deliveries posted in 2025, 90,138.93; 8 for 2025
   deliveries posted in 2026, 19,540.86; and 9 December 2026 shipment lines never invoiced, 44,481.11 at order
   price, whose standard cost (22,895.78) is already in cost of goods sold. Sales tax is recorded on invoicing
   and is not adjusted.

   Payroll, by working day: 302,568.90 at 2024-12-31, 365,921.19 at 2025-12-31, and 383,044.82 at 2026-12-31
   from the last eight processed periods' cost per working day. The manufacturing part goes to 1090 and, with
   no completion to absorb it, ends in 5080 and cost of goods sold; the rest goes to the cost centers' salary
   accounts and 6060. Interest (2080 has never been used): each payment's interest covers the days since the
   one before; the day count includes the year-end: 1,838.58 at 2024-12-31, 1,369.27 at 2025-12-31, 2,007.26
   at 2026-12-31. Prorating a pay period or a payment is a formula a reviewer should see, so the workbook
   holds the prorations and this script the populations.
*/

/* Model answer (Requirement 5)

   Recorded adjustments, effect on retained earnings at 1 January 2025 / 2025 income / 2026 income: A1 payroll
   accrual -302,568.90 / -63,352.29 / -17,123.63; A2 revenue cutoff +90,138.93 / -70,598.07 / +24,940.25; A3
   old accruals +39,028.43 / +57,021.15 / +61,297.21; A4 interest -1,838.58 / +469.31 / -637.99; totals
   -175,240.12 / -76,459.90 / +68,475.84. Adjusted net income 5,057,894.81 (2025) and 4,572,087.08 (2026).
   Reclassifications: R1 the current portion of the notes (89,243.61 and 147,503.76); R2 the credit balance of
   1090 netted into work in process.

   Materiality 225,180.56 (2026, on recorded income as the controller set it) and 256,717.74 (2025). 2026's
   income effect is 30% of materiality, but the payroll liability (383,044.82) exceeds it, current liabilities
   at 2026 rise by 227,705.29 before the reclassification, and the missing payroll accrual recurs every year.
   Record A1-A4, R1, and R2, and present 2025 as restated, with the Topic 250 disclosures, because the
   shareholders received 2025 statements. Passed items: P1 the allowance -34,106.25 (+553.09 on 2026 income),
   P2 expected returns about -6,773.13 (-900.48), P3 the damaged and quality-concern returns restocked at full
   cost -61,146.00; aggregate -102,025.38, 45% of materiality (-61,493.39 on 2026 income). Pass all three and
   list them for the CFO's approval, with the freight residual of 3,719.65 as trivial.
*/

/* Model answer (Requirement 8)

   The 2027 records are 263 supplier payments, 271,327.17, from 1 January to 23 February 2027 (526 ledger
   rows, Dr 2010, Cr 1010), paying 262 invoices of 78 suppliers, all received from November to December 2026
   and recorded in payables at the year-end; no invoice was received after 2026, so no unrecorded liability is
   found. The same weeks of 2026 had 2,530 payments, 3,040,077.15, and payables due in January and February
   2027 were 2,665,014.91. The extract has no payroll for the pay dates it covers, no note payments, no
   freight settlement, and no rent, sales, or receipts, so it is incomplete: it does not show that the company
   stopped paying. Going-concern conditions: cash net of sales tax 2,821,415.14; quick ratio 0.96, down from
   1.28; operating cash flow -807,189.75 against 3,975,026.14; materials (11,751,653.92) above twelve months
   of issues (10,161,204.64); 2,096,371.12 of opening payables unchanged for three years. The ledger alone
   does not establish substantial doubt, but the CFO's evaluation needs evidence from outside the database.
*/

/* Model answer (Requirement 9)

   The matters the records cannot settle, with what this script measures (the memo itself is in the package
   workbook). Tax status: no tax account and no tax recorded in three years; if the company is a C
   corporation, 21% federal on adjusted 2026 income of 4,572,087.08 alone is about 960,000, several times
   materiality, so state it and record no number. Leases: rent of 467,525.63, 484,969.91, 504,245.32 is paid
   from cash each month while 2120 and 1140 are unused; the agreements decide the right-of-use assets and
   lease liabilities. Sales tax: 5,620,840.66 collected with no remittance recorded (2050 credits only from
   invoices, debits only from credit memos, 38,587.80). Opening balances: assets 440,000.00 and liabilities
   2,276,371.12 that no document supports; if none is real, equity rises by 1,836,371.12. Standards unchanged
   since 2024: at a standard rebuilt on normal capacity the manufactured finished goods would be about 471,000
   higher at the end of 2026 and 370,000 at the end of 2025, so a strong memo recommends a cost study.
   Recommendation: record A1-A4 and R1-R2, and do not release the package until the tax status, the leases,
   the sales tax, and the opening balances are settled.
*/

/* Notes

   Requirement 1: Build the trial balances and the recorded statements (Chapters 6, 10, and 11)
   Three trial balances that differ only in their date are one query, rerun with a parameter, as Chapter 11's
      Params CTE showed. Mapping accounts to statement lines and laying out the statements are workbook work,
      as in Chapter 6, and the workbook is where the adjustments will go.
   In LenderPackage.sql, write one trial-balance query whose as-of date sits in a Params CTE and that leaves
      out only the closing entries dated on that date. Run it for 31 December 2024, 2025, and 2026.
   Copy each result into its own worksheet of the package workbook, map the accounts to statement lines by
      AccountSubType and account number, and build the recorded balance sheets and statements of income.
      Validate them against control totals you can trace: Chapter 6's pre-closing trial balance at the end of
      fiscal 2026 and its net income.
   List the accounts that have never been posted with an anti-join (Chapter 10), and note any account that a
      company like Charles River would need and the chart does not have.
   Instructor note: WITH Params AS (SELECT '2026-12-31' AS AsOfDate); PostingDate <= AsOfDate; leave out a
      posting only if it belongs to a close (JournalEntry.EntryType LIKE 'Year-End Close%':
      JE-2024-000265/266, JE-2025-000287/288, JE-2026-000296/297) AND is dated on AsOfDate. Year-ends 2024 /
      2025 / 2026: 69 / 71 / 71 accounts with postings, 2 / 4 / 4 of them at zero, debit and credit balances
      47,565,211.56 / 58,143,212.29 / 67,107,722.36 (the last is Chapter 6's). The earlier closes stay in
      because they moved earlier years' income into retained earnings; leaving them out would count that
      income twice. Net income equals each Income Summary close to 3030: 5,110,308.27 / 5,134,354.71 /
      4,503,611.24. Recorded year-ends 2024 / 2025 / 2026: total assets 23,742,720.31 / 31,838,684.00 /
      39,328,524.11; current assets 21,074,807.78 / 29,358,195.27 / 37,236,780.57; current liabilities
      7,621,731.07 / 10,666,774.33 / 13,507,123.75; notes payable (2110, all classified long-term) 326,859.51
      / 243,425.23 / 389,304.68; retained earnings before the year's close 10,183,821.46 / 15,294,129.73 /
      20,428,484.44; common stock 500,000.00. Recorded income 2025 / 2026: operating revenue 29,586,268.92 /
      29,973,822.48; returns (4060) 201,104.38 / 242,764.56; cost of goods sold 17,833,805.16 / 18,634,303.63;
      gross margin 11,551,359.38 / 11,096,754.29; operating expense 6,355,491.55 / 6,471,696.58; operating
      income 5,195,867.83 / 4,625,057.71; interest expense 19,513.12 / 28,946.47; loss on disposal (7020)
      42,000.00 / 92,500.00. Never posted, headers aside: 23 accounts, 16 active (1030 Allowance for Doubtful
      Accounts, 1060, 1070, 1080, 1140 Leasehold Improvements, 1180, 1190, 2070 Deferred Revenue, 2080
      Interest Payable, 2090, 2120 Lease Liability, 2130, 3020, 3040 Dividends or Owner Distributions, 3050,
      8020) and 7 inactive (4070, 5070, 6170 Bad Debt Expense, 6260, 6270, 7010 Interest Income, 7040). The
      chart has no income tax account at all, neither an expense nor a payable; the accounts named for taxes
      are sales tax and payroll taxes. The unused 2080, 2120, 1140, 1030, and 7010 each lead to a later
      requirement.

   Milestone 1: The ledger as it stands
   (Requirements 1 and 2): the three trial balances, the recorded statements, and the Questions table.
   Instructor note: trial balances at the 2024 / 2025 / 2026 year-ends 69 / 71 / 71 accounts, debit and credit
      balances 47,565,211.56 / 58,143,212.29 / 67,107,722.36; recorded net income 5,110,308.27 / 5,134,354.71
      / 4,503,611.24; recorded total assets 23,742,720.31 / 31,838,684.00 / 39,328,524.11; 23 accounts never
      posted, and no income tax account.

   Requirement 2: Review the recorded statements before adjusting them (Chapters 14 and 15)
   A review that moves from a statement line down to the entries behind it is quickest in a report with a
      ledger model and drill-through. Build Charles River Lender Review.pbix from CharlesRiver.xlsx as
      Tutorial 14.3 built its ledger star, with the closing entries flagged, and write a Balance measure that
      adds debits less credits up to a date and leaves out only the closing entries dated on that date.
   Build a matrix of statement lines and accounts with each year-end balance and the change from 2025 to 2026,
      and flag the changes above a threshold that a what-if parameter sets at the controller's materiality, as
      in Exercise 15.4.
   Drill through from the flagged lines to their postings. With a matrix of balances by account and
      SourceDocumentType, find the balances that rest on journal entries alone and those that have not moved
      since the opening entry.
   Record each question the review raises in a Questions table entered with Enter data, as Chapter 16 kept its
      dispositions, with the requirement that will answer it.
   Instructor note: materiality, 5% of recorded income before income taxes: 225,180.56 (2026) and 256,717.74
      (2025). At a year-end the Balance measure shows a revenue or expense account's activity for that year,
      because the prior close zeroed it, so the change for those accounts is this year's activity less last
      year's. Changes from 2025 to 2026 above 225,180.56: 1045 +7,416,931.36; 2050 +1,932,519.29 (credit);
      1040 +1,339,881.52; 1010 -941,310.30; 2010 +769,657.14 (credit); 4020 +498,432.37 (credit); 5080
      +403,686.80; 5020 +246,456.24; retained earnings moves by 2025's net income, closed into it. Next
      largest: 1186 186,166.63 and 2110 145,879.45. Balances resting on the opening entry (JE-2024-000001, 18
      lines): 1050 Prepaid Expenses 60,000.00, its only posting; 2030 Accrued Payroll 95,000.00, because every
      payroll posting to it nets to zero; and parts of 1020 (380,000.00), 2010 (2,096,371.12, equal to opening
      cash to the cent), and 2040 (85,000.00), none with a document. 1110 also has a single posting, but the
      FixedAsset register supports it (OFF-0001, 420,000). Questions to expect: why 2040 grew (by 83,563.65;
      Requirement 3); cutoff, payroll, and interest at each year-end (Requirement 4); a credit balance in 1090
      inside current assets (Requirement 5); 1030 unused (Requirement 5); 2050 has no debits except credit
      memos, 2120 and 1140 are unused while rent is paid monthly, there is no tax account, and 7010 shows no
      interest income on more than 8 million of cash (Requirement 9).

   Requirement 3: Rebuild Accrued Expenses at each year-end (Chapters 3, 10, and 12)
   Account 2040 Accrued Expenses has grown every year. Apart from its opening line, five kinds of posting
      reach it, as the figure shows. Month-end accrual entries credit it for services received and not yet
      billed. A supplier invoice that refers to an accrual debits it, up to the amount accrued, and an Accrual
      Adjustment entry clears what remains. Shipments credit it for the freight they will cost, and a monthly
      settlement entry pays the carriers. Splitting the balance into these parts at three dates joins four
      tables under conditions on dates, the work Chapters 10 and 12 did in SQL.
   Split 2040 at each year-end into the opening line, the freight accrued on shipments and not yet settled,
      and the service accruals not yet cleared, and reconcile the parts to the ledger at all three dates.
   For each accrual entry, subtract what had cleared it by each date: the invoice postings to 2040 for the
      invoice lines that refer to it, and the Accrual Adjustment entries that reverse it.
   Measure how long invoices took to clear the accruals, and age the open accruals at each year-end against
      the longest wait you observe.
   Decide which open accruals are still liabilities and which should have been reversed, and in which period.
   !How an accrued expense is recorded and cleared.{#fig-17-01 fig-alt="An entity-relationship diagram of the
      tables behind account 2040 Accrued Expenses. JournalEntry holds the accrual entries and the Accrual
      Adjustment entries, which refer back to the accrual they clear through ReversesJournalEntryID.
      PurchaseInvoiceLine refers to the accrual it clears through AccrualJournalEntryID and belongs to a
      PurchaseInvoice. JournalEntry, PurchaseInvoice, and Shipment each post to GLEntry through the source-
      document trace, shown as dashed amber lines. Crow's-foot endpoints show that most invoice lines refer to
      no accrual and that an accrual is cleared by at most one invoice line."}
   Instructor note: populations: 396 Accrual entries, 4,052,446.62, each crediting 2040 and debiting one
      expense account (6100-6220); 355 invoice lines refer to them, at most one per accrual, all on the ASV
      service invoices with no purchase order, and clear 3,646,702.22 through their 2040 debits;
      AccrualJournalEntryID is NULL on the other 40,293 invoice lines; 149 Accrual Adjustment entries, 149
      distinct targets, 54,615.91. The excess of invoices over their accruals went to expense: 24,489.89 /
      26,702.96 / 34,364.32 (60 / 65 / 84 lines). Clearing lag (accrual date to invoice posting): 15 to 62
      days, median 39; four cleared at exactly 62 days, so "older than 62 days" is the rule; a rule of "older
      than the last two month-ends" would wrongly flag JE-2025-000188, 61 days old at the end of 2025 and
      cleared on 2026-01-01 by ASV0050-2025-040073. Composition of 2040 at 2024 / 2025 / 2026 year-ends:
      opening line 85,000.00 (no document); freight not yet settled 48,797.21 / 47,290.49 / 44,423.87
      (December's freight 45,381.01 / 41,564.67 / 40,704.22 plus estimates above settlements 3,416.20 /
      5,725.82 / 3,719.65; settlements post on the first weekday of the next month, so December 2026's falls
      outside the data; shipment credits to 2040 equal the 5050 debits, 1,477,398.06; 35 settlements,
      1,432,974.19); open accruals 62 days old or less 152,347.13 / 168,648.64 / 193,781.70; open accruals
      more than 62 days old 39,028.43 (7) / 96,049.58 (15) / 157,346.79 (22); total 325,172.77 / 396,988.71 /
      480,552.36, equal to the ledger. The 22 old items at 2026 were never invoiced; 3 were partly cleared by
      "Partial cleanup" adjustments with no invoice (JE-2024-000264, JE-2025-000286, JE-2026-000295). By year
      recorded 2024 68,844.44 (11), 2025 32,795.49 (5), 2026 55,706.86 (6); by expense account 6110 22,616.85,
      6120 26,261.26, 6140 5,572.08, 6160 17,895.82, 6180 9,569.93, 6190 10,368.12, 6200 15,120.25, 6210
      25,601.55, 6220 24,340.93. Of the young items open at the end of 2024, 32,929.99 was never invoiced
      (JE-2024-000188, -000206, -000210, -000214); of those at the end of 2025, 5,590.35 (JE-2025-000202,
      10,198.72 open, partly cleaned up in 2026). Preferred treatment: an accrual past the invoicing window at
      a year-end should have been reversed then, because the facts existed, so the old items are corrections
      of errors at each year-end (retained earnings at 1 January 2025 +39,028.43; 2025 expense -57,021.15;
      2026 expense -61,297.21); an accrual within the window is an estimate, and one that later proves
      unneeded is a change in estimate in the year it goes stale. Allocating by year of origin (68,844.44 /
      32,795.49 / 55,706.86) is acceptable if argued, but it uses hindsight on the November and December items
      of 2024 and 2025 that it cannot apply to 2026. Keep the 193,781.70 of young 2026 accruals, and leave the
      85,000.00 to Requirement 9.

   Requirement 4: Test cutoff at each year-end (Chapters 6 and 12)
   Chapter 12 tested revenue and payroll cutoff, and Exercise 12.1 measured it at each year-end. The
      statements need those measurements as entries with their accounts, made by one method at every year-end
      they present and at the one before, because an error at the end of 2024 reverses in 2025. Queries find
      the populations; prorating a pay period or an interest payment is a formula that a reviewer should be
      able to see, so it belongs in the workbook.
   Revenue: at the end of 2024, 2025, and 2026, find the invoices whose revenue was posted in a different year
      from the delivery of the goods they bill, and the shipments never invoiced, as tests L5 and L6 of
      Audit.sql do. Recognize revenue in the year of delivery, and value the unbilled shipments at their order
      price less discount.
   Payroll: measure the cost of the work done in the last days of each December and paid in the next year,
      with one working-day method (tests L7 and L8 of Audit.sql list the pay periods that cross each year-
      end). For 2024 and 2025, take the registers of those pay periods, prorated by the working days in
      WorkCenterCalendar. For 2026, whose last pay periods have no registers, multiply the cost per working
      day of the last eight processed pay periods by the working days left in the year. Split manufacturing
      from the other cost centers, and explain where each part ends up.
   Interest: from DebtScheduleLine, measure the interest that each note had accrued between its last payment
      and each year-end, and state your day-count convention.
   Instructor note: revenue, by the latest DeliveryDate of each invoice's shipments against the year of its
      posting (SubTotal; these invoices carry no freight): 15 invoices for 2024 deliveries posted in 2025,
      90,138.93 (Strategic 35,325.32, Wholesale 54,813.61; Furniture 76,792.75, Lighting 4,836.07, Textiles
      8,510.11; tax 5,859.04); 8 for 2025 deliveries posted in 2026, 19,540.86 (Strategic 13,241.85, Wholesale
      6,299.01; Furniture 12,288.72, Lighting 3,065.83, Textiles 1,784.83, Accessories 2,401.48; tax 1,270.17;
      includes SI-2026-013742, dated in 2025); 9 December 2026 shipment lines never invoiced, 44,481.11 at
      order price (Quantity shipped x UnitPrice x (1 - Discount); Strategic 20,022.95, Wholesale 24,458.16;
      Furniture 34,792.95, Lighting 2,432.78, Textiles 3,494.67, Accessories 3,760.71), whose standard cost
      (22,895.78) is already in cost of goods sold. Sales tax is recorded on invoicing and is not adjusted;
      the tax on the unbilled lines is not known. Payroll (PayrollRegister gross pay plus employer taxes and
      benefits; working days identical in every work center): end of 2024, period 26 (2024-12-16 to 12-29,
      paid 2025-01-03) in full, 242,165.92, plus 2 of the 9 working days of period 27, 60,402.98: 302,568.90
      (gross 265,750.45, employer taxes 20,329.93, benefits 16,488.52; manufacturing 132,849.90, other
      169,719.00). End of 2025: period 52 in full, 263,426.72, plus 3/9 of period 53, 102,494.47: 365,921.19
      (gross 321,409.38, taxes 24,587.79, benefits 19,924.02; manufacturing 180,675.14, other 185,246.05). End
      of 2026: periods 70-77 cost 2,298,268.90 over 78 working days, 29,464.99 a day, times 13 working days:
      383,044.82 (gross 336,456.34, taxes 25,738.93, benefits 20,849.55; manufacturing 197,970.68, other
      185,074.14). The manufacturing part goes to 1090 and, with no completion to absorb it, ends in 5080 and
      cost of goods sold; the rest goes to the cost centers' salary accounts and 6060. Exercise 12.1 allocated
      hourly labor by the hours worked and got about 296,000 (2024) and 335,000 (2025); either method is
      acceptable if it is applied at every year-end and the 2026 estimate uses the same one. Interest (2080
      has never been used; each payment's interest covers the month before it): end of 2024, note 1's payment
      of 2025-01-01, 1,838.58; end of 2025, note 1's payment of 2026-01-01, 1,369.27; end of 2026, note 1's
      payment of 2027-01-01, 867.27 plus 30 of the 33 days of note 2's 1,253.99 (2026-12-02 to 2027-01-04),
      1,139.99, total 2,007.26 (29 days gives 1,969.26; accept either with the convention stated).

   Requirement 5: Classify, measure, and judge the adjustments (Chapters 4, 6, and 8)
   A working trial balance, with the recorded balances, the adjustments, and the adjusted balances side by
      side, is the accountant's standard form, and in a workbook every adjustment stays traceable to its
      evidence. @tbl-17-03 lays out the schedule of adjustments.
   Number each adjustment and write its entries for the 31 December 2025 and 2026 trial balances, with the
      accounts and the queries or document numbers that support it. Keep the entry lines in an Excel Table,
      one row per account, so that the Review file can load them.
   Classify each as the correction of an error, a change in estimate, or a reclassification, and assign it to
      a period. the figure shows how an item missed at each year-end moves across the periods presented.
   Compute the controller's materiality for each year, and decide what to record and what to pass,
      individually and in aggregate. Consider also an allowance for credit losses at the rates of Exercise 8.1
      (0.5%, 2%, 5%, 15%, and 40% of the balances current, 1 to 30, 31 to 60, 61 to 90, and more than 90 days
      past due), the returns expected after the year-end on the year's deliveries, and the condition of
      returned goods put back into stock at full cost.
   Show that every adjusted trial balance balances and that no adjustment touches cash. Decide how the 2025
      column and the statement of changes in equity present the corrections, under the guidance on accounting
      changes and error corrections (ASC Topic 250).
   | Column | What it holds | |----------------|-------------------------------------------------------| | No.
      | A number for each recorded adjustment, reclassification, or passed item | | Adjustment | What the
      entry corrects or estimates, in a few words | | Accounts | The accounts debited and credited | |
      Evidence | The query in LenderPackage.sql and the document or entry numbers | | Retained earnings, 1
      January 2025 | The effect on opening equity | | Income 2025 and 2026 | The effect on each year's income
      before income taxes | | Balance 2025 and 2026 | The effect on the balance sheet at each year-end | |
      Type | Error, change in estimate, or reclassification | | Decision | Recorded or passed, and why |
   : Layout of the schedule of adjustments {#tbl-17-03}
   !How a year-end adjustment moves across the periods presented.{#fig-17-02 fig-alt="A timeline of three
      year-ends, 2024, 2025, and 2026, with the periods the statements present. An item missed at the end of
      2024 enters retained earnings at 1 January 2025 and reverses in 2025 income. An item missed at the end
      of 2025 enters 2025 income and the 2025 balance sheet and reverses in 2026 income. An item missed at the
      end of 2026 enters 2026 income and the 2026 balance sheet. A side panel contrasts the correction of an
      error, which changes the period in which the facts existed, with a change in estimate, which changes
      only the current and later periods."}
   ::: {.callout-warning .watch-out icon=false}
   Instructor note: recorded adjustments, effect on retained earnings at 1 January 2025 / 2025 income / 2026
      income: A1 payroll accrual -302,568.90 / -63,352.29 (cost of goods sold +47,825.24, operating expense
      +15,527.05) / -17,123.63 (cost of goods sold +17,295.54, operating expense -171.91); A2 revenue cutoff
      +90,138.93 / -70,598.07 / +24,940.25 (4010 +22,504.23, 4020 -633.05, 4030 +1,709.84, 4040 +1,359.23); A3
      old accruals +39,028.43 / +57,021.15 / +61,297.21; A4 interest -1,838.58 / +469.31 / -637.99. Totals
      -175,240.12 / -76,459.90 / +68,475.84; equity effect at 2025 / 2026 year-ends -251,700.02 / -183,224.18.
      Adjusted net income 2025 5,057,894.81, 2026 4,572,087.08 (recorded 4,503,611.24 + 68,475.84). Entries at
      2026-12-31 (debits = credits): A1 Dr retained earnings 365,921.19, Dr 5080 17,295.54, Cr operating
      expense 171.91, Cr 2030 336,456.34, Cr 2032 25,738.93, Cr 2033 20,849.55; A2 Dr 1020 44,481.11, Cr
      retained earnings 19,540.86, Cr revenue 24,940.25; A3 Dr 2040 157,346.79, Cr retained earnings
      96,049.58, Cr operating expense 61,297.21; A4 Dr retained earnings 1,369.27, Dr 7030 637.99, Cr 2080
      2,007.26. Reclassifications: R1 the current portion of the notes, 89,243.61 at 2025 (note 1 only; note 2
      began in 2026) and 147,503.76 at 2026; R2 the credit balance of 1090 (-49,102.81 / -46,730.55) netted
      into work in process (1046 63,392.97 / 61,095.34). Materiality 225,180.56 (2026, on recorded income as
      the controller set it) and 256,717.74 (2025). Judgment: 2026's income effect is 30% of materiality, but
      the payroll liability (383,044.82) exceeds it; current liabilities at 2026 rise by 227,705.29 before the
      reclassification and working capital falls by 330,727.94 after it; at 2025 current liabilities were
      understated by 271,240.88, above 2025 materiality, and the missing payroll accrual recurs every year.
      Record A1-A4, R1, and R2, and present 2025 as restated, with the Topic 250 disclosures, because the
      shareholders received 2025 statements (a reasoned "revised" presentation is acceptable). Passed items,
      at the 2026 year-end and, for the two estimates, on 2026 income once the same estimate at the end of
      2025 reverses: P1 an allowance at Chapter 8's rates, -34,106.25 (-34,659.34 at the end of 2025, so
      +553.09 on 2026 income); P2 expected returns, from 2026's returns of 2025 deliveries (14 returns,
      16,319.03 of revenue less 9,545.90 of cost; 13 in 2025 for 2024 deliveries, 13,985.96 less 8,113.31),
      about -6,773.13 (about -900.48 on 2026 income); P3 a write-down of the Damaged and Quality Concern
      returns of 2026 restocked at full standard cost, -61,146.00 (137,606.43 since 2024: 24,429.94 /
      52,030.49 / 61,146.00); aggregate -102,025.38, 45% of materiality (-61,493.39 on 2026 income). Pass all
      three and list them for the CFO's approval; list the freight residual of 3,719.65 as trivial, since the
      controller wants every adjustment listed.

   Requirement 6: Prepare the statements (Chapter 6)
   The statements come from the adjusted trial balances in the workbook, and the Review file tests them
      against the ledger. A statement of changes in equity carries each component of equity from its opening
      balance to its closing one; when an error of an earlier year is corrected, the opening retained earnings
      are adjusted and the earlier year's columns are labeled as restated (ASC Topic 250).
   Prepare classified balance sheets at both year-ends, and statements of income by function with a line for
      income before income taxes.
   Prepare a statement of changes in stockholders' equity from 1 January 2025 that shows the correction of the
      opening balance.
   Prepare statements of cash flows by the indirect method: start from net income, add back depreciation and
      the loss on disposals, adjust for the change in each working-capital balance, and classify the rest as
      investing or financing. Find the entries that moved no cash, such as equipment financed by a note and a
      disposal with no proceeds, and disclose them instead of reporting them as cash flows. Show that the
      adjustments change only the lines of the reconciliation, never the totals. Add the supplemental
      information: interest paid, income taxes paid, and investing and financing activities that involved no
      cash.
   In the Review file, load the adjustment lines from the package workbook beside the ledger, and add tests to
      its Tests tab: each entry balances, no entry touches cash, adjusted net income agrees with the workbook,
      and recorded total assets agree with your trial balances of Requirement 1.
   Instructor note: balance sheets, 2026 / 2025: cash 8,442,255.80 / 9,383,566.10; receivables 4,843,285.43 /
      4,755,337.09; inventories 23,935,720.45 / 15,178,832.94; prepaid 60,000.00 / 60,000.00; current assets
      37,281,261.68 / 29,377,736.13; property and equipment, net 2,091,743.54 / 2,480,488.73; total assets
      39,373,005.22 / 31,858,224.86; accounts payable 6,237,466.66 / 5,467,809.52; goods received not invoiced
      1,020,992.06 / 969,574.35; accrued liabilities 852,116.20 / 811,301.30; sales tax payable 5,620,840.66 /
      3,688,321.37; customer credits (2060) 3,413.46 / 1,008.67; current portion of notes 147,503.76 /
      89,243.61; current liabilities 13,882,332.80 / 11,027,258.82; notes payable less current portion
      241,800.92 / 154,181.62; total liabilities 14,124,133.72 / 11,181,440.44; common stock 500,000.00;
      retained earnings 24,748,871.50 / 20,176,784.42; total equity 25,248,871.50 / 20,676,784.42. Working
      capital 23,398,928.88 / 18,350,477.31; current ratio 2.69 / 2.66; quick ratio (cash and receivables)
      0.957 / 1.28; cash net of sales tax 2,821,415.14. Income, 2025 / 2026: operating revenue 29,515,670.85 /
      29,998,762.73; returns 201,104.38 / 242,764.56; net revenue 29,314,566.47 / 29,755,998.17; cost of goods
      sold 17,881,630.40 / 18,651,599.17; gross margin 11,432,936.07 / 11,104,399.00; operating expense
      6,313,997.45 / 6,410,227.46; operating income 5,118,938.62 / 4,694,171.54; interest 19,043.81 /
      29,584.46; loss on disposal 42,000.00 / 92,500.00; income before income taxes and net income
      5,057,894.81 / 4,572,087.08. Retained earnings: 1 January 2025 as previously reported 15,294,129.73,
      correction -175,240.12, as restated 15,118,889.61; plus 2025 net income, 20,176,784.42; plus 2026,
      24,748,871.50; no distributions. Cash flows, 2026 / 2025: net income 4,572,087.08 / 5,057,894.81;
      depreciation 576,245.19 / 542,423.80; loss on disposal 92,500.00 / 42,000.00; receivables -87,948.34 /
      +324,845.74; inventories, with 1090, -8,756,887.51 / -5,043,043.30; payables (2010, 2020) +821,074.85 /
      +1,087,218.19; sales tax +1,932,519.29 / +1,910,036.22; accrued and other +43,219.69 / +53,650.68;
      operating -807,189.75 / 3,975,026.14; investing 0.00 / -397,000.00 (425,000.00 paid, 28,000.00 of
      proceeds); financing -134,120.55 / -83,434.28; change in cash -941,310.30 / +3,494,591.86, which no
      adjustment changes. Interest paid 28,946.47 / 19,513.12; income taxes paid: none recorded (a matter for
      the CFO); noncash: 280,000.00 of equipment financed by a note in 2026. Review tests: every entry nets to
      zero, none posts to 1010, adjusted net income equals the workbook's, and recorded total assets equal
      Requirement 1's.

   Requirement 7: Build the note schedules from the records (Chapters 6, 10, 11, and 14)
   Each note is a schedule that the records can produce and that must agree with a line of the statements.
      Rebuilding a property register, a debt schedule, or revenue by product line joins documents to the
      ledger, which suits SQL, and the workbook formats the schedules beside the statements they support. The
      sales model of Chapter 14 could give the revenue disaggregation instead, but it would then have to be
      reconciled to the ledger and to the cutoff adjustment, so choose, and say why.
   Property and equipment: roll cost and accumulated depreciation forward by class from FixedAsset and
      FixedAssetEvent, reconcile the roll-forward to the ledger, and state the method and the lives.
   Notes payable: the terms of each note, the asset the records link it to, the principal due in each of the
      next five years, the current portion, and the interest paid.
   Revenue: disaggregate revenue on the adjusted basis by product line, customer segment, and timing of
      transfer, and show the contract balances that ASC Topic 606 requires: receivables, contract assets, and
      contract liabilities. Test whether any service work was done and not billed at a year-end.
   Accrued liabilities by component; for a fuller package, inventories by component and basis.
   Write the text of the notes on property and equipment, notes payable, revenue, and accrued liabilities, and
      of the note on the correction of the 2025 statements. The policies note and the others are optional.
   Instructor note: property and equipment, cost 4,027,000 at 1 January 2025; 2025 additions 425,000 (1120
      360,000, WH-0005 and WH-0006; 1130 65,000, OFF-0005) and disposal of WH-0001 (cost 168,000, accumulated
      depreciation 98,000, proceeds 28,000, loss 42,000), 4,284,000; 2026 addition of MFG-0007, 280,000 by
      note (noncash), and disposal of MFG-0004 (cost 210,000, accumulated depreciation 117,500, no proceeds,
      loss 92,500), 4,354,000. Depreciation 2025 / 2026 by class: furniture and fixtures 52,500.00 /
      52,500.00; warehouse 88,090.51 / 101,828.64; office 106,333.29 / 118,249.92; manufacturing 295,500.00 /
      303,666.63; total 542,423.80 / 576,245.19 (to 6130 246,923.80 / 272,578.56, to 1090 295,500.00 /
      303,666.63). Accumulated depreciation 1,359,087.47 -> 1,803,511.27 -> 2,262,256.46; net book value at
      2026 by class 157,500.00 / 501,680.85 / 109,479.32 / 1,323,083.37. Straight line, lives of 48 to 120
      months, no residual value, from the month after the asset is placed in service through the month before
      disposal; the register reproduces the ledger within monthly rounding. Notes: note 1, 360,000 at 6.75%,
      48 payments of 8,578.95 from August 2024, linked to MFG-0006, 154,181.62 at 2026 (243,425.23 at 2025);
      note 2, 280,000 at 6.4%, 60 payments of 5,465.42 from February 2026, linked to MFG-0007, 235,123.06;
      total 389,304.68. Principal due 2027 147,503.76; 2028 114,200.83; 2029 59,133.22; 2030 63,030.74; 2031
      5,436.13. The records link each note to the asset it financed; they do not show a security interest, so
      do not claim one. Revenue on the adjusted basis, 2026 / 2025: Furniture 17,420,791.79 / 17,418,046.62;
      Lighting 5,998,016.11 / 5,498,446.55; Textiles 3,279,920.95 / 3,177,119.95; Accessories 1,873,869.85 /
      1,947,191.82; design services 1,213,344.00 / 1,261,365.95; freight 212,820.03 / 213,499.96. By segment,
      products and services: Wholesale 15,288,355.75 / 14,349,172.31; Strategic 9,008,553.51 / 9,245,320.80;
      Design Trade 3,035,208.44 / 3,251,824.91; Small Business 1,240,481.00 / 1,194,486.92; Design Services
      1,213,344.00 / 1,261,365.95. Timing: at a point in time (goods and freight) 28,785,418.73 /
      28,254,304.90; over time (services) 1,213,344.00 / 1,261,365.95. Cross-checks: 2025 product revenue,
      28,040,804.94, equals Exercise 14.2's revenue by ship date; 2026's equals 28,528,117.59 plus the
      44,481.11 never invoiced. A private company may limit the disaggregation to the timing of transfer with
      qualitative information; a lender may still want product lines. Contract balances: receivables
      5,080,182.83 (1 January 2025, adjusted) / 4,755,337.09 / 4,843,285.43, each including the unsupported
      380,000.00; no contract assets and no contract liabilities (2070 unused); customer credits awaiting
      refund in 2060 3,105.75 / 1,008.67 / 3,413.46, at 2026 three Issued credit memos. Services: every
      billable hour in ServiceTimeEntry (19,627.49) is billed, December's work was billed on 31 December, and
      engagement 209 (In Progress, ended 2026-10-31) billed all 125.64 hours worked through 23 October; its
      142.69 planned hours were never all recorded, so there is no unbilled work. Inventories 2026 / 2025:
      finished goods at standard cost 12,169,701.74 / 10,829,820.22; materials and packaging at purchase-order
      cost (price variance to cost of goods sold) 11,751,653.92 / 4,334,722.56; work in process net of the
      1090 credit 14,364.79 / 14,290.16; total 23,935,720.45 / 15,178,832.94. Accrued liabilities 2026 / 2025:
      payroll and related, with the opening 95,000.00, 478,044.82 / 460,921.19; commissions (2034) 48,858.55 /
      48,071.71; accrued expenses 323,205.57 / 300,939.13; interest 2,007.26 / 1,369.27; total 852,116.20 /
      811,301.30.

   Requirement 8: Look past the balance-sheet date and at the year ahead (Chapters 8 and 12)
   The statements must account for what happened after 31 December 2026, up to the date they are available to
      be issued (ASC Topic 855), and management must evaluate whether conditions raise substantial doubt about
      the company's ability to continue as a going concern for a year after that date (ASC Subtopic 205-40).
      The database can contribute to both, but it cannot complete either.
   Profile the records dated after fiscal 2026, compare them with the same weeks of 2026, and state what they
      contain and what they cannot contain.
   Search them for liabilities missing at the year-end: payments in 2027 for goods or services received in
      2026 and not recorded as payables, Chapter 12's unrecorded liabilities.
   List the events the CFO must evaluate up to the date the statements are available to be issued.
   Measure the conditions that a going-concern evaluation weighs, and the factors that mitigate them, from the
      adjusted statements, and state what the CFO's evaluation needs beyond the database.
   Instructor note: the 2027 records are 263 supplier payments, 271,327.17, from 1 January to 23 February 2027
      (526 ledger rows, Dr 2010, Cr 1010), paying 262 invoices of 78 suppliers, all received from November to
      December 2026 and recorded in payables at the year-end (238 paid in full); no invoice was received after
      2026, so no unrecorded liability is found. The same weeks of 2026 had 2,530 payments, 3,040,077.15;
      payables at 2026 due in January and February 2027 were 2,665,014.91. The extract has no payroll for
      periods 78-79 (pay dates 2027-01-01 and 2027-01-05), no note payments (due 2027-01-01, 01-04, 02-01,
      02-02, all Scheduled), no December freight settlement, and no rent, sales, or receipts, so it is
      incomplete: do not read it as the company having stopped paying. Events to evaluate: the credit line
      itself if obtained before the statements are available to be issued, the sales tax position, and
      anything the CFO learns about the opening balances; the date the statements are available to be issued
      must be disclosed. Conditions: cash net of sales tax 2,821,415.14; quick ratio 0.96, down from 1.28;
      operating cash flow -807,189.75 against +3,975,026.14; inventories 64% of current assets, with materials
      (11,751,653.92) above twelve months of issues (10,161,204.64); 2,096,371.12 of opening payables
      unchanged for three years. Mitigating: profit, working capital of 23.4 million, and debt of only
      389,304.68. Conclusion: the ledger alone does not establish substantial doubt, but the sales tax and the
      opening payables could change that, so the CFO's evaluation needs evidence from outside the database.

   Requirement 9: Assemble the package and write the memo to the CFO (Chapter 8)
   Assemble the statements and notes as a PDF produced from the workbook, and write a memorandum of no more
      than two pages to the CFO, with an appendix of exhibits of no more than three pages. For each matter
      that the records cannot settle, state what the records show, the evidence that would settle it, its
      possible effect where the ledger allows you to measure it, and the treatment you propose. The memo must
      cover the company's tax status, its leases, the sales tax collected, and the balances that no document
      supports; it may also raise other matters the records point to, such as whether standard costs unchanged
      for three years still measure the finished goods at cost. Add the passed adjustments for the CFO's
      approval, the changes to the year-end close that would prevent this year's adjustments from recurring,
      and your recommendation on whether the package should go to the bank as it stands.
   Instructor note: (1) Tax status (ASC Topic 740): no tax account and no tax recorded in three years; equity
      is common stock with no distributions. Evidence: the entity's legal form or tax election, its returns,
      and its payments. If it is a C corporation, the omitted provision is several times materiality (21%
      federal on 4,572,087.08 alone is about 960,000), so state it; do not record a number. (2) Leases (ASC
      Topic 842): office and warehouse rent is paid on the first weekday of each month straight from cash
      (467,525.63 / 484,969.91 / 504,245.32), in amounts that vary slightly from month to month; 2120 and 1140
      are unused and no lessor appears among the suppliers. Evidence: the agreements (term, options,
      escalation, discount rate). Likely effect: right-of-use assets and lease liabilities, which would move
      the bank's ratios. (3) Sales tax: 5,620,840.66 collected with no remittance recorded (2050 credits only
      from invoices, debits only from credit memos, 38,587.80). Evidence: the returns, the bank statements,
      the tax authority's account. Either the liability is overstated, if the tax was paid outside the ledger,
      which would also overstate cash, or penalties and interest may be owed (ASC Topic 450). (4) Opening
      balances: receivables 380,000.00, prepaid 60,000.00, payables 2,096,371.12 (equal to opening cash to the
      cent), accrued payroll 95,000.00, accrued expenses 85,000.00, all unchanged in three years; if none is
      real, equity rises by 1,836,371.12 (assets -440,000.00, liabilities -2,276,371.12); if the payables are
      real, they are three years past due. (5) Cash: no interest income and no bank reconciliation in the
      records; confirm the balance with the bank. (6) Inventories (ASC Topic 330): a physical count and a net
      realizable value review are needed; stock by item cannot be rebuilt because the opening inventory has no
      item detail. Whether standards unchanged since 2024 still approximate cost on normal capacity needs a
      cost study; at a standard rebuilt on normal capacity, manufactured finished goods would be about 471,000
      higher at the end of 2026 and 370,000 higher at the end of 2025, so a strong memo names it and
      recommends the study. (7) Subsequent events and going concern, as in Requirement 8. (8) Passed items
      P1-P3, for approval. Recommendation: record A1-A4 and R1-R2, and do not release the package until items
      1 to 4 are settled. Close-process changes: a year-end payroll accrual, a monthly review of open
      accruals, revenue cutoff by delivery date, and an interest accrual.

   Milestone 4: What the data cannot settle
   (Requirements 8 and 9): the review of later events and the memo to the CFO.
   Instructor note: the 2027 records hold 263 supplier payments (271,327.17) and no unrecorded liability; the
      memo's required matters are tax status, leases, sales tax payable 5,620,840.66, and the unsupported
      opening balances (equity +1,836,371.12 if none is real).

   Checks (each agreed on dataset release v2026.1 when this file was built):
   Requirement 1: accounts with postings: 71
   Requirement 1: accounts at zero: 4
   Requirement 1: debit balances: 67,107,722.36
   Requirement 1: credit balances: 67,107,722.36
   Requirement 1: debit balances less credit balances: 0.00
   Requirement 1: accounts with postings: 71
   Requirement 1: accounts at zero: 4
   Requirement 1: debit balances: 58,143,212.29
   Requirement 1: credit balances: 58,143,212.29
   Requirement 1: debit balances less credit balances: 0.00
   Requirement 1: accounts with postings: 69
   Requirement 1: accounts at zero: 2
   Requirement 1: debit balances: 47,565,211.56
   Requirement 1: credit balances: 47,565,211.56
   Requirement 1: debit balances less credit balances: 0.00
   Requirement 1: fiscal years: [2024, 2025, 2026]
   Requirement 1: net income: [5110308.27, 5134354.71, 4503611.24]
   Requirement 1: each equal to its close: [5110308.27, 5134354.71, 4503611.24]
   Requirement 1: 2024 TotalAssets: 23,742,720.31
   Requirement 1: 2024 CurrentAssets: 21,074,807.78
   Requirement 1: 2024 CurrentLiabilities: 7,621,731.07
   Requirement 1: 2024 NotesPayable: 326,859.51
   Requirement 1: 2024 RetainedEarnings: 10,183,821.46
   Requirement 1: 2024 CommonStock: 500,000.00
   Requirement 1: 2025 TotalAssets: 31,838,684.00
   Requirement 1: 2025 CurrentAssets: 29,358,195.27
   Requirement 1: 2025 CurrentLiabilities: 10,666,774.33
   Requirement 1: 2025 NotesPayable: 243,425.23
   Requirement 1: 2025 RetainedEarnings: 15,294,129.73
   Requirement 1: 2025 CommonStock: 500,000.00
   Requirement 1: 2026 TotalAssets: 39,328,524.11
   Requirement 1: 2026 CurrentAssets: 37,236,780.57
   Requirement 1: 2026 CurrentLiabilities: 13,507,123.75
   Requirement 1: 2026 NotesPayable: 389,304.68
   Requirement 1: 2026 RetainedEarnings: 20,428,484.44
   Requirement 1: 2026 CommonStock: 500,000.00
   Requirement 1: 2025 OperatingRevenue: 29,586,268.92
   Requirement 1: 2025 Returns: 201,104.38
   Requirement 1: 2025 NetRevenue: 29,385,164.54
   Requirement 1: 2025 CostOfGoodsSold: 17,833,805.16
   Requirement 1: 2025 GrossMargin: 11,551,359.38
   Requirement 1: 2025 OperatingExpense: 6,355,491.55
   Requirement 1: 2025 OperatingIncome: 5,195,867.83
   Requirement 1: 2025 InterestExpense: 19,513.12
   Requirement 1: 2025 LossOnDisposal: 42,000.00
   Requirement 1: 2025 NetIncome: 5,134,354.71
   Requirement 1: 2026 OperatingRevenue: 29,973,822.48
   Requirement 1: 2026 Returns: 242,764.56
   Requirement 1: 2026 NetRevenue: 29,731,057.92
   Requirement 1: 2026 CostOfGoodsSold: 18,634,303.63
   Requirement 1: 2026 GrossMargin: 11,096,754.29
   Requirement 1: 2026 OperatingExpense: 6,471,696.58
   Requirement 1: 2026 OperatingIncome: 4,625,057.71
   Requirement 1: 2026 InterestExpense: 28,946.47
   Requirement 1: 2026 LossOnDisposal: 92,500.00
   Requirement 1: 2026 NetIncome: 4,503,611.24
   Requirement 1: accounts: [1030, 1060, 1070, 1080, 1140, 1180, 1190, 2070, 2080, 2090, 2120, 2130, 3020,
      3040, 3050, 4070, 5070, 6170, 6260, 6270, 7010, 7040, 8020]
   Requirement 1: active: 16
   Requirement 1: inactive: 7
   Requirement 1: accounts named for taxes: ['Payroll Tax Withholdings Payable', 'Employer Payroll Taxes
      Payable', 'Sales Tax Payable', 'Payroll Taxes and Benefits']
   Requirement 1: accounts named for income tax: 0
   Milestone 1: 2024 accounts: 69
   Milestone 1: 2024 at zero: 2
   Milestone 1: 2024 debit balances: 47,565,211.56
   Milestone 1: 2024 credit balances: 47,565,211.56
   Milestone 1: 2024 total assets: 23,742,720.31
   Milestone 1: 2024 net income (the year's revenue and expense balances): 5,110,308.27
   Milestone 1: 2025 accounts: 71
   Milestone 1: 2025 at zero: 4
   Milestone 1: 2025 debit balances: 58,143,212.29
   Milestone 1: 2025 credit balances: 58,143,212.29
   Milestone 1: 2025 total assets: 31,838,684.00
   Milestone 1: 2025 net income (the year's revenue and expense balances): 5,134,354.71
   Milestone 1: 2026 accounts: 71
   Milestone 1: 2026 at zero: 4
   Milestone 1: 2026 debit balances: 67,107,722.36
   Milestone 1: 2026 credit balances: 67,107,722.36
   Milestone 1: 2026 total assets: 39,328,524.11
   Milestone 1: 2026 net income (the year's revenue and expense balances): 4,503,611.24
   Requirement 2: 2025 materiality: 256,717.74
   Requirement 2: 2026 materiality: 225,180.56
   Requirement 2: accounts: [1045, 2050, 1040, 1010, 2010, 4020, 5080, 5020]
   Requirement 2: changes on each account's normal side: [7416931.36, 1932519.29, 1339881.52, -941310.3,
      769657.14, 498432.37, 403686.8, 246456.24]
   Requirement 2: accounts of the opening entry: 18
   Requirement 2: 1050 opening line: 60,000.00
   Requirement 2: 1050 other postings: 0
   Requirement 2: 2030 opening line: -95,000.00
   Requirement 2: 2030 other postings net: 0.00
   Requirement 2: 1020 opening line: 380,000.00
   Requirement 2: 2010 opening line: -2,096,371.12
   Requirement 2: 2010 equal to the opening cash line: 2,096,371.12
   Requirement 2: 2040 opening line: -85,000.00
   Requirement 3: accrual entries: 396
   Requirement 3: amount accrued: 4,052,446.62
   Requirement 3: invoice lines referring to an accrual: 355
   Requirement 3: at most one line per accrual: 355
   Requirement 3: cleared by invoices: 3,646,702.22
   Requirement 3: lines without an accrual: 40293
   Requirement 3: Accrual Adjustment entries: 149
   Requirement 3: their targets: 149
   Requirement 3: cleared by adjustments: 54,615.91
   Requirement 3: fiscal years: [2024, 2025, 2026]
   Requirement 3: lines: [60, 65, 84]
   Requirement 3: excess to expense: [24489.89, 26702.96, 34364.32]
   Requirement 3: shortest: 15.00
   Requirement 3: longest: 62.00
   Requirement 3: median: 39.00
   Requirement 3: at the longest: 4
   Requirement 3: 2024 young: 152,347.13
   Requirement 3: 2024 old: 39,028.43
   Requirement 3: 2024 old items: 7
   Requirement 3: 2025 young: 168,648.64
   Requirement 3: 2025 old: 96,049.58
   Requirement 3: 2025 old items: 15
   Requirement 3: 2026 young: 193,781.70
   Requirement 3: 2026 old: 157,346.79
   Requirement 3: 2026 old items: 22
   Requirement 3: flagged though inside the window, and invoiced after the year-end: [['2025-12-31',
      'JE-2025-000188', 61.0, '2026-01-01']]
   Requirement 3: shipment credits to 2040: 1,477,398.06
   Requirement 3: equal to the 5050 debits: 1,477,398.06
   Requirement 3: settlements: 35
   Requirement 3: settled: 1,432,974.19
   Requirement 3: none in the data for December 2026: True
   Requirement 3: 2024 Opening: 85,000.00
   Requirement 3: 2024 FreightNotSettled: 48,797.21
   Requirement 3: 2024 DecemberFreight: 45,381.01
   Requirement 3: 2024 YoungAccruals: 152,347.13
   Requirement 3: 2024 OldAccruals: 39,028.43
   Requirement 3: 2024 Parts: 325,172.77
   Requirement 3: 2024 Ledger: 325,172.77
   Requirement 3: 2025 Opening: 85,000.00
   Requirement 3: 2025 FreightNotSettled: 47,290.49
   Requirement 3: 2025 DecemberFreight: 41,564.67
   Requirement 3: 2025 YoungAccruals: 168,648.64
   Requirement 3: 2025 OldAccruals: 96,049.58
   Requirement 3: 2025 Parts: 396,988.71
   Requirement 3: 2025 Ledger: 396,988.71
   Requirement 3: 2026 Opening: 85,000.00
   Requirement 3: 2026 FreightNotSettled: 44,423.87
   Requirement 3: 2026 DecemberFreight: 40,704.22
   Requirement 3: 2026 YoungAccruals: 193,781.70
   Requirement 3: 2026 OldAccruals: 157,346.79
   Requirement 3: 2026 Parts: 480,552.36
   Requirement 3: 2026 Ledger: 480,552.36
   Requirement 3: no difference at any year-end: [0.0, 0.0, 0.0]
   Requirement 3: items: 22
   Requirement 3: open amount: 157,346.79
   Requirement 3: none invoiced: 0
   Requirement 3: partly cleared by a cleanup: 3
   Requirement 3: recorded in 2024: [68844.44, 11]
   Requirement 3: recorded in 2025: [32795.49, 5]
   Requirement 3: recorded in 2026: [55706.86, 6]
   Requirement 3: expense account 6110: 22,616.85
   Requirement 3: expense account 6120: 26,261.26
   Requirement 3: expense account 6140: 5,572.08
   Requirement 3: expense account 6160: 17,895.82
   Requirement 3: expense account 6180: 9,569.93
   Requirement 3: expense account 6190: 10,368.12
   Requirement 3: expense account 6200: 15,120.25
   Requirement 3: expense account 6210: 25,601.55
   Requirement 3: expense account 6220: 24,340.93
   Requirement 3: 2024 items: ['JE-2024-000188', 'JE-2024-000206', 'JE-2024-000210', 'JE-2024-000214']
   Requirement 3: 2025 items: ['JE-2025-000202']
   Requirement 3: 2024 items open at 2026-12-31: 32,929.99
   Requirement 3: 2025 items open at 2026-12-31: 5,590.35
   Requirement 4: the rows the workbook pastes (LateInvoices): [['SI-2025-006738', '2025-01-01', '2025-01-01',
      '2024-12-31', 'Wholesale', 2163.02, 140.6, 0.0, 0.0, 2163.02, 0.0, 0.0], ['SI-2025-006743',
      '2025-01-02', '2025-01-02', '2024-12-23', 'Strategic', 21043.98, 1367.86, 0.0, 21043.98, 0.0, 0.0, 0.0],
      ['SI-2025-006745', '2025-01-02', '2025-01-02', '2024-12-12', 'Strategic', 1392.1, 90.49, 0.0, 0.0, 0.0,
      1392.1, 0.0], ['SI-2025-006752', '2025-01-02', '2025-01-02', '2024-12-22', 'Wholesale', 2133.77, 138.7,
      0.0, 2133.77, 0.0, 0.0, 0.0], ['SI-2025-006758', '2025-01-03', '2025-01-03', '2024-12-12', 'Wholesale',
      5739.06, 373.04, 0.0, 5739.06, 0.0, 0.0, 0.0], ['SI-2025-006763', '2025-01-03', '2025-01-03',
      '2024-12-12', 'Wholesale', 3780.02, 245.7, 0.0, 3780.02, 0.0, 0.0, 0.0], ['SI-2025-006764',
      '2025-01-03', '2025-01-03', '2024-12-16', 'Strategic', 2121.39, 137.89, 0.0, 0.0, 0.0, 2121.39, 0.0],
      ['SI-2025-006779', '2025-01-04', '2025-01-04', '2024-12-06', 'Wholesale', 1949.81, 126.74, 0.0, 0.0,
      0.0, 1949.81, 0.0], ['SI-2025-006784', '2025-01-04', '2025-01-04', '2024-12-17', 'Wholesale', 3046.81,
      198.04, 0.0, 0.0, 0.0, 3046.81, 0.0], ['SI-2025-006803', '2025-01-05', '2025-01-05', '2024-12-06',
      'Wholesale', 2673.05, 173.75, 0.0, 0.0, 2673.05, 0.0, 0.0], ['SI-2025-006815', '2025-01-05',
      '2025-01-05', '2024-12-25', 'Wholesale', 9569.24, 622.0, 0.0, 9569.24, 0.0, 0.0, 0.0],
      ['SI-2025-006820', '2025-01-05', '2025-01-05', '2024-12-11', 'Wholesale', 21889.56, 1422.82, 0.0,
      21889.56, 0.0, 0.0, 0.0], ['SI-2025-006834', '2025-01-06', '2025-01-06', '2024-12-06', 'Wholesale',
      1869.27, 121.5, 0.0, 1869.27, 0.0, 0.0, 0.0], ['SI-2025-006844', '2025-01-06', '2025-01-06',
      '2024-12-12', 'Strategic', 5924.9, 385.12, 0.0, 5924.9, 0.0, 0.0, 0.0], ['SI-2025-006853', '2025-01-06',
      '2025-01-06', '2024-12-25', 'Strategic', 4842.95, 314.79, 0.0, 4842.95, 0.0, 0.0, 0.0],
      ['SI-2026-013742', '2025-12-04', '2026-01-01', '2025-12-10', 'Wholesale', 3233.18, 210.16, 0.0, 3233.18,
      0.0, 0.0, 0.0], ['SI-2026-013745', '2026-01-01', '2026-01-01', '2025-12-11', 'Strategic', 866.89, 56.35,
      0.0, 0.0, 0.0, 866.89, 0.0], ['SI-2026-013746', '2026-01-01', '2026-01-01', '2025-12-19', 'Strategic',
      2401.48, 156.1, 0.0, 0.0, 0.0, 0.0, 2401.48], ['SI-2026-013749', '2026-01-02', '2026-01-02',
      '2025-12-05', 'Strategic', 917.94, 59.67, 0.0, 0.0, 0.0, 917.94, 0.0], ['SI-2026-013764', '2026-01-03',
      '2026-01-03', '2025-12-05', 'Wholesale', 2476.7, 160.99, 0.0, 0.0, 2476.7, 0.0, 0.0], ['SI-2026-013766',
      '2026-01-03', '2026-01-03', '2025-12-11', 'Wholesale', 589.13, 38.29, 0.0, 0.0, 589.13, 0.0, 0.0],
      ['SI-2026-013859', '2026-01-06', '2026-01-06', '2025-12-28', 'Strategic', 3547.34, 230.58, 0.0, 3547.34,
      0.0, 0.0, 0.0], ['SI-2026-013861', '2026-01-06', '2026-01-06', '2025-12-14', 'Strategic', 5508.2,
      358.03, 0.0, 5508.2, 0.0, 0.0, 0.0]]
   Requirement 4: 2024 deliveries: invoices: 15
   Requirement 4: 2024 deliveries: SubTotal: 90,138.93
   Requirement 4: 2024 deliveries: tax: 5,859.04
   Requirement 4: 2025 deliveries: invoices: 8
   Requirement 4: 2025 deliveries: SubTotal: 19,540.86
   Requirement 4: 2025 deliveries: tax: 1,270.17
   Requirement 4: freight on these invoices: 0.00
   Requirement 4: 2024 Strategic: 35,325.32
   Requirement 4: 2024 Wholesale: 54,813.61
   Requirement 4: 2025 Strategic: 13,241.85
   Requirement 4: 2025 Wholesale: 6,299.01
   Requirement 4: 2024 Furniture: 76,792.75
   Requirement 4: 2024 Lighting: 4,836.07
   Requirement 4: 2024 Textiles: 8,510.11
   Requirement 4: 2025 Furniture: 12,288.72
   Requirement 4: 2025 Lighting: 3,065.83
   Requirement 4: 2025 Textiles: 1,784.83
   Requirement 4: 2025 Accessories: 2,401.48
   Requirement 4: the rows the workbook pastes (UnbilledLines): [[26779, 'SH-2026-009455', '2026-12-01',
      '2026-12-04', 'ACC-VAS-0029', 'Accessories', 'Strategic', 1.87, 58.32, 0.0, 57.76, 109.06], [26792,
      'SH-2026-009461', '2026-12-01', '2026-12-03', 'TXT-THR-0009', 'Textiles', 'Wholesale', 6.02, 580.51,
      0.0, 1678.56, 3494.67], [26836, 'SH-2026-009486', '2026-12-03', '2026-12-05', 'ACC-PLN-0013',
      'Accessories', 'Wholesale', 9.59, 166.02, 0.0, 680.7, 1592.13], [27053, 'SH-2026-009584', '2026-12-09',
      '2026-12-13', 'FUR-DSK-0083', 'Furniture', 'Strategic', 15.07, 868.27, 0.0, 6748.8, 13084.83], [27271,
      'SH-2026-009650', '2026-12-21', '2026-12-24', 'LGT-FLR-0014', 'Lighting', 'Wholesale', 9.97, 244.01,
      0.0, 1104.68, 2432.78], [27309, 'SH-2026-009660', '2026-12-23', '2026-12-24', 'FUR-CTB-0056',
      'Furniture', 'Strategic', 11.68, 584.68, 0.0, 3606.78, 6829.06], [27337, 'SH-2026-009667', '2026-12-25',
      '2026-12-26', 'FUR-CON-0021', 'Furniture', 'Wholesale', 12.25, 843.86, 0.0, 5307.93, 10337.28], [27427,
      'SH-2026-009689', '2026-12-31', '2026-12-31', 'FUR-CTB-0047', 'Furniture', 'Wholesale', 7.48, 607.19,
      0.0, 2790.04, 4541.78], [27482, 'SH-2026-009703', '2026-12-31', '2026-12-31', 'ACC-ART-0024',
      'Accessories', 'Wholesale', 10.89, 189.12, 0.0, 920.53, 2059.52]]
   Requirement 4: value at order price: 44,481.11
   Requirement 4: standard cost: 22,895.78
   Requirement 4: Strategic: 20,022.95
   Requirement 4: Wholesale: 24,458.16
   Requirement 4: Furniture: 34,792.95
   Requirement 4: Lighting: 2,432.78
   Requirement 4: Textiles: 3,494.67
   Requirement 4: Accessories: 3,760.71
   Requirement 4: the rows the workbook pastes (GroupAccounts): [['Furniture', 4010], ['Lighting', 4020],
      ['Textiles', 4030], ['Accessories', 4040], ['Services', 4080]]
   Requirement 4: periods starting: ['2024-12-16', '2024-12-30', '2025-12-15', '2025-12-29', '2026-12-14',
      '2026-12-28']
   Requirement 4: registers of the 2026 periods: [0, 0]
   Requirement 4: cost of the period of 2024-12-16: 242,165.92
   Requirement 4: cost of the period of 2025-12-15: 263,426.72
   Requirement 4: the opening line: 95,000.00
   Requirement 4: the payroll postings net: -0.00
   Requirement 4: 2024 PayrollOwed: 302,568.90
   Requirement 4: 2024 GrossPay: 265,750.45
   Requirement 4: 2024 EmployerTaxes: 20,329.93
   Requirement 4: 2024 Benefits: 16,488.52
   Requirement 4: 2024 Manufacturing: 132,849.90
   Requirement 4: 2025 PayrollOwed: 365,921.19
   Requirement 4: 2025 GrossPay: 321,409.38
   Requirement 4: 2025 EmployerTaxes: 24,587.79
   Requirement 4: 2025 Benefits: 19,924.02
   Requirement 4: 2025 Manufacturing: 180,675.14
   Requirement 4: 2024 periods: 2
   Requirement 4: 2025 periods: 2
   Requirement 4: cost of the eight periods: 2,298,268.90
   Requirement 4: their working days: 78
   Requirement 4: working days left: 13
   Requirement 4: cost per working day: 29,464.99
   Requirement 4: payroll owed: 383,044.82
   Requirement 4: gross pay: 336,456.34
   Requirement 4: employer taxes: 25,738.93
   Requirement 4: benefits: 20,849.55
   Requirement 4: manufacturing: 197,970.68
   Requirement 4: the rows the workbook pastes (PayrollAccounts): [['Administration', 6030], ['Customer
      Service', 6040], ['Design Services', 6280], ['Executive', 6050], ['Manufacturing', 1090], ['Marketing',
      6240], ['Purchasing', 6230], ['Research and Development', 6250], ['Sales', 6010], ['Warehouse', 6020]]
   Requirement 4: 2024 total: 1,838.58
   Requirement 4: 2025 total: 1,369.27
   Requirement 4: 2026 total: 2,007.26
   Requirement 4: 2024 note 1: ['2024-12-02', '2025-01-01', 1838.58, 30.0, 30.0, 1838.58]
   Requirement 4: 2025 note 1: ['2025-12-01', '2026-01-01', 1369.27, 31.0, 31.0, 1369.27]
   Requirement 4: 2026 note 1: ['2026-12-01', '2027-01-01', 867.27, 31.0, 31.0, 867.27]
   Requirement 4: 2026 note 2: ['2026-12-02', '2027-01-04', 1253.99, 33.0, 30.0, 1139.99]
   Requirement 5: the rows the workbook pastes (ReceivableAging): [['Current', 3567153.91, 809, 3655971.5,
      780], ['1-30 days', 764981.8, 271, 745674.84, 258], ['31-60 days', 27924.74, 24, 16711.26, 28], ['61-90
      days', 523.28, 8, 405.41, 10], ['Over 90 days', 123.01, 8, 41.31, 3]]
   Requirement 5: 2025 allowance: 34,659.34
   Requirement 5: 2026 allowance: 34,106.25
   Requirement 5: effect on 2026 income: 553.09
   Requirement 5: the rows the workbook pastes (ReturnsAfterYearEnd): [[2025, 2024, 13, 13985.96, 8113.31],
      [2026, 2025, 14, 16319.03, 9545.9]]
   Requirement 5: P2 at 2026-12-31: -6,773.13
   Requirement 5: damaged or of concern by year: [24429.94, 52030.49, 61146.0]
   Requirement 5: since the first year: 137,606.43
   Requirement 5: restocked at full standard cost: [True, True, True]
   Requirement 5: 2025 current portion: 89,243.61
   Requirement 5: 2026 current portion: 147,503.76
   Requirement 5: notes at 2025-12-31: 1
   Requirement 5: 1090 at 2025-12-31: -49,102.81
   Requirement 5: 1090 at 2026-12-31: -46,730.55
   Requirement 5: 1046 at 2025-12-31: 63,392.97
   Requirement 5: 1046 at 2026-12-31: 61,095.34
   Requirement 6: 2024 cash at year-end: 5,888,974.24
   Requirement 6: 2025 cash at year-end: 9,383,566.10
   Requirement 6: 2026 cash at year-end: 8,442,255.80
   Requirement 6: 2025 change in cash: 3,494,591.86
   Requirement 6: 2025 interest paid: 19,513.12
   Requirement 6: 2026 change in cash: -941,310.30
   Requirement 6: 2026 interest paid: 28,946.47
   Requirement 6: financed by a note: [['2024', 360000], ['2026', 280000]]
   Requirement 6: years with a disposal without proceeds: [2026]
   Requirement 7: cost accounts: [1110, 1120, 1130, 1185]
   Requirement 7: cost at 2024-12-31: 4,027,000.00
   Requirement 7: cost at 2025-12-31: 4,284,000.00
   Requirement 7: cost at 2026-12-31: 4,354,000.00
   Requirement 7: additions 2025: 425000
   Requirement 7: additions 2026: 280000
   Requirement 7: disposals 2025: 168,000.00
   Requirement 7: disposals 2026: 210,000.00
   Requirement 7: lives in months: [48, 120]
   Requirement 7: no residual value: 0
   Requirement 7: additions 2025, account 1120: 360,000.00
   Requirement 7: additions 2025, account 1130: 65,000.00
   Requirement 7: cost by class at 2026-12-31, register against the ledger: [420000.0, 834000.0, 510000.0,
      2590000.0]
   Requirement 7: furniture and fixtures 2025: 52,500.00
   Requirement 7: furniture and fixtures 2026: 52,500.00
   Requirement 7: warehouse 2025: 88,090.51
   Requirement 7: warehouse 2026: 101,828.64
   Requirement 7: office 2025: 106,333.29
   Requirement 7: office 2026: 118,249.92
   Requirement 7: manufacturing 2025: 295,500.00
   Requirement 7: manufacturing 2026: 303,666.63
   Requirement 7: total 2025: 542,423.80
   Requirement 7: total 2026: 576,245.19
   Requirement 7: the register reproduces the ledger: [True, True, True, True]
   Requirement 7: accounts charged: [1090, 6130]
   Requirement 7: 6130 2025: 246,923.80
   Requirement 7: 6130 2026: 272,578.56
   Requirement 7: 1090 2025: 295,500.00
   Requirement 7: 1090 2026: 303,666.63
   Requirement 7: accumulated at 2024-12-31: 1,359,087.47
   Requirement 7: accumulated at 2025-12-31: 1,803,511.27
   Requirement 7: accumulated at 2026-12-31: 2,262,256.46
   Requirement 7: net book value by class at 2026-12-31: [157500.0, 501680.85, 109479.32, 1323083.37]
   Requirement 7: 2025 disposal: [168000.0, 98000.0, 28000.0, 42000.0]
   Requirement 7: 2026 disposal: [210000.0, 117500.0, 0.0, 92500.0]
   Requirement 7: assets financed: ['MFG-0006', 'MFG-0007']
   Requirement 7: principal: [360000, 280000]
   Requirement 7: terms: [48, 60]
   Requirement 7: payments: [8578.95, 5465.42]
   Requirement 7: outstanding at 2025-12-31: [243425.23, None]
   Requirement 7: outstanding at 2026-12-31: [154181.62, 235123.06]
   Requirement 7: total equal to 2110: 389,304.68
   Requirement 7: maturities: [[2027, 147503.76], [2028, 114200.83], [2029, 59133.22], [2030, 63030.74],
      [2031, 5436.13]]
   Requirement 7: the rows the workbook pastes (SegmentRevenue): [['Design Services', 2025, 1261365.95],
      ['Design Services', 2026, 1213344.0], ['Design Trade', 2025, 3251824.91], ['Design Trade', 2026,
      3035208.44], ['Small Business', 2025, 1194486.92], ['Small Business', 2026, 1240481.0], ['Strategic',
      2025, 9267404.27], ['Strategic', 2026, 9001772.41], ['Wholesale', 2025, 14397686.91], ['Wholesale',
      2026, 15270196.6]]
   Requirement 7: Furniture 2025: 17,418,046.62
   Requirement 7: Furniture 2026: 17,420,791.79
   Requirement 7: Lighting 2025: 5,498,446.55
   Requirement 7: Lighting 2026: 5,998,016.11
   Requirement 7: Textiles 2025: 3,177,119.95
   Requirement 7: Textiles 2026: 3,279,920.95
   Requirement 7: Accessories 2025: 1,947,191.82
   Requirement 7: Accessories 2026: 1,873,869.85
   Requirement 7: design services 2025: 1,261,365.95
   Requirement 7: design services 2026: 1,213,344.00
   Requirement 7: 2025 products equal Exercise 14.2's revenue by ship date: 28,040,804.94
   Requirement 7: 2026 products equal revenue by ship date plus the lines never invoiced: 28,572,598.70
   Requirement 7: freight account: [4050]
   Requirement 7: freight 2025: 213,499.96
   Requirement 7: freight 2026: 212,820.03
   Requirement 7: 2060 at the year-ends: [3105.75, 1008.67, 3413.46]
   Requirement 7: 2070: [0.0, 0.0, 0.0]
   Requirement 7: Issued credit memos: 3
   Requirement 7: equal to 2060 at 2026-12-31: 3,413.46
   Requirement 7: engagements not Billed: [209]
   Requirement 7: billed every hour worked: [125.64]
   Requirement 7: billed hours: [125.64]
   Requirement 7: planned hours: [142.69]
   Requirement 7: all billable hours: 19,627.49
   Requirement 7: all billed: 19,627.49
   Requirement 7: 2025 finished goods: 10,829,820.22
   Requirement 7: 2025 materials: 4,334,722.56
   Requirement 7: 2025 work in process net of 1090: 14,290.16
   Requirement 7: 2025 commissions: 48,071.71
   Requirement 7: 2025 payroll recorded (the opening 2030 alone): 95,000.00
   Requirement 7: 2025 2040: 396,988.71
   Requirement 7: 2026 finished goods: 12,169,701.74
   Requirement 7: 2026 materials: 11,751,653.92
   Requirement 7: 2026 work in process net of 1090: 14,364.79
   Requirement 7: 2026 commissions: 48,858.55
   Requirement 7: 2026 payroll recorded (the opening 2030 alone): 95,000.00
   Requirement 7: 2026 2040: 480,552.36
   Requirement 8: source documents: ['DisbursementPayment']
   Requirement 8: accounts: [1010, 2010]
   Requirement 8: rows: 526
   Requirement 8: credits to cash: 271,327.17
   Requirement 8: debits to payables: 271,327.17
   Requirement 8: payments: 263
   Requirement 8: amount: 271,327.17
   Requirement 8: invoices: 262
   Requirement 8: suppliers: 78
   Requirement 8: received by the year-end: True
   Requirement 8: paid in full: 238
   Requirement 8: invoices received after the year-end: 0
   Requirement 8: payments in the same weeks: 2530
   Requirement 8: their amount: 3,040,077.15
   Requirement 8: payables due: 2,665,014.91
   Requirement 8: pay dates: ['2027-01-01', '2027-01-05']
   Requirement 8: registers recorded: [0, 0]
   Requirement 8: note payments: 4
   Requirement 8: all Scheduled, none recorded: [['Scheduled', 0]]
   Requirement 8: materials on hand: 11,751,653.92
   Requirement 8: twelve months of issues: 10,161,204.64
   Requirement 9: rent by year: [467525.63, 484969.91, 504245.32]
   Requirement 9: paid from cash: [467525.63, 484969.91, 504245.32]
   Requirement 9: source documents: ['CreditMemo', 'SalesInvoice']
   Requirement 9: credit memo debits: 38,587.80
   Requirement 9: no credits from credit memos: 0.00
   Requirement 9: no debits from invoices: 0.00
   Requirement 9: balance: 5,620,840.66
   Requirement 9: assets: 440,000.00
   Requirement 9: liabilities: 2,276,371.12
   Requirement 9: equity if none is real: 1,836,371.12
   Milestone 4: payments: 263
   Milestone 4: amount: 271,327.17
   Milestone 4: sales tax payable: 5,620,840.66
   Milestone 4: equity if none is real: 1,836,371.12
*/
