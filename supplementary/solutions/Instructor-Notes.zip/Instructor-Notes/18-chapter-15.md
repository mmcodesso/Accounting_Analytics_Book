# Chapter 15: Reports for Management Decisions

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 15.1: The Promotions Page

**Tutorial 15.1 expected values (SQL twins; the measures checked in Desktop 2.158's engine on the CR15 reference model):** PromotionProgram 9 rows; 25,825 of 27,933 lines have no promotion. Fiscal 2026 gross to net: List Amount 33,589,137.45; price lists and overrides -3,470,607.31; promotions -362,110.06 (Discounts 362,110.75; 0.69 of line rounding); total 29,756,420.08. 2026 discounts by promotion: 8 Furniture Seasonal 296,053.58 (576 lines); 7 Harbor Collection 30,478.57 (68); 9 Design Trade Customer 28,057.57 (88); 6 Wholesale Customer (2025) 6,858.14 (54); 5 Textiles Seasonal (2025) 662.89 (10). Promotion 8 by invoice month: 2026-09 95,996.97 (167 lines); 10 136,935.59 (249); 11 51,965.03 (119); 12 11,155.99 (41); 160 lines after 2026-10-31. Promotion 7 effective 2026-03-01 to 2026-02-28, invoiced 2026-03-07 to 2026-08-08.

## Guided Tutorial 15.2: The Cost-Center Budget Page

**Tutorial 15.2 expected values (SQL twins; checked in Desktop 2.158's engine on the CR15 reference model):** BudgetLine 2026 without Balance Sheet: Revenue 103,974,558.70 (2,463 lines, CC Sales), COGS 55,159,897.72 (CC Manufacturing), Operating Expense category 8,318,595.27 incl. Debt Interest Schedule 28,946.47 (account 7030, AccountSubType Other Expense); opex by AccountSubType 8,289,648.80. 2026 opex by cost center (budget / actual / variance %): (Blank) 2,024,273.70 / 2,040,916.48 / +0.8%; Administration 659,199.36 / 546,710.11 / -17.1%; Customer Service 230,151.96 / 221,422.90 / -3.8%; Design Services 558,149.42 / 534,250.28 / -4.3%; Executive 854,857.56 / 820,566.24 / -4.0%; Marketing 286,786.93 / 276,150.82 / -3.7%; Purchasing 385,041.96 / 370,153.16 / -3.9%; Research and Development 203,993.58 / 194,798.15 / -4.5%; Sales 2,734,179.05 / 1,018,872.21 / -62.7%; Warehouse 353,015.28 / 447,856.23 / +26.9%; total 8,289,648.80 / 6,471,696.58. Commission rate 2,264,973.29 / 103,974,558.70 = 2.1784% (the same in every month); product revenue 28,543,076.08; flexed commission 621,780.04 (Chapter 7); Sales flexed budget 1,090,985.80 (other opex 469,205.76 + 621,780.04). Volume effect -1,643,193.25; depreciation 6130: budget 272,578.56 all Administration, actual 170,749.92 Administration and 101,828.64 Warehouse; classification +101,828.64 / -101,828.64, total 0. Remaining: Warehouse -6,987.69 (-2.0%), Administration -10,660.61 (-1.6%), Sales -72,113.59 (-6.6%), others as above, (Blank) +16,642.78; total -174,758.97. Monthly variance to flexed (engine; the rate is applied month by month): Jan +99,620.67, Feb -36,350.15, Mar -43,925.89, Apr -34,491.81, May -38,383.26, Jun -39,824.69, Jul +98,203.74, Aug -36,397.02, Sep -37,008.46, Oct -37,116.99, Nov -36,459.18, Dec -32,625.93 (above the flexed budget only in January and July, the months with three pay dates); YTD +99,620.67 in January, -93,355.12 in June, +4,848.62 in July, -174,758.96 in December. Test 4: 8,289,648.80; 6,646,455.55; 6,471,696.58.

## Guided Tutorial 15.3: The Plant Page and the Package

**Tutorial 15.3 expected values (SQL twins; checked in Desktop 2.158's engine on the CR15 reference model):** LaborTimeEntry 68,859 rows (Direct 51,117, Indirect 11,702, NonManufacturing 6,040), last WorkDate 2026-12-11; 51,097 direct rows match an operation; ProductionCompletionLine 17,352 rows, 83 items. Test 5: 2024 83,637 / 70,871 / 1.18; 2025 93,391 / 66,109 / 1.41; 2026 101,237 / 66,998 / 1.51. TTM (measure) from 2024-12: 1.180, 1.121, 1.195, 1.269, 1.345, 1.392, 1.435, 1.407, 1.412, 1.396, 1.399, 1.360, 1.413 (2025-12), 1.440, 1.441, 1.457, 1.464, 1.447, 1.470, 1.508, 1.492, 1.494, 1.544, 1.528, 1.511 (2026-12). Visual calculation on an axis starting 2025-01: 1.375, 1.554, 1.611, 1.592, 1.604, 1.495, 1.463, 1.494, 1.498, 1.470, 1.418, 1.413 (equal to the measure from 2025-12). 2026 direct hours by work center: Packing 33,026.9; Assembly 12,777.0; Finishing and Test 10,480.1; Cutting 4,856.0; Quality Assurance 1,602.0; (Blank) 22.1 (direct lines without an operation). Overtime share by job title, 2024 to 2026: Assembler 11.9% to 20.1%; Machine Operator 11.8% to 19.6%; Quality Technician 11.1% to 19.5%; plant 0.116, 0.167, 0.198. The card without a year filter is (Blank): its window ends 2027-12, past the time records; filtered to 2024-2026 or to 2026 it shows 1.51, and the 2024 measure 1.18.

## Multiple-Choice Answer Key

Key: 1 D, 2 B, 3 A, 4 C, 5 B, 6 D, 7 C, 8 A, 9 B, 10 D, 11 A, 12 C, 13 C, 14 B, 15 A.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | D | a KPI is a measure shown with the comparison that gives it meaning. |
| 2 | B | only the common measures affected the evaluations (Lipe & Salterio, 2000). |
| 3 | A | drill-through opens another page filtered to the selected item. |
| 4 | C | tooltips are not interactive and screen readers cannot read them (Learn). |
| 5 | B | a disconnected table supplies categories; the measure reads the selected step. |
| 6 | D | store the first day of the period and relate it one-to-many to the date table. |
| 7 | C | actual less budget, positive for an expense, is spending above budget, unfavorable. |
| 8 | A | the commission budget was calculated on the budget's revenue volume, several times actual. |
| 9 | B | a classification difference moves cost between cost centers; the total is unchanged. |
| 10 | D | a visual calculation sees only the rows on its visual (1.375 against the measure's 1.121). |
| 11 | A | visual calculations cannot be reused or exported; KPIs belong in measures. |
| 12 | C | a filter argument on the same column replaces the existing filter unless KEEPFILTERS is used. |
| 13 | C | the page navigator syncs with pages; bookmarks capture a page as it was. |
| 14 | B | a GENERATESERIES-style table and a measure with SELECTEDVALUE, and optionally a slider. |
| 15 | A | judge a forecast by a hindcast against known periods and simple benchmarks (Chapter 7). |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 15.1: From the Income Statement to the Entry

**Instructor notes, Exercise 15.1 (SQL and the CR15 reference model):** Other Income or Expense holds 7020 Gain or Loss on Asset Disposal and 7040 Foreign Exchange Gain or Loss (no postings); only 7020 has entries. 2026: JE-2026-000115, 2026-06-05, "Dispose Packing Line Conveyors And Sealers": Dr 7020 92,500.00 (line "Recognize loss on asset disposal"), Dr 1186 Accumulated Depreciation - Manufacturing Equipment 117,500.00, Cr 1185 Manufacturing Equipment 210,000.00; FixedAssetEvent 20, asset 4, "Retirement Of Obsolete Packing Line Conveyor", proceeds 0; loss = cost 210,000 - accumulated depreciation 117,500 - proceeds 0. 2025: JE-2025-000028, 2025-02-12: Dr 7020 42,000.00, Dr 1010 Cash and Cash Equivalents 28,000.00, Dr 1160 98,000.00, Cr 1120 Warehouse Equipment 168,000.00 (asset 6, "Disposal Of Replaced Forklift A"); loss = 168,000 - 98,000 - 28,000 proceeds. The closes JE-2026-000296 and JE-2025-000287 credit 7020 but are excluded by GL Amount, so the drill-through shows only the loss entries. (5) Drill-through passes the filters of the selected data point, the row (AccountSubType) and the column (Year); without the year the page would list both years' entries.

#### Exercise 15.2: Month and Year to Date With Visual Calculations

**Instructor notes, Exercise 15.2 (CR15 reference model):** 2026 net income by month: Jan 310,849.93; Feb 341,046.27; Mar 447,271.03; Apr 442,726.36; May 485,708.78; Jun 325,069.56; Jul 114,521.97; Aug 403,445.66; Sep 468,714.44; Oct 255,812.14; Nov 405,751.40; Dec 502,693.70; YTD at June 2,352,671.93, December 4,503,611.24 (equal to JE-2026-000297). Visual calculations: YTD = RUNNINGSUM ( \[Net Income\] ); Change = \[Net Income\] - PREVIOUS ( \[Net Income\] ). (3) Filtered to July-December, the running sum starts at July and reaches 2,150,939.31 in December, while TOTALYTD still shows 2,467,193.90 in July and 4,503,611.24 in December, because the measure reads the model and the visual calculation only the visual's rows. (4) July, the low point, has three pay dates, as does January (Chapters 11 and 14); October has Furniture revenue 22.7% below October 2025 (Chapter 11) at the peak of the promotion's discounts. (5) The measure, which is right whatever the visual shows and can be exported.

### Managerial Accounting Exercises

#### Exercise 15.3: One Chart, Three Measures

**Instructor notes, Exercise 15.3 (CR15 reference model):** Labor Cost per Standard Hour = DIVIDE ( CALCULATE ( SUM ( LaborTimeEntry\[ExtendedLaborCost\] ), KEEPFILTERS ( LaborTimeEntry\[LaborType\] \<\> "NonManufacturing" ) ), \[Standard Hours to Cut-off\] ). By year: hours per standard hour 1.18, 1.41, 1.51; overtime share 0.116, 0.167, 0.198; labor cost per standard hour 33.18, 40.71, 44.21 (manufacturing labor cost 2,351,220.56; 2,691,548.63; 2,961,742.51). (4) Cost per standard hour = hours per standard hour x cost per hour; overtime hours cost a premium, and the overtime share grew, so the cost per hour rose too (the straight-time rate moved little: 26.57, 26.59, 26.62). (5) Learn: field parameters cannot be the linked fields of a drill-through or tooltip page; link the underlying fields instead.

#### Exercise 15.4: What Would the Design Trade Promotion Need?

**Instructor notes, Exercise 15.4 (CR15 reference model and Python):** promotion 9 2026 lines: 561.74 units, price before discount 416.23 per unit, standard cost 215.99 per unit (the Part II case's inputs). Break-even lift = (p (1 - 0.01903) - c) / (p (1 - d) (1 - 0.01903) - c) - 1: 5% 11.9%, 8% 20.5%, 10% 27.0%, 12% 34.2% (the Part II case), 15% 46.7%. The case found no lift in any promotion's months (from -20.7% to +11.9% against the other months of the year), so even a 5% discount needs about the largest increase ever measured; a defensible answer is not to repeat it, or to test a small discount on a defined group first.

### Auditing Exercises

#### Exercise 15.5: Testing the Forecast Before Trusting It

**Instructor notes, Exercise 15.5:** actual fiscal 2026 Q4 revenue 7,287,187.68 (invoice lines; 33 months from January 2024 to September 2026 fit the forecast). Chapter 7's backtest for the same quarter: trend +4.72% error, mean +0.03% (monthly error 3.65%), same quarter last year +0.32% (11.48% monthly). Power BI's forecast is computed in the visual (exponential smoothing, Microsoft 2014) and its values cannot be read from the model; students read them from the forecast's tooltip. A good answer reports the forecast's quarter error beside the benchmarks, notes that a seasonal pattern needs more than three years to detect reliably, and checks the effect of the start-up month, January 2024 at 60% of the year's other months, on the fit (requirement 5). The note should require any forecast shown to managers to carry its hindcast error and the benchmark it beat or did not beat.

#### Exercise 15.6: Which Work Center Did the Time Belong To?

**Instructor notes, Exercise 15.6 (SQL):** direct lines that join both an operation and a clock entry: 51,097. Disagreements by year (lines / of / hours): 2024 8,939 / 21,401 / 18,573.2; 2025 3,446 / 15,791 / 12,080.0; 2026 3,137 / 13,905 / 14,732.6; 15,522 in all. 2026 matrix (hours; the first row in full, the others with their largest off-diagonal cell): Packing operations clocked at Packing 24,413.5, at Assembly 4,325.8, Finishing and Test 2,311.9, Cutting 1,689.9, QA 285.9; Assembly operations at Assembly 11,122.8, at Finishing and Test 698.3; Finishing operations at Finishing 8,101.6, at Assembly 1,354.8; Cutting operations at Cutting 3,696.8, at Assembly 573.9; QA operations at QA 674.9, at Assembly 420.8. After the operation's end: 2,243 of the 3,137 disagreeing lines (72%) against 5,823 of the 13,905 direct lines that join both paths (42%; 13,913 direct lines in all), so the disagreement concentrates in the late time of Chapter 12. Indirect 2026 by clock work center: Assembly 16,830.0, Finishing and Test 9,561.6, Cutting 7,477.9, Packing 3,354.4, QA 1,249.0. Conclusion: the operation path answers "what work was the time charged to"; the clock path "where the employee was"; neither alone supports the Packing finding, which needs corroboration (Chapter 12).
