# Chapter 11: Analytical Queries in SQL

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 11.1: Classifying the Payroll and Measuring the Hours by Month

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 11.2: Tracking the Gap Month by Month

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 11.3: Building the Monthly Measure and Saving It as a View

No separate instructor note: the book holds none for this tutorial.

## Multiple-Choice Answer Key

Key: 1 D, 2 B, 3 C, 4 A, 5 D, 6 C, 7 A, 8 B, 9 D, 10 B, 11 A, 12 C, 13 D, 14 B, 15 A.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | D | a CASE without ELSE returns NULL for rows that meet no condition. |
| 2 | B | conditions are tested in order, and the first true one wins. |
| 3 | C | conditional aggregation passes the amounts of one category and zero for the others; B counts rows, and D is not an aggregate of the category. |
| 4 | A | strftime returns text formatted by its pattern. |
| 5 | D | the difference of two julianday values is a number of days. |
| 6 | C | date functions return text; compare with '2026' or CAST. |
| 7 | A | an ordered aggregate window is a running total, restarting in each partition (each period appears once a year, so there are no ties). |
| 8 | B | LAG with offset 12 over one row per month returns the same month a year earlier. |
| 9 | D | RANK gives ties the same number; ROW\_NUMBER numbers every row differently. |
| 10 | B | WHERE runs before window functions; filter in an outer query. |
| 11 | A | the default window of an ordered aggregate runs through the current row and its peers, the rows tied with it; B describes ROWS UNBOUNDED PRECEDING. |
| 12 | C | named steps can be read and checked one at a time; a subquery can also be repeated, so D is false. |
| 13 | D | a view stores its query and runs it again each time. |
| 14 | B | PARTITION BY decides which rows each calculation sees, without collapsing them. |
| 15 | A | a trailing measure separates a trend from single-month swings. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 11.1: The Financial Statements from the Ledger

**Instructor notes, Exercise 11.1:** pre-closing balances at 2026-12-31 (PostingDate \<= '2026-12-31', without JE-2026-000296 and JE-2026-000297), credits less debits by subtype: Operating Revenue 29,973,822.48; Contra Revenue -242,764.56; COGS -18,634,303.63; Operating Expense -6,471,696.58; Other Expense -28,946.47; Other Income or Expense -92,500.00. Net revenue 29,731,057.92; gross margin 11,096,754.29 (37.32%); operating income 4,625,057.71 (15.56%); net income 4,503,611.24, equal to the credit of JE-2026-000297 to retained earnings (Chapter 6). Assets: Current 37,236,780.57 + Fixed 4,354,000.00 - Contra Fixed 2,262,256.46 = 39,328,524.11; liabilities 13,507,123.75 + 389,304.68 and equity 20,928,484.44 plus net income 4,503,611.24 = 39,328,524.11. The Closing subtype (8010 Income Summary) has a zero balance before the closes. A CTE such as `WITH Params AS (SELECT '2026-12-31' AS AsOfDate)`, read with `(SELECT AsOfDate FROM Params)`, makes the date one parameter; the closes are found with `EntryType LIKE 'Year-End Close%' AND PostingDate = AsOfDate` (JE-2026-000296 and JE-2026-000297 at 2026-12-31), so nothing else changes with the year.

#### Exercise 11.2: Monthly Revenue with Year-to-Date and Prior-Year Comparisons

**Instructor notes, Exercise 11.2:** the only journal entries that post to the revenue accounts are the year-end closes (JE-2024-000265, JE-2025-000287, JE-2026-000296), so SourceDocumentType \<\> 'JournalEntry' removes exactly them. 180 rows (5 lines x 36 months). December year-to-date, fiscal 2026: Furniture 17,398,287.56, Lighting 5,998,649.16, Textiles 3,278,211.11, Accessories 1,872,510.62, Services 1,213,344.00, total 29,761,002.45, equal to the trial balance balances of those accounts (operating revenue in the trial balance also includes 4050 Freight, 212,820.03) and to the SalesInvoice postings of Exercise 10.1. Furniture, fiscal 2026 against 2025: largest decline October (1,314,620.10 against 1,700,781.60, -22.7%), largest increase November (1,425,903.01 against 1,264,497.48, +12.8%). October 2025 was Furniture's highest month of 2025; the fiscal 2026 promotion (Chapter 6) lowered prices in September and October and its orders were invoiced into November and December, so the timing of invoicing and promotions is the first thing to examine.

### Managerial Accounting Exercises

#### Exercise 11.3: Ranking Items by Unit Margin Within Each Product Line

**Instructor notes, Exercise 11.3:** 223 items have a list price (Accessories 56, Furniture 85, Lighting 44, Services 4, Textiles 34). No two items in a group share a unit margin, so RANK, DENSE\_RANK, and ROW\_NUMBER agree. Top items: Furniture FUR-CON-0032 Willow Console Table Acacia Warm Walnut 48 in (974.49); Textiles TXT-THR-0009 Drift Throw Blanket Ivory Small (386.13); Lighting LGT-SCN-0026 Atlas Wall Sconce Brushed Brass (329.60); Services DSV-SPC-0001 Specification Development (210.00); Accessories ACC-VAS-0032 Harbor Decor Vase Ceramic Natural (151.60). Ranges: Furniture 135.71 to 974.49; Accessories 9.24 to 151.60; Lighting 32.29 to 329.60; Textiles 32.05 to 386.13; Services 145.00 to 210.00. Services carry a StandardCost of zero, because their cost is design staff payroll (Chapter 6). For the 88 manufactured items StandardCost includes fixed overhead (the 131 purchased finished goods carry none), and for every item the measure ignores variable selling costs such as commissions, freight, and discounts, so ListPrice minus StandardCost is not a contribution margin; list price is also not the price charged. Unrounded differences may show binary fractions; ROUND fixes the display.

#### Exercise 11.4: Is Overtime Concentrated?

**Instructor notes, Exercise 11.4:** 64 employees recorded manufacturing overtime in fiscal 2026 (LaborType other than NonManufacturing, by WorkDate: 20,030 hours; the payroll year of Chapter 10 gives 20,411). The largest totals are close together: employee 48 (Machine Operator) 348.8 hours, 43 (Machine Operator) 338.2, 66 (Quality Technician) 336.7, 18 (Assembler) 333.5, 62 (Machine Operator) 333.0. Half of the overtime is reached at rank 32, half of the employees, so overtime is spread evenly, about six hours a week each. By job title: Assemblers 24 employees, 7,483 hours (311.8 each); Machine Operators 22, 6,931 (315.0); Quality Technicians 18, 5,616 (312.0). The claim is not supported: overtime is plant-wide. A running share needs SUM(x) OVER (ORDER BY x DESC ROWS UNBOUNDED PRECEDING) divided by SUM(x) OVER (), both taught in the section on window functions; ROWS matters if two employees tie.

### Auditing Exercises

#### Exercise 11.5: Journal Entry Tests in SQL

**Instructor notes, Exercise 11.5:** 851 journal entries. Flags: Weekend 17, Backdated 6, SelfApproved 7, AboveLimit 9, RoundAmount 4; scores 0: 818, 1: 25, 2: 7, 4: 1 (no entry scores 3, so that row does not appear), the same as Chapter 8. Working formulas: Weekend strftime('%w', CreatedDate) IN ('0', '6'); Backdated date(CreatedDate) \> PostingDate; RoundAmount TotalAmount = ROUND(TotalAmount / 1000, 0) \* 1000 (the % operator truncates decimals in SQLite, so it is not safe on amounts); AboveLimit with a LEFT JOIN to Employee on ApprovedByEmployeeID. The score-4 entry is JE-2024-000001, the opening balance entry created by the chief financial officer.

#### Exercise 11.6: Requisitions Just Under the Approval Threshold

**Instructor notes, Exercise 11.6:** bands of \$50 from 4,700: 2, 7, 7, 8, 4, 18 (4,950-4,999.99), 9 (5,000-5,049.99), 4, 9, 4, 5. The band just below 5,000 holds twice as many as its neighbors. Two runs of three consecutive requisitions of 4,990.92, each on January 1: PR-2025-004714 to 004716 (2025-01-01, requesters 80, 76, 80) and PR-2026-013258 to 013260 (2026-01-01, requesters 21, 74, 78). In each run, two requisitions have no approver (IDs 4714, 4715, 13258, 13259) and the third was approved by employee 2, the chief financial officer; all six were converted to purchase orders. The unapproved ones are among the six of Exercise 2.5, and all six of those, the only requisitions without an approver, fall just below 5,000 (4,990.92 to 4,993.92). LAG and LEAD flag only the middle row of each run (4715 and 13259); to list all three, keep the flagged rows in a CTE with LAG(RequisitionID) and LEAD(RequisitionID) and join back to the requisitions whose RequisitionID lies between them, or flag the first and last rows too with offsets of 2. The approval limits in Employee are 0, 5,000 (two production employees), 25,000, and 250,000.
