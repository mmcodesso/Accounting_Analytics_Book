# Appendix: Publishing, Securing, and Sharing Reports

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial A.1: Securing the Reporting Package

**Guided Tutorial A.1 expected values (SQL twins; CR16 reference model in Desktop 2.158, roles tested through ADOMD.NET with Roles= and literal-UPN test roles; the rule with USERPRINCIPALNAME returned no rows for the Windows identity, as expected):** Access review: Executive 81 Daniel Diaz, Account Executive, Terminated 2024-04-26; Sales 83 Cassandra Cardenas, Sales Representative, Terminated 2024-06-21; Warehouse 85 Dean Cook, Inventory Specialist, Terminated 2024-09-13; Research and Development 13 Melinda Murphy, Product Analyst, Active; the other six are their departments' managers (4, 10, 5, 11, 12, 14). Actual Sales Manager employee 6 (Carrie Schultz), Warehouse Manager employee 7 (Robert Fisher). Every address in the Security table is the Email of an active employee whose own CostCenterID is the cost center the table gives them (1, 6, 7, 4, 10, 5, 11, 12, 14). 2026, Operating Expense: Sales Manager sees Sales only, budget 2,734,179.05, actual 1,018,872.21, flexed 1,090,985.80 (unchanged); Income Statement net income 11,306,186.32 (Sales revenue 28,517,713.92 less Sales expenses 17,211,527.60), 2.51 times the company's 4,503,611.24; Revenue measure 29,756,420.08 (all sales); Plant blank. Warehouse Manager: 353,015.28 / 447,856.23; net income -447,856.23; Plant hours blank (standard hours still 66,997.8, completions unrelated to CostCenter). Production Manager: Budget page empty (Manufacturing has COGS budget lines only); Plant 101,237 hours / 66,997.8 standard / 1.511; net income -2,412,332.31; 67 employees. employee083: nothing (no cost centers, no employees, no items, Revenue blank); the Customer table still lists 220 customers. Finance (no rules) and no role: everything (net income 4,503,611.24; Cost Centers Shown lists all ten). Who Am I in Desktop without View as returned the Windows identity (machine\\user on a local account). Labels to confirm in 2.158: the View as roles dialog (Other user, role check boxes, OK), the bar shown while viewing as, and Stop viewing; UI Automation reads Manage security roles (New role, Tables, Switch to DAX editor, Save, Close) and Modeling \> Security (Manage roles, View as).

## Guided Tutorial A.2: Publishing and Sharing the Package

Guided Tutorial A.2 notes (Learn: Publish from Desktop 2025c; workspace roles 2025f; RLS 2026e (ms.date 2026-05-13): RLS applies to Viewers only; Security is on the semantic model's More options menu; Test as role is under More options next to the role, with a "Now viewing as" header and "Back to Row-Level Security"; Test as role uses your own identity for USERPRINCIPALNAME, so another user's view is validated by that user signing in. Give access (Learn, 2025-11-01): Manage access needs the workspace Admin role; + Add people or groups, Add \> Close; changes take effect at the user's next sign-in. Enter data (Learn, 2025-02-26): data in an Enter data table can be changed only in Desktop and republished). Label to confirm in 2.158: the settings (gear) icon of the Source step reopens the Create Table dialog. Expected memo: managers as Viewers or app readers, the controller's staff as Members or Contributors (who bypass RLS, so the list of editors is itself reviewed); the Income Statement and Validation pages in a separate finance report on the same semantic model, shown to the controller's audience; a gateway, or the workbook moved to OneDrive or SharePoint, with failure notifications to the package's owner; Publish to web disabled by the administrator; a Confidential label where labels are enabled (not supported in .pbip projects).

## Multiple-Choice Answer Key

Key: 1 D, 2 B, 3 C, 4 D, 5 A, 6 C, 7 A, 8 B.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | D | a rule filters its table and, through active relationships, the tables on the many side. |
| 2 | B | row-level security applies to Viewers and app readers, not to Admin, Member, or Contributor. |
| 3 | C | managers of record 81, 83, 85 are terminated; the Sales and Warehouse Managers are not recorded. |
| 4 | D | deny by default; a user in the role but missing from the table sees no sales (and no cost centers). |
| 5 | A | object-level security hides tables and columns from a role; row-level security hides rows. |
| 6 | C | Publish to web needs no sign-in, exposes all the model's data, and does not support row-level security. |
| 7 | A | a local file is an on-premises source; a gateway (or moving the file to OneDrive or SharePoint) is needed. |
| 8 | B | no setting secures a page by role, and app audiences show whole reports, so finance's pages go in a separate report; on the pages managers keep, a card naming the cost centers shown tells them what they see. A hidden page can still be reached, so hiding it is not security. |

## Applied Exercises

### Managerial Accounting Exercises

#### Exercise A.1: Securing Pay Data

**Instructor notes, Exercise A.1 (Learn, OLS 2026-06-30; RLS guidance 2024):** TMDL view scripts a role with createOrReplace; starting from the scripted role keeps its tablePermission filters, and adding tablePermission LaborTimeEntry columnPermission ExtendedLaborCost metadataPermission: none hides the column from the role. The Labor Cost measure, and the visual that uses it, fail for the role ("the field can't be found"), while the Plant page's hours visuals still work; the Finance role sees everything. A role written from scratch with createOrReplace would replace the role and lose its row filters, which is why the exercise starts from the scripted role. Row-level security restricts rows, not columns; the controller should keep cost measures off the managers' pages or in the finance report. Performance analyzer durations vary by machine; expect slightly longer durations under View as.

### Auditing Exercises

#### Exercise A.2: Reviewing Access with a Query

**Instructor notes, Exercise A.2 (SQL twins; the CR16 reference model):** (2) one cost center, Research and Development (8), whose manager of record is a Product Analyst. Security is unrelated, so RELATEDTABLE cannot be used; EXCEPT ( VALUES ( CostCenter\[CostCenterID\] ), VALUES ( Security\[CostCenterID\] ) ), or a FILTER on CostCenter with a COUNTROWS ( FILTER ( Security, ... ) ) = 0 test, finds it. (3) none: nine users, nine cost centers. (4) all nine names match the Email of an active employee (1 Chief Executive Officer, 6 Sales Manager, 7 Warehouse Manager, 4 Production Manager, 10 Purchasing Manager, 5 Accounting Manager, 11 Customer Service Manager, 12 Marketing Manager, 14 Design Services Manager), each in the cost center the table gives them, so no user is flagged; LOOKUPVALUE ( AccessEmployees\[EmployeeID\], AccessEmployees\[Email\], Security\[UserPrincipalName\] ) inside ADDCOLUMNS. (5) every row of AccessEmployees, all 120 employees with their addresses and termination dates, because no rule filters an unrelated table (the same reason the Customer table still lists every customer for a user missing from the security table). A rule of FALSE () on the table for Cost Center Managers, or keeping the table out of the published file, closes it. Run the review whenever the table changes and at least quarterly, with the controller's approval recorded.
