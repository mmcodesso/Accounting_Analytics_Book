# Chapter 6: Descriptive and Diagnostic Analytics in Excel

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 6.1: Profiling Fiscal 2026 and Proving the Total

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 6.2: Revenue and Margin by Product Line and Quarter

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 6.3: Explaining the Furniture Margin

No separate instructor note: the book holds none for this tutorial.

## Multiple-Choice Answer Key

Key: 1 B, 2 C, 3 A, 4 D, 5 A, 6 C, 7 D, 8 B, 9 C, 10 A, 11 D, 12 B, 13 C, 14 A, 15 B.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | B | a mean well above the median signals a right skew: a minority of large lines pulls the average up. |
| 2 | C | STDEV.S divides by n - 1 for a sample; STDEV.P divides by n for a whole population. |
| 3 | A | MEDIAN accepts no criteria and there is no MEDIANIFS, so FILTER supplies the year's rows. |
| 4 | D | a misspelled criterion matches nothing, so SUMIFS returns zero silently; a control total catches it. |
| 5 | A | the difference equals a whole category, Services, missing from the summary. |
| 6 | C | a histogram shows how values are distributed across bins of equal width. |
| 7 | D | a calculated field applies its formula to sums, so Quantity\*UnitPrice multiplies two sums. |
| 8 | B | % of Column Total shows each group's share of the quarter's revenue. |
| 9 | C | GETPIVOTDATA names the value by field and item, so layout changes do not break it. |
| 10 | A | a PivotTable reads its pivot cache, which updates only on refresh. |
| 11 | D | the year-end closing entry debits every revenue account on December 31. |
| 12 | B | the closing entries zero the revenue and expense accounts, so a pre-closing trial balance leaves them out. |
| 13 | C | each item has one standard cost, so the cost effect at standard is zero. |
| 14 | A | margin before discounts rising while margin falls isolates the promotional discounts as the cause. |
| 15 | B | the auditor develops the expectation and sets the acceptable difference before evaluating it. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 6.1: From the Ledger to the Income Statement

**Instructor notes, Exercise 6.1:** the pre-closing trial balance at 2026-12-31 (GLEntry with PostingDate before 2027-01-01, without the 45 GL rows of the closes JE-2026-000296 and JE-2026-000297) has 71 accounts, 4 of them with a zero balance; debit and credit balances are both 67,107,722.36. Revenue and expense accounts show only fiscal 2026 because the 2024 and 2025 closing entries zeroed them. Income statement: operating revenue 29,973,822.48 (100.82% of net revenue); sales returns and allowances -242,764.56 (4060); net revenue 29,731,057.92; cost of goods sold -18,634,303.63 (62.68%; includes freight-out 5050, purchase price variance 5060, and manufacturing variance 5080); gross margin 11,096,754.29 (37.32%); operating expenses -6,471,696.58 (21.77%); operating income 4,625,057.71 (15.56%); other income and expense -121,446.47 (loss on asset disposal 7020 of 92,500.00, an account typed Revenue with subtype Other Income or Expense, and interest expense 7030 of 28,946.47); net income 4,503,611.24 (15.15%), equal to JE-2026-000297. Balance sheet: assets 39,328,524.11 = liabilities 13,896,428.43 + equity 20,928,484.44 + net income 4,503,611.24. The balances include the unsupported opening balances found in Chapter 8. Revenue reconciliation, account balance vs InvoiceLines 2026: 4010 17,398,287.56 vs Furniture 17,395,054.38 (+3,233.18); 4020 5,998,649.16 vs Lighting 5,997,536.93 (+1,112.23); 4030 3,278,211.11 vs Textiles, equal; 4040 1,872,510.62 vs Accessories 1,872,273.66 (+236.96); 4080 1,213,344.00 vs Services, equal. The differences are SI-2026-013742 (Furniture, dated 2025-12-04), SI-2026-013741 (Lighting, 2025-11-29), and SI-2026-013743 (Accessories, 2025-12-03), dated in 2025 with the next year's number and posted 2026-01-01. InvoiceLines assigns them to fiscal 2025 by their invoice dates, the ledger to fiscal 2026. The date that determines the period is the delivery of the goods, not the invoice date or number (every shipment is delivered in the year it ships). Only SI-2026-013742 shipped in 2025 (on 2025-12-06), so its 3,233.18 is a revenue cutoff error; the other two shipped on 2026-01-01, so the ledger is right and their invoice dates are wrong. Tutorial 12.1 tests cutoff by delivery date for every invoice. Freight revenue (4050, 212,820.03) has no invoice line.

#### Exercise 6.2: Disaggregating Revenue by Segment and Product Line

**Instructor notes, Exercise 6.2:** 2026 shares of grand total: Wholesale-Furniture 31.68% (9,427,365.72), Strategic-Furniture 18.24% (5,426,213.53), Wholesale-Lighting 10.59% (3,149,776.65); then Strategic-Lighting 6.60% and Design Trade-Furniture 6.05%. Changes from 2025 for combinations with at least \$500,000 in 2025: increases Strategic-Lighting +13.3% (1,732,739 to 1,962,918) and Wholesale-Lighting +9.3% (2,882,869 to 3,149,777); decreases Strategic-Accessories -17.8% (693,226 to 569,622) and Design Trade-Furniture -11.4% (2,030,430 to 1,799,124). Segments: Wholesale +5.99%, Small Business +3.85%, Strategic -2.86%, Design Services -3.81%, Design Trade -6.66%; total +1.29%. Regions: West +9.9%, Northeast +9.2%, Midwest -2.0%, South -7.2%. Design Services buys only Services, so the segment and the product line coincide there. A nonpublic entity may elect not to give the quantitative disaggregation (ASC 606-10-50-7); the exercise treats the disclosure as if it were required.

### Managerial Accounting Exercises

#### Exercise 6.3: Product-Line Profitability at Standard Cost

**Instructor notes, Exercise 6.3:** 2026 margin at standard cost: Accessories 50.96% (margin 954,080.96 on 1,872,273.66), Textiles 49.47% (1,621,892.16 on 3,278,211.11), Lighting 46.66% (2,798,584.12 on 5,997,536.93), Furniture 42.34% (7,365,245.96 on 17,395,054.38). Excluding Services, revenue shares are Furniture 60.9%, Lighting 21.0%, Textiles 11.5%, Accessories 6.6%, and margin shares 57.8%, 22.0%, 12.7%, 7.5%, so Lighting, Textiles, and Accessories contribute more margin than revenue. Furniture types: highest DSK (desk) 44.36% and CON (console table) 44.00%; lowest BNH (bench) 39.04% and BKC (bookcase) 39.37%. Services items carry StandardCost 0, so their margin shows 100%; their cost is design staff time. Possible measures: ServiceTimeEntry.ExtendedCost for 2026 work dates (220,317.28, a margin of about 82%) or the 2026 Design Services salaries expense in account 6280 (471,214.88, about 61%). The gap shows that the answer depends on the cost definition, which the report must state.

#### Exercise 6.4: The Margin Bridge by Product Type

**Instructor notes, Exercise 6.4:** Furniture margin 1,810,257.09 (Q3) to 1,695,211.02 (Q4), change -115,046.07. Product-type bridge: price -183,737.35, cost +43,345.66, volume +7,885.63, mix +17,459.98 (sums exactly). The cost effect is not zero because each type's average standard cost per unit depends on which of its items were sold: DSK (desks) price per unit 731.85 to 628.50 and cost per unit 406.55 to 359.63, as cheaper desks made up more of the quarter; TBL and BNH move the same way, and price and cost per unit rose together for CON and BKC. At this level, within-type item mix appears as price and cost; the price effect also contains the promotional discount (about -119,800 at this level). Units by type Q3 to Q4: NGT 905.06 to 734.14 and SDB 1,072.57 to 958.22 fell; DSK 1,050.73 to 1,195.45 and TBL 1,280.52 to 1,385.62 rose. Tutorial 6.3's Furniture-level bridge is the better headline because each of its effects has one meaning (cost zero, mix at the item level), with the product-type view as supporting detail for the sales team.

### Auditing Exercises

#### Exercise 6.5: A Substantive Analytical Procedure on Quarterly Revenue

**Instructor notes, Exercise 6.5:** flagged (over 10% and over \$50,000): Lighting Q1 +215,084.80 (+15.9%), Textiles Q4 +166,764.46 (+24.4%), Accessories Q2 -76,547.35 (-15.0%), Services Q2 -66,187.40 (-20.9%), Services Q3 -52,688.80 (-16.4%), Services Q4 +77,195.65 (+26.9%). Not flagged: Furniture Q4 -315,983.47 (-7.1%), the largest dollar difference, and Furniture Q2 +266,724.77 (+6.2%). A percentage test alone misses large dollar differences in the largest product line; a tolerable amount based on materiality, or an expectation that reflects known changes such as the promotion, would treat them differently. Prior-year revenue is a weak expectation because it ignores growth and known events, which students may note. Follow-up examples: Lighting Q1, the largest flagged difference, is mostly volume (units +15.2%, price per unit +0.6%), so the evidence is its invoice lines by customer and item, traced to their orders and shipping documents, and the question is which customers bought more and why; for Services, engagement and time records by quarter. Furniture Q4, which the threshold misses, would still call for the promotion discounts (Tutorial 6.3) and the late-invoiced promotion lines (Tutorial 5.2).

#### Exercise 6.6: A Descriptive Profile of the Revenue Population

**Instructor notes, Exercise 6.6:** 2026 by group (lines, revenue, average, median): Furniture 3,496, 17,395,054.38, 4,975.70, 4,467.08; Lighting 2,496, 5,997,536.93, 2,402.86, 2,006.90; Textiles 1,359, 3,278,211.11, 2,412.22, 1,778.18; Accessories 2,027, 1,872,273.66, 923.67, 815.28; Services 144, 1,213,344.00, 8,426.00, 7,803.20. 209 customers invoiced in 2026; top 5 hold 9.9% and top 10 hold 17.8% of revenue, all in the Strategic segment (largest: Glenn-Estrada, Wright PLC, Eaton, Robertson and Grant, Richardson, Porter and Chavez, Thomas Ltd), so concentration is low. Pricing by revenue: Segment Price List 83.6% (8,405 lines), Customer Price List 10.7% (816), Base List 4.1% (144, the hourly design services only), Approved Override 1.6% (157). Promotions in 2026 (lines, discount): 5: 10, 662.89; 6: 54, 6,858.14; 7: 68, 30,478.57; 8: 576, 296,053.58; 9: 88, 28,057.57. Promotion lines as a share of each group's lines: Furniture 19.9%, Textiles 2.1%, Accessories 1.7%, Lighting 1.5%, Services 0%. Promotions 5 (Textiles, September to October 2025) and 6 (Wholesale, November 2025) have lines invoiced in January to March 2026, the same late-invoicing pattern as promotion 8. Promotion 7's effective dates are left for the audit work later in Part II.
