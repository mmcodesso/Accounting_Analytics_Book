# Appendix: Power BI in the Browser

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial C.1: Building the Chapter 13 Model in the Browser

**Guided Tutorial C.1 expected values (read-only twin of Tutorial 13.1's model; the same steps were run in the Power BI service):** Power Query Online reads InvoiceDate as a whole number, the Excel date: the first invoice, SI-2024-000001, shows 45292, which reads 2024-01-01 once the type is Date. Discount comes in as a whole number (Replace current keeps the rates); PromotionID has no type. Item keeps 223 items after the ListPrice filter. Profile (Step 6): first 1,000 lines PromotionID 100% empty and Discount one value; entire data set PromotionID empty on 25,825 of 27,933 lines (92%), Discount 4 distinct values (0, 0.08, 0.10, 0.12). Validation page by fiscal year: 2024 9,040 lines, 27,313,723.48, list 30,596,029.91, discounts 126,607.64; 2025 9,371, 29,376,702.28, 33,030,575.85, 234,534.72; 2026 9,522, 29,756,420.08, 33,589,137.45, 362,110.75 (Tutorial 13.1). The item group table has 5 rows and no (Blank). SalesInvoiceLineID comes in as Count of SalesInvoiceLineID: the service sets the keys that relationships use not to summarize.

## Guided Tutorial C.2: Building the Sales and Discounts Page in the Browser

**Guided Tutorial C.2 expected values:** cards for fiscal 2026 (Display units None): Revenue 29,756,420.08, At list price 33,589,137.45, Discounts 362,110.75, Invoices 7,171 (Count (Distinct) of the lines' SalesInvoiceID; a plain count gives 9,522, the lines). Discounts by month: Jan 6,602.69; Feb 844.80; Mar 7,670.52; Apr 14,950.85; May 6,751.62; Jun 822.35; Jul 0.00; Aug 356.75; Sep 95,996.97; Oct 136,935.59; Nov 73,447.23; Dec 17,731.36. Sorted by value, the axis starts Oct, Sep, Nov, Dec, which draws a falling line; sorted by Month, ascending, the line rises in the Furniture Seasonal Promotion's months. Furniture holds 96.1% of the year's discounts, so it leads the bar chart.

## Guided Tutorial C.3: Adding a Measures Table and a First Measure

**Guided Tutorial C.3 expected values:** the Revenue measure by fiscal year, rounded in the query: 2024 27313723.48; 2025 29376702.28; 2026 29756420.08 (the Results grid shows the raw values, without the format), equal to the Validation page's line totals. Key Measures moves to the top of the Data pane once Column1 is hidden.

## Multiple-Choice Answer Key

Key: 1 C, 2 A, 3 D, 4 B, 5 B, 6 D, 7 C, 8 A.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | C | Power Query Online reads uploaded files from the user's OneDrive for work or school. |
| 2 | A | the workbook stores InvoiceDate as an Excel date; the first invoice reads 45292, which is 2024-01-01 once typed as Date. |
| 3 | D | Restore default visuals, under the … below the visual types, brings the card back. |
| 4 | B | DAX query view in the browser discards its tabs on close; keep the tests in a text file. |
| 5 | B | keys used by relationships are set not to summarize, so the field lands in Categories; drag it to Value and choose Count (Distinct). |
| 6 | D | the chart is sorted by its values; More options \> Sort by \> Month, then Sort ascending. |
| 7 | C | Power Query Online's Save applies its changes to the model; Close & Apply is Desktop's. |
| 8 | A | Power Query Online also types each column from its first 200 rows, where Discount is zero. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise C.1: Control Totals by Quarter

**Instructor notes, Exercise C.1:** fiscal 2026 by quarter (lines, revenue, list amount, discounts): Q1 2,472, 7,546,851.67, 8,432,384.12, 15,118.02; Q2 2,377, 7,654,417.42, 8,579,566.07, 22,524.82; Q3 2,341, 7,267,963.31, 8,212,248.05, 96,353.72; Q4 2,332, 7,287,187.68, 8,364,939.21, 228,114.18. The quarters add up to the Validation row: 9,522 lines, 29,756,420.08, 33,589,137.45, 362,110.75 (the discounts may differ from the sum of the rounded quarters by a cent). (4) Q4 carries 63.0% of the year's discounts: Furniture Seasonal Promotion 200,056.61; Design Trade Customer Promotion 28,057.57. The Furniture Seasonal Promotion ran in September and October, but its orders were invoiced through December. (5) A query in Tests.dax does not change when a page is edited, and DAX query view in the browser discards its tabs on close.

### Managerial Accounting Exercises

#### Exercise C.2: Which Customers Got the Discounts, and When

**Instructor notes, Exercise C.2:** fiscal 2026 discounts by segment, with each segment's peak month: Design Trade peaks in November (27,595.87 of 59,673.47); Small Business peaks in September (4,070.03 of 13,279.03); Strategic peaks in October (46,330.25 of 104,232.11); Wholesale peaks in October (74,453.77 of 184,926.14). (4) Design Trade peaks in November, the month of the Design Trade Customer Promotion; Small Business peaks in September, Strategic peaks in October, Wholesale peaks in October, the months of the Furniture Seasonal Promotion (September and October). (5) Design Services received no discounts. A segment promotion reaches one segment, while an item-group promotion reaches every segment that buys the group, so a calendar aimed at one segment should use a segment promotion.

### Auditing Exercises

#### Exercise C.3: A Change, Recorded and Restored

**Instructor notes, Exercise C.3:** the test's fiscal 2026 revenue is 29,756,420.08 before the change, 33,589,137.45 with ListAmount (higher by 3,832,717.37, the price reductions and discounts), and 29,756,420.08 again after the restore. Version history records the model's state, not who changed it or why, keeps only the last few versions, and needs a Pro license; a Power BI project under version control (Chapter 16) records every change with its author and message and can be reviewed before it is merged.
