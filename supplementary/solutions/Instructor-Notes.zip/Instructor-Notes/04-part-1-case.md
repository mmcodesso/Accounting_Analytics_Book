# Comprehensive Case, Part 1: Getting the Data Ready for the Furniture Margin Question

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Requirements

### Requirement 1: Frame the question (Chapter 1)

**Instructor notes, Requirement 1:** descriptive = did the Furniture gross margin fall from the prior quarter to the most recent quarter, and by how much; diagnostic = which of price, volume, mix, and cost explains the change. This case covers defining the question, accessing the data, and preparing and testing it (stages 1-3, plus communicating the readiness findings); analysis and visualization of the causes are left for Part II.

### Requirement 2: Map the data (Chapter 3)

**Instructor notes, Requirement 2:** Item.ItemGroup = 'Furniture' (85 items); every Furniture item has RevenueAccountID 42 (account 4010 Sales Revenue - Furniture) and COGSAccountID 50 (account 5010 COGS - Furniture); InventoryAccountID 5 (1040). Joins: SalesInvoice 1 to 1..many SalesInvoiceLine (SalesInvoiceID); Item 1 to 0..many SalesInvoiceLine (ItemID); Shipment 1 to 1..many ShipmentLine (ShipmentID); Item 1 to 0..many ShipmentLine (ItemID); Account 1 to 0..many GLEntry (AccountID). Returns: SalesReturn postings reduce 5010 (and restore inventory 1040), so the cost side stays by product line; the revenue side of a return is recorded by CreditMemo postings to 4060 Sales Returns and Allowances, which is shared by all product lines (credit memos also reverse billed freight, 99 debits to 4050 Freight Revenue), so a Furniture margin built from 4010 and 5010 is a gross margin before returns. Account 4070 Sales Discounts has no postings.

### Requirement 3: Test the data (Chapter 2)

**Instructor notes, Requirement 3:** invoices run through 2026-12-31, and the GL continues to 2027-02-23 with only DisbursementPayment rows (supplier payments for prior-year invoices), so the latest complete quarter is 2026 Q4 (compared with 2026 Q3). Of the 9 invoices dated before their order's first shipment, 3 contain Furniture lines (SI-2024-000003, SI-2025-006735, SI-2026-013742), and none is dated, shipped, or posted in 2026 Q3 or Q4, so they do not affect this comparison (though they matter for revenue cutoff in general: two of them cross a quarter end, SI-2025-006735 dated 2024-12-15, shipped 2024-12-17, and posted 2025-01-01; SI-2026-013742 dated 2025-12-04, shipped 2025-12-06, and posted 2026-01-01). Same-name customers do not affect a product-line margin. Blank list prices belong to purchased items and services, not to Furniture products.

### Requirement 4: Reconcile the sub-ledger to the ledger (Chapters 2 and 3)

**Instructor notes, Requirement 4:** Furniture invoice lines total \$4,283,322.86 in 2026 Q3 and \$4,156,787.84 in 2026 Q4; SalesInvoice postings to AccountID 42 (4010) match exactly in both quarters. Furniture shipment lines at standard cost total \$2,459,120.72 in Q3 and \$2,475,813.68 in Q4; Shipment postings to AccountID 50 (5010) match exactly. Other sources posting to 5010: SalesReturn (Q3 -\$31,867.81, Q4 -\$25,752.61) and, at year-end, JournalEntry (the closing entry). Agreement shows the ledger completely and accurately reflects the sub-ledger for this product line, so either source can support the analysis.

### Requirement 5: Find what could mislead (Auditing)

**Instructor notes, Requirement 5:** using all rows, Q4 Furniture revenue is -\$13,241,499.72 and COGS is -\$7,496,777.60, because year-end close JE-2026-000296 (EntryType "Year-End Close - P&L to Income Summary", posted 2026-12-31) debits 4010 by \$17,398,287.56 and credits 5010 by \$9,946,838.67. The naive margin percentage is 43.4%, almost identical to Q3's 43.3%, so the ratio alone hides both the nonsense totals and the decline. Excluding the closing entry (SourceDocumentType JournalEntry with a Year-End Close EntryType), Q4 revenue is \$4,156,787.84 and COGS \$2,450,061.07 (shipments less returns), and the margin falls from 43.3% in Q3 to 41.1% in Q4. A sub-ledger check at standard cost (invoiced quantity x Item.StandardCost) also falls, from 42.3% to 40.8%.

### Requirement 6: Write the data readiness memo

No separate instructor note: the book holds none for this requirement.
