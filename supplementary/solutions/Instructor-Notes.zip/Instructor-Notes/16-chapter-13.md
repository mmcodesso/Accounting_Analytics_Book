# Chapter 13: Power BI Essentials for Accounting Analytics

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 13.1: Loading, Relating, and Reconciling the Sales Tables

**Tutorial 13.1 expected values (read-only twin, pbi\_ch13.py):** rows loaded: SalesInvoiceLine 27,933; SalesInvoice 20,914; Item 223 after the ListPrice filter (266 before); Customer 220. No invoice line refers to an item with a blank ListPrice, and every line finds its invoice, item, and customer. Validation table: 2024 9,040 lines, 27,313,723.48, list 30,596,029.91, discounts 126,607.64; 2025 9,371, 29,376,702.28, 33,030,575.85, 234,534.72; 2026 9,522, 29,756,420.08, 33,589,137.45, 362,110.75 (Chapter 6 control total and the Part II case gross to net); total 27,933, 86,446,845.84. Item groups (all years): no (Blank) row. Profile (Step 6): first 1,000 lines (dated 2024-01-01 to 2024-02-29) PromotionID 100% empty, Discount 1 distinct value (0); entire data set: PromotionID empty on 25,825 of 27,933 lines (92%), Discount 4 distinct values (0, 0.08, 0.10, 0.12).

## Guided Tutorial 13.2: Building the Sales and Discounts Page

**Tutorial 13.2 expected values (fiscal 2026, read-only twin):** cards Revenue 29,756,420.08; At list price 33,589,137.45; Discounts 362,110.75; Invoices 7,171. Furniture selected: 17,395,054.38; 19,878,268.16; 347,864.64; 3,093 invoices with a Furniture line; the SalesInvoice count stays 7,171. Discounts by month 2026: Jan 6,602.69; Feb 844.80; Mar 7,670.52; Apr 14,950.85; May 6,751.62; Jun 822.35; Jul 0.00; Aug 356.75; Sep 95,996.97; Oct 136,935.59; Nov 73,447.23; Dec 17,731.36 (Furniture: Sep 95,996.97, Oct 136,935.59, Nov 66,155.58, Dec 14,369.30). Discounts by group: Furniture 347,864.64; Lighting 7,825.54; Textiles 4,098.06; Accessories 2,322.51; Services 0. Design Trade: Furniture 48,988.07, Lighting 6,296.95, Textiles 2,598.82, Accessories 1,789.63; by month Sep 9,393.41, Oct 12,409.04, Nov 27,595.87 (promotion 9 21,482.20), Dec 8,692.04. Furniture revenue by quarter (product types BKC, BNH, CON, CTB, DSK, NGT, SDB, TBL): Q1 4,354,122.83; Q2 4,600,820.85; Q3 4,283,322.86; Q4 4,156,787.84 (the Part I case totals).

## Guided Tutorial 13.3: Correcting Three Misleading Charts

**Tutorial 13.3 expected values (read-only twin):** fiscal 2026 monthly revenue from 2,260,980.22 (February) to 2,688,918.15 (January), mean 2,479,701.67; the range is 17% of the mean. Revenue: January 2024 1,408,516.50; February 2024 2,170,765.25; December 2026 2,519,722.16; increase from January 2024 +78.9%, from February 2024 +16.1%. Fiscal years 27,313,723.48, 29,376,702.28, 29,756,420.08: +7.6% then +1.3%. January 2024 had 279 invoices against 512-639 in other months. Discounts as a share of revenue in 2026 peak in October at 6.0% (136,935.59 of 2,297,493.38), then September 3.8% and November 3.0%. The secondary axis appears automatically because the two ranges barely overlap (Microsoft Learn, combo chart page).

## Multiple-Choice Answer Key

Key: 1 B, 2 D, 3 C, 4 A, 5 B, 6 D, 7 A, 8 C, 9 D, 10 B, 11 C, 12 A, 13 D, 14 B, 15 A.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | B | a report serves readers who ask the next question themselves. |
| 2 | D | dashboards are single pages of pinned tiles in the Power BI service. |
| 3 | C | by default, profiling covers the first 1,000 rows, which predate every promotion. |
| 4 | A | a guessed relationship can join the wrong columns silently. |
| 5 | B | a whole-number year is summed unless its summarization is Don't summarize. |
| 6 | D | the filter flows from Item to the lines, not from the lines to SalesInvoice. |
| 7 | A | an average of rates weights each line equally; the ratio of totals weights by dollars. |
| 8 | C | position along a common scale ranks first in Cleveland and McGill's experiments. |
| 9 | D | a table fits a task that needs an exact value. |
| 10 | B | a line chart's default axis starts just below the smallest value. |
| 11 | C | one axis shows the true size; separate charts show each pattern on its own labeled scale. |
| 12 | A | the comparison starts at the start-up month; whole years show little growth. |
| 13 | D | meaning must not rest on color alone. |
| 14 | B | good performers graphed more, and about 30% of graphs distorted, exaggerating on average. |
| 15 | A | a hidden page filter changes the numbers without telling the reader. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 13.1: Revenue Control Totals by Year and Item Group

**Instructor notes, Exercise 13.1:** line totals by year and group: 2024 Accessories 1,936,112.10; Furniture 15,673,570.29; Lighting 5,341,114.32; Services 1,045,095.60; Textiles 3,317,831.17; total 27,313,723.48. 2025 Accessories 1,944,887.00; Furniture 17,485,275.08; Lighting 5,501,329.02; Services 1,261,365.95; Textiles 3,183,845.23; total 29,376,702.28. 2026 Accessories 1,872,273.66; Furniture 17,395,054.38; Lighting 5,997,536.93; Services 1,213,344.00; Textiles 3,278,211.11; total 29,756,420.08 (Chapter 6). SubTotal by year equals the line totals exactly (6,735, 7,008, and 7,171 invoices; no invoice without lines). GrandTotal 29,293,739.11; 31,514,678.11; 31,919,124.42 = SubTotal + freight (192,134.79; 214,544.33; 214,588.22) + tax (1,787,880.84; 1,923,431.50; 1,948,116.12). Revenue from goods and services is SubTotal; freight posts to its own revenue account (4050) and sales tax is a liability (2050), as Chapter 10's trace of SI-2025-007947 showed. (4) A second table with the same key would be a second path from the invoices to the lines; the model keeps one table per entity, and InvoiceHeaders exists only to test the header amounts.

#### Exercise 13.2: Customer Concentration by Name or by Key

**Instructor notes, Exercise 13.2:** fiscal 2026: 209 customers with revenue and 208 names. By name, Brown LLC ranks ninth with 468,165.51, the sum of two different customers: CustomerID 173 (Midwest, Strategic) 380,740.63, which ranks fifteenth by key, and CustomerID 5 (West, Design Trade) 87,424.88, which ranks 117th. By key, the tenth customer is Willis and Sons (200), 420,365.88, which grouping by name pushes to eleventh. Smith Ltd is also two customers (170 and 220), but only 170 had 2026 revenue (14,093.15). The largest customer, Glenn-Estrada (136), 654,622.92, holds 2.2% of revenue; Wright PLC 2.0%; the top ten by key hold 17.8% (18.0% by name), so no customer approaches the 5% policy. The Top N filter is invisible unless stated; the title should say, for example, "Top 10 customers by revenue, fiscal 2026".

### Managerial Accounting Exercises

#### Exercise 13.3: Promotions in the Report

**Instructor notes, Exercise 13.3:** fiscal 2026 promotion lines and discounts by month: Textiles Seasonal (5, 2025 promotion) January 10 lines, 662.89; Wholesale Customer (6, November 2025) January 44, February 8, March 2 (6,858.14); Harbor Collection (7) March 18, April 29, May 16, June 4, August 1 (30,478.57); Furniture Seasonal (8) September 167 (95,996.97), October 249 (136,935.59), November 119 (51,965.03), December 41 (11,155.99); Design Trade Customer (9) November 61 (21,482.20), December 27 (6,575.37). Total 362,110.75. The (Blank) row is the 8,726 lines without a promotion (26,479,419.83 of revenue, zero discount), a meaningful blank (Chapter 5), not a broken key. Lines invoiced after the end date in 2026: promotion 8, 160 lines in November and December (all ordered within the promotion's dates, Chapter 5); promotion 9, 27 lines in December; promotions 5 and 6 (2025 promotions) all 2026 lines; promotion 7 (Harbor) ends 2026-02-28 before its 2026-03-01 start, so all its 68 lines fall after the end date: a master-data error, since its lines were ordered in March and April (the Part II case). The discount is applied when the order is priced, so invoicing later does not remove it. The report cannot show whether the promotions paid off: that needs margin and volume lift (Chapter 7, Part II case).

#### Exercise 13.4: A Page for the Sales Manager

**Instructor notes, Exercise 13.4:** fiscal 2026 by segment: Wholesale 15,265,614.23 (79 customers with revenue; discounts 184,926.14), Strategic 9,001,772.41 (21; 104,232.11), Design Trade 3,035,208.44 (41; 59,673.47), Small Business 1,240,481.00 (49; 13,279.03), Design Services 1,213,344.00 (19; 0, services carry no promotion). By region: Midwest 10,124,914.43, South 6,877,880.82, West 6,444,493.03, Northeast 6,309,131.80. Largest cell: Wholesale-Midwest 4,876,620. Cognitive fit: the bar chart for the comparison (a spatial task), the matrix for the exact figures (a symbolic task). Clicking a bar cross-highlights the matrix by default (or filters it) and filters the card; setting the matrix to None keeps the full table visible while the card answers for one segment. A restriction such as excluding the Design Services segment from a merchandise page, or keeping only sellable items, belongs to the report and can sit in the Filters pane, provided the title says so.

### Auditing Exercises

#### Exercise 13.5: Profiling the Sales Tables on the Entire Data Set

**Instructor notes, Exercise 13.5:** Profile\_Lines (27,933 rows): PromotionID empty 25,825 (92.5%) on the entire data set, 100% on the top 1,000; PriceOverrideApprovalID empty 27,419 (98.2%) against 976 of 1,000; PriceListLineID and ShipmentLineID empty on 439 lines (1.6%, the Base List design-service lines) against 8 of 1,000; PricingMethod 4 distinct values on both bases; Discount 4 distinct on the entire set, 1 (zero) on the top 1,000; Quantity is fractional on 26,797 lines (Chapter 5's validity check). Profile\_Invoices (20,914): PaymentDate empty on 911 (876 open invoices, 35 Settled) against 2 of 1,000; Status 3 distinct (Settled, Partially Settled, Submitted) against 1 (Settled) on the top 1,000, because the earliest invoices are all Settled. Profile\_Items (266; 223 with a ListPrice): ListPrice empty on 43 items bought, not sold; CollectionName empty on 63 of the sellable items (all 56 Accessories, 3 Furniture, the 4 services). Profile\_Customers (220): no empty values; CustomerName has 218 distinct values (Brown LLC and Smith Ltd twice). The first rows are almost all the earliest records (lines to 2024-02-29, invoices to 2024-03-10; only 60 later lines and 33 later invoices are dated earlier), before the first promotion and with almost every invoice paid; overrides already occur (2.4% of the top 1,000 against 1.8% overall). Meaningful blanks: PromotionID (no promotion), PaymentDate (unpaid), PriceListLineID on Base List lines; follow-up: CollectionName on the three Furniture items (the Part II case found one of them, FUR-CON-0003, ordered under the Alder promotion).

#### Exercise 13.6: Reviewing a Draft Report Page

**Instructor notes, Exercise 13.6:** pie: five slices of 58.5% (Furniture), 20.2% (Lighting), 11.0% (Textiles), 6.3% (Accessories), 4.1% (Services); the small slices cannot be ranked by eye; replace with a sorted bar chart with labels. Card: Average of Discount in fiscal 2026 is 0.85%, an unweighted average of line rates; discount dollars over the dollars before discount are 1.20% (1.08% of list), and Furniture's average rate is 1.98%; the right figure is a ratio of totals, which needs a measure (Chapter 14); until then, show discount dollars and the list amount side by side. Line chart: the default axis and the January 2024 start-up month (1,408,516.50 against 2,093,775 to 2,719,019 in the other months) suggest growth of 79% to December 2026; whole years show +7.6% and +1.3%; start the axis at zero and compare whole years. Combo chart: the discounts get their own axis and appear comparable to revenue (October 2026 discounts were 6.0% of that month's revenue); use one axis or two charts. Hidden filter: excluding Services removes 1,213,344.00 (4.1%) of fiscal 2026 revenue without telling the reader; move it to a visible slicer or state it in the titles.
