# Chapter 3: The Accounting Data Environment

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 3.1: Reading the Charles River O2C Entity-Relationship Diagram

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 3.2: Tracing a Sale from Sales Order to General Ledger

No separate instructor note: the book holds none for this tutorial.

## Multiple-Choice Answer Key

Key: 1 A, 2 B, 3 B, 4 D, 5 C, 6 C, 7 A, 8 C, 9 D, 10 C, 11 A, 12 B, 13 A, 14 D, 15 B.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | A | a primary key uniquely identifies each row and cannot be duplicated or blank. |
| 2 | B | CustomerID in SalesOrder refers to the Customer table's primary key, so it is a foreign key. |
| 3 | B | a single bar at one end and a crow's foot at the other is one-to-many. |
| 4 | D | SalesOrderLine resolves the many-to-many relationship between orders and items. |
| 5 | C | the Manufacturing group holds the work orders, completions, and closes with cost and variance data. |
| 6 | C | ParentAccountID points to another row of the same table. |
| 7 | A | a trial balance sums the GLEntry rows by account, labeled from the Account table. |
| 8 | C | undeclared relationships still join, but nothing enforces them, so they must be tested. |
| 9 | D | referential integrity means every foreign key value matches an existing primary key. |
| 10 | C | the join returns one row per order line, 45 rows. |
| 11 | A | the chart of accounts hierarchy is a self-referencing table. |
| 12 | B | the target table depends on SourceDocumentType, so no single foreign key can describe it. |
| 13 | A | a relational database organizes tables connected by primary and foreign keys. |
| 14 | D | an INTEGER column stores whole numbers such as 4500. |
| 15 | B | the O2C cycle has many stages, each needing its own tables. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 3.1: Tracing a Purchase Transaction Through the Charles River Database

No separate instructor note: the book holds none for this exercise.

#### Exercise 3.2: Mapping the Charles River O2C Group to the Revenue Cycle

No separate instructor note: the book holds none for this exercise.

### Managerial Accounting Exercises

#### Exercise 3.3: Mapping the Charles River Manufacturing Group

No separate instructor note: the book holds none for this exercise.

#### Exercise 3.4: Mapping the Keys Behind a Budget-Versus-Actual Report

No separate instructor note: the book holds none for this exercise.

### Auditing Exercises

#### Exercise 3.5: Planning a Data Extraction Strategy for the Charles River Audit

No separate instructor note: the book holds none for this exercise.

#### Exercise 3.6: Assessing Referential Integrity Across the Charles River Database

No separate instructor note: the book holds none for this exercise.
