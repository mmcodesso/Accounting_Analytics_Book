# Chapter 9: SQL Essentials for Accounting Analytics

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 9.1: Opening the Database and Writing Your First Queries

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 9.2: Filtering the Ledger to the Variance Postings

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 9.3: Ranking the Largest Work-Order Variances

No separate instructor note: the book holds none for this tutorial.

## Multiple-Choice Answer Key

Key: 1 B, 2 D, 3 A, 4 C, 5 C, 6 A, 7 D, 8 B, 9 A, 10 D, 11 B, 12 C, 13 A, 14 D, 15 B.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | B | a column list separated by commas returns just those columns. |
| 2 | D | GLEntry.AccountID is the Account table's surrogate key; 5080 has AccountID 93. |
| 3 | A | = compares text exactly, including case; the stored value is WorkOrderClose. |
| 4 | C | dates stored as year-month-day text are compared with dates written the same way, in quotes. |
| 5 | C | AND is evaluated before OR, so the condition adds every 2026 posting of every account. |
| 6 | A | no comparison with NULL is true; IS NULL finds the missing values. |
| 7 | D | DISTINCT reveals the values in use, so a filter is not written for a value that does not exist. |
| 8 | B | DESC sorts from the largest, and LIMIT 10 keeps the first ten rows. |
| 9 | A | without ORDER BY, LIMIT returns an undefined selection of rows. |
| 10 | D | a working copy keeps the download safe; DB Browser opens files for writing unless opened read-only, and a SELECT never changes a file. |
| 11 | B | without the comma, AccountName becomes an alias for AccountNumber, a logical error. |
| 12 | C | the clauses must be written as SELECT, FROM, WHERE, ORDER BY, LIMIT. |
| 13 | A | % matches any run of characters; = compares the pattern literally, \_ matches exactly one character, and IN needs an exact value. |
| 14 | D | documentation lets another person understand, rerun, and review the queries. |
| 15 | B | two whole numbers divide as whole numbers, a decimal keeps the fraction, and text never equals a number when neither side is a column; SELECT needs no FROM. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 9.1: Reviewing the Chart of Accounts

**Instructor notes, Exercise 9.1:** 104 accounts: Asset 25, Liability 18, Equity 8, Revenue 13, Expense 40. Eighteen subtypes, including Header (10), Current Asset (11), Fixed Asset (5), Contra Fixed Asset (4), Contra Current Asset (1), Current Liability (13), Long-Term Liability (3), Operating Revenue (6), Contra Revenue (2), COGS (8), Operating Expense (29), Closing (1). Header accounts: 10; eight top-level headers (1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000) have a NULL ParentAccountID, while 1100 Fixed Assets and 2100 Long-Term Liabilities are sub-headers under 1000 and 2000, so the chart has two levels of headers. No header account has a posting. Opposite normal balances (8): 1030 Allowance for Doubtful Accounts, 1150/1160/1170/1186 accumulated depreciation (contra assets, credit); 3040 Dividends or Owner Distributions (contra equity, debit); 4060 Sales Returns and Allowances and 4070 Sales Discounts (contra revenue, debit). The query needs parentheses: (AccountType IN ('Asset','Expense') AND NormalBalance = 'Credit') OR (AccountType IN ('Liability','Equity','Revenue') AND NormalBalance = 'Debit'). Inactive (8), none with any posting: 4070 Sales Discounts, 5070 Inventory Adjustments, 6170 Bad Debt Expense, 6260 Salaries Expense - Manufacturing, 6270 Factory Overhead Expense, 7000 Other Income and Expense (header), 7010 Interest Income, 7040 Foreign Exchange Gain or Loss. Manufacturing salaries and factory overhead are charged to 1090 Manufacturing Cost Clearing (AccountID 92) and reach cost of goods sold through inventory and 5080 Manufacturing Variance. Memo points: 1030 has no postings, so no allowance has ever been recorded (Chapter 8); 4070 is inactive, so discounts are netted in revenue (Part II case).

#### Exercise 9.2: The Purchase Price Variance in the Ledger

**Instructor notes, Exercise 9.2:** 5060 Purchase Price Variance is AccountID 55. Fiscal 2026 source types: PurchaseInvoice and JournalEntry; the JournalEntry row is closing entry JE-2026-000296, a credit of 176,011.36, which clears the account. PurchaseInvoice postings: 23,556 rows with three descriptions: "Record unfavorable purchase variance" 12,389 debits (167,063.83), "Record favorable purchase variance" 7,270 credits (57,497.25), and "Record nonrecoverable purchase tax" 3,897 debits (66,444.78); the net, 176,011.36, equals the close. The purchase variance is the invoice price against the purchase-order price at which the goods were received (the invoice clears goods received not invoiced, account 2020, at the receipt value); a credit means the supplier billed below the order price (three one-cent credits and seven one-cent debits on lines billed at the order price are rounding). The account also absorbs purchase tax that cannot be recovered. Largest unfavorable variance 796.29 (2026-01-31, voucher V0101-2026-020853); next 783.75 and 752.40. Purchase variance is recorded when a supplier invoice is posted; manufacturing variance when a work order closes, comparing actual with standard production cost.

### Managerial Accounting Exercises

#### Exercise 9.3: Standard Cost Components of Manufactured Items

**Instructor notes, Exercise 9.3:** 88 manufactured items (Furniture 56, Lighting 26, Textiles 5, Accessories 1). Material cost = StandardCost - StandardConversionCost, from 10.43 to 558.40. The component check returns no rows: labor + variable overhead + fixed overhead = conversion for every item. Labor rate per standard hour ranges from 23.27 to 31.82, so rates are item-specific, not one plant rate. Highest conversion cost: FUR-TBL-0017 Mason Dining Table Ash Natural 84 in (112.43), FUR-CON-0077 (106.38), FUR-CTB-0014 (105.58); the top ten are Furniture.

#### Exercise 9.4: Open Work Orders at Year-End

**Instructor notes, Exercise 9.4:** 670 work orders have a NULL ClosedDate: Released 558, In Progress 27, Completed 85 (completed but not closed). Every WorkOrderNumber carries the year of its ReleasedDate, and every open work order is a 2026 work order (released 2026-05-23 to 2026-12-31); COALESCE shows not completed for the 585 released or in progress and a date for the 85 completed. Due on or before 2026-12-31: 471 (Released 406, Completed 64, In Progress 1). The oldest is WO-2026-011512, released 2026-05-23 and due 2026-06-07, still Released at the end of the data; the next are WO-2026-011742 (due 2026-06-21) and WO-2026-012609 (due 2026-08-30). Hundreds of released work orders are past due without being started, a backlog worth raising with production. Their variance will be recorded when they close, after the data ends. Counting needs one query per status (COUNT comes in Chapter 10).

### Auditing Exercises

#### Exercise 9.5: Shipments That Need Follow-Up

**Instructor notes, Exercise 9.5:** Status values Delivered (8,967) and In Transit (740); ShippedBy DHL Supply Chain, FedEx Freight, Private Fleet, UPS Freight. No TrackingNumber (NULL): 392 shipments, dated 2024-01-16 to 2026-12-31. In Transit with DeliveryDate before 2026-12-31: 739, the oldest delivered 2024-01-10 (one more In Transit shipment has a DeliveryDate on or after 2026-12-31). The SQL results equal the Excel filters of Tutorial 2.1. Dimensions: completeness (tracking number) and consistency or timeliness (status that contradicts the delivery date). The tests are saved as text and rerun with one click.

#### Exercise 9.6: Missing Values in Time and Labor Records

**Instructor notes, Exercise 9.6:** three Direct Manufacturing labor rows have no WorkOrderOperationID: LaborTimeEntryIDs 213 (employee 17, work order 1, 2024-01-17, 3.74 hours), 26171 (employee 17, work order 5328, 2025-01-02, 1.55 hours), and 48261 (employee 18, work order 9897, 2026-01-02, 0.50 hours); employees 17 and 18 are assemblers. They are planted anomalies (invalid direct labor operation link). ClockStatus values: Approved (52,962) and Pending (5). Three entries have no ClockOutTime, all for employee 85 (an Inventory Specialist) on January 1 of 2024, 2025, and 2026, with Pending status (planted missing clock-out). Thirteen employees have a TerminationDate; all are Terminated with IsActive 0, so the three columns agree. Missing links mean labor cost that cannot be traced to an operation; missing clock-outs mean paid hours without a complete time record.
