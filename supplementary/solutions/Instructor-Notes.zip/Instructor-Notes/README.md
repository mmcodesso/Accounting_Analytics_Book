# Instructor Notes, 2026 edition

*Accounting Analytics: An Integrated Approach*, 2026 edition, built on the Charles River dataset release v2026.1 (fiscal 2024–2026).

These files are public, like the rest of the book. Try an exercise first, then compare your work with the solution.

## What these files hold

One file per chapter, comprehensive case and appendix, in the order of the book (each also as a Word document). Each gives, for every guided tutorial, exercise, case requirement and milestone, the book's heading and the instructor note: the values to expect on this dataset release, the conditions the exercise depends on, and what a strong answer says. A chapter that has multiple-choice questions also gives the answer key with a rationale for every question.

The values were computed from the dataset release named above. On a different release or build of the dataset, expect different values; the instructor notes of that release replace these.

## Dataset release

- Edition: 2026
- Dataset release: v2026.1 (fiscal 2024–2026)
- CharlesRiver.sqlite SHA-256: de861968e07412d71032b6ed6a0fb8eb9825cf6911886b1597c4a628a914474c
- CharlesRiver.xlsx SHA-256: 185d42bd069fad177fae23c5e30df93edc7cf2669f687236c8a9f29435388e09
- CharlesRiver_csv (zip) SHA-256: 5f2821ee81f86c2da60702a9feaa51fa18f72687e5d0807c44a7d5489fecffb6

## Files

| File | Contents | Items with a note |
|---|---|---|
| 01-chapter-01.md | Chapter 1: The Role of Analytics in Accounting | 1 of 8 |
| 02-chapter-02.md | Chapter 2: Understanding Data in Accounting | 2 of 9 |
| 03-chapter-03.md | Chapter 3: The Accounting Data Environment | 1 of 9 |
| 04-part-1-case.md | Part 1 case: Getting the Data Ready for the Furniture Margin Question | 5 of 6 |
| 05-chapter-04.md | Chapter 4: Excel Essentials for Accounting Analytics | 7 of 10 |
| 06-chapter-05.md | Chapter 5: Data Preparation and Cleaning in Excel | 7 of 10 |
| 07-chapter-06.md | Chapter 6: Descriptive and Diagnostic Analytics in Excel | 7 of 10 |
| 08-chapter-07.md | Chapter 7: Forecasting, Budgeting, and What-If Analysis in Excel | 7 of 10 |
| 09-chapter-08.md | Chapter 8: Audit Analytics in Excel | 7 of 10 |
| 10-part-2-case.md | Part 2 case: Deciding on the 2027 Promotion Calendar | 6 of 6 |
| 11-chapter-09.md | Chapter 9: SQL Essentials for Accounting Analytics | 7 of 10 |
| 12-chapter-10.md | Chapter 10: Joining and Summarizing Data in SQL | 7 of 10 |
| 13-chapter-11.md | Chapter 11: Analytical Queries in SQL | 7 of 10 |
| 14-chapter-12.md | Chapter 12: Audit Analytics in SQL | 7 of 10 |
| 15-part-3-case.md | Part 3 case: Planning the Plant's Hours for 2027 | 6 of 6 |
| 16-chapter-13.md | Chapter 13: Power BI Essentials for Accounting Analytics | 10 of 10 |
| 17-chapter-14.md | Chapter 14: Data Models and DAX Measures | 10 of 10 |
| 18-chapter-15.md | Chapter 15: Reports for Management Decisions | 10 of 10 |
| 19-chapter-16.md | Chapter 16: Audit Monitoring and Report Assurance | 10 of 10 |
| 20-part-4-case.md | Part 4 case: Finding the Cash Behind the Profit | 6 of 6 |
| 21-chapter-17.md | Chapter 17: Financial Statements for a Lender | 13 of 13 |
| 22-chapter-18.md | Chapter 18: Make, Buy, or Reprice | 14 of 14 |
| 23-chapter-19.md | Chapter 19: Auditing the Customer Credits Cycle | 13 of 13 |
| 24-appendix-b.md | Appendix: Publishing, Securing, and Sharing Reports | 5 of 5 |
| 25-appendix-c.md | Appendix: Power BI in the Browser | 7 of 7 |

Items without a note are listed in the file with a line that says so: the book holds no instructor note for them.
