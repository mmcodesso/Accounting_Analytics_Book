# Chapter 2: Understanding Data in Accounting

Accounting Analytics: An Integrated Approach, 2026 edition. Dataset release v2026.1 (fiscal 2024–2026).
Public, like the rest of the book: try an exercise first, then compare your work.

## Guided Tutorial 2.1: Inspecting Charles River O2C and Item Data for Data Quality Problems

No separate instructor note: the book holds none for this tutorial.

## Guided Tutorial 2.2: Examining the Charles River Accounting Core for Completeness and Consistency

No separate instructor note: the book holds none for this tutorial.

## Multiple-Choice Answer Key

Key: 1 A, 2 B, 3 C, 4 A, 5 D, 6 D, 7 C, 8 A, 9 C, 10 A, 11 B, 12 C, 13 B, 14 D, 15 B.

| Question | Answer | Rationale |
|---:|:---:|---|
| 1 | A | a recorded value that differs from the true value is an accuracy problem. |
| 2 | B | blank values in a required field are a completeness problem. |
| 3 | C | two columns of the same record that disagree are a consistency problem. |
| 4 | A | a cost center's name is a category, not a measurement. |
| 5 | D | months as column headers leave the month without a column and put several observations in one row. |
| 6 | D | an extract taken before the final entries were posted is not current as of the reporting date. |
| 7 | C | most accounting work uses structured data, while unstructured data is growing. |
| 8 | A | one product under two ItemIDs is a duplicate record. |
| 9 | C | the general ledger records every financial transaction of the organization. |
| 10 | A | SourceDocumentType names the kind of business event that created the ledger row. |
| 11 | B | the structure is tidy, but the entry errors mean it is not clean. |
| 12 | C | grouping by name merges two different customers that share it. |
| 13 | B | an ERP system integrates the data of several functional areas in one database. |
| 14 | D | quality problems can make results unreliable, so they are found and addressed first. |
| 15 | B | separating manual journal entries from system-generated ones targets management override. |

## Applied Exercises

### Financial Accounting Exercises

#### Exercise 2.1: Assessing Revenue Data Quality in the Charles River O2C Tables

No separate instructor note: the book holds none for this exercise.

#### Exercise 2.2: Evaluating General Ledger Completeness at Charles River

No separate instructor note: the book holds none for this exercise.

### Managerial Accounting Exercises

#### Exercise 2.3: Data Quality Assessment for Product Cost Analysis

No separate instructor note: the book holds none for this exercise.

#### Exercise 2.4: Evaluating Budget Data for Budget-Versus-Actual Analysis

No separate instructor note: the book holds none for this exercise.

### Auditing Exercises

#### Exercise 2.5: Data Quality Evaluation for Audit Planning

No separate instructor note: the book holds none for this exercise.

#### Exercise 2.6: Testing for Duplicate Payments

**Instructor notes, Exercise 2.6:** six supplier invoice numbers appear twice for the same supplier (suppliers 1 and 2, one pair each per year, for example V0002-2024-000182); each pair has different dates and amounts and each invoice was paid once, so they are reused numbers rather than one invoice paid twice, but they still require follow-up. Two check numbers repeat for supplier 1 (CHK0006076 on payments 6076 and 6107, CHK0019708 on payments 19708 and 19843); each pair pays two different invoices of different amounts. The SUMIFS test finds no invoice paid above its GrandTotal (2,641 invoices were paid in installments): recorded payments never exceed an invoice, which does not prove the invoices themselves are valid. The generator's AnomalyLog lists six duplicate payment references, but only these two are present in the data.
