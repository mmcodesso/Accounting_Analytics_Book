Accounting Analytics: An Integrated Approach (2026 edition), instructor files
The Power BI part of the solution to the Chapter 18 capstone case: Product Costs (a Power BI project)

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.xlsx SHA-256 185d42bd069fad177fae23c5e30df93edc7cf2669f687236c8a9f29435388e09

Open Product Costs/Product Costs.pbip in Power BI Desktop (the September 2026 release or later). Its queries read
C:\CharlesRiver\CharlesRiver.xlsx; point them at your copy with Home > Transform data > Data source settings >
Change Source, choose Home > Refresh, and save it as a .pbix file if you prefer. The Notes page lists the
exercises or requirements with the instructor notes; in DAX query view, the Checks tab tests every value.
It also reads C:\CharlesRiver\Make Buy Reprice.xlsx: copy Make Buy Reprice.xlsx from Chapter18-capstone-excel.zip
into that folder, or point those queries at your copy the same way.
These files are public, like the rest of the book. Try an exercise first, then compare your work.
