/* MakeBuy.sql: make, buy, or reprice: what the records show for fiscal 2026
   Database: CharlesRiver_Capstone.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: family variances against account 5080; inputs to 1090 against the ledger and the standard cost released; routing time against the standard hours completed; each result the workbook pastes against the workbook's own query */

-- Requirement 1, Q1: the dates through which the base year's records run
-- Population: invoices, completions, closes, and time records of 2026; expected: time records end first
SELECT
    (SELECT MAX(InvoiceDate)
     FROM SalesInvoice
     WHERE InvoiceDate <= '2026-12-31') AS LastInvoice,
    (SELECT MAX(CompletionDate)
     FROM ProductionCompletion
     WHERE CompletionDate <= '2026-12-31') AS LastCompletion,
    (SELECT MAX(CloseDate)
     FROM WorkOrderClose
     WHERE CloseDate <= '2026-12-31') AS LastClose,
    (SELECT MAX(WorkDate)
     FROM LaborTimeEntry
     WHERE WorkDate <= '2026-12-31') AS LastTimeRecord;  -- Result: 1 rows

-- Requirement 1, Q2: the family results of the base year, kept as the view FamilyResults
-- Population: finished goods by family (ItemCode's first seven characters); expected: each family sold
DROP VIEW IF EXISTS FamilyResults;
CREATE VIEW FamilyResults AS
WITH FinishedGoods AS (
    SELECT ItemID, SUBSTR(ItemCode, 1, 7) AS Family, ItemGroup,
        SupplyMode, StandardCost
    FROM Item
    WHERE ItemType = 'Finished Good'
),
Sold AS (
    SELECT fg.Family, fg.SupplyMode, SUM(sil.Quantity) AS Units,
        SUM(sil.LineTotal) AS Revenue,
        SUM(sil.Quantity * sil.BaseListPrice) AS ListValue,
        SUM(sil.Quantity * fg.StandardCost) AS StandardCost
    FROM SalesInvoiceLine AS sil
        INNER JOIN SalesInvoice AS si
            ON si.SalesInvoiceID = sil.SalesInvoiceID
        INNER JOIN FinishedGoods AS fg ON fg.ItemID = sil.ItemID
    WHERE si.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY fg.Family, fg.SupplyMode
),
Closes AS (
    SELECT fg.Family, COUNT(*) AS Closes,
        SUM(woc.MaterialVarianceAmount) AS MaterialVariance,
        SUM(woc.DirectLaborVarianceAmount) AS LaborVariance,
        SUM(woc.OverheadVarianceAmount) AS OverheadVariance,
        SUM(woc.TotalVarianceAmount) AS TotalVariance
    FROM WorkOrderClose AS woc
        INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = woc.WorkOrderID
        INNER JOIN FinishedGoods AS fg ON fg.ItemID = wo.ItemID
    WHERE woc.CloseDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY fg.Family
),
Made AS (
    SELECT fg.Family, SUM(pcl.QuantityCompleted) AS UnitsCompleted,
        SUM(pcl.QuantityCompleted * fg.StandardCost)
            AS StandardCostCompleted,
        SUM(pcl.ExtendedStandardMaterialCost)
            AS StandardMaterialCompleted
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN FinishedGoods AS fg ON fg.ItemID = pcl.ItemID
    WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY fg.Family
)
SELECT s.Family,
    (SELECT MIN(fg.ItemGroup)
     FROM FinishedGoods AS fg
     WHERE fg.Family = s.Family) AS ItemGroup,
    ROUND(s.Units, 2) AS Units, ROUND(s.Revenue, 2) AS Revenue,
    ROUND(s.ListValue, 2) AS ListValue,
    ROUND(s.StandardCost, 2) AS StandardCost, c.Closes,
    ROUND(c.MaterialVariance, 2) AS MaterialVariance,
    ROUND(c.LaborVariance, 2) AS LaborVariance,
    ROUND(c.OverheadVariance, 2) AS OverheadVariance,
    ROUND(c.TotalVariance, 2) AS TotalVariance,
    ROUND(m.UnitsCompleted, 2) AS UnitsCompleted,
    ROUND(m.StandardCostCompleted, 2) AS StandardCostCompleted,
    ROUND(m.StandardMaterialCompleted, 2) AS StandardMaterialCompleted,
    ROUND(p.Revenue, 2) AS PurchasedRevenue,
    ROUND(p.StandardCost, 2) AS PurchasedStandardCost
FROM Sold AS s
    LEFT JOIN Closes AS c ON c.Family = s.Family
    LEFT JOIN Made AS m ON m.Family = s.Family
    LEFT JOIN Sold AS p
        ON p.Family = s.Family AND p.SupplyMode = 'Purchased'
WHERE s.SupplyMode = 'Manufactured';  -- Result: creates the view FamilyResults

-- Requirement 1, Q3: the family results, as the workbook pastes them (Copy with Headers)
-- Population: the view FamilyResults; expected: sales, the closes' variance by part, and completions
SELECT *
FROM FamilyResults
ORDER BY Family;  -- Result: 16 rows

-- Requirement 1, Q4: each family's variance per unit completed and three margins, purchased beside
-- Population: the view FamilyResults; expected: the variance lowers every margin, few beat purchased
SELECT Family, ItemGroup,
    ROUND(TotalVariance / StandardCostCompleted, 4)
        AS ShareOfStandardCompleted,
    ROUND(TotalVariance / UnitsCompleted, 2) AS VariancePerUnit,
    ROUND(1 - StandardCost / Revenue, 4) AS MarginAtStandard,
    ROUND(1 - (StandardCost + TotalVariance / UnitsCompleted * Units)
        / Revenue, 4) AS MarginAfterPerUnit,
    ROUND(1 - (StandardCost + TotalVariance) / Revenue, 4)
        AS MarginWithYearVariance,
    ROUND(1 - PurchasedStandardCost / PurchasedRevenue, 4)
        AS PurchasedMarginAtStandard
FROM FamilyResults
ORDER BY Family;  -- Result: 16 rows

-- Requirement 1, Q5: the three margins by item group (the CFO's comparison)
-- Population: the view FamilyResults; expected: about ten points from standard to the year's variance
SELECT ItemGroup, ROUND(SUM(Revenue), 2) AS Revenue,
    ROUND(SUM(TotalVariance), 2) AS Variance,
    ROUND(1 - SUM(StandardCost) / SUM(Revenue), 4) AS MarginAtStandard,
    ROUND(1 - SUM(StandardCost + TotalVariance / UnitsCompleted * Units)
        / SUM(Revenue), 4) AS MarginAfterPerUnit,
    ROUND(1 - SUM(StandardCost + TotalVariance) / SUM(Revenue), 4)
        AS MarginWithYearVariance
FROM FamilyResults
GROUP BY ItemGroup
ORDER BY ItemGroup;  -- Result: 3 rows

-- Requirement 1, Q6: account 5080 Manufacturing Variance in the base year, the closes left out
-- Population: the ledger's 5080 postings of fiscal 2026; expected: the closes' variance
SELECT ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Variance5080
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 5080 AND gl.FiscalYear = 2026
    AND gl.VoucherNumber NOT IN (
        SELECT EntryNumber
        FROM JournalEntry
        WHERE EntryType LIKE 'Year-End Close%');  -- Result: 1 row (Variance5080 = 2265636.88)

-- Requirement 1, Q7: the families' variances reconciled to account 5080
-- Population: the view FamilyResults and the 5080 postings; expected: no difference
SELECT
    (SELECT ROUND(SUM(TotalVariance), 2)
     FROM FamilyResults) AS FamilyVariance,
    (SELECT ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2)
     FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 5080 AND gl.FiscalYear = 2026
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')) AS Variance5080;  -- Result: 1 row (FamilyVariance = 2265636.88, Variance5080 = 2265636.88)

-- Requirement 1, Q8: the base year's purchase orders for purchased finished goods, by family
-- Population: 2026 order lines for purchased finished goods; expected: near standard, half of list
SELECT SUBSTR(i.ItemCode, 1, 7) AS Family,
    ROUND(SUM(pol.Quantity * pol.UnitCost), 2) AS OrderCost,
    ROUND(SUM(pol.Quantity * i.ListPrice), 2) AS ListValue,
    ROUND(SUM(pol.Quantity * i.StandardCost), 2) AS StandardValue,
    ROUND(MIN(pol.UnitCost / i.StandardCost), 4)
        AS LowestCostToStandard,
    ROUND(MAX(pol.UnitCost / i.StandardCost), 4)
        AS HighestCostToStandard
FROM PurchaseOrderLine AS pol
    INNER JOIN PurchaseOrder AS po
        ON po.PurchaseOrderID = pol.PurchaseOrderID
    INNER JOIN Item AS i ON i.ItemID = pol.ItemID
WHERE i.SupplyMode = 'Purchased' AND i.ItemType = 'Finished Good'
    AND po.OrderDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY Family
ORDER BY Family;  -- Result: 22 rows

-- Requirement 1, Q9: the CFO's second premise: did list prices or standard costs ever change?
-- Population: every invoice, shipment, and completion line; expected: no change beyond rounding
SELECT
    (SELECT COUNT(*)
     FROM SalesInvoiceLine) AS InvoiceLines,
    (SELECT COUNT(*)
     FROM SalesInvoiceLine AS sil
        INNER JOIN Item AS i ON i.ItemID = sil.ItemID
     WHERE sil.BaseListPrice IS NULL OR i.ListPrice IS NULL
        OR ABS(sil.BaseListPrice - i.ListPrice) > 0.004)
        AS ListPriceDiffers,
    (SELECT COUNT(*)
     FROM ShipmentLine AS sl
        INNER JOIN Item AS i ON i.ItemID = sl.ItemID
     WHERE sl.ExtendedStandardCost IS NULL
        OR ABS(sl.ExtendedStandardCost
            - ROUND(sl.QuantityShipped * i.StandardCost, 2)) > 0.011)
        AS ShipmentCostDiffers,
    (SELECT ROUND(MAX(ABS(pcl.ExtendedStandardTotalCost
            - pcl.QuantityCompleted * i.StandardCost)), 4)
     FROM ProductionCompletionLine AS pcl
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID)
        AS LargestCompletionDifference,
    (SELECT COUNT(*)
     FROM (SELECT sil.ItemID
           FROM SalesInvoiceLine AS sil
               INNER JOIN SalesInvoice AS si
                   ON si.SalesInvoiceID = sil.SalesInvoiceID
           WHERE si.InvoiceDate BETWEEN '2024-01-01' AND '2026-12-31'
           GROUP BY sil.ItemID
           HAVING COUNT(DISTINCT SUBSTR(si.InvoiceDate, 1, 4))
               = 3)) AS ItemsSoldEveryYear;  -- Result: 1 rows

-- Requirement 2, Q10: the inputs to 1090 from payroll, by line type and labor type
-- Population: Manufacturing payroll lines of 2026, deductions left out; expected: the PayrollSummary debits
SELECT prl.LineType, COALESCE(lte.LaborType, '') AS LaborType,
    ROUND(SUM(prl.Hours), 2) AS Hours,
    ROUND(SUM(prl.Amount), 2) AS Amount
FROM PayrollRegisterLine AS prl
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollRegisterID = prl.PayrollRegisterID
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
    LEFT JOIN LaborTimeEntry AS lte
        ON lte.LaborTimeEntryID = prl.LaborTimeEntryID
WHERE cc.CostCenterName = 'Manufacturing' AND pp.FiscalYear = 2026
    AND prl.LineType NOT IN ('Benefits Deduction',
        'Employee Tax Withholding')
GROUP BY prl.LineType, lte.LaborType
ORDER BY CASE prl.LineType
        WHEN 'Regular Earnings' THEN 1
        WHEN 'Overtime Earnings' THEN 2
        WHEN 'Salary Earnings' THEN 3
        WHEN 'Employer Payroll Tax' THEN 4
        ELSE 5 END,
    lte.LaborType;  -- Result: 7 rows

-- Requirement 2, Q11: the debits to 1090 Manufacturing Cost Clearing by source
-- Population: 1090 debits of 2026 but the closes'; expected: payroll, overhead entries, depreciation
SELECT COALESCE(je.EntryType, gl.SourceDocumentType) AS Source,
    ROUND(SUM(gl.Debit), 2) AS Debits
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    LEFT JOIN JournalEntry AS je
        ON je.JournalEntryID = gl.SourceDocumentID
        AND gl.SourceDocumentType = 'JournalEntry'
WHERE a.AccountNumber = 1090
    AND gl.PostingDate BETWEEN '2026-01-01' AND '2026-12-31'
    AND gl.Debit > 0 AND gl.SourceDocumentType <> 'WorkOrderClose'
GROUP BY Source
ORDER BY Source;  -- Result: 3 rows

-- Requirement 2, Q12: what the base year's completions released at standard, and 1090's credits
-- Population: the completion lines of 2026; expected: conversion equal to the credits within rounding
SELECT ROUND(SUM(pcl.QuantityCompleted
        * i.StandardLaborHoursPerUnit), 2) AS StandardHours,
    ROUND(SUM(pcl.ExtendedStandardMaterialCost), 2) AS Material,
    ROUND(SUM(pcl.ExtendedStandardDirectLaborCost), 2) AS DirectLabor,
    ROUND(SUM(pcl.ExtendedStandardVariableOverheadCost), 2)
        AS VariableOverhead,
    ROUND(SUM(pcl.ExtendedStandardFixedOverheadCost), 2)
        AS FixedOverhead,
    ROUND(SUM(pcl.ExtendedStandardConversionCost), 2) AS Conversion,
    (SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
     FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 1090 AND gl.FiscalYear = 2026
        AND gl.SourceDocumentType = 'ProductionCompletion')
        AS CreditsTo1090
FROM ProductionCompletionLine AS pcl
    INNER JOIN ProductionCompletion AS pc
        ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31';  -- Result: 1 rows

-- Requirement 2, Q13: the inputs to 1090 and the standard cost released, per standard hour
-- Population: the totals of Q10 to Q12; expected: actual cost well above standard, mostly overhead
WITH Totals AS (
    SELECT
        (SELECT SUM(gl.Debit)
         FROM GLEntry AS gl
            INNER JOIN Account AS a ON a.AccountID = gl.AccountID
         WHERE a.AccountNumber = 1090
            AND gl.PostingDate BETWEEN '2026-01-01' AND '2026-12-31'
            AND gl.Debit > 0
            AND gl.SourceDocumentType <> 'WorkOrderClose') AS Inputs,
        (SELECT SUM(prl.Amount)
         FROM PayrollRegisterLine AS prl
            INNER JOIN PayrollRegister AS pr
                ON pr.PayrollRegisterID = prl.PayrollRegisterID
            INNER JOIN PayrollPeriod AS pp
                ON pp.PayrollPeriodID = pr.PayrollPeriodID
            INNER JOIN CostCenter AS cc
                ON cc.CostCenterID = pr.CostCenterID
            INNER JOIN LaborTimeEntry AS lte
                ON lte.LaborTimeEntryID = prl.LaborTimeEntryID
         WHERE cc.CostCenterName = 'Manufacturing'
            AND pp.FiscalYear = 2026
            AND lte.LaborType = 'Direct Manufacturing'
            AND prl.LineType IN ('Regular Earnings',
                'Overtime Earnings')) AS DirectEarnings,
        (SELECT SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
         FROM ProductionCompletionLine AS pcl
            INNER JOIN ProductionCompletion AS pc
                ON pc.ProductionCompletionID = pcl.ProductionCompletionID
            INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
         WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31')
            AS StandardHours,
        (SELECT SUM(pcl.ExtendedStandardDirectLaborCost)
         FROM ProductionCompletionLine AS pcl
            INNER JOIN ProductionCompletion AS pc
                ON pc.ProductionCompletionID = pcl.ProductionCompletionID
         WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31')
            AS LaborReleased,
        (SELECT SUM(pcl.ExtendedStandardVariableOverheadCost
                + pcl.ExtendedStandardFixedOverheadCost)
         FROM ProductionCompletionLine AS pcl
            INNER JOIN ProductionCompletion AS pc
                ON pc.ProductionCompletionID = pcl.ProductionCompletionID
         WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31')
            AS OverheadReleased
)
SELECT ROUND(Inputs / StandardHours, 2) AS InputsPerStandardHour,
    ROUND((LaborReleased + OverheadReleased) / StandardHours, 2)
        AS ReleasedPerStandardHour,
    ROUND(LaborReleased / StandardHours, 2) AS LaborPerStandardHour,
    ROUND(OverheadReleased / StandardHours, 2)
        AS OverheadPerStandardHour,
    ROUND(DirectEarnings, 2) AS DirectEarnings,
    ROUND(Inputs - DirectEarnings, 2) AS ActualOverhead,
    ROUND((Inputs - DirectEarnings) / StandardHours, 2)
        AS ActualOverheadPerStandardHour,
    ROUND((Inputs - DirectEarnings) / OverheadReleased, 2)
        AS ActualToApplied,
    ROUND(OverheadReleased / (Inputs - DirectEarnings), 2)
        AS AppliedShareOfActual
FROM Totals;  -- Result: 1 rows

-- Requirement 2, Q14: each input to 1090 by month, with the standard hours completed
-- Population: completions and 1090 debits, 2024-01 to 2026-12; expected: some months with 3 pay dates
WITH Made AS (
    SELECT strftime('%Y-%m', pc.CompletionDate) AS Month,
        SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
            AS StandardHours,
        SUM(pcl.ExtendedStandardVariableOverheadCost
            + pcl.ExtendedStandardFixedOverheadCost) AS AppliedOverhead
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    GROUP BY Month
),
Posted AS (
    SELECT strftime('%Y-%m', gl.PostingDate) AS Month,
        SUM(CASE WHEN je.EntryType = 'Factory Overhead'
            THEN gl.Debit ELSE 0 END) AS FactoryOverhead,
        SUM(CASE WHEN gl.SourceDocumentType = 'PayrollSummary'
            THEN gl.Debit ELSE 0 END) AS Payroll,
        SUM(CASE WHEN je.EntryType = 'Depreciation'
            THEN gl.Debit ELSE 0 END) AS Depreciation,
        COUNT(DISTINCT CASE WHEN gl.SourceDocumentType = 'PayrollSummary'
            THEN gl.PostingDate END) AS PayDates
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
        LEFT JOIN JournalEntry AS je
            ON je.JournalEntryID = gl.SourceDocumentID
            AND gl.SourceDocumentType = 'JournalEntry'
    WHERE a.AccountNumber = 1090
    GROUP BY Month
)
SELECT mo.Month, ROUND(mo.StandardHours, 2) AS StandardHours,
    ROUND(mo.AppliedOverhead, 2) AS AppliedOverhead,
    ROUND(COALESCE(p.FactoryOverhead, 0), 2) AS FactoryOverhead,
    ROUND(COALESCE(p.Payroll, 0), 2) AS Payroll,
    ROUND(COALESCE(p.Depreciation, 0), 2) AS Depreciation,
    COALESCE(p.PayDates, 0) AS PayDates
FROM Made AS mo
    LEFT JOIN Posted AS p ON p.Month = mo.Month
WHERE mo.Month BETWEEN '2024-01' AND '2026-12'
ORDER BY mo.Month;  -- Result: 36 rows

-- Requirement 3, Q15: the activities of the base year's completions, kept as the view FamilyActivity
-- Population: work orders completed in 2026, their routings and issues; expected: each family made
DROP VIEW IF EXISTS FamilyActivity;
CREATE VIEW FamilyActivity AS
WITH Done AS (
    SELECT pc.WorkOrderID, SUM(pcl.QuantityCompleted) AS Units
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY pc.WorkOrderID
),
Orders AS (
    SELECT dn.WorkOrderID, dn.Units, wo.RoutingID,
        SUBSTR(i.ItemCode, 1, 7) AS Family, i.ItemGroup
    FROM Done AS dn
        INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = dn.WorkOrderID
        INNER JOIN Item AS i ON i.ItemID = wo.ItemID
),
Issues AS (
    SELECT mi.WorkOrderID, COUNT(*) AS IssueLines
    FROM MaterialIssueLine AS mil
        INNER JOIN MaterialIssue AS mi
            ON mi.MaterialIssueID = mil.MaterialIssueID
    WHERE mi.WorkOrderID IN (SELECT WorkOrderID FROM Done)
    GROUP BY mi.WorkOrderID
),
Families AS (
    SELECT o.Family, MIN(o.ItemGroup) AS ItemGroup,
        COUNT(*) AS WorkOrders, SUM(o.Units) AS UnitsCompleted,
        SUM(COALESCE(x.IssueLines, 0)) AS IssueLines
    FROM Orders AS o
        LEFT JOIN Issues AS x ON x.WorkOrderID = o.WorkOrderID
    GROUP BY o.Family
),
Hours AS (
    SELECT o.Family,
        SUM(CASE WHEN ro.WorkCenterID = 1
            THEN o.Units * ro.StandardRunHoursPerUnit END) AS CuttingRun,
        SUM(CASE WHEN ro.WorkCenterID = 2
            THEN o.Units * ro.StandardRunHoursPerUnit END) AS AssemblyRun,
        SUM(CASE WHEN ro.WorkCenterID = 3
            THEN o.Units * ro.StandardRunHoursPerUnit END) AS FinishingRun,
        SUM(CASE WHEN ro.WorkCenterID = 4
            THEN o.Units * ro.StandardRunHoursPerUnit END) AS PackingRun,
        SUM(CASE WHEN ro.WorkCenterID = 5
            THEN o.Units * ro.StandardRunHoursPerUnit END) AS QARun,
        SUM(CASE WHEN ro.WorkCenterID = 1
            THEN ro.StandardSetupHours END) AS CuttingSetup,
        SUM(CASE WHEN ro.WorkCenterID = 2
            THEN ro.StandardSetupHours END) AS AssemblySetup,
        SUM(CASE WHEN ro.WorkCenterID = 3
            THEN ro.StandardSetupHours END) AS FinishingSetup,
        SUM(CASE WHEN ro.WorkCenterID = 4
            THEN ro.StandardSetupHours END) AS PackingSetup,
        SUM(CASE WHEN ro.WorkCenterID = 5
            THEN ro.StandardSetupHours END) AS QASetup
    FROM Orders AS o
        INNER JOIN RoutingOperation AS ro ON ro.RoutingID = o.RoutingID
    GROUP BY o.Family
)
SELECT f.Family, f.ItemGroup, f.WorkOrders,
    ROUND(f.UnitsCompleted, 2) AS UnitsCompleted,
    ROUND(h.CuttingRun, 2) AS CuttingRun,
    ROUND(h.AssemblyRun, 2) AS AssemblyRun,
    ROUND(h.FinishingRun, 2) AS FinishingRun,
    ROUND(h.PackingRun, 2) AS PackingRun,
    ROUND(h.QARun, 2) AS QARun,
    ROUND(h.CuttingSetup, 2) AS CuttingSetup,
    ROUND(h.AssemblySetup, 2) AS AssemblySetup,
    ROUND(h.FinishingSetup, 2) AS FinishingSetup,
    ROUND(h.PackingSetup, 2) AS PackingSetup,
    ROUND(h.QASetup, 2) AS QASetup,
    f.IssueLines
FROM Families AS f
    LEFT JOIN Hours AS h ON h.Family = f.Family;  -- Result: creates the view FamilyActivity

-- Requirement 3, Q16: the activities by family, as the workbook pastes them (Copy with Headers)
-- Population: the view FamilyActivity; expected: run hours equal to the standard hours completed
SELECT *
FROM FamilyActivity
ORDER BY Family;  -- Result: 16 rows

-- Requirement 3, Q17: setup hours and material issue lines per thousand units, by family
-- Population: the view FamilyActivity; expected: small batches carry more setup per unit
SELECT Family, ItemGroup, WorkOrders, UnitsCompleted,
    ROUND(UnitsCompleted / WorkOrders, 1) AS AverageBatch,
    ROUND((COALESCE(CuttingSetup, 0)
        + COALESCE(AssemblySetup, 0)
        + COALESCE(FinishingSetup, 0)
        + COALESCE(PackingSetup, 0)
        + COALESCE(QASetup, 0))
        / UnitsCompleted * 1000, 1) AS SetupHoursPerThousand,
    ROUND(IssueLines / UnitsCompleted * 1000, 1)
        AS IssueLinesPerThousand
FROM FamilyActivity
ORDER BY Family;  -- Result: 16 rows

-- Requirement 3, Q18: the same activities by item group
-- Population: the view FamilyActivity; expected: Furniture's small batches carry twice the setup
SELECT ItemGroup, SUM(WorkOrders) AS WorkOrders,
    ROUND(SUM(UnitsCompleted), 1) AS UnitsCompleted,
    ROUND(SUM(UnitsCompleted) / SUM(WorkOrders), 1) AS AverageBatch,
    ROUND(SUM(COALESCE(CuttingSetup, 0)
        + COALESCE(AssemblySetup, 0)
        + COALESCE(FinishingSetup, 0)
        + COALESCE(PackingSetup, 0)
        + COALESCE(QASetup, 0))
        / SUM(UnitsCompleted) * 1000, 1) AS SetupHoursPerThousand,
    ROUND(SUM(IssueLines) / SUM(UnitsCompleted) * 1000, 1)
        AS IssueLinesPerThousand
FROM FamilyActivity
GROUP BY ItemGroup
ORDER BY ItemGroup;  -- Result: 3 rows

-- Requirement 3, Q19: the hours available at each work center in the base year
-- Population: WorkCenterCalendar, 2026; expected: one row for each work center
SELECT wc.WorkCenterID, wc.WorkCenterName,
    ROUND(SUM(wcc.AvailableHours), 2) AS AvailableHours,
    SUM(wcc.IsWorkingDay) AS WorkingDays
FROM WorkCenterCalendar AS wcc
    INNER JOIN WorkCenter AS wc ON wc.WorkCenterID = wcc.WorkCenterID
WHERE wcc.CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY wc.WorkCenterID, wc.WorkCenterName
ORDER BY wc.WorkCenterID;  -- Result: 5 rows

-- Requirement 3, Q20: each work center's available, practical, and routing hours, and its shares
-- Population: the calendar, 80% practical (tbl-18-02), 2026's routings; expected: idle capacity
WITH Done AS (
    SELECT pc.WorkOrderID, SUM(pcl.QuantityCompleted) AS Units
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY pc.WorkOrderID
),
Used AS (
    SELECT ro.WorkCenterID,
        SUM(dn.Units * ro.StandardRunHoursPerUnit) AS RunHours,
        SUM(ro.StandardSetupHours) AS SetupHours
    FROM Done AS dn
        INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = dn.WorkOrderID
        INNER JOIN RoutingOperation AS ro ON ro.RoutingID = wo.RoutingID
    GROUP BY ro.WorkCenterID
),
Available AS (
    SELECT WorkCenterID, SUM(AvailableHours) AS AvailableHours
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY WorkCenterID
),
Centers AS (
    SELECT wc.WorkCenterID, wc.WorkCenterName, av.AvailableHours,
        av.AvailableHours * 0.80 AS PracticalHours,
        COALESCE(u.RunHours, 0) AS RunHours,
        COALESCE(u.SetupHours, 0) AS SetupHours
    FROM WorkCenter AS wc
        INNER JOIN Available AS av ON av.WorkCenterID = wc.WorkCenterID
        LEFT JOIN Used AS u ON u.WorkCenterID = wc.WorkCenterID
),
Rows AS (
    SELECT WorkCenterID, WorkCenterName, AvailableHours,
        PracticalHours, RunHours, SetupHours
    FROM Centers
    UNION ALL
    SELECT NULL, 'Plant', SUM(AvailableHours), SUM(PracticalHours),
        SUM(RunHours), SUM(SetupHours)
    FROM Centers
)
SELECT WorkCenterID, WorkCenterName,
    ROUND(AvailableHours, 2) AS AvailableHours,
    ROUND(PracticalHours, 2) AS PracticalHours,
    ROUND(RunHours, 2) AS RunHours, ROUND(SetupHours, 2) AS SetupHours,
    ROUND(RunHours + SetupHours, 1) AS RoutingHours,
    ROUND((RunHours + SetupHours) / AvailableHours, 3)
        AS ShareOfAvailable,
    ROUND((RunHours + SetupHours) / PracticalHours, 3)
        AS ShareOfPractical
FROM Rows
ORDER BY COALESCE(WorkCenterID, 99);  -- Result: 6 rows

-- Requirement 4, Q21: the committed cost of the crew and supervision: payroll by pay class
-- Population: Manufacturing payroll registers of 2026; expected: the hourly crew, a few salaried
SELECT e.PayClass, COUNT(DISTINCT pr.EmployeeID) AS Employees,
    (SELECT COUNT(*)
     FROM Employee AS x
        INNER JOIN CostCenter AS y ON y.CostCenterID = x.CostCenterID
     WHERE y.CostCenterName = 'Manufacturing'
        AND x.PayClass = e.PayClass) AS EmployeesOnRecord,
    ROUND(SUM(pr.GrossPay), 2) AS GrossPay,
    ROUND(SUM(pr.EmployerPayrollTax), 2) AS EmployerTax,
    ROUND(SUM(pr.EmployerBenefits), 2) AS Benefits
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing' AND pp.FiscalYear = 2026
GROUP BY e.PayClass
ORDER BY e.PayClass;  -- Result: 2 rows

-- Requirement 6, Q22: the materials of the families to buy (FUR-BNH, FUR-NGT, FUR-TBL)
-- Population: their 2026 completions and issues, and all 2026 issues; expected: a quarter of issues
WITH Received AS (
    SELECT grl.ItemID, SUM(grl.ExtendedStandardCost) AS Amount
    FROM GoodsReceiptLine AS grl
        INNER JOIN GoodsReceipt AS gr
            ON gr.GoodsReceiptID = grl.GoodsReceiptID
    WHERE gr.ReceiptDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY grl.ItemID
),
Issued AS (
    SELECT mil.ItemID, SUM(mil.ExtendedStandardCost) AS Amount
    FROM MaterialIssueLine AS mil
        INNER JOIN MaterialIssue AS mi
            ON mi.MaterialIssueID = mil.MaterialIssueID
    WHERE mi.IssueDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY mil.ItemID
),
SixBuilt AS (
    SELECT i.ItemID
    FROM Item AS i
        LEFT JOIN Received AS rc ON rc.ItemID = i.ItemID
        LEFT JOIN Issued AS iss ON iss.ItemID = i.ItemID
    WHERE i.ItemGroup IN ('Raw Materials', 'Packaging')
    ORDER BY COALESCE(rc.Amount, 0) - COALESCE(iss.Amount, 0) DESC
    LIMIT 6
),
FamilyIssues AS (
    SELECT mil.ItemID, mil.ExtendedStandardCost
    FROM MaterialIssueLine AS mil
        INNER JOIN MaterialIssue AS mi
            ON mi.MaterialIssueID = mil.MaterialIssueID
        INNER JOIN WorkOrder AS wo ON wo.WorkOrderID = mi.WorkOrderID
        INNER JOIN Item AS i ON i.ItemID = wo.ItemID
    WHERE mi.IssueDate BETWEEN '2026-01-01' AND '2026-12-31'
        AND SUBSTR(i.ItemCode, 1, 7) IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
)
SELECT
    (SELECT ROUND(SUM(pcl.QuantityCompleted
            * (i.StandardCost - i.StandardConversionCost)), 2)
     FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
     WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'
        AND SUBSTR(i.ItemCode, 1, 7) IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL'))
        AS StandardMaterialCompleted,
    (SELECT ROUND(SUM(ExtendedStandardCost), 2)
     FROM FamilyIssues) AS IssuedToTheirWorkOrders,
    (SELECT ROUND(SUM(ExtendedStandardCost), 2)
     FROM FamilyIssues
     WHERE ItemID IN (SELECT ItemID FROM SixBuilt))
        AS OfWhichSixRawMaterials,
    (SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
     FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 1045 AND gl.FiscalYear = 2026
        AND gl.SourceDocumentType = 'MaterialIssue') AS AllIssues1045;  -- Result: 1 rows

-- Requirement 7, Q23: the hours that buying the families of Requirement 6 frees at each work center
-- Population: FamilyActivity (2026) and the calendar; expected: fewer than the hours already unused
WITH Routing AS (
    SELECT Family,
        COALESCE(CuttingRun, 0) + COALESCE(CuttingSetup, 0) AS Cutting,
        COALESCE(AssemblyRun, 0) + COALESCE(AssemblySetup, 0) AS Assembly,
        COALESCE(FinishingRun, 0) + COALESCE(FinishingSetup, 0) AS Finishing,
        COALESCE(PackingRun, 0) + COALESCE(PackingSetup, 0) AS Packing,
        COALESCE(QARun, 0) + COALESCE(QASetup, 0) AS QA
    FROM FamilyActivity
),
Practical AS (
    SELECT SUM(AvailableHours) * 0.80 AS PracticalHours
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
)
SELECT
    ROUND(SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
        THEN Cutting ELSE 0 END), 1) AS CuttingFreed,
    ROUND(SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
        THEN Assembly ELSE 0 END), 1) AS AssemblyFreed,
    ROUND(SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
        THEN Finishing ELSE 0 END), 1) AS FinishingFreed,
    ROUND(SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
        THEN Packing ELSE 0 END), 1) AS PackingFreed,
    ROUND(SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
        THEN QA ELSE 0 END), 1) AS QAFreed,
    ROUND(SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
        THEN Cutting + Assembly + Finishing + Packing + QA ELSE 0 END), 1) AS HoursFreed,
    ROUND(SUM(Cutting + Assembly + Finishing + Packing + QA)
        / (SELECT PracticalHours FROM Practical), 3) AS UseBefore,
    ROUND((SUM(Cutting + Assembly + Finishing + Packing + QA)
        - SUM(CASE WHEN Family IN ('FUR-BNH', 'FUR-NGT', 'FUR-TBL')
            THEN Cutting + Assembly + Finishing + Packing + QA ELSE 0 END))
        / (SELECT PracticalHours FROM Practical), 3) AS UseAfter,
    ROUND((SELECT PracticalHours FROM Practical)
        - SUM(Cutting + Assembly + Finishing + Packing + QA), 1) AS UnusedToday
FROM Routing;  -- Result: 1 rows

-- Requirement 8, Q24: list-price order value by month in each promotion's scope (the Part II case)
-- Population: every sales order line in each promotion's scope and year; expected: no lift
WITH Orders AS (
    SELECT so.OrderDate, sol.Quantity * sol.BaseListPrice AS ListValue,
        sol.PromotionID, i.CollectionName, i.ItemGroup,
        c.CustomerSegment
    FROM SalesOrderLine AS sol
        INNER JOIN SalesOrder AS so ON so.SalesOrderID = sol.SalesOrderID
        INNER JOIN Item AS i ON i.ItemID = sol.ItemID
        INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
),
Promotions AS (
    SELECT PromotionID, PromotionCode, ScopeType,
        CASE ScopeType
            WHEN 'Collection' THEN CollectionName
            WHEN 'ItemGroup' THEN ItemGroup
            ELSE CustomerSegment END AS Scope,
        SUBSTR(EffectiveStartDate, 1, 4) AS Year
    FROM PromotionProgram
),
Scoped AS (
    SELECT p.PromotionID,
        CAST(SUBSTR(o.OrderDate, 6, 2) AS INTEGER) AS M, o.ListValue
    FROM Promotions AS p
        INNER JOIN Orders AS o
            ON SUBSTR(o.OrderDate, 1, 4) = p.Year
            AND p.Scope = CASE p.ScopeType
                WHEN 'Collection' THEN o.CollectionName
                WHEN 'ItemGroup' THEN o.ItemGroup
                ELSE o.CustomerSegment END
)
SELECT p.PromotionID, p.PromotionCode, p.ScopeType, p.Scope,
    CAST(p.Year AS INTEGER) AS Year,
    (SELECT GROUP_CONCAT(M, ',')
     FROM (SELECT DISTINCT CAST(SUBSTR(o.OrderDate, 6, 2) AS INTEGER) AS M
           FROM Orders AS o
           WHERE o.PromotionID = p.PromotionID
           ORDER BY M)) AS PromotionMonths,
    ROUND(SUM(CASE WHEN sc.M = 1 THEN sc.ListValue ELSE 0 END), 2)
        AS M01,
    ROUND(SUM(CASE WHEN sc.M = 2 THEN sc.ListValue ELSE 0 END), 2)
        AS M02,
    ROUND(SUM(CASE WHEN sc.M = 3 THEN sc.ListValue ELSE 0 END), 2)
        AS M03,
    ROUND(SUM(CASE WHEN sc.M = 4 THEN sc.ListValue ELSE 0 END), 2)
        AS M04,
    ROUND(SUM(CASE WHEN sc.M = 5 THEN sc.ListValue ELSE 0 END), 2)
        AS M05,
    ROUND(SUM(CASE WHEN sc.M = 6 THEN sc.ListValue ELSE 0 END), 2)
        AS M06,
    ROUND(SUM(CASE WHEN sc.M = 7 THEN sc.ListValue ELSE 0 END), 2)
        AS M07,
    ROUND(SUM(CASE WHEN sc.M = 8 THEN sc.ListValue ELSE 0 END), 2)
        AS M08,
    ROUND(SUM(CASE WHEN sc.M = 9 THEN sc.ListValue ELSE 0 END), 2)
        AS M09,
    ROUND(SUM(CASE WHEN sc.M = 10 THEN sc.ListValue ELSE 0 END), 2)
        AS M10,
    ROUND(SUM(CASE WHEN sc.M = 11 THEN sc.ListValue ELSE 0 END), 2)
        AS M11,
    ROUND(SUM(CASE WHEN sc.M = 12 THEN sc.ListValue ELSE 0 END), 2)
        AS M12
FROM Promotions AS p
    INNER JOIN Scoped AS sc ON sc.PromotionID = p.PromotionID
GROUP BY p.PromotionID, p.PromotionCode, p.ScopeType, p.Scope, p.Year
ORDER BY p.PromotionID;  -- Result: 9 rows

-- Requirement 8, Q25: the price lists, prices against list, and lines priced after the end (Ex. 8.6)
-- Population: every price list; expected: expired lists still in use
SELECT pl.PriceListID, pl.PriceListName, pl.ScopeType, pl.Status,
    pl.EffectiveStartDate, pl.EffectiveEndDate,
    (SELECT ROUND(MIN(pll.UnitPrice / i.ListPrice), 4)
     FROM PriceListLine AS pll
        INNER JOIN Item AS i ON i.ItemID = pll.ItemID
     WHERE pll.PriceListID = pl.PriceListID) AS LowestPriceToList,
    (SELECT ROUND(MAX(pll.UnitPrice / i.ListPrice), 4)
     FROM PriceListLine AS pll
        INNER JOIN Item AS i ON i.ItemID = pll.ItemID
     WHERE pll.PriceListID = pl.PriceListID) AS HighestPriceToList,
    (SELECT COUNT(*)
     FROM SalesOrderLine AS sol
        INNER JOIN SalesOrder AS so ON so.SalesOrderID = sol.SalesOrderID
        INNER JOIN PriceListLine AS pll
            ON pll.PriceListLineID = sol.PriceListLineID
     WHERE pll.PriceListID = pl.PriceListID
        AND so.OrderDate > pl.EffectiveEndDate) AS OrderLinesAfterEnd
FROM PriceList AS pl
ORDER BY pl.PriceListID;  -- Result: 14 rows

-- Requirement 8, Q26: approved price overrides by the approver's job title
-- Population: PriceOverrideApproval, status Approved; expected: one approver
SELECT e.JobTitle AS ApproverJobTitle, COUNT(*) AS ApprovedOverrides
FROM PriceOverrideApproval AS poa
    INNER JOIN Employee AS e ON e.EmployeeID = poa.ApprovedByEmployeeID
WHERE poa.Status = 'Approved'
GROUP BY e.JobTitle
ORDER BY ApprovedOverrides DESC;  -- Result: 1 row (ApproverJobTitle = Sales Manager, ApprovedOverrides = 409)

-- Requirement 9, Q27: the depreciation FixedAsset charges to 1090 in 2027 (the plan's)
-- Population: assets depreciated to 1090, month after service to month before disposal; expected: a total
WITH Assets AS (
    SELECT ROUND(fa.OriginalCost * 1.0 / fa.UsefulLifeMonths, 2)
            AS Monthly,
        CAST(SUBSTR(fa.InServiceDate, 1, 4) AS INTEGER) * 12
            + CAST(SUBSTR(fa.InServiceDate, 6, 2) AS INTEGER)
            AS FirstMonth,
        CAST(SUBSTR(fa.InServiceDate, 1, 4) AS INTEGER) * 12
            + CAST(SUBSTR(fa.InServiceDate, 6, 2) AS INTEGER)
            + fa.UsefulLifeMonths - 1 AS LifeEndMonth,
        CAST(SUBSTR(fa.DisposalDate, 1, 4) AS INTEGER) * 12
            + CAST(SUBSTR(fa.DisposalDate, 6, 2) AS INTEGER) - 2
            AS DisposalEndMonth
    FROM FixedAsset AS fa
        INNER JOIN Account AS a
            ON a.AccountID = fa.DepreciationDebitAccountID
    WHERE a.AccountNumber = 1090
),
InPlanYear AS (
    SELECT Monthly,
        CASE WHEN FirstMonth > 2027 * 12 THEN FirstMonth
            ELSE 2027 * 12 END AS FromMonth,
        CASE WHEN DisposalEndMonth < LifeEndMonth
                AND DisposalEndMonth < 2027 * 12 + 11
                THEN DisposalEndMonth
            WHEN LifeEndMonth < 2027 * 12 + 11 THEN LifeEndMonth
            ELSE 2027 * 12 + 11 END AS ToMonth
    FROM Assets
)
SELECT ROUND(SUM(Monthly * (ToMonth - FromMonth + 1)), 2)
    AS PlanYearDepreciation
FROM InPlanYear
WHERE ToMonth >= FromMonth;  -- Result: 1 row (PlanYearDepreciation = 293499.96)

-- Requirement 9, Q28: manufactured finished goods made since the opening, on hand at each year-end
-- Population: completions less shipments plus returns; expected: a few items negative (opening stock)
WITH Moves AS (
    SELECT pcl.ItemID, pc.CompletionDate AS MoveDate,
        pcl.QuantityCompleted AS Quantity
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    UNION ALL
    SELECT sl.ItemID, s.ShipmentDate, -sl.QuantityShipped
    FROM ShipmentLine AS sl
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    UNION ALL
    SELECT srl.ItemID, sr.ReturnDate, srl.QuantityReturned
    FROM SalesReturnLine AS srl
        INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = srl.SalesReturnID
)
SELECT i.ItemID, i.ItemCode,
    ROUND(SUM(CASE WHEN mv.MoveDate <= '2024-12-31'
        THEN mv.Quantity ELSE 0 END), 2) AS OnHand2024,
    ROUND(SUM(CASE WHEN mv.MoveDate <= '2025-12-31'
        THEN mv.Quantity ELSE 0 END), 2) AS OnHand2025,
    ROUND(SUM(CASE WHEN mv.MoveDate <= '2026-12-31'
        THEN mv.Quantity ELSE 0 END), 2) AS OnHand2026
FROM Moves AS mv
    INNER JOIN Item AS i ON i.ItemID = mv.ItemID
WHERE i.SupplyMode = 'Manufactured' AND i.ItemType = 'Finished Good'
GROUP BY i.ItemID, i.ItemCode
ORDER BY i.ItemCode;  -- Result: 83 rows

-- Requirement 9, Q29: the stock of Q28 at each year-end, the negative items left out
-- Population: the items of Q28 with units on hand; expected: stock growing every year
WITH Moves AS (
    SELECT pcl.ItemID, pc.CompletionDate AS MoveDate,
        pcl.QuantityCompleted AS Quantity
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    UNION ALL
    SELECT sl.ItemID, s.ShipmentDate, -sl.QuantityShipped
    FROM ShipmentLine AS sl
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    UNION ALL
    SELECT srl.ItemID, sr.ReturnDate, srl.QuantityReturned
    FROM SalesReturnLine AS srl
        INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = srl.SalesReturnID
),
YearEnds AS (
    SELECT DISTINCT FiscalYear, FiscalYear || '-12-31' AS YearEnd
    FROM GLEntry
    WHERE FiscalYear BETWEEN 2024 AND 2026
),
OnHand AS (
    SELECT ye.FiscalYear, mv.ItemID, SUM(mv.Quantity) AS Units
    FROM YearEnds AS ye
        INNER JOIN Moves AS mv ON mv.MoveDate <= ye.YearEnd
    GROUP BY ye.FiscalYear, mv.ItemID
)
SELECT oh.FiscalYear, COUNT(*) AS Items, ROUND(SUM(oh.Units), 1) AS Units,
    ROUND(SUM(oh.Units * i.StandardLaborHoursPerUnit), 1)
        AS StandardHours,
    ROUND(SUM(oh.Units * i.StandardConversionCost), 2)
        AS ConversionAtStandard,
    ROUND(SUM(oh.Units * i.StandardCost), 2) AS AtStandardCost,
    ROUND(SUM(oh.Units * i.StandardConversionCost)
        / SUM(oh.Units * i.StandardLaborHoursPerUnit), 2)
        AS ConversionPerHour
FROM OnHand AS oh
    INNER JOIN Item AS i ON i.ItemID = oh.ItemID
WHERE i.SupplyMode = 'Manufactured' AND i.ItemType = 'Finished Good'
    AND oh.Units > 0
GROUP BY oh.FiscalYear
ORDER BY oh.FiscalYear;  -- Result: 3 rows

-- Requirement 9, Q30: income before income taxes as recorded, by fiscal year (for materiality)
-- Population: revenue and expense postings, closes left out (no tax account); expected: a row a year
SELECT gl.FiscalYear,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS IncomeBeforeTaxes
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountType IN ('Revenue', 'Expense')
    AND gl.FiscalYear BETWEEN 2024 AND 2026
    AND gl.VoucherNumber NOT IN (
        SELECT EntryNumber
        FROM JournalEntry
        WHERE EntryType LIKE 'Year-End Close%')
GROUP BY gl.FiscalYear
ORDER BY gl.FiscalYear;  -- Result: 3 rows

-- Requirement 9, Q31: the finished goods (1040) on the opening entry, which has no item detail
-- Population: the opening entry's 1040 line; expected: one row, left out of the revaluation
SELECT je.EntryNumber,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS OpeningFinishedGoods
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    INNER JOIN JournalEntry AS je ON je.EntryNumber = gl.VoucherNumber
WHERE a.AccountNumber = 1040 AND je.EntryType = 'Opening'
GROUP BY je.EntryNumber;  -- Result: 1 row (EntryNumber = JE-2024-000001, OpeningFinishedGoods = 4111795.76)

/* Model answer (Requirement 1)

   Queries Q2 to Q5 rebuild the CFO's comparison once, from the invoice lines, items, work orders, closes, and
   completions of 2026, each joined at its own grain and aggregated by family before the families are joined
   (the joins cannot fan out). The families' variances total 2,265,636.88 (material 106,498.85, labor
   -14,074.81, overhead 2,173,212.84), equal to account 5080 without the closes (Q7). Furniture earns 42.3% at
   standard, 32.6% after the variance per unit completed, and 31.6% with the year's whole variance charged:
   the CFO's "about ten points" is the gap between the first and the last. Only TXT-PIL keeps a margin after
   the variance per unit above that of the purchased products of its family (Q4); the variance runs from 12.8%
   to 21.8% of the standard cost completed.

   The second premise holds as arithmetic (Q9): the base list price equals the item's list price on all 27,933
   invoice lines, every shipment line's standard cost is its quantity times the item's standard cost,
   completion lines differ by at most 0.02 (component rounding), and 198 items were sold in each of the three
   years, so neither list prices nor standards changed. It fails as a diagnosis: whether the products are
   under-costed depends on what the variance is made of, which Requirement 2 takes apart.
*/

/* Model answer (Requirement 2)

   In 2026, 1090 received 5,427,932.83 (Q11): payroll 3,815,397.14, the Factory Overhead entries 1,308,869.06,
   and depreciation 303,666.63; the completions released 3,266,422.54 at standard (Q12), 47.40 per standard
   hour (labor 28.28, overhead 19.12) against 78.77 of actual cost (Q13). Overhead, the inputs less the direct
   earnings of 1,936,068.40, is 3,491,864.43, 2.65 times what the standards applied: the standards apply 0.38
   of it, the CFO's "a third". Q14 is the monthly extract the workbook's regressions read, from February 2024
   on, and from January 2024 to show what the start-up month does to them; it carries the pay dates of each
   month, so the months with three payrolls (2024-03, 2024-08, 2025-01, 2025-08, 2026-01, 2026-07) can be
   marked before anyone reads a slope from them.
*/

/* Model answer (Requirement 3)

   Routing time is the right measure of use because it is what each product should take, set by engineering
   for every operation, and it does not depend on the time records that Part III found drifting toward packing
   and quality assurance and recorded after the operations ended: the 2026 completions' run hours (68,912.79)
   equal their standard labor hours exactly. What it leaves out is everything the plant pays for beyond that
   standard: the indirect time, the hours beyond the work, and the overtime of the surge days. The plant used
   71.6% of its practical capacity on routing time (73,822.9 of 103,066.6 hours); the 29,243.7 practical hours
   left over are exactly what Requirement 4's unused capacity holds.
*/

/* Model answer (Requirement 9)

   Q28 and Q29 rebuild the manufactured finished goods made since the ledger opened and still on hand:
   11,880.3 units (16,482.8 standard hours) at the end of 2024, 17,103.3 at the end of 2025, and 21,883.6
   (29,522.4 standard hours, 5,627,028.26 at standard) at the end of 2026, carried at about 47.51 of
   conversion per standard hour. FUR-SDB-0006 at 2024 and FUR-DSK-0044 at 2026 come out negative, which proves
   stock that predates the ledger's item detail; they are left out, as is the opening 4,111,795.76 of finished
   goods (Q31). The workbook revalues this stock at the proposed standard; Q30 gives the materiality it is
   measured against (256,717.74 for 2025 and 225,180.56 for 2026).
*/

/* Notes

   Requirement 1: Test the CFO's numbers and the premises behind them (Chapters 9 to 11)
   The CFO's comparison joins invoice lines, items, work orders, their closes, and completions, and every one
      of those joins can fan out. It is a query, written once and reconciled to the ledger before anyone reads
      a margin from it.
   In MakeBuy.sql, for each manufactured family in fiscal 2026, return the units sold, revenue, list value,
      and standard cost; the variance of the year's closes, by material, labor, and overhead, and as a share
      of the standard cost completed; and the variance per unit completed.
   Compute three margins for each family: at standard, after the variance per unit completed, and with the
      year's whole variance charged, as the ledger charges it. Set the purchased products of the same family
      beside them.
   Test the CFO's second premise: whether list prices and standard costs changed at any time in the three
      years.
   Reconcile the families' variances to account 5080.
   Instructor note: families of manufactured finished goods (Item.SupplyMode 'Manufactured'), first seven
      characters of ItemCode; ACC-CDL was not made or sold in 2026. Fiscal 2026 by InvoiceDate; variance =
      TotalVarianceAmount of closes dated in 2026 (material 106,498.85, labor -14,074.81, overhead
      2,173,212.84; total 2,265,636.88, equal to 5080). Variance per unit completed = the family's 2026 close
      variance / its 2026 units completed. Family / units sold / revenue / closes / variance / share of
      standard completed / per unit completed / margin at standard / after per-unit variance / with the year's
      variance / purchased margin at standard: FUR-BKC 1,955.0 / 1,158,000.85 / 179 / 106,587.95 / 14.5% /
      52.33 / 39.4 / 30.5 / 30.2 / none; FUR-BNH 1,454.9 / 885,941.44 / 152 / 111,599.30 / 16.1% / 62.48 /
      37.8 / 27.5 / 25.2 / 47.6; FUR-CON 1,321.7 / 822,620.94 / 165 / 104,967.73 / 15.4% / 55.48 / 45.9 / 37.0
      / 33.2 / 42.8; FUR-CTB 4,361.0 / 2,452,336.51 / 490 / 280,253.94 / 16.5% / 53.27 / 42.4 / 32.9 / 30.9 /
      38.1; FUR-DSK 4,567.4 / 2,982,469.82 / 439 / 235,254.95 / 14.6% / 49.23 / 44.3 / 36.8 / 36.4 / 45.1;
      FUR-NGT 3,198.9 / 1,565,380.69 / 331 / 167,618.64 / 18.3% / 52.33 / 41.6 / 30.9 / 30.9 / 44.5; FUR-SDB
      3,780.0 / 2,079,063.38 / 370 / 259,360.59 / 20.1% / 62.23 / 43.5 / 32.2 / 31.0 / 40.9; FUR-TBL 4,984.1 /
      2,822,552.50 / 462 / 313,491.13 / 18.7% / 63.62 / 41.3 / 30.1 / 30.2 / 44.0; LGT-CHD 2,167.1 /
      678,919.89 / 138 / 52,219.07 / 12.9% / 23.12 / 41.7 / 34.3 / 34.0 / 48.3; LGT-FLR 4,404.4 / 1,085,286.98
      / 321 / 113,365.27 / 17.6% / 21.75 / 47.9 / 39.1 / 37.5 / 46.3; LGT-PND 2,773.2 / 1,081,462.36 / 207 /
      104,786.77 / 16.2% / 33.98 / 45.9 / 37.2 / 36.2 / 41.8; LGT-SCN 4,591.4 / 1,500,136.53 / 274 /
      170,490.55 / 20.9% / 34.12 / 48.0 / 37.6 / 36.6 / 45.9; LGT-TBL 2,976.2 / 864,006.77 / 213 / 80,274.14 /
      16.5% / 24.24 / 49.4 / 41.0 / 40.1 / 44.4; TXT-CRT 1,657.0 / 720,512.88 / 99 / 52,879.36 / 12.8% / 29.45
      / 47.1 / 40.3 / 39.8 / 49.0; TXT-PIL 673.3 / 246,514.48 / 27 / 17,307.85 / 21.8% / 34.56 / 56.6 / 47.2 /
      49.6 / 41.0; TXT-THR 1,920.5 / 1,115,802.11 / 93 / 95,179.64 / 17.6% / 48.91 / 52.2 / 43.8 / 43.7 /
      44.6. Groups (standard / per unit / year): Furniture revenue 14,768,366.13, 42.33% / 32.56% / 31.64%
      (variance 1,579,134.23); Lighting 5,209,812.53, 46.96% / 37.96% / 36.96% (521,135.80); Textiles
      2,082,829.47, 50.96% / 42.99% / 43.02% (165,366.85). The CFO's "ten points" is Furniture's 42.3% against
      31.6%; only TXT-PIL beats its purchased benchmark after the variance. Premises: BaseListPrice equals
      Item.ListPrice on all 27,933 invoice lines; every ShipmentLine standard cost equals quantity x
      StandardCost; completion lines differ by at most 0.02 (component rounding); 198 items were sold in each
      of the three years; so neither list prices nor standards changed. Purchased cost to list in 2026 for the
      quoted families: BNH 0.472, NGT 0.478, SDB 0.517, TBL 0.485, SCN 0.486, PIL 0.540 (the quote's
      calibration); purchased cost averages 1.011 times standard (0.95 to 1.07). The CFO's premise holds as
      arithmetic and fails as a diagnosis: Requirement 2.

   Requirement 2: Take the overhead apart (Chapters 7, 10, and 11)
   "Overhead at a third of its cost" is a claim about cost behavior, and cost behavior is tested, not assumed.
      SQL extracts what flowed into account 1090 and what the standards released from it; the regressions
      belong in the workbook, as in Chapter 7.
   Split the 2026 inputs to 1090 into direct and indirect labor, regular and overtime, salaries, employer
      taxes and benefits, the Factory Overhead entries, and depreciation, and set them against the standard
      cost that completions released, by labor and overhead. Express both per standard hour.
   Extract each input by month, January 2024 to December 2026, with the standard hours completed each month,
      and test which inputs move with output from February 2024 on. Explain what including January 2024, and
      the months with three pay dates, would do to the test.
   Write a sentence for each input that classifies it as a cost that varies with output, a committed capacity
      cost, or neither, with the evidence.
   Instructor note: inputs to 1090 in fiscal 2026 (PayrollSummary, Factory Overhead and Depreciation entries;
      the favorable closes' debits excluded): direct labor regular 47,020.5 hours 1,253,247.29, overtime
      17,105.1 hours 682,821.11; indirect regular 38,030.5 hours 1,011,567.67, overtime 3,306.0 hours
      131,908.30; salaries 263,191.24; employer payroll tax 255,719.16; employer benefits 216,942.37 (payroll
      3,815,397.14); Factory Overhead entries 1,308,869.06; depreciation 303,666.63; total 5,427,932.83.
      Released at standard (ProductionCompletion credits 3,266,422.54; completion lines 3,266,421.95): labor
      1,948,859.23, variable overhead 746,606.73, fixed overhead 570,955.99, on 68,912.79 standard hours:
      47.40 per standard hour (labor 28.28, overhead 19.12). Actual: 78.77 per standard hour; overhead (inputs
      less direct earnings of 1,936,068.40) 3,491,864.43, 50.67 per standard hour, 2.65 times applied: the
      CFO's "a third" is 0.38. Behavior, 35 months February 2024 to December 2026, on standard hours
      completed: Factory Overhead entries slope 19.66, intercept -3,122, r 0.975, R-squared 0.951 (variable,
      at about the applied rate: their ratio to applied overhead is 1.001, 1.003, 0.993 by year); payroll to
      1090 slope 3.06, intercept 268,143, r 0.066, R-squared 0.004 (committed; with January 2024, r 0.396, a
      start-up artifact); depreciation follows its schedule (24,625.00; 26,958.33 in February to May;
      24,458.33 from June 2026), and its r of -0.515 is spurious. Conclusion: the overhead the standards apply
      already covers the overhead that varies; the gap is the crew and supervision, which do not move with
      output, plus depreciation, spread over a plant that runs well below its capacity. So the products are
      not "under-costed" by the variable overhead rate; the question is what the committed capacity is for.

   Requirement 3: Measure the activities and the capacity (Chapters 10 and 11)
   What each family uses of the plant comes from the routings, multiplied by what was made; what the plant had
      comes from its calendar. Both are joins and sums over the year's work orders, which SQL handles
      directly.
   For each family's 2026 completions, return the work orders, units, average batch size, run hours and setup
      hours by work center, and material issue lines, and express setup hours and issue lines per thousand
      units.
   For each work center, return the hours available in 2026, the practical capacity under @tbl-18-02, the
      routing time used, and its share of each.
   Explain in a sentence why routing time is the right measure of use here, and what it leaves out.
   Instructor note: 2026 completions by group (units / work orders / batch / setup hours per 1,000 units /
      issue lines per 1,000 units): Furniture 28,052.6 / 2,604 / 10.8 / 127.9 / 543.3; Lighting 18,865.1 /
      1,160 / 16.3 / 57.8 / 257.0; Textiles 4,242.3 / 220 / 19.3 / 54.7 / 279.6. Furniture's small batches
      carry twice the setup per unit. Routing time on 2026 completions: run 68,912.79 hours (equal to the
      standard labor hours) plus setup 4,910.11 = 73,822.90. Work centers (available / practical at 80% / used
      / of available / of practical): Cutting 25,655.58 / 20,524.46 / 12,313.7 / 48.0% / 60.0%; Assembly
      55,177.04 / 44,141.63 / 34,435.8 / 62.4% / 78.0%; Finishing and Test 30,234.03 / 24,187.22 / 19,064.8 /
      63.1% / 78.8%; Packing 13,809.10 / 11,047.28 / 7,648.5 / 55.4% / 69.2%; Quality Assurance 3,957.50 /
      3,166.00 / 360.2 / 9.1% / 11.4%; plant 128,833.25 / 103,066.60 / 73,822.9 / 57.3% / 71.6%. Routing time
      measures what the products should use; it leaves out the indirect time and the hours beyond the work
      that Part III found, which are exactly what the unused capacity of Requirement 4 will hold.

   Requirement 4: Compute three costs for each family (Chapter 7)
   Each cost is a formula over a handful of inputs that the decision makers will want to change, which makes
      this workbook work: one Assumptions sheet, every cost a formula, and every assumption a cell.
   Compute each manufactured item's cost under the three views. Standard is the item's standard cost. Actual
      absorption adds its family's variance per unit completed. Time-driven costs material, with the 2026
      material variance as a rate; the Factory Overhead entries per standard hour; and the committed costs of
      the crew (every hourly manufacturing employee), supervision, and equipment per hour of practical
      capacity, times the item's routing time per unit, with setup spread over the family's average batch.
   Show the unused capacity as its own line, and reconcile the products' costs plus the unused capacity to the
      inputs to 1090.
   Summarize by family at the 2026 mix of items sold, with the margin under each view, and find the share of
      margin the top fifth of items earns under each.
   Add a Data Table of practical capacity from 75% to 90% of available hours, and explain what moves and what
      barely moves. Excel takes a data table's input cell only from the table's own worksheet, so keep the
      practical share that the cost formulas use in a cell on that sheet.
   Keep the item costs as an Excel Table, so that Power BI can load them.
   Instructor note: committed cost 4,119,063.77 = hourly crew 3,515,852.70 (64 employees; gross 3,079,544.37,
      employer tax 235,585.02, benefits 200,723.31) + salaried staff 299,544.44 (3; gross 263,191.24) +
      depreciation 303,666.63; practical capacity 103,066.6 hours; rate 39.9651 an hour (crew 34.1124,
      supervision and equipment 5.8526); Factory Overhead 18.9931 per standard hour; material variance rate
      1.059% of standard material completed. Products' conversion 4,259,206.41; unused capacity 29,243.7
      hours, 1,168,726.42 (crew 997,573.76); total 5,427,932.83 = the inputs to 1090. Per unit at the 2026 mix
      (price / standard / absorption / time-driven / time-driven margin): FUR-BKC 592.33 / 359.14 / 411.47 /
      380.16 / 35.8%; FUR-BNH 608.92 / 378.70 / 441.18 / 399.01 / 34.5%; FUR-CON 622.40 / 336.49 / 391.97 /
      356.34 / 42.7%; FUR-CTB 562.33 / 324.10 / 377.37 / 348.59 / 38.0%; FUR-DSK 652.99 / 363.51 / 412.74 /
      385.34 / 41.0%; FUR-NGT 489.36 / 285.97 / 338.29 / 308.67 / 36.9%; FUR-SDB 550.02 / 310.77 / 373.00 /
      338.07 / 38.5%; FUR-TBL 566.31 / 332.28 / 395.90 / 357.64 / 36.8%; LGT-CHD 313.29 / 182.68 / 205.79 /
      197.27 / 37.0%; LGT-FLR 246.41 / 128.35 / 150.10 / 145.67 / 40.9%; LGT-PND 389.96 / 210.83 / 244.81 /
      231.18 / 40.7%; LGT-SCN 326.73 / 169.92 / 204.03 / 188.24 / 42.4%; LGT-TBL 290.31 / 146.93 / 171.17 /
      163.79 / 43.6%; TXT-CRT 434.82 / 230.04 / 259.49 / 251.98 / 42.0%; TXT-PIL 366.13 / 158.86 / 193.42 /
      180.09 / 50.8%; TXT-THR 580.99 / 277.64 / 326.55 / 305.55 / 47.4%. Group time-driven margins: Furniture
      38.23%, Lighting 41.23%, Textiles 45.96%. Time-driven sits between standard and absorption for every
      family: the products cost more than their standards say (the standards miss the rate increase,
      supervision, and depreciation; 1,008,586.26 in total) but less than absorption says (idle capacity is
      not theirs; 1,069,728.92), nearer standard for Furniture and nearer absorption for Lighting and
      Textiles. Top fifth of the 207 finished goods sold (41 items) earns 51.2% of margin at standard, 50.6%
      under absorption, 50.7% time-driven; no item loses money under any view (lowest under absorption LGT-
      SCN-0011, 12.6%). Data Table at 75 / 80 / 85 / 90%: rate 42.63 / 39.97 / 37.61 / 35.52; unused capacity
      972,037 / 1,168,726 / 1,342,276 / 1,496,542; FUR-TBL 362.79 / 357.64 / 353.10 / 349.06. Product costs
      move by a few dollars; the unused capacity moves by hundreds of thousands.

   Requirement 6: Decide make or buy, family by family (Chapter 7)
   The comparison is a few lines per family, with two assumptions that the decision turns on: the quote and
      what happens to the crew. A workbook lets the decision makers change both and watch the answer move.
   For each quoted family, compute the relevant cost per unit with the crew kept, which is materials and the
      overhead that varies, and with the crew reduced in step with the hours freed, which adds the crew's cost
      of the routing time. Compare each with the delivered quote, and compute the annual effect at the 2026
      volume.
   Add the one-time costs for the families you would buy: tooling, and severance for the positions no longer
      needed under @tbl-18-02. Show the effect over the two years the prices are fixed.
   Use Goal Seek for the quote at which each family breaks even under each crew case, and build a two-way Data
      Table of the quote, 10% either side, against the share of the freed crew time actually removed, for the
      families you would buy taken together.
   Set the CFO's absorption view beside your answer, and explain in two sentences why the two disagree.
   List the terms that the numbers leave out.
   ::: {.callout-warning .watch-out icon=false}
   Instructor note: per unit (crew kept / crew reduced / delivered quote; annual effect of buying at 2026
      volume under absorption / crew kept / crew reduced; break-even quote kept / reduced): FUR-BNH 332.16 /
      389.22 / 334.75; +154,853 / -3,773 / +79,249; 322.48 / 377.88. FUR-NGT 243.27 / 299.09 / 278.10;
      +192,550 / -111,432 / +67,149; 236.18 / 290.38. FUR-SDB 267.98 / 327.81 / 334.75; +144,571 / -252,392 /
      -26,237; 260.17 / 318.26. FUR-TBL 280.42 / 346.34 / 324.45; +356,123 / -219,431 / +109,084; 272.26 /
      336.25. LGT-SCN 143.68 / 181.72 / 185.40; +85,551 / -191,571 / -16,917; 139.49 / 176.42. TXT-PIL 138.64
      / 174.02 / 226.60; -22,341 / -59,222 / -35,404; 134.60 / 168.95. (Relevant cost kept = material x 1.0106
      + 18.99 x standard hours; reduced adds 34.11 x routing hours per unit.) The CFO's absorption view says
      buy five of six; on relevant costs, buy only BNH, NGT, and TBL, and only with the crew reduced: +255,481
      a year; their routing time at 2026 volume 17,299 hours, 10.56 positions of 1,638.4 hours; severance 8
      weeks x 40 hours x 30.38 = 9,722.90 a position, 102,660; tooling 70,000; two-year net about +338,302.
      With the crew kept, buying the three costs 334,636 a year. Two-way table (crew removed 0 / 50 / 100%;
      quote -10 / 0 / +10%): -35,263 / -334,636 / -634,009; +259,796 / -39,578 / -338,951; +554,854 / +255,481
      / -43,892. Make SDB, SCN, and PIL under any crew case. Left out: the 80% minimum (the quoted volumes are
      within 4% of 2026 sales, family by family), quality and the 1.5% defect threshold, lead time and
      inventory, the designs and bills of material shared with a supplier, the price risk after two years, and
      the materials stock of the Part IV case (the three families used 2,465,127.57 of standard material in
      their 2026 completions; their work orders drew 2,485,926.61, 24% of the year's issues of 10,161,204.64,
      of which 1,782,126 was the six raw materials that carry the Part IV build, so buying them slows its
      drawdown).

   Requirement 7: Value the capacity that buying would free (Chapter 7)
   Measure the hours that buying the families of Requirement 6 would free at each work center, and the plant's
      use of its practical capacity afterwards.
   Compare them with the capacity the plant already leaves unused, in hours and in positions, and explain what
      that comparison means for the decision.
   Show what happens to the cost of the remaining families if the crew is kept.
   Optional: with Solver, find which families to buy if volume grew by 40% and by 50%, minimizing the added
      cost with the crew kept and practical capacity at each work center as the limit, and report which work
      center binds and its shadow price.
   Instructor note: buying BNH, NGT, and TBL frees (2026 production) Cutting 3,884, Assembly 7,607, Finishing
      4,596, Packing 1,708 hours, 17,795 in all; plant use of practical capacity falls from 71.6% to 54.4%.
      The plant already leaves 29,243.7 practical hours unused, 17.85 positions, more than buying would free:
      fitting the crew to the work matters more than outsourcing, and the production manager's point that idle
      capacity is not the products' fault is right but cuts both ways, because it is still a cost. If the crew
      is kept, its 17,299 hours on those families (about 590,117, sales basis) become unused capacity, and the
      supervision and equipment the three families carried (about 101,246) spreads over the rest, so their
      absorption cost rises. Practical capacity over 2026 use (sales basis): Cutting 1.80, Assembly 1.40,
      Finishing 1.40, Packing 1.58, QA 10.24, so growth of about 40% reaches the first limit. Solver (Simplex
      LP, buying the quoted families at their crew-kept extra cost): +40%, Finishing binds (shadow price about
      6.01 an hour), buy about 151 BNH, extra cost about 391; +50%, Assembly binds (about 49.98), buy all
      2,182 BNH and about 2,311 NGT, extra cost about 86,177.

   Requirement 8: Reprice the families below the floor (Chapter 7)
   Use Goal Seek for the price at which each family reaches the margin floor of @tbl-18-02 on its time-driven
      cost, and compute the increase and the share of volume the increase could lose before the family earns
      less contribution than it does now, measuring contribution over the relevant cost with the crew kept.
   Set those figures against the evidence on how Charles River's customers respond to price: test whether
      order volume rose in the months of past promotions, and check the dates and use of the price lists, as
      Exercise 8.6 did. Recommend increases, and how the lists should be rebuilt.
   Show how the answer changes for any family you would buy in Requirement 6.
   ::: {.callout-tip .in-practice icon=false}
   Instructor note: families below the 40% floor on time-driven cost and the increase that reaches it (volume
      loss the increase absorbs, on the crew-kept contribution margin): FUR-BKC +6.97% (12.7%), FUR-BNH +9.21%
      (16.9%), FUR-CTB +3.32% (6.1%), FUR-NGT +5.13% (9.3%), FUR-SDB +2.44% (4.5%), FUR-TBL +5.26% (9.4%),
      LGT-CHD +4.94% (9.2%); +556,535 of revenue a year if volume holds. If BNH, NGT, and TBL are bought,
      their delivered margins are 45.0%, 43.2%, and 42.7%, so only BKC, CTB, SDB, and CHD need increases.
      Evidence: no promotion raised volume (Part II case); active price lists run at 0.84 to 0.94 of list and
      every one ended 2026-12-31, and lists 1, 2, and 4 had expired yet were still used (Exercise 8.6); the
      Sales Manager approves overrides; so the increases need new, approved lists for 2028 with stated end
      dates, and customer-specific lists should be renegotiated, not inherited.

   Requirement 9: Revise the standards, and measure what they mean for the statements (Chapter 9)
   Standards serve inventory as well as decisions. The inventory standard of U.S. generally accepted
      accounting principles (Financial Accounting Standards Board Accounting Standards Codification Topic 330)
      allocates fixed production overhead on the normal capacity of the facilities and charges abnormal costs,
      such as idle facility expense, to the period. The workbook can rebuild a standard from the plan in
      @tbl-18-02 and revalue the stock it applies to.
   Propose a standard conversion rate per standard hour on normal capacity, the plan volume of @tbl-18-02 at
      its hours per standard hour: the labor rate with burden for the direct and the normal indirect hours,
      the overhead that varies, and the plan's supervision and depreciation spread over the plan volume.
      Compare it with the current rate, the time-driven rate, and 2026's actual cost, and explain why a
      standard built on 2026's actual cost would carry idle capacity into inventory.
   Revalue the manufactured finished goods made since the ledger opened and still on hand at the end of fiscal
      2024, 2025, and 2026, and measure the effect on retained earnings at the start of fiscal 2025, on 2025
      and 2026 income, and on each balance sheet, against the materiality of @tbl-18-02. Show how the answer
      depends on what you treat as normal capacity.
   The company issued its fiscal 2025 and 2026 statements to its shareholders. Recommend whether the
      correction belongs in the next statements or calls for revised ones, and what the CFO should tell the
      shareholders.
   Instructor note: proposed rate per standard hour on the Part III plan (68,912.79 standard hours, 1.18 hours
      per standard hour): direct labor 26.62 x 1.1414 = 30.38; overhead that varies 18.99; indirect labor at
      plan 0.18 x 30.38 = 5.47; supervision 263,191.24 x 1.1414 / 68,912.79 = 4.36; depreciation 293,499.96 /
      68,912.79 = 4.26; total 63.46 (58.00 at 1.0 hours). Current 47.40; time-driven 61.81; 2026 actual 78.77,
      which includes idle capacity and the hours beyond the work (Part III), abnormal under Topic 330. Revised
      standard costs (time-driven beside): BNH 398.17 (399.01), NGT 306.99 (308.67), SDB 337.91 (338.07), TBL
      358.19 (357.64), SCN 189.74 (188.24), PIL 180.97 (180.09). Manufactured finished goods made since the
      opening and on hand (completions less shipments plus returns, by item; FUR-SDB-0006 at 2024 and FUR-
      DSK-0044 at 2026 are negative, proof of opening stock, and left out): 2024 11,880.3 units, 16,482.8
      standard hours, conversion 788,641.14 (47.85 an hour); 2025 17,103.3, 23,116.1, 1,097,455.36; 2026
      21,883.6, 29,522.4, 1,402,508.30 (5,627,028.26 at standard). Revaluation at 63.46: +257,435 / +369,596 /
      +471,117; at 1.0 hours (58.00): +167,288 / +243,171 / +309,655; time-driven +230,093 / +331,251 /
      +422,145; at 2026 actual +922,829 (capitalizing idle capacity). Effect on the fiscal 2025 and 2026
      statements at 63.46: retained earnings at 1 January 2025 +257,435, 2025 income +112,161, 2026 income
      +101,521; balance sheet +369,596 (2025) and +471,117 (2026), both above the materiality of tbl-18-02
      (256,717.74 and 225,180.56), while the income effects are below it; at 1.0 hours the 2025 balance
      (243,171) falls below materiality and 2026's (309,655) stays above. The rates are 2027's plan applied to
      2024-2026 stock, an approximation a strong answer names. A strong answer judges the balance sheet effect
      material on the plan's definition of normal capacity, recommends revised statements for the shareholders
      (inventories, retained earnings, and income corrected, with the correction disclosed), or, if the CFO
      judges it immaterial on a narrower definition, a correction in the next statements with disclosure; the
      decision is the CFO's. The opening 4,111,795.76 of finished goods has no item detail and is left out.

   Milestone 1: What the records show
   (Requirements 1 to 3): the family results, the inputs to 1090 with their behavior tests, and the capacity
      table.
   Instructor note: Furniture margin 42.33% at standard, 32.56% after the variance per unit completed, 31.64%
      with the year's variance (Lighting 46.96 / 37.96 / 36.96; Textiles 50.96 / 42.99 / 43.02); family
      variances 2,265,636.88; inputs to 1090 5,427,932.83 against 3,266,422.54 released; Factory Overhead r
      0.975, payroll r 0.066; the plant uses 71.6% of its practical capacity.

   Milestone 2: What a product costs
   (Requirements 4 and 5): the three costs for each family, the unused capacity reconciled to 1090, and the
      explorer.
   Instructor note: committed cost 4,119,063.77; 39.97 an hour (crew 34.11); unused capacity 29,243.7 hours,
      1,168,726; time-driven group margins Furniture 38.23%, Lighting 41.23%, Textiles 45.96%; explorer
      margins (item costs unrounded, as the explorer reads them) 12,739,803.20 (standard), 10,661,488.03
      (absorption), 11,731,216.94 (time-driven) on revenue of 28,543,076.08.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   Requirement 1: the workbook's pasted result (dates): 1 row of 4 columns, equal
   Requirement 1: last invoice: 2026-12-31
   Requirement 1: last time record: 2026-12-11
   Requirement 1: the workbook's pasted result (family): 16 rows of 16 columns, equal
   Requirement 1: families sold: ['FUR-BKC', 'FUR-BNH', 'FUR-CON', 'FUR-CTB', 'FUR-DSK', 'FUR-NGT', 'FUR-SDB',
      'FUR-TBL', 'LGT-CHD', 'LGT-FLR', 'LGT-PND', 'LGT-SCN', 'LGT-TBL', 'TXT-CRT', 'TXT-PIL', 'TXT-THR']
   Requirement 1: the families' variance: 2,265,636.88
   Requirement 1: material variance: 106,498.85
   Requirement 1: labor variance: -14,074.81
   Requirement 1: overhead variance: 2,173,212.84
   Requirement 1: FUR-BKC units sold: 1,954.98
   Requirement 1: FUR-BKC revenue: 1,158,000.85
   Requirement 1: FUR-BKC closes: 179
   Requirement 1: FUR-BKC variance: 106,587.95
   Requirement 1: FUR-BNH units sold: 1,454.93
   Requirement 1: FUR-BNH revenue: 885,941.44
   Requirement 1: FUR-BNH closes: 152
   Requirement 1: FUR-BNH variance: 111,599.30
   Requirement 1: FUR-CON units sold: 1,321.69
   Requirement 1: FUR-CON revenue: 822,620.94
   Requirement 1: FUR-CON closes: 165
   Requirement 1: FUR-CON variance: 104,967.73
   Requirement 1: FUR-CTB units sold: 4,360.99
   Requirement 1: FUR-CTB revenue: 2,452,336.51
   Requirement 1: FUR-CTB closes: 490
   Requirement 1: FUR-CTB variance: 280,253.94
   Requirement 1: FUR-DSK units sold: 4,567.43
   Requirement 1: FUR-DSK revenue: 2,982,469.82
   Requirement 1: FUR-DSK closes: 439
   Requirement 1: FUR-DSK variance: 235,254.95
   Requirement 1: FUR-NGT units sold: 3,198.85
   Requirement 1: FUR-NGT revenue: 1,565,380.69
   Requirement 1: FUR-NGT closes: 331
   Requirement 1: FUR-NGT variance: 167,618.64
   Requirement 1: FUR-SDB units sold: 3,779.96
   Requirement 1: FUR-SDB revenue: 2,079,063.38
   Requirement 1: FUR-SDB closes: 370
   Requirement 1: FUR-SDB variance: 259,360.59
   Requirement 1: FUR-TBL units sold: 4,984.11
   Requirement 1: FUR-TBL revenue: 2,822,552.50
   Requirement 1: FUR-TBL closes: 462
   Requirement 1: FUR-TBL variance: 313,491.13
   Requirement 1: LGT-CHD units sold: 2,167.06
   Requirement 1: LGT-CHD revenue: 678,919.89
   Requirement 1: LGT-CHD closes: 138
   Requirement 1: LGT-CHD variance: 52,219.07
   Requirement 1: LGT-FLR units sold: 4,404.37
   Requirement 1: LGT-FLR revenue: 1,085,286.98
   Requirement 1: LGT-FLR closes: 321
   Requirement 1: LGT-FLR variance: 113,365.27
   Requirement 1: LGT-PND units sold: 2,773.23
   Requirement 1: LGT-PND revenue: 1,081,462.36
   Requirement 1: LGT-PND closes: 207
   Requirement 1: LGT-PND variance: 104,786.77
   Requirement 1: LGT-SCN units sold: 4,591.42
   Requirement 1: LGT-SCN revenue: 1,500,136.53
   Requirement 1: LGT-SCN closes: 274
   Requirement 1: LGT-SCN variance: 170,490.55
   Requirement 1: LGT-TBL units sold: 2,976.16
   Requirement 1: LGT-TBL revenue: 864,006.77
   Requirement 1: LGT-TBL closes: 213
   Requirement 1: LGT-TBL variance: 80,274.14
   Requirement 1: TXT-CRT units sold: 1,657.02
   Requirement 1: TXT-CRT revenue: 720,512.88
   Requirement 1: TXT-CRT closes: 99
   Requirement 1: TXT-CRT variance: 52,879.36
   Requirement 1: TXT-PIL units sold: 673.29
   Requirement 1: TXT-PIL revenue: 246,514.48
   Requirement 1: TXT-PIL closes: 27
   Requirement 1: TXT-PIL variance: 17,307.85
   Requirement 1: TXT-THR units sold: 1,920.52
   Requirement 1: TXT-THR revenue: 1,115,802.11
   Requirement 1: TXT-THR closes: 93
   Requirement 1: TXT-THR variance: 95,179.64
   Requirement 1: ACC-CDL not sold in 2026: False
   Requirement 1: FUR-BKC variance as a share of standard completed: 0.15
   Requirement 1: FUR-BKC variance per unit completed: 52.33
   Requirement 1: FUR-BKC margin at standard: 0.39
   Requirement 1: FUR-BKC margin after the variance per unit: 0.31
   Requirement 1: FUR-BKC margin with the year's variance: 0.30
   Requirement 1: FUR-BKC purchased margin at standard: None
   Requirement 1: FUR-BNH variance as a share of standard completed: 0.16
   Requirement 1: FUR-BNH variance per unit completed: 62.48
   Requirement 1: FUR-BNH margin at standard: 0.38
   Requirement 1: FUR-BNH margin after the variance per unit: 0.28
   Requirement 1: FUR-BNH margin with the year's variance: 0.25
   Requirement 1: FUR-BNH purchased margin at standard: 0.48
   Requirement 1: FUR-CON variance as a share of standard completed: 0.15
   Requirement 1: FUR-CON variance per unit completed: 55.48
   Requirement 1: FUR-CON margin at standard: 0.46
   Requirement 1: FUR-CON margin after the variance per unit: 0.37
   Requirement 1: FUR-CON margin with the year's variance: 0.33
   Requirement 1: FUR-CON purchased margin at standard: 0.43
   Requirement 1: FUR-CTB variance as a share of standard completed: 0.17
   Requirement 1: FUR-CTB variance per unit completed: 53.27
   Requirement 1: FUR-CTB margin at standard: 0.42
   Requirement 1: FUR-CTB margin after the variance per unit: 0.33
   Requirement 1: FUR-CTB margin with the year's variance: 0.31
   Requirement 1: FUR-CTB purchased margin at standard: 0.38
   Requirement 1: FUR-DSK variance as a share of standard completed: 0.15
   Requirement 1: FUR-DSK variance per unit completed: 49.23
   Requirement 1: FUR-DSK margin at standard: 0.44
   Requirement 1: FUR-DSK margin after the variance per unit: 0.37
   Requirement 1: FUR-DSK margin with the year's variance: 0.36
   Requirement 1: FUR-DSK purchased margin at standard: 0.45
   Requirement 1: FUR-NGT variance as a share of standard completed: 0.18
   Requirement 1: FUR-NGT variance per unit completed: 52.33
   Requirement 1: FUR-NGT margin at standard: 0.42
   Requirement 1: FUR-NGT margin after the variance per unit: 0.31
   Requirement 1: FUR-NGT margin with the year's variance: 0.31
   Requirement 1: FUR-NGT purchased margin at standard: 0.44
   Requirement 1: FUR-SDB variance as a share of standard completed: 0.20
   Requirement 1: FUR-SDB variance per unit completed: 62.23
   Requirement 1: FUR-SDB margin at standard: 0.43
   Requirement 1: FUR-SDB margin after the variance per unit: 0.32
   Requirement 1: FUR-SDB margin with the year's variance: 0.31
   Requirement 1: FUR-SDB purchased margin at standard: 0.41
   Requirement 1: FUR-TBL variance as a share of standard completed: 0.19
   Requirement 1: FUR-TBL variance per unit completed: 63.62
   Requirement 1: FUR-TBL margin at standard: 0.41
   Requirement 1: FUR-TBL margin after the variance per unit: 0.30
   Requirement 1: FUR-TBL margin with the year's variance: 0.30
   Requirement 1: FUR-TBL purchased margin at standard: 0.44
   Requirement 1: LGT-CHD variance as a share of standard completed: 0.13
   Requirement 1: LGT-CHD variance per unit completed: 23.12
   Requirement 1: LGT-CHD margin at standard: 0.42
   Requirement 1: LGT-CHD margin after the variance per unit: 0.34
   Requirement 1: LGT-CHD margin with the year's variance: 0.34
   Requirement 1: LGT-CHD purchased margin at standard: 0.48
   Requirement 1: LGT-FLR variance as a share of standard completed: 0.18
   Requirement 1: LGT-FLR variance per unit completed: 21.75
   Requirement 1: LGT-FLR margin at standard: 0.48
   Requirement 1: LGT-FLR margin after the variance per unit: 0.39
   Requirement 1: LGT-FLR margin with the year's variance: 0.37
   Requirement 1: LGT-FLR purchased margin at standard: 0.46
   Requirement 1: LGT-PND variance as a share of standard completed: 0.16
   Requirement 1: LGT-PND variance per unit completed: 33.98
   Requirement 1: LGT-PND margin at standard: 0.46
   Requirement 1: LGT-PND margin after the variance per unit: 0.37
   Requirement 1: LGT-PND margin with the year's variance: 0.36
   Requirement 1: LGT-PND purchased margin at standard: 0.42
   Requirement 1: LGT-SCN variance as a share of standard completed: 0.21
   Requirement 1: LGT-SCN variance per unit completed: 34.12
   Requirement 1: LGT-SCN margin at standard: 0.48
   Requirement 1: LGT-SCN margin after the variance per unit: 0.38
   Requirement 1: LGT-SCN margin with the year's variance: 0.37
   Requirement 1: LGT-SCN purchased margin at standard: 0.46
   Requirement 1: LGT-TBL variance as a share of standard completed: 0.17
   Requirement 1: LGT-TBL variance per unit completed: 24.24
   Requirement 1: LGT-TBL margin at standard: 0.49
   Requirement 1: LGT-TBL margin after the variance per unit: 0.41
   Requirement 1: LGT-TBL margin with the year's variance: 0.40
   Requirement 1: LGT-TBL purchased margin at standard: 0.44
   Requirement 1: TXT-CRT variance as a share of standard completed: 0.13
   Requirement 1: TXT-CRT variance per unit completed: 29.45
   Requirement 1: TXT-CRT margin at standard: 0.47
   Requirement 1: TXT-CRT margin after the variance per unit: 0.40
   Requirement 1: TXT-CRT margin with the year's variance: 0.40
   Requirement 1: TXT-CRT purchased margin at standard: 0.49
   Requirement 1: TXT-PIL variance as a share of standard completed: 0.22
   Requirement 1: TXT-PIL variance per unit completed: 34.56
   Requirement 1: TXT-PIL margin at standard: 0.57
   Requirement 1: TXT-PIL margin after the variance per unit: 0.47
   Requirement 1: TXT-PIL margin with the year's variance: 0.50
   Requirement 1: TXT-PIL purchased margin at standard: 0.41
   Requirement 1: TXT-THR variance as a share of standard completed: 0.18
   Requirement 1: TXT-THR variance per unit completed: 48.91
   Requirement 1: TXT-THR margin at standard: 0.52
   Requirement 1: TXT-THR margin after the variance per unit: 0.44
   Requirement 1: TXT-THR margin with the year's variance: 0.44
   Requirement 1: TXT-THR purchased margin at standard: 0.45
   Requirement 1: families whose purchased margin is below their margin after the variance per unit: ['TXT-
      PIL']
   Requirement 1: Furniture revenue: 14,768,366.13
   Requirement 1: Furniture variance: 1,579,134.23
   Requirement 1: Furniture margin at standard: 0.42
   Requirement 1: Furniture margin after the variance per unit: 0.33
   Requirement 1: Furniture margin with the year's variance: 0.32
   Requirement 1: Lighting revenue: 5,209,812.53
   Requirement 1: Lighting variance: 521,135.80
   Requirement 1: Lighting margin at standard: 0.47
   Requirement 1: Lighting margin after the variance per unit: 0.38
   Requirement 1: Lighting margin with the year's variance: 0.37
   Requirement 1: Textiles revenue: 2,082,829.47
   Requirement 1: Textiles variance: 165,366.85
   Requirement 1: Textiles margin at standard: 0.51
   Requirement 1: Textiles margin after the variance per unit: 0.43
   Requirement 1: Textiles margin with the year's variance: 0.43
   Requirement 1: Milestone 1: Furniture margin at standard: 0.42
   Requirement 1: Milestone 1: Furniture margin with the year's variance: 0.32
   Requirement 1: the workbook's pasted result (ledger5080): 1 row of 1 columns, equal
   Requirement 1: 5080: 2,265,636.88
   Requirement 1: family variances: 2,265,636.88
   Requirement 1: 5080: 2,265,636.88
   Requirement 1: difference: 0.00
   Requirement 1: Milestone 1: family variances: 2,265,636.88
   Requirement 1: the workbook's pasted result (purchased): 22 rows of 6 columns, equal
   Requirement 1: purchased cost over standard, all families: 1.01
   Requirement 1: lowest cost to standard: 0.95
   Requirement 1: highest cost to standard: 1.07
   Requirement 1: BNH purchased cost to list: 0.47
   Requirement 1: NGT purchased cost to list: 0.48
   Requirement 1: SDB purchased cost to list: 0.52
   Requirement 1: TBL purchased cost to list: 0.48
   Requirement 1: SCN purchased cost to list: 0.49
   Requirement 1: PIL purchased cost to list: 0.54
   Requirement 1: the workbook's pasted result (premises): 1 row of 5 columns, equal
   Requirement 1: invoice lines: 27933
   Requirement 1: list prices that differ: 0
   Requirement 1: shipment costs that differ: 0
   Requirement 1: largest completion difference: 0.02
   Requirement 1: items sold in every year: 198
   Requirement 2: the workbook's pasted result (payroll): 7 rows of 4 columns, equal
   Requirement 2: payroll lines: 7
   Requirement 2: payroll to 1090: 3,815,397.14
   Requirement 2: Employer Benefits amount: 216,942.37
   Requirement 2: Employer Payroll Tax amount: 255,719.16
   Requirement 2: Overtime Earnings, Direct Manufacturing amount: 682,821.11
   Requirement 2: Overtime Earnings, Direct Manufacturing hours: 17,105.10
   Requirement 2: Overtime Earnings, Indirect Manufacturing amount: 131,908.30
   Requirement 2: Overtime Earnings, Indirect Manufacturing hours: 3,306.00
   Requirement 2: Regular Earnings, Direct Manufacturing amount: 1,253,247.29
   Requirement 2: Regular Earnings, Direct Manufacturing hours: 47,020.53
   Requirement 2: Regular Earnings, Indirect Manufacturing amount: 1,011,567.67
   Requirement 2: Regular Earnings, Indirect Manufacturing hours: 38,030.54
   Requirement 2: Salary Earnings amount: 263,191.24
   Requirement 2: the workbook's pasted result (debits1090): 3 rows of 2 columns, equal
   Requirement 2: inputs to 1090: 5,427,932.83
   Requirement 2: Factory Overhead entries: 1,308,869.06
   Requirement 2: depreciation: 303,666.63
   Requirement 2: payroll: 3,815,397.14
   Requirement 2: Milestone 1: inputs to 1090: 5,427,932.83
   Requirement 2: the workbook's pasted result (released): 1 row of 7 columns, equal
   Requirement 2: standard hours: 68,912.79
   Requirement 2: labor released: 1,948,859.23
   Requirement 2: variable overhead released: 746,606.73
   Requirement 2: fixed overhead released: 570,955.99
   Requirement 2: conversion on the lines: 3,266,421.95
   Requirement 2: ProductionCompletion credits to 1090: 3,266,422.54
   Requirement 2: Milestone 1: released: 3,266,422.54
   Requirement 2: inputs per standard hour: 78.77
   Requirement 2: released per standard hour: 47.40
   Requirement 2: labor released per standard hour: 28.28
   Requirement 2: overhead released per standard hour: 19.12
   Requirement 2: direct earnings: 1,936,068.40
   Requirement 2: actual overhead: 3,491,864.43
   Requirement 2: actual overhead per standard hour: 50.67
   Requirement 2: actual overhead over applied: 2.65
   Requirement 2: applied over actual (the CFO's 'a third'): 0.38
   Requirement 2: the workbook's pasted result (monthly): 36 rows of 7 columns, equal
   Requirement 2: months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06', '2024-07',
      '2024-08', '2024-09', '2024-10', '2024-11', '2024-12', '2025-01', '2025-02', '2025-03', '2025-04',
      '2025-05', '2025-06', '2025-07', '2025-08', '2025-09', '2025-10', '2025-11', '2025-12', '2026-01',
      '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09', '2026-10',
      '2026-11', '2026-12']
   Requirement 2: Factory Overhead entries in 2026: 1,308,869.06
   Requirement 2: payroll in 2026: 3,815,397.14
   Requirement 2: depreciation in 2026: 303,666.63
   Requirement 2: standard hours in 2026: 68,912.79
   Requirement 2: Factory Overhead entries over the overhead applied, by year: [1.001, 1.003, 0.993]
   Requirement 2: months with three pay dates: ['2024-03', '2024-08', '2025-01', '2025-08', '2026-01',
      '2026-07']
   Requirement 2: 2026 depreciation by month (its schedule): [24625.0, 26958.33, 26958.33, 26958.33, 26958.33,
      24458.33, 24458.33, 24458.33, 24458.33, 24458.33, 24458.33, 24458.33]
   Requirement 3: the workbook's pasted result (activity): 16 rows of 15 columns, equal
   Requirement 3: run hours: 68,912.79
   Requirement 3: setup hours: 4,910.11
   Requirement 3: work orders: 3984
   Requirement 3: FUR-BKC average batch: 11.44
   Requirement 3: FUR-BNH average batch: 11.91
   Requirement 3: FUR-CON average batch: 11.61
   Requirement 3: FUR-CTB average batch: 10.61
   Requirement 3: FUR-DSK average batch: 10.88
   Requirement 3: FUR-NGT average batch: 9.56
   Requirement 3: FUR-SDB average batch: 11.08
   Requirement 3: FUR-TBL average batch: 10.55
   Requirement 3: LGT-CHD average batch: 16.02
   Requirement 3: LGT-FLR average batch: 16.44
   Requirement 3: LGT-PND average batch: 14.62
   Requirement 3: LGT-SCN average batch: 17.66
   Requirement 3: LGT-TBL average batch: 15.92
   Requirement 3: TXT-CRT average batch: 18.13
   Requirement 3: TXT-PIL average batch: 17.89
   Requirement 3: TXT-THR average batch: 20.93
   Requirement 3: Furniture units: 28,052.60
   Requirement 3: Furniture work orders: 2604
   Requirement 3: Furniture average batch: 10.77
   Requirement 3: Furniture setup hours per thousand units: 127.91
   Requirement 3: Furniture issue lines per thousand units: 543.30
   Requirement 3: Lighting units: 18,865.12
   Requirement 3: Lighting work orders: 1160
   Requirement 3: Lighting average batch: 16.26
   Requirement 3: Lighting setup hours per thousand units: 57.77
   Requirement 3: Lighting issue lines per thousand units: 257.04
   Requirement 3: Textiles units: 4,242.34
   Requirement 3: Textiles work orders: 220
   Requirement 3: Textiles average batch: 19.28
   Requirement 3: Textiles setup hours per thousand units: 54.72
   Requirement 3: Textiles issue lines per thousand units: 279.56
   Requirement 3: the group with the most setup per unit: Furniture
   Requirement 3: the workbook's pasted result (calendar): 5 rows of 4 columns, equal
   Requirement 3: available hours: 128,833.25
   Requirement 3: plant available: 128,833.25
   Requirement 3: plant practical: 103,066.60
   Requirement 3: plant run hours: 68,912.79
   Requirement 3: plant setup hours: 4,910.11
   Requirement 3: plant routing hours: 73,822.90
   Requirement 3: plant share of available: 0.57
   Requirement 3: plant share of practical: 0.72
   Requirement 3: unused practical hours: 29,243.70
   Requirement 3: Cutting available: 25,655.58
   Requirement 3: Cutting practical: 20,524.46
   Requirement 3: Cutting routing hours: 12,313.68
   Requirement 3: Cutting share of available: 0.48
   Requirement 3: Cutting share of practical: 0.60
   Requirement 3: Assembly available: 55,177.04
   Requirement 3: Assembly practical: 44,141.63
   Requirement 3: Assembly routing hours: 34,435.83
   Requirement 3: Assembly share of available: 0.62
   Requirement 3: Assembly share of practical: 0.78
   Requirement 3: Finishing and Test available: 30,234.03
   Requirement 3: Finishing and Test practical: 24,187.22
   Requirement 3: Finishing and Test routing hours: 19,064.76
   Requirement 3: Finishing and Test share of available: 0.63
   Requirement 3: Finishing and Test share of practical: 0.79
   Requirement 3: Packing available: 13,809.10
   Requirement 3: Packing practical: 11,047.28
   Requirement 3: Packing routing hours: 7,648.48
   Requirement 3: Packing share of available: 0.55
   Requirement 3: Packing share of practical: 0.69
   Requirement 3: Quality Assurance available: 3,957.50
   Requirement 3: Quality Assurance practical: 3,166.00
   Requirement 3: Quality Assurance routing hours: 360.16
   Requirement 3: Quality Assurance share of available: 0.09
   Requirement 3: Quality Assurance share of practical: 0.11
   Requirement 3: Milestone 1: share of practical capacity used: 0.72
   Requirement 3: Milestone 2: unused capacity hours: 29,243.70
   Requirement 4: the workbook's pasted result (payclass): 2 rows of 6 columns, equal
   Requirement 4: Hourly employees: 64
   Requirement 4: Hourly gross pay: 3,079,544.37
   Requirement 4: Hourly employer tax: 235,585.02
   Requirement 4: Hourly benefits: 200,723.31
   Requirement 4: Hourly with employer costs: 3,515,852.70
   Requirement 4: Salary employees: 3
   Requirement 4: Salary gross pay: 263,191.24
   Requirement 4: Salary employer tax: 20,134.14
   Requirement 4: Salary benefits: 16,219.06
   Requirement 4: Salary with employer costs: 299,544.44
   Requirement 6: the workbook's pasted result (materials): 1 row of 4 columns, equal
   Requirement 6: standard material completed: 2,465,127.57
   Requirement 6: issued to their work orders: 2,485,926.61
   Requirement 6: of which the six raw materials: 1,782,126.01
   Requirement 6: all issues (1045): 10,161,204.64
   Requirement 6: share of the year's issues: 0.24
   Requirement 7: Cutting hours freed: 3,883.91
   Requirement 7: Assembly hours freed: 7,607.32
   Requirement 7: Finishing hours freed: 4,596.02
   Requirement 7: Packing hours freed: 1,707.85
   Requirement 7: QA hours freed: 0.00
   Requirement 7: hours freed: 17,795.09
   Requirement 7: use of practical capacity before: 0.72
   Requirement 7: use of practical capacity after: 0.54
   Requirement 7: practical hours left unused today: 29,243.70
   Requirement 8: the workbook's pasted result (promotions): 9 rows of 18 columns, equal
   Requirement 8: promotions: 9
   Requirement 8: largest lift in a promotion's months (none unusual, Part II case): 0.12
   Requirement 8: promotion 1 months of its lines: 3,4
   Requirement 8: promotion 1 lift on the other months of its year: -0.03
   Requirement 8: promotion 2 months of its lines: 9,10
   Requirement 8: promotion 2 lift on the other months of its year: 0.12
   Requirement 8: promotion 3 months of its lines: 11
   Requirement 8: promotion 3 lift on the other months of its year: -0.21
   Requirement 8: promotion 4 months of its lines: 3,4
   Requirement 8: promotion 4 lift on the other months of its year: -0.15
   Requirement 8: promotion 5 months of its lines: 9,10
   Requirement 8: promotion 5 lift on the other months of its year: -0.06
   Requirement 8: promotion 6 months of its lines: 11
   Requirement 8: promotion 6 lift on the other months of its year: 0.03
   Requirement 8: promotion 7 months of its lines: 3,4
   Requirement 8: promotion 7 lift on the other months of its year: 0.00
   Requirement 8: promotion 8 months of its lines: 9,10
   Requirement 8: promotion 8 lift on the other months of its year: 0.00
   Requirement 8: promotion 9 months of its lines: 11
   Requirement 8: promotion 9 lift on the other months of its year: 0.03
   Requirement 8: the workbook's pasted result (pricelists): 14 rows of 9 columns, equal
   Requirement 8: expired lists used after their end: [1, 2, 4]
   Requirement 8: order lines priced after the end date: 8135
   Requirement 8: lowest price to list on an active list: 0.84
   Requirement 8: highest price to list on an active list: 0.94
   Requirement 8: end dates of the active lists in use: ['2026-12-31']
   Requirement 8: the workbook's pasted result (overrides): 1 row of 2 columns, equal
   Requirement 8: approvers: ['Sales Manager']
   Requirement 8: approved overrides: 409
   Requirement 9: the workbook's pasted result (plandep): 1 row of 1 columns, equal
   Requirement 9: depreciation of 2027: 293,499.96
   Requirement 9: the workbook's pasted result (onhand): 83 rows of 5 columns, equal
   Requirement 9: FUR-SDB-0006 negative at 2024 (opening stock): True
   Requirement 9: FUR-DSK-0044 negative at 2026 (opening stock): True
   Requirement 9: units on hand at 2024: 11,880.27
   Requirement 9: units on hand at 2025: 17,103.25
   Requirement 9: units on hand at 2026: 21,883.60
   Requirement 9: years: [2024, 2025, 2026]
   Requirement 9: 2024 units: 11,880.27
   Requirement 9: 2024 standard hours: 16,482.84
   Requirement 9: 2024 conversion at standard: 788,641.14
   Requirement 9: 2024 at standard cost: 3,102,007.67
   Requirement 9: 2024 conversion per standard hour: 47.85
   Requirement 9: 2025 units: 17,103.25
   Requirement 9: 2025 standard hours: 23,116.07
   Requirement 9: 2025 conversion at standard: 1,097,455.36
   Requirement 9: 2025 at standard cost: 4,496,529.80
   Requirement 9: 2025 conversion per standard hour: 47.48
   Requirement 9: 2026 units: 21,883.60
   Requirement 9: 2026 standard hours: 29,522.38
   Requirement 9: 2026 conversion at standard: 1,402,508.30
   Requirement 9: 2026 at standard cost: 5,627,028.26
   Requirement 9: 2026 conversion per standard hour: 47.51
   Requirement 9: the workbook's pasted result (income): 3 rows of 2 columns, equal
   Requirement 9: 2024 income before income taxes: 5,110,308.27
   Requirement 9: 2025 income before income taxes: 5,134,354.71
   Requirement 9: 2026 income before income taxes: 4,503,611.24
   Requirement 9: 2025 materiality: 256,717.74
   Requirement 9: 2026 materiality: 225,180.56
   Requirement 9: the workbook's pasted result (openingfg): 1 row of 2 columns, equal
   Requirement 9: opening finished goods: 4,111,795.76
*/
