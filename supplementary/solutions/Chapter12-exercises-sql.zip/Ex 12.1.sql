/* Ex 12.1.sql: cutoff of revenue, supplier invoices, and payroll at each year-end
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: revenue by delivery date; supplier invoices by posting date; payroll by work date; effects by fiscal year */

-- Exercise 12.1, test C1: revenue posted in a different fiscal year from the delivery
-- Population: all sales invoices (test L5); expected: no rows
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
)
SELECT si.InvoiceNumber, si.InvoiceDate, sh.ShipmentDate,
    sh.DeliveryDate, p.PostingDate, ROUND(si.SubTotal, 2) AS SubTotal
FROM SalesInvoice AS si
    INNER JOIN Shipped AS sh ON sh.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
WHERE strftime('%Y', p.PostingDate) <> strftime('%Y', sh.DeliveryDate)
ORDER BY p.PostingDate, si.InvoiceNumber;  -- Result: 23 rows

-- Exercise 12.1, test C2: invoices dated before their shipment, posted in the year of delivery
-- Population: all sales invoices; expected: no rows
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
)
SELECT si.InvoiceNumber, si.InvoiceDate, sh.ShipmentDate,
    sh.DeliveryDate, p.PostingDate, ROUND(si.SubTotal, 2) AS SubTotal
FROM SalesInvoice AS si
    INNER JOIN Shipped AS sh ON sh.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
WHERE strftime('%Y', p.PostingDate) = strftime('%Y', sh.DeliveryDate)
    AND si.InvoiceDate < sh.ShipmentDate
ORDER BY si.InvoiceNumber;  -- Result: 8 rows

-- Exercise 12.1, test C3: the effect of revenue cutoff on each fiscal year
-- Population: tests C1 and L6; expected: no effect in any year
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
),
Late AS (
    SELECT CAST(strftime('%Y', sh.DeliveryDate) AS INTEGER)
            AS DeliveryYear,
        CAST(strftime('%Y', p.PostingDate) AS INTEGER) AS PostingYear,
        si.SubTotal
    FROM SalesInvoice AS si
        INNER JOIN Shipped AS sh ON sh.SalesInvoiceID = si.SalesInvoiceID
        INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
    WHERE strftime('%Y', p.PostingDate)
        <> strftime('%Y', sh.DeliveryDate)
),
Unbilled AS (
    SELECT CAST(strftime('%Y', s.ShipmentDate) AS INTEGER)
            AS ShipmentYear,
        ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
            AS SalesValue
    FROM ShipmentLine AS sl
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
        INNER JOIN SalesOrderLine AS sol
            ON sol.SalesOrderLineID = sl.SalesOrderLineID
        LEFT JOIN SalesInvoiceLine AS sil
            ON sil.ShipmentLineID = sl.ShipmentLineID
    WHERE sil.SalesInvoiceLineID IS NULL
),
Effects AS (
    SELECT PostingYear AS FiscalYear, SubTotal AS FromYearBefore,
        0 AS ToNextYear, 0 AS NeverInvoiced
    FROM Late
    UNION ALL
    SELECT DeliveryYear, 0, SubTotal, 0
    FROM Late
    UNION ALL
    SELECT ShipmentYear, 0, 0, SalesValue
    FROM Unbilled
)
SELECT FiscalYear, ROUND(SUM(FromYearBefore), 2) AS FromYearBefore,
    ROUND(SUM(ToNextYear), 2) AS ToNextYear,
    ROUND(SUM(NeverInvoiced), 2) AS NeverInvoiced,
    ROUND(SUM(FromYearBefore) - SUM(ToNextYear) - SUM(NeverInvoiced), 2)
        AS NetEffect
FROM Effects
GROUP BY FiscalYear
ORDER BY FiscalYear;  -- Result: 3 rows

-- Exercise 12.1, test C4: cost of goods sold posted at shipment, and the unbilled lines' cost
-- Population: shipment postings and the lines of test L6; expected: cost on the shipment date
SELECT
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        INNER JOIN Shipment AS s ON s.ShipmentID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'Shipment'
        AND gl.PostingDate <> s.ShipmentDate) AS CostOffShipmentDate,
    COUNT(*) AS UnbilledLines,
    ROUND(SUM(sl.ExtendedStandardCost), 2) AS UnbilledStandardCost,
    ROUND(SUM(ROUND(sl.QuantityShipped * sol.UnitPrice
        * (1 - sol.Discount), 2)), 2) AS UnbilledSalesValue
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL;  -- Result: 1 rows

-- Exercise 12.1, test C5: supplier invoices by the date their ledger rows are posted on
-- Population: all supplier invoices; expected: posted on one date, in the year of the invoice
WITH Posted AS (
    SELECT SourceDocumentID AS PurchaseInvoiceID,
        MIN(PostingDate) AS FirstPosting, MAX(PostingDate) AS LastPosting
    FROM GLEntry
    WHERE SourceDocumentType = 'PurchaseInvoice'
    GROUP BY SourceDocumentID
)
SELECT COUNT(*) AS Invoices,
    SUM(CASE WHEN p.FirstPosting = pi.InvoiceDate
        AND p.LastPosting = pi.InvoiceDate THEN 1 ELSE 0 END)
        AS PostedOnInvoiceDate,
    SUM(CASE WHEN p.FirstPosting = pi.ReceivedDate
        AND p.LastPosting = pi.ReceivedDate THEN 1 ELSE 0 END)
        AS PostedOnReceivedDate,
    SUM(CASE WHEN strftime('%Y', p.FirstPosting)
        <> strftime('%Y', pi.InvoiceDate) THEN 1 ELSE 0 END)
        AS PostedInAnotherYear
FROM PurchaseInvoice AS pi
    INNER JOIN Posted AS p ON p.PurchaseInvoiceID = pi.PurchaseInvoiceID;  -- Result: 1 rows

-- Exercise 12.1, test C6: the supplier invoices dated in one year and posted in the next
-- Population: all supplier invoices; expected: no rows
SELECT pi.InvoiceNumber, pi.SupplierID, pi.InvoiceDate, pi.ReceivedDate,
    ROUND(pi.GrandTotal, 2) AS GrandTotal,
    (SELECT GROUP_CONCAT(je.EntryNumber, ', ')
     FROM PurchaseInvoiceLine AS pil
        INNER JOIN JournalEntry AS je
            ON je.JournalEntryID = pil.AccrualJournalEntryID
     WHERE pil.PurchaseInvoiceID = pi.PurchaseInvoiceID) AS AccrualEntries
FROM PurchaseInvoice AS pi
WHERE strftime('%Y', pi.InvoiceDate) <> strftime('%Y', pi.ReceivedDate)
ORDER BY pi.ReceivedDate, pi.InvoiceNumber;  -- Result: 1 rows

-- Exercise 12.1, test C7: hourly labor cost by the year of the work and of its pay period
-- Population: all labor time; expected: work and pay in the same fiscal year
SELECT strftime('%Y', lt.WorkDate) AS WorkYear, pp.FiscalYear AS PaidYear,
    MIN(lt.WorkDate) AS FirstWorkDate, MAX(lt.WorkDate) AS LastWorkDate,
    ROUND(SUM(lt.ExtendedLaborCost), 2) AS LaborCost,
    ROUND(SUM(CASE WHEN lt.LaborType <> 'NonManufacturing'
        THEN lt.ExtendedLaborCost ELSE 0 END), 2) AS ManufacturingCost
FROM LaborTimeEntry AS lt
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = lt.PayrollPeriodID
GROUP BY WorkYear, PaidYear
ORDER BY WorkYear, PaidYear;  -- Result: 5 rows

-- Exercise 12.1, test C8: the full cost of the late-December work paid in the next fiscal year
-- Population: the pay periods that cross a year-end (test L7); expected: none unrecorded
WITH Crossing AS (
    SELECT PayrollPeriodID, PeriodStartDate, PeriodEndDate,
        strftime('%Y', PeriodStartDate) AS WorkYear
    FROM PayrollPeriod
    WHERE strftime('%Y', PeriodStartDate) <> strftime('%Y', PayDate)
),
PeriodDays AS (
    SELECT c.PayrollPeriodID,
        SUM(CASE WHEN cal.CalendarDate <= c.WorkYear || '-12-31'
            THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS ShareInYear
    FROM Crossing AS c
        INNER JOIN WorkCenterCalendar AS cal
            ON cal.CalendarDate
                BETWEEN c.PeriodStartDate AND c.PeriodEndDate
    WHERE cal.WorkCenterID = (SELECT MIN(WorkCenterID)
            FROM WorkCenterCalendar)
        AND cal.IsWorkingDay = 1
    GROUP BY c.PayrollPeriodID
),
Registers AS (
    SELECT PayrollPeriodID, SUM(GrossPay) AS GrossPay,
        SUM(EmployerPayrollTax + EmployerBenefits) AS Charges
    FROM PayrollRegister
    GROUP BY PayrollPeriodID
),
Salaries AS (
    SELECT pr.PayrollPeriodID, SUM(prl.Amount) AS Salaries
    FROM PayrollRegisterLine AS prl
        INNER JOIN PayrollRegister AS pr
            ON pr.PayrollRegisterID = prl.PayrollRegisterID
    WHERE prl.LineType = 'Salary Earnings'
    GROUP BY pr.PayrollPeriodID
),
Hourly AS (
    SELECT c.PayrollPeriodID, SUM(lt.ExtendedLaborCost) AS HourlyCost
    FROM Crossing AS c
        INNER JOIN LaborTimeEntry AS lt
            ON lt.PayrollPeriodID = c.PayrollPeriodID
            AND strftime('%Y', lt.WorkDate) = c.WorkYear
    GROUP BY c.PayrollPeriodID
)
SELECT c.WorkYear, ROUND(SUM(h.HourlyCost), 2) AS HourlyLabor,
    ROUND(SUM(s.Salaries * d.ShareInYear), 2) AS SalariesInYear,
    ROUND(SUM(r.Charges) / SUM(r.GrossPay), 4) AS ChargeRate,
    ROUND((SUM(h.HourlyCost) + SUM(s.Salaries * d.ShareInYear))
        * (1 + SUM(r.Charges) / SUM(r.GrossPay)), 2) AS FullCost
FROM Crossing AS c
    INNER JOIN Registers AS r ON r.PayrollPeriodID = c.PayrollPeriodID
    INNER JOIN PeriodDays AS d ON d.PayrollPeriodID = c.PayrollPeriodID
    LEFT JOIN Salaries AS s ON s.PayrollPeriodID = c.PayrollPeriodID
    LEFT JOIN Hourly AS h ON h.PayrollPeriodID = c.PayrollPeriodID
GROUP BY c.WorkYear
ORDER BY c.WorkYear;  -- Result: 2 rows

-- Exercise 12.1, test C9: the payroll cost of 14-31 December 2026, which has no registers
-- Population: the last eight processed pay periods; expected: an estimate to accrue
WITH Params AS (
    SELECT '2026-12-14' AS FromDate, '2026-12-31' AS AsOfDate
),
LastPeriods AS (
    SELECT PayrollPeriodID, PeriodStartDate, PeriodEndDate
    FROM PayrollPeriod
    WHERE Status = 'Processed'
    ORDER BY PeriodStartDate DESC
    LIMIT 8
),
PeriodCost AS (
    SELECT pr.PayrollPeriodID,
        SUM(pr.GrossPay + pr.EmployerPayrollTax + pr.EmployerBenefits)
            AS PayrollCost,
        SUM(CASE WHEN cc.CostCenterName = 'Manufacturing'
            THEN pr.GrossPay + pr.EmployerPayrollTax + pr.EmployerBenefits
            ELSE 0 END) AS ManufacturingCost
    FROM PayrollRegister AS pr
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
    WHERE pr.PayrollPeriodID IN (SELECT PayrollPeriodID FROM LastPeriods)
    GROUP BY pr.PayrollPeriodID
),
WorkingDays AS (
    SELECT
        SUM(CASE WHEN CalendarDate
            BETWEEN (SELECT MIN(PeriodStartDate) FROM LastPeriods)
            AND (SELECT MAX(PeriodEndDate) FROM LastPeriods)
            THEN 1 ELSE 0 END) AS InPeriods,
        SUM(CASE WHEN CalendarDate BETWEEN (SELECT FromDate FROM Params)
            AND (SELECT AsOfDate FROM Params) THEN 1 ELSE 0 END)
            AS Unrecorded
    FROM WorkCenterCalendar
    WHERE WorkCenterID = (SELECT MIN(WorkCenterID) FROM WorkCenterCalendar)
        AND IsWorkingDay = 1
)
SELECT COUNT(*) AS Periods,
    ROUND(AVG(PayrollCost), 2) AS AveragePeriodCost,
    ROUND(AVG(ManufacturingCost), 2) AS AverageManufacturing,
    (SELECT InPeriods FROM WorkingDays) AS WorkingDays,
    (SELECT Unrecorded FROM WorkingDays) AS UnrecordedDays,
    ROUND(SUM(PayrollCost) / (SELECT InPeriods FROM WorkingDays)
        * (SELECT Unrecorded FROM WorkingDays), 2) AS EstimatedCost,
    ROUND(SUM(ManufacturingCost) / (SELECT InPeriods FROM WorkingDays)
        * (SELECT Unrecorded FROM WorkingDays), 2)
        AS EstimatedManufacturing
FROM PeriodCost;  -- Result: 1 rows

-- Exercise 12.1, test C10: accrued payroll (account 2030) at each year-end
-- Population: postings to 2030 to each year-end; expected: the unpaid wages
SELECT ye.YearEnd, ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
FROM (
    SELECT '2024-12-31' AS YearEnd
    UNION ALL SELECT '2025-12-31'
    UNION ALL SELECT '2026-12-31'
) AS ye
    INNER JOIN Account AS a ON a.AccountNumber = 2030
    INNER JOIN GLEntry AS gl
        ON gl.AccountID = a.AccountID AND gl.PostingDate <= ye.YearEnd
GROUP BY ye.YearEnd
ORDER BY ye.YearEnd;  -- Result: 3 rows

/* Model answer (Requirement (2))

   Cost of goods sold is posted on the shipment date (test C4 finds no shipment posting on another date), so
   it falls in the year of the delivery whatever happens to the invoice. When the revenue moves to the next
   year, or is never billed, the cost stays where it belongs and only the revenue is misplaced: the year's
   gross margin moves by the whole revenue amount, while cost of goods sold does not move at all. For the nine
   unbilled lines of 2026, cost of 22,895.78 is in 2026's cost of goods sold with no revenue of 44,481.11
   beside it.
*/

/* Model answer (Requirement (3))

   All 40,204 supplier invoices are posted on their ReceivedDate (test C5): Charles River records a supplier
   invoice when it receives it, not on the date the supplier wrote on it (the two dates are the same for
   15,406 of them). Only ASV0050-2025-040073 (supplier 50, dated 2025-12-30, received 2026-01-01, 3,266.27)
   crosses a year-end. Its line refers to the accrual entry JE-2025-000188, so the liability for the service
   was carried in accrued expenses at the end of 2025; it is not an unrecorded liability.
*/

/* Model answer (Requirement (5), memo to the controller)

   To: the controller. Subject: cutoff at each year-end.

   Revenue. Revenue is posted when the invoice is posted, and invoices for goods delivered in December are
   posted in January: 15 invoices for December 2024 deliveries (90,138.93) and 8 for December 2025 deliveries
   (19,540.86), among them SI-2026-013742, dated before the year-end. Nine December 2026 shipment lines were
   never invoiced (44,481.11 at order price). The net effect on revenue is -90,138.93 in 2024, +70,598.07 in
   2025, and -24,940.25 in 2026; because cost of goods sold is posted at shipment, gross margin moves by the
   same amounts. The 8 invoices dated before their shipment are posted in the year of delivery: an invoice-
   dating failure for the billing team, not a cutoff error.

   Supplier invoices are posted on the date received, and the one invoice that crosses a year-end was accrued,
   so the payables cutoff holds.

   Payroll. Wages are recorded only when paid, and account 2030 holds the opening 95,000.00 at every year-end,
   so no year-end accrues the wages earned in late December. The work of late December cost about 296,000 in
   2024 and 335,000 in 2025 (hourly labor by work date of 117,073.89 and 138,290.66, plus salaries by working
   day and employer taxes and benefits), and the 13 working days of 14-31 December 2026 are estimated at
   383,044.82 (the cost of periods 70-77, 287,283.61 a period on average, per working day; spreading salaries
   over weekdays instead gives about 392,000). Each year-end's liability is understated by these amounts, and
   each year's expense by the change between them.

   Recommendation: before the fiscal 2026 statements are final, record revenue for the December deliveries
   billed in January and for the unbilled lines, and accrue the late-December payroll of about 383,000; then
   make both part of every close, with a cutoff report of deliveries not yet invoiced and a payroll accrual
   from the open pay periods.
*/

/* Model answer (Dispositions)

   C1 (23 invoices): revenue cutoff errors, to be adjusted in the year of delivery; the 2026 effect
   (-24,940.25 with C3) is proposed as an adjustment before the statements are final. C2 (8 invoices): no
   revenue effect; reported to billing as invoices dated before shipment. C3 and C4: the unbilled lines
   (44,481.11) are referred for billing and accrued revenue at 2026-12-31; no exception in the cost postings.
   C5: no exception. C6 (ASV0050-2025-040073): no exception, accrued by JE-2025-000188. C7 and C8: late-
   December payroll recorded in the next fiscal year, an accrual deficiency in every year. C9: the 2026
   accrual of about 383,044.82 is proposed. C10: account 2030 carries only the opening balance; the missing
   accrual is reported as a control deficiency of the close.
*/

/* Notes

   Exercise 12.1: Cutoff at Each Year-End
   (1) List the sales invoices whose revenue was posted in a different fiscal year from the delivery of the
      goods they bill, with their SubTotal, invoice date, shipment and delivery dates, and posting date, and
      list separately the invoices dated before their shipment.
   (2) For each fiscal year, total the SubTotal of the revenue recorded in that year for goods delivered in
      the year before, and of the revenue for goods delivered in that year but recorded in the next one. Add
      the shipments of fiscal 2026 that were never invoiced, valued at their order price, and calculate the
      net effect of cutoff on each year's revenue. Explain why the effect on gross margin is larger than the
      effect on cost of goods sold.
   (3) Repeat the test for supplier invoices, comparing InvoiceDate with the posting date of each invoice's
      ledger rows. Compare the posting dates with ReceivedDate, and explain which date Charles River posts
      supplier invoices on.
   (4) Total the hourly labor cost of LaborTimeEntry (ExtendedLaborCost) by the year of its WorkDate and the
      fiscal year of its pay period, and identify the cost of work done in December that was recorded in the
      next fiscal year. Estimate the full payroll cost of the work of 14 to 31 December 2026, whose pay
      periods have no registers, from the average cost of the last pay periods of fiscal 2026.
   (5) Write a short memo (one half page) to the controller with the effect on each year and a recommendation
      for the year-end close.
   Instructor note: revenue by delivery date (every shipment is delivered in the year it ships). Fifteen
      invoices for goods delivered in December 2024 were invoiced and posted in January 2025 (SubTotal
      90,138.93), and eight for December 2025 deliveries were posted in January 2026 (19,540.86), among them
      SI-2026-013742 (dated 2025-12-04, shipped 2025-12-06, posted 2026-01-01). Nine December 2026 shipment
      lines were never invoiced by the end of the data: standard cost 22,895.78, already posted to cost of
      goods sold; about 44,481.11 at order price. Net effect on revenue: 2024 understated 90,138.93; 2025
      overstated 70,598.07 (90,138.93 received less 19,540.86 moved on); 2026 understated about 24,940
      (19,540.86 received less 44,481.11 unbilled). Cost of goods sold is posted at shipment, so margin moves
      by the whole revenue amount. Eight invoices are dated before their shipment but posted in the year of
      delivery (SI-2024-000001 to 000003, SI-2025-006733 to 006735, SI-2026-013741 and 013743): an invoice-
      dating failure, not a revenue cutoff error; they are Exercise 5.2's invoices except SI-2026-013742.
      Exercises 6.1 and 10.1 compared InvoiceLines, built on invoice dates, with the ledger: of their three
      2026 differences, only SI-2026-013742 is a revenue cutoff error. Supplier invoices post on their
      ReceivedDate (no exception); one, ASV0050-2025-040073 (dated 2025-12-30, received 2026-01-01, 3,266.27,
      supplier 50), crosses the year-end. Payroll: hourly labor of 2024 work paid in fiscal 2025, 117,073.89
      (manufacturing 98,041.68); of 2025 work paid in fiscal 2026, 138,290.66 (manufacturing 117,800.12). With
      salaries allocated by working day and employer taxes and benefits applied as a rate on gross pay, the
      full cost of late-December work is about 296,000 (2024) and 335,000 (2025). Periods 70-77 average
      287,283.61 (manufacturing 148,478.01); the 13 working days of 14-31 December 2026 cost about
      383,000-392,000 (manufacturing about 198,000-199,000), never recorded. Account 2030 holds only the
      opening 95,000, so no year-end accrues the wages; each year-end's liability is understated by the
      amounts above.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   12.1: invoices posted in another year: 23
   12.1: for deliveries of 2024: 90,138.93
   12.1: for deliveries of 2025: 19,540.86
   12.1: the invoices dated before the year-end and posted after it: ['SI-2026-013742']
   12.1: invoices dated before their shipment: 8
   12.1: the invoices: ['SI-2024-000001', 'SI-2024-000002', 'SI-2024-000003', 'SI-2025-006733',
      'SI-2025-006734', 'SI-2025-006735', 'SI-2026-013741', 'SI-2026-013743']
   12.1: fiscal years: [2024, 2025, 2026]
   12.1: 2026 never invoiced (order price): 44,481.11
   12.1: 2024 net effect: -90,138.93
   12.1: 2025 net effect: 70,598.07
   12.1: 2026 net effect: -24,940.25
   12.1: shipment postings on another date: 0
   12.1: unbilled lines: 9
   12.1: their standard cost (posted to cost of goods sold): 22,895.78
   12.1: their value at order price: 44,481.11
   12.1: supplier invoices: 40204
   12.1: posted on the invoice date: 15406
   12.1: posted on the received date (all): 40204
   12.1: posted in another year than dated: 1
   12.1: invoices: 1
   12.1: the invoice: ASV0050-2025-040073
   12.1: its supplier: 50
   12.1: its amount: 3,266.27
   12.1: its accrual entry: JE-2025-000188
   12.1: year pairs: 5
   12.1: 2024 work paid in 2025: 117,073.89
   12.1: of it manufacturing: 98,041.68
   12.1: 2024 work paid in 2025, all in December: 2024-12
   12.1: 2025 work paid in 2026: 138,290.66
   12.1: of it manufacturing: 117,800.12
   12.1: 2025 work paid in 2026, all in December: 2025-12
   12.1: year-ends with late-December work paid later: 2
   12.1: 2024 full cost: 295,972.91
   12.1: 2025 full cost: 334,886.38
   12.1: 2024 full cost, rounded as the note gives it: 296000
   12.1: 2025 full cost, rounded as the note gives it: 335000
   12.1: pay periods: 8
   12.1: average cost of periods 70-77: 287,283.61
   12.1: of it manufacturing: 148,478.01
   12.1: working days not recorded: 13
   12.1: estimated cost: 383,044.82
   12.1: within the note's range (383,000-392,000): True
   12.1: estimated manufacturing cost: 197,970.68
   12.1: within the note's range (198,000-199,000): True
   12.1: year-ends: 3
   12.1: 2024-12-31 balance (the opening line only): 95,000.00
   12.1: 2025-12-31 balance (the opening line only): 95,000.00
   12.1: 2026-12-31 balance (the opening line only): 95,000.00
*/
