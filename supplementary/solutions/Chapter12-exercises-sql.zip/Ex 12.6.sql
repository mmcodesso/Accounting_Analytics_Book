/* Ex 12.6.sql: Chapter 8's duplicate, sequence, and first-digit tests in SQL
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: duplicate invoice and check numbers; near-duplicate payments; document series; first-digit MAD equal to Tutorial 8.1 */

-- Exercise 12.6, test D1: supplier invoice numbers that appear more than once for a supplier
-- Population: all supplier invoices; expected: no rows
WITH Repeated AS (
    SELECT SupplierID, InvoiceNumber
    FROM PurchaseInvoice
    GROUP BY SupplierID, InvoiceNumber
    HAVING COUNT(*) > 1
)
SELECT pi.SupplierID, pi.InvoiceNumber, pi.PurchaseInvoiceID,
    pi.InvoiceDate, ROUND(pi.GrandTotal, 2) AS GrandTotal,
    COUNT(dp.DisbursementID) AS Payments,
    ROUND(SUM(dp.Amount), 2) AS AmountPaid
FROM PurchaseInvoice AS pi
    INNER JOIN Repeated AS r ON r.SupplierID = pi.SupplierID
        AND r.InvoiceNumber = pi.InvoiceNumber
    LEFT JOIN DisbursementPayment AS dp
        ON dp.PurchaseInvoiceID = pi.PurchaseInvoiceID
GROUP BY pi.PurchaseInvoiceID, pi.SupplierID, pi.InvoiceNumber,
    pi.InvoiceDate, pi.GrandTotal
ORDER BY pi.SupplierID, pi.InvoiceNumber, pi.PurchaseInvoiceID;  -- Result: 12 rows

-- Exercise 12.6, test D2: the same test on invoice numbers standardized with UPPER, TRIM, and REPLACE
-- Population: all supplier invoices; expected: no pair the exact test missed
SELECT SupplierID,
    UPPER(TRIM(REPLACE(REPLACE(InvoiceNumber, '-', ''), ' ', '')))
        AS StandardNumber,
    COUNT(*) AS Invoices, COUNT(DISTINCT InvoiceNumber) AS ExactNumbers
FROM PurchaseInvoice
GROUP BY SupplierID, StandardNumber
HAVING COUNT(*) > 1
ORDER BY SupplierID, StandardNumber;  -- Result: 6 rows

-- Exercise 12.6, test D3: check numbers used more than once for the same supplier
-- Population: payments with a check number; expected: no rows
SELECT SupplierID, CheckNumber, COUNT(*) AS Payments,
    ROUND(SUM(Amount), 2) AS Amount
FROM DisbursementPayment
WHERE CheckNumber IS NOT NULL
GROUP BY SupplierID, CheckNumber
HAVING COUNT(*) > 1
ORDER BY CheckNumber;  -- Result: 2 rows

-- Exercise 12.6, test D4: payments to a supplier for the same amount within 30 days
-- Population: supplier payments dated through 2026-12-31; expected: no rows
SELECT a.SupplierID, a.Amount, a.PaymentNumber, a.PaymentDate,
    b.PaymentNumber AS OtherPayment, b.PaymentDate AS OtherDate,
    ABS(julianday(b.PaymentDate) - julianday(a.PaymentDate))
        AS DaysApart,
    CASE WHEN a.PurchaseInvoiceID = b.PurchaseInvoiceID
        THEN 1 ELSE 0 END AS SameInvoice
FROM DisbursementPayment AS a
    INNER JOIN DisbursementPayment AS b
        ON b.SupplierID = a.SupplierID AND b.Amount = a.Amount
        AND b.DisbursementID > a.DisbursementID
WHERE a.PaymentDate <> b.PaymentDate
    AND a.PaymentDate <= '2026-12-31' AND b.PaymentDate <= '2026-12-31'
    AND ABS(julianday(b.PaymentDate) - julianday(a.PaymentDate)) <= 30
ORDER BY DaysApart, a.SupplierID;  -- Result: 13 rows

-- Exercise 12.6, test D5: all same-supplier, same-amount pairs, by distance in days
-- Population: supplier payments dated through 2026-12-31; expected: no pair on one invoice
SELECT COUNT(*) AS Pairs,
    SUM(CASE WHEN ABS(julianday(b.PaymentDate)
        - julianday(a.PaymentDate)) <= 30 THEN 1 ELSE 0 END)
        AS Within30Days,
    SUM(CASE WHEN a.PurchaseInvoiceID = b.PurchaseInvoiceID
        THEN 1 ELSE 0 END) AS SameInvoice
FROM DisbursementPayment AS a
    INNER JOIN DisbursementPayment AS b
        ON b.SupplierID = a.SupplierID AND b.Amount = a.Amount
        AND b.DisbursementID > a.DisbursementID
WHERE a.PaymentDate <> b.PaymentDate
    AND a.PaymentDate <= '2026-12-31' AND b.PaymentDate <= '2026-12-31';  -- Result: 1 row (Pairs = 113, Within30Days = 13, SameInvoice = 0)

-- Exercise 12.6, test S1: the first and last number of each document series and year
-- Population: four document series; expected: numbers without gaps
WITH Numbers AS (
    SELECT 'Sales invoice' AS Series,
        CAST(SUBSTR(InvoiceNumber, 4, 4) AS INTEGER) AS NumberYear,
        CAST(SUBSTR(InvoiceNumber, 9) AS INTEGER) AS Sequence
    FROM SalesInvoice
    UNION ALL
    SELECT 'Purchase order', CAST(SUBSTR(PONumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(PONumber, 9) AS INTEGER)
    FROM PurchaseOrder
    UNION ALL
    SELECT 'Cash receipt', CAST(SUBSTR(ReceiptNumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(ReceiptNumber, 9) AS INTEGER)
    FROM CashReceipt
    UNION ALL
    SELECT 'Journal entry', CAST(SUBSTR(EntryNumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(EntryNumber, 9) AS INTEGER)
    FROM JournalEntry
)
SELECT Series, NumberYear, MIN(Sequence) AS FirstNumber,
    MAX(Sequence) AS LastNumber, COUNT(*) AS Documents
FROM Numbers
GROUP BY Series, NumberYear
ORDER BY Series, NumberYear;  -- Result: 12 rows

-- Exercise 12.6, test S2: steps greater than one between consecutive numbers
-- Population: four document series; expected: no gaps
WITH Numbers AS (
    SELECT 'Sales invoice' AS Series,
        CAST(SUBSTR(InvoiceNumber, 4, 4) AS INTEGER) AS NumberYear,
        CAST(SUBSTR(InvoiceNumber, 9) AS INTEGER) AS Sequence
    FROM SalesInvoice
    UNION ALL
    SELECT 'Purchase order', CAST(SUBSTR(PONumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(PONumber, 9) AS INTEGER)
    FROM PurchaseOrder
    UNION ALL
    SELECT 'Cash receipt', CAST(SUBSTR(ReceiptNumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(ReceiptNumber, 9) AS INTEGER)
    FROM CashReceipt
    UNION ALL
    SELECT 'Journal entry', CAST(SUBSTR(EntryNumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(EntryNumber, 9) AS INTEGER)
    FROM JournalEntry
),
Steps AS (
    SELECT Series, Sequence - LAG(Sequence) OVER (
        PARTITION BY Series ORDER BY Sequence) AS Step
    FROM Numbers
    WHERE Series <> 'Journal entry'
    UNION ALL
    SELECT Series, Sequence - LAG(Sequence) OVER (
        PARTITION BY Series, NumberYear ORDER BY Sequence)
    FROM Numbers
    WHERE Series = 'Journal entry'
)
SELECT Series, COUNT(Step) AS StepsTested, MAX(Step) AS LargestStep,
    SUM(CASE WHEN Step > 1 THEN 1 ELSE 0 END) AS Gaps
FROM Steps
GROUP BY Series
ORDER BY Series;  -- Result: 4 rows

-- Exercise 12.6, test B1: first-digit mean absolute deviation of the supplier payments
-- Population: supplier payments dated through 2026-12-31; expected: close conformity
WITH Payments AS (
    SELECT dp.Amount, pi.GrandTotal,
        CAST(SUBSTR(printf('%e', dp.Amount), 1, 1) AS INTEGER) AS Digit
    FROM DisbursementPayment AS dp
        INNER JOIN PurchaseInvoice AS pi
            ON pi.PurchaseInvoiceID = dp.PurchaseInvoiceID
    WHERE dp.PaymentDate <= '2026-12-31'
),
Groups AS (
    SELECT 'All payments' AS PaymentGroup, Digit
    FROM Payments
    UNION ALL
    SELECT 'Full payments', Digit
    FROM Payments
    WHERE Amount = GrandTotal
    UNION ALL
    SELECT 'Partial payments', Digit
    FROM Payments
    WHERE Amount < GrandTotal
),
Observed AS (
    SELECT PaymentGroup, Digit, COUNT(*) AS Payments,
        COUNT(*) * 1.0 / SUM(COUNT(*)) OVER (PARTITION BY PaymentGroup)
            AS Actual
    FROM Groups
    GROUP BY PaymentGroup, Digit
)
SELECT PaymentGroup, SUM(Payments) AS Payments, COUNT(*) AS Digits,
    ROUND(AVG(ABS(Actual - LOG10(1 + 1.0 / Digit))), 5) AS MAD
FROM Observed
GROUP BY PaymentGroup
ORDER BY PaymentGroup;  -- Result: 3 rows

/* Model answer (Requirement (6), results and dispositions)

   D1, duplicate supplier invoice numbers: six numbers appear twice for the same supplier; each pair has
   different amounts and each invoice was paid once (Exercise 2.6). Disposition: obtain both invoices of each
   pair from the suppliers to confirm they are distinct bills; no duplicate payment found.

   D2, standardized numbers: the same six pairs and no others; the numbers are entered consistently.
   Disposition: no exception.

   D3, repeated check numbers: two check numbers, CHK0006076, CHK0019708, each used twice for supplier 1 (the
   AnomalyLog lists six duplicate references, but only two carry check numbers). Disposition: trace both
   payments of each check to the bank statement.

   D4 and D5, near-duplicate payments: 113 pairs share supplier and amount on different dates, 13 within 30
   days (6 within 14, the chapter's example), and none pays the same invoice. Disposition: recurring
   purchases, no exception.

   S1 and S2, document series: no gaps. Sales invoices, purchase orders, and cash receipts continue across
   years, and journal entries restart each year (1-266, 1-288, 1-297). Disposition: no exception.

   B1, first digits: MAD 0.01295 for all payments, 0.00755 for full payments, and 0.04496 for partial
   payments, the values of Tutorial 8.1. Disposition: the partial payments' nonconformity is explained by how
   invoices are paid in parts (Chapter 8): only invoices of 1,000.00 or more are paid in installments, so the
   partial amounts cluster; no further work.

   Why the near-duplicate test needs a self-join: GROUP BY finds rows with identical values, but a near
   duplicate is a pair of different payments whose dates fall within a range of each other, so each payment
   must be compared with the other payments of the same supplier, which takes the table joined to itself. A
   LAG partitioned by year on a series that continues across years would also miss a gap between the last
   number of one year and the first of the next, which is why the continuing series are ordered without a
   partition.

   What SQL gains over a workbook: the tests run on the whole population in the database, every quarter,
   without copying data into a workbook or refreshing formulas; each test is a saved, readable definition that
   a reviewer can rerun and get the same result; and printf writes every positive amount in scientific
   notation (688.42 as 6.884200e+02, the smallest payment 0.12 as 1.200000e-01), so the first character is
   always the first significant digit, without the text tricks the workbook needed.
*/

/* Notes

   Exercise 12.6: Chapter 8's Tests in SQL
   (1) Find the supplier invoice numbers that appear more than once for the same supplier, and list both
      invoices of each pair with their amounts and payments. Repeat the test on invoice numbers standardized
      with UPPER, TRIM, and REPLACE, as Exercise 2.6 warned, and report whether it finds any pair that the
      exact test missed.
   (2) Find the check numbers used more than once for the same supplier.
   (3) Use a self-join to find pairs of payments to the same supplier for the same amount on different dates
      within 30 days of each other, dated through 2026-12-31, and report whether any pair pays the same
      invoice.
   (4) For the sales invoice, purchase order, cash receipt, and journal entry numbers, extract the year and
      the sequence number with SUBSTR and CAST, and report the first and last number of each year. Use LAG to
      find any step greater than one: partitioned by year for a series that restarts each year, and ordered
      across the years, without a partition, for a series that continues.
   (5) Calculate the first significant digit of every supplier payment dated through 2026-12-31 with
      printf('%e', Amount), and the mean absolute deviation from the expected proportions of LOG10(1 + 1.0 /
      Digit), for all payments, for full payments (Amount equal to the invoice's GrandTotal), and for partial
      payments. Compare the results with Tutorial 8.1.
   (6) For each test, record the number of exceptions and a disposition, and write a short note on why the
      near-duplicate test needs a self-join and on what running these tests in SQL gains over a workbook.
   Instructor note: (1) six supplier invoice numbers each appear twice for the same supplier; each pair has
      different amounts, and each invoice was paid once (Exercise 2.6). Standardized numbers (UPPER, TRIM, and
      REPLACE of hyphens and spaces) find the same six pairs and no others: the numbers are entered
      consistently. (2) Two check numbers are used twice, both for supplier 1: CHK0006076 and CHK0019708 (the
      AnomalyLog lists six duplicate references, but only two have check numbers). (3) 113 pairs share
      supplier and amount on different dates; 13 are within 30 days (the chapter's example, with 14 days,
      finds 6), and none pays the same invoice, so they are recurring purchases rather than duplicates.
      Grouping finds identical values; comparing each payment with other payments across a range of dates
      needs the table joined to itself. (4) No gaps in any series. Sales invoices and cash receipts continue
      across years (SI 1-6,732 in 2024, 6,733-13,740 in 2025, 13,741-20,914 in 2026; CR 1-2,274, 2,275-4,840,
      4,841-7,409), as do purchase orders (1-3,921, 3,922-10,466, 10,467-18,832); journal entries restart each
      year (1-266, 1-288, 1-297). A LAG partitioned by year on a continuing series would miss a gap between
      the last number of one year and the first of the next. (5) MAD: all payments 0.01295, full payments
      0.00755, partial payments 0.04496, exactly the values of Tutorial 8.1. printf writes 688.42 as
      6.884200e+02 and 0.12 as 1.200000e-01, so the first character is the first significant digit for every
      positive amount (the smallest payment is 0.12); LOG10 needs SQLite's math functions, which DB Browser
      3.13.1 includes.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   12.6: invoices (both of each pair): 12
   12.6: pairs: 6
   12.6: each invoice paid once: [1]
   12.6: each pair has different amounts: True
   12.6: standardized pairs: 6
   12.6: pairs the exact test missed (more than one exact number): 0
   12.6: check numbers: ['CHK0006076', 'CHK0019708']
   12.6: supplier: [1]
   12.6: used twice each: [2]
   12.6: pairs within 30 days: 13
   12.6: pairs within 14 days (the chapter's example): 6
   12.6: pairs paying the same invoice: 0
   12.6: pairs on different dates: 113
   12.6: within 30 days: 13
   12.6: paying the same invoice: 0
   12.6: series and years: 12
   12.6: Sales invoice first numbers: [1, 6733, 13741]
   12.6: Sales invoice last numbers: [6732, 13740, 20914]
   12.6: Cash receipt first numbers: [1, 2275, 4841]
   12.6: Cash receipt last numbers: [2274, 4840, 7409]
   12.6: Purchase order first numbers: [1, 3922, 10467]
   12.6: Purchase order last numbers: [3921, 10466, 18832]
   12.6: Journal entry first numbers: [1, 1, 1]
   12.6: Journal entry last numbers: [266, 288, 297]
   12.6: series: 4
   12.6: gaps: [0, 0, 0, 0]
   12.6: largest step: [1, 1, 1, 1]
   12.6: steps tested: 48000
   12.6: groups: ['All payments', 'Full payments', 'Partial payments']
   12.6: all nine digits in every group: [9, 9, 9]
   12.6: All payments payments: 39864
   12.6: All payments MAD (Tutorial 8.1): 0.01
   12.6: Full payments payments: 34115
   12.6: Full payments MAD (Tutorial 8.1): 0.01
   12.6: Partial payments payments: 5749
   12.6: Partial payments MAD (Tutorial 8.1): 0.04
*/
