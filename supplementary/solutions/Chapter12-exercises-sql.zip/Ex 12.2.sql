/* Ex 12.2.sql: the open balances at the end of fiscal 2026: receivables and receipts not invoiced
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: open invoices aged and reconciled to 1020; customer strata; receipts not invoiced against 2020 */

-- Exercise 12.2, test A1: the open balance of each sales invoice at the as-of date
-- Population: invoices dated by 2026-12-31; expected: the open receivables
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Applied AS (
    SELECT SalesInvoiceID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    WHERE ApplicationDate <= (SELECT AsOfDate FROM Params)
    GROUP BY SalesInvoiceID
),
Credited AS (
    SELECT OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(GrandTotal) AS Credited
    FROM CreditMemo
    WHERE CreditMemoDate <= (SELECT AsOfDate FROM Params)
    GROUP BY OriginalSalesInvoiceID
),
Balances AS (
    SELECT si.SalesInvoiceID, si.InvoiceNumber, si.CustomerID,
        si.InvoiceDate, si.DueDate, si.GrandTotal,
        COALESCE(a.Applied, 0) AS Applied,
        COALESCE(c.Credited, 0) AS Credited,
        ROUND(si.GrandTotal - COALESCE(a.Applied, 0)
            - COALESCE(c.Credited, 0), 2) AS OpenBalance,
        julianday((SELECT AsOfDate FROM Params))
            - julianday(si.DueDate) AS DaysPastDue
    FROM SalesInvoice AS si
        LEFT JOIN Applied AS a ON a.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS c ON c.SalesInvoiceID = si.SalesInvoiceID
    WHERE si.InvoiceDate <= (SELECT AsOfDate FROM Params)
)
SELECT InvoiceNumber, CustomerID, InvoiceDate, DueDate, GrandTotal,
    ROUND(Applied, 2) AS Applied, ROUND(Credited, 2) AS Credited,
    OpenBalance
FROM Balances
WHERE OpenBalance > 0
ORDER BY CustomerID, InvoiceDate;  -- Result: 1079 rows

-- Exercise 12.2, test A2: the open balances aged by days past due
-- Population: the invoices of test A1; expected: most of the balance current
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Applied AS (
    SELECT SalesInvoiceID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    WHERE ApplicationDate <= (SELECT AsOfDate FROM Params)
    GROUP BY SalesInvoiceID
),
Credited AS (
    SELECT OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(GrandTotal) AS Credited
    FROM CreditMemo
    WHERE CreditMemoDate <= (SELECT AsOfDate FROM Params)
    GROUP BY OriginalSalesInvoiceID
),
Balances AS (
    SELECT si.SalesInvoiceID, si.InvoiceNumber, si.CustomerID,
        si.InvoiceDate, si.DueDate, si.GrandTotal,
        COALESCE(a.Applied, 0) AS Applied,
        COALESCE(c.Credited, 0) AS Credited,
        ROUND(si.GrandTotal - COALESCE(a.Applied, 0)
            - COALESCE(c.Credited, 0), 2) AS OpenBalance,
        julianday((SELECT AsOfDate FROM Params))
            - julianday(si.DueDate) AS DaysPastDue
    FROM SalesInvoice AS si
        LEFT JOIN Applied AS a ON a.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS c ON c.SalesInvoiceID = si.SalesInvoiceID
    WHERE si.InvoiceDate <= (SELECT AsOfDate FROM Params)
)
SELECT
    CASE
        WHEN DaysPastDue <= 0 THEN 'Current'
        WHEN DaysPastDue <= 30 THEN '1-30 days'
        WHEN DaysPastDue <= 60 THEN '31-60 days'
        WHEN DaysPastDue <= 90 THEN '61-90 days'
        ELSE 'Over 90 days'
    END AS AgingBucket,
    COUNT(*) AS Invoices, ROUND(SUM(OpenBalance), 2) AS OpenBalance
FROM Balances
WHERE OpenBalance > 0
GROUP BY AgingBucket
ORDER BY MIN(DaysPastDue);  -- Result: 5 rows

-- Exercise 12.2, test A3: the open balances against account 1020 Accounts Receivable
-- Population: the invoices of test A1 and the ledger; expected: no difference
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Applied AS (
    SELECT SalesInvoiceID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    WHERE ApplicationDate <= (SELECT AsOfDate FROM Params)
    GROUP BY SalesInvoiceID
),
Credited AS (
    SELECT OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(GrandTotal) AS Credited
    FROM CreditMemo
    WHERE CreditMemoDate <= (SELECT AsOfDate FROM Params)
    GROUP BY OriginalSalesInvoiceID
),
Balances AS (
    SELECT si.SalesInvoiceID, si.InvoiceNumber, si.CustomerID,
        si.InvoiceDate, si.DueDate, si.GrandTotal,
        COALESCE(a.Applied, 0) AS Applied,
        COALESCE(c.Credited, 0) AS Credited,
        ROUND(si.GrandTotal - COALESCE(a.Applied, 0)
            - COALESCE(c.Credited, 0), 2) AS OpenBalance,
        julianday((SELECT AsOfDate FROM Params))
            - julianday(si.DueDate) AS DaysPastDue
    FROM SalesInvoice AS si
        LEFT JOIN Applied AS a ON a.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS c ON c.SalesInvoiceID = si.SalesInvoiceID
    WHERE si.InvoiceDate <= (SELECT AsOfDate FROM Params)
),
Ledger AS (
    SELECT SUM(gl.Debit) - SUM(gl.Credit) AS Balance,
        SUM(CASE WHEN gl.VoucherNumber = 'JE-2024-000001'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS OpeningLine
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 1020
        AND gl.PostingDate <= (SELECT AsOfDate FROM Params)
)
SELECT ROUND(SUM(b.OpenBalance), 2) AS OpenInvoices,
    ROUND((SELECT Balance FROM Ledger), 2) AS Account1020,
    ROUND((SELECT Balance FROM Ledger) - SUM(b.OpenBalance), 2)
        AS Difference,
    ROUND((SELECT OpeningLine FROM Ledger), 2) AS OpeningEntryLine
FROM Balances AS b
WHERE b.OpenBalance > 0;  -- Result: 1 rows

-- Exercise 12.2, test A4: the invoices with a negative balance
-- Population: the invoices dated by the as-of date; expected: no rows
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Applied AS (
    SELECT SalesInvoiceID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    WHERE ApplicationDate <= (SELECT AsOfDate FROM Params)
    GROUP BY SalesInvoiceID
),
Credited AS (
    SELECT OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(GrandTotal) AS Credited
    FROM CreditMemo
    WHERE CreditMemoDate <= (SELECT AsOfDate FROM Params)
    GROUP BY OriginalSalesInvoiceID
),
Balances AS (
    SELECT si.SalesInvoiceID, si.InvoiceNumber, si.CustomerID,
        si.InvoiceDate, si.DueDate, si.GrandTotal,
        COALESCE(a.Applied, 0) AS Applied,
        COALESCE(c.Credited, 0) AS Credited,
        ROUND(si.GrandTotal - COALESCE(a.Applied, 0)
            - COALESCE(c.Credited, 0), 2) AS OpenBalance,
        julianday((SELECT AsOfDate FROM Params))
            - julianday(si.DueDate) AS DaysPastDue
    FROM SalesInvoice AS si
        LEFT JOIN Applied AS a ON a.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS c ON c.SalesInvoiceID = si.SalesInvoiceID
    WHERE si.InvoiceDate <= (SELECT AsOfDate FROM Params)
),
Negative AS (
    SELECT SalesInvoiceID, OpenBalance,
        CASE WHEN Applied >= GrandTotal - 0.005 THEN 1 ELSE 0 END
            AS PaidInFull
    FROM Balances
    WHERE OpenBalance < 0
)
SELECT COUNT(*) AS Invoices, ROUND(SUM(n.OpenBalance), 2) AS Balance,
    SUM(n.PaidInFull) AS PaidInFull,
    SUM(CASE WHEN EXISTS (
        SELECT 1
        FROM CreditMemo AS cm
            INNER JOIN CustomerRefund AS rf
                ON rf.CreditMemoID = cm.CreditMemoID
        WHERE cm.OriginalSalesInvoiceID = n.SalesInvoiceID
            AND rf.RefundDate <= (SELECT AsOfDate FROM Params))
        THEN 1 ELSE 0 END) AS Refunded
FROM Negative AS n;  -- Result: 1 rows

-- Exercise 12.2, test A5: customers stratified by open balance
-- Population: customers with a positive balance; expected: 203 customers
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Applied AS (
    SELECT SalesInvoiceID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    WHERE ApplicationDate <= (SELECT AsOfDate FROM Params)
    GROUP BY SalesInvoiceID
),
Credited AS (
    SELECT OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(GrandTotal) AS Credited
    FROM CreditMemo
    WHERE CreditMemoDate <= (SELECT AsOfDate FROM Params)
    GROUP BY OriginalSalesInvoiceID
),
Balances AS (
    SELECT si.SalesInvoiceID, si.InvoiceNumber, si.CustomerID,
        si.InvoiceDate, si.DueDate, si.GrandTotal,
        COALESCE(a.Applied, 0) AS Applied,
        COALESCE(c.Credited, 0) AS Credited,
        ROUND(si.GrandTotal - COALESCE(a.Applied, 0)
            - COALESCE(c.Credited, 0), 2) AS OpenBalance,
        julianday((SELECT AsOfDate FROM Params))
            - julianday(si.DueDate) AS DaysPastDue
    FROM SalesInvoice AS si
        LEFT JOIN Applied AS a ON a.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS c ON c.SalesInvoiceID = si.SalesInvoiceID
    WHERE si.InvoiceDate <= (SELECT AsOfDate FROM Params)
),
Customers AS (
    SELECT CustomerID, SUM(OpenBalance) AS OpenBalance
    FROM Balances
    WHERE OpenBalance > 0
    GROUP BY CustomerID
)
SELECT
    CASE
        WHEN OpenBalance < 1000 THEN 'Under 1,000'
        WHEN OpenBalance < 10000 THEN '1,000-9,999'
        WHEN OpenBalance < 50000 THEN '10,000-49,999'
        ELSE '50,000 and over'
    END AS Stratum,
    COUNT(*) AS Customers, ROUND(SUM(OpenBalance), 2) AS OpenBalance,
    ROUND(SUM(OpenBalance) / (SELECT SUM(OpenBalance) FROM Customers), 3)
        AS ShareOfBalance
FROM Customers
GROUP BY Stratum
ORDER BY MIN(OpenBalance);  -- Result: 4 rows

-- Exercise 12.2, test A6: the customers of $50,000 or more, the key items to confirm
-- Population: the customers of test A5; expected: 23 key items
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Applied AS (
    SELECT SalesInvoiceID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    WHERE ApplicationDate <= (SELECT AsOfDate FROM Params)
    GROUP BY SalesInvoiceID
),
Credited AS (
    SELECT OriginalSalesInvoiceID AS SalesInvoiceID,
        SUM(GrandTotal) AS Credited
    FROM CreditMemo
    WHERE CreditMemoDate <= (SELECT AsOfDate FROM Params)
    GROUP BY OriginalSalesInvoiceID
),
Balances AS (
    SELECT si.SalesInvoiceID, si.InvoiceNumber, si.CustomerID,
        si.InvoiceDate, si.DueDate, si.GrandTotal,
        COALESCE(a.Applied, 0) AS Applied,
        COALESCE(c.Credited, 0) AS Credited,
        ROUND(si.GrandTotal - COALESCE(a.Applied, 0)
            - COALESCE(c.Credited, 0), 2) AS OpenBalance,
        julianday((SELECT AsOfDate FROM Params))
            - julianday(si.DueDate) AS DaysPastDue
    FROM SalesInvoice AS si
        LEFT JOIN Applied AS a ON a.SalesInvoiceID = si.SalesInvoiceID
        LEFT JOIN Credited AS c ON c.SalesInvoiceID = si.SalesInvoiceID
    WHERE si.InvoiceDate <= (SELECT AsOfDate FROM Params)
),
Customers AS (
    SELECT CustomerID, SUM(OpenBalance) AS OpenBalance
    FROM Balances
    WHERE OpenBalance > 0
    GROUP BY CustomerID
)
SELECT c.CustomerID, cu.CustomerName,
    ROUND(c.OpenBalance, 2) AS OpenBalance,
    ROUND(c.OpenBalance / (SELECT SUM(OpenBalance) FROM Customers), 4)
        AS ShareOfBalance
FROM Customers AS c
    INNER JOIN Customer AS cu ON cu.CustomerID = c.CustomerID
WHERE c.OpenBalance >= 50000
ORDER BY c.OpenBalance DESC;  -- Result: 23 rows

-- Exercise 12.2, test A7: goods receipt lines not fully invoiced at the as-of date
-- Population: receipt lines received by the as-of date; expected: receipts not yet billed
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
InvoicedByReceipt AS (
    SELECT pil.GoodsReceiptLineID, SUM(pil.Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine AS pil
        INNER JOIN PurchaseInvoice AS pi
            ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    WHERE pi.ReceivedDate <= (SELECT AsOfDate FROM Params)
    GROUP BY pil.GoodsReceiptLineID
),
NotInvoiced AS (
    SELECT grl.GoodsReceiptLineID, gr.ReceiptNumber, gr.ReceiptDate,
        po.SupplierID, grl.QuantityReceived,
        COALESCE(ibr.QtyInvoiced, 0) AS QtyInvoiced,
        grl.ExtendedStandardCost
            * (1 - COALESCE(ibr.QtyInvoiced, 0) / grl.QuantityReceived)
            AS ValueNotInvoiced
    FROM GoodsReceiptLine AS grl
        INNER JOIN GoodsReceipt AS gr
            ON gr.GoodsReceiptID = grl.GoodsReceiptID
        INNER JOIN PurchaseOrder AS po
            ON po.PurchaseOrderID = gr.PurchaseOrderID
        LEFT JOIN InvoicedByReceipt AS ibr
            ON ibr.GoodsReceiptLineID = grl.GoodsReceiptLineID
    WHERE gr.ReceiptDate <= (SELECT AsOfDate FROM Params)
        AND COALESCE(ibr.QtyInvoiced, 0) < grl.QuantityReceived - 0.0001
)
SELECT ReceiptNumber, ReceiptDate, SupplierID, QuantityReceived,
    QtyInvoiced, ROUND(ValueNotInvoiced, 2) AS ValueNotInvoiced
FROM NotInvoiced
ORDER BY ReceiptDate, ReceiptNumber;  -- Result: 1150 rows

-- Exercise 12.2, test A8: the receipts not invoiced against account 2020
-- Population: the lines of test A7 and the ledger; expected: no difference
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
InvoicedByReceipt AS (
    SELECT pil.GoodsReceiptLineID, SUM(pil.Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine AS pil
        INNER JOIN PurchaseInvoice AS pi
            ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    WHERE pi.ReceivedDate <= (SELECT AsOfDate FROM Params)
    GROUP BY pil.GoodsReceiptLineID
),
NotInvoiced AS (
    SELECT grl.GoodsReceiptLineID, gr.ReceiptNumber, gr.ReceiptDate,
        po.SupplierID, grl.QuantityReceived,
        COALESCE(ibr.QtyInvoiced, 0) AS QtyInvoiced,
        grl.ExtendedStandardCost
            * (1 - COALESCE(ibr.QtyInvoiced, 0) / grl.QuantityReceived)
            AS ValueNotInvoiced
    FROM GoodsReceiptLine AS grl
        INNER JOIN GoodsReceipt AS gr
            ON gr.GoodsReceiptID = grl.GoodsReceiptID
        INNER JOIN PurchaseOrder AS po
            ON po.PurchaseOrderID = gr.PurchaseOrderID
        LEFT JOIN InvoicedByReceipt AS ibr
            ON ibr.GoodsReceiptLineID = grl.GoodsReceiptLineID
    WHERE gr.ReceiptDate <= (SELECT AsOfDate FROM Params)
        AND COALESCE(ibr.QtyInvoiced, 0) < grl.QuantityReceived - 0.0001
),
Ledger AS (
    SELECT SUM(gl.Credit) - SUM(gl.Debit) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 2020
        AND gl.PostingDate <= (SELECT AsOfDate FROM Params)
)
SELECT ROUND(SUM(ValueNotInvoiced), 2) AS NotInvoicedValue,
    ROUND((SELECT Balance FROM Ledger), 2) AS Account2020,
    ROUND(SUM(ValueNotInvoiced) - (SELECT Balance FROM Ledger), 2)
        AS Difference
FROM NotInvoiced;  -- Result: 1 row (NotInvoicedValue = 1020992.8, Account2020 = 1020992.06, Difference = 0.74)

-- Exercise 12.2, test A9: the receipts not invoiced by receipt month
-- Population: the lines of test A7; expected: only the latest month
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
InvoicedByReceipt AS (
    SELECT pil.GoodsReceiptLineID, SUM(pil.Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine AS pil
        INNER JOIN PurchaseInvoice AS pi
            ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    WHERE pi.ReceivedDate <= (SELECT AsOfDate FROM Params)
    GROUP BY pil.GoodsReceiptLineID
),
NotInvoiced AS (
    SELECT grl.GoodsReceiptLineID, gr.ReceiptNumber, gr.ReceiptDate,
        po.SupplierID, grl.QuantityReceived,
        COALESCE(ibr.QtyInvoiced, 0) AS QtyInvoiced,
        grl.ExtendedStandardCost
            * (1 - COALESCE(ibr.QtyInvoiced, 0) / grl.QuantityReceived)
            AS ValueNotInvoiced
    FROM GoodsReceiptLine AS grl
        INNER JOIN GoodsReceipt AS gr
            ON gr.GoodsReceiptID = grl.GoodsReceiptID
        INNER JOIN PurchaseOrder AS po
            ON po.PurchaseOrderID = gr.PurchaseOrderID
        LEFT JOIN InvoicedByReceipt AS ibr
            ON ibr.GoodsReceiptLineID = grl.GoodsReceiptLineID
    WHERE gr.ReceiptDate <= (SELECT AsOfDate FROM Params)
        AND COALESCE(ibr.QtyInvoiced, 0) < grl.QuantityReceived - 0.0001
)
SELECT strftime('%Y-%m', ReceiptDate) AS ReceiptMonth,
    COUNT(*) AS ReceiptLines, ROUND(SUM(ValueNotInvoiced), 2) AS Value
FROM NotInvoiced
GROUP BY ReceiptMonth
ORDER BY ReceiptMonth DESC;  -- Result: 5 rows

-- Exercise 12.2, test A10: the five suppliers with the most received but not invoiced
-- Population: the lines of test A7; expected: five rows
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
InvoicedByReceipt AS (
    SELECT pil.GoodsReceiptLineID, SUM(pil.Quantity) AS QtyInvoiced
    FROM PurchaseInvoiceLine AS pil
        INNER JOIN PurchaseInvoice AS pi
            ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    WHERE pi.ReceivedDate <= (SELECT AsOfDate FROM Params)
    GROUP BY pil.GoodsReceiptLineID
),
NotInvoiced AS (
    SELECT grl.GoodsReceiptLineID, gr.ReceiptNumber, gr.ReceiptDate,
        po.SupplierID, grl.QuantityReceived,
        COALESCE(ibr.QtyInvoiced, 0) AS QtyInvoiced,
        grl.ExtendedStandardCost
            * (1 - COALESCE(ibr.QtyInvoiced, 0) / grl.QuantityReceived)
            AS ValueNotInvoiced
    FROM GoodsReceiptLine AS grl
        INNER JOIN GoodsReceipt AS gr
            ON gr.GoodsReceiptID = grl.GoodsReceiptID
        INNER JOIN PurchaseOrder AS po
            ON po.PurchaseOrderID = gr.PurchaseOrderID
        LEFT JOIN InvoicedByReceipt AS ibr
            ON ibr.GoodsReceiptLineID = grl.GoodsReceiptLineID
    WHERE gr.ReceiptDate <= (SELECT AsOfDate FROM Params)
        AND COALESCE(ibr.QtyInvoiced, 0) < grl.QuantityReceived - 0.0001
)
SELECT SupplierID, COUNT(*) AS ReceiptLines,
    ROUND(SUM(ValueNotInvoiced), 2) AS Value
FROM NotInvoiced
GROUP BY SupplierID
ORDER BY Value DESC
LIMIT 5;  -- Result: 5 rows

/* Model answer (Requirement (2))

   The open invoices total 4,418,804.32, and account 1020 shows 4,798,804.32 at 2026-12-31. The difference of
   380,000.00 is exactly the receivables line of the opening entry JE-2024-000001, which no invoice supports
   (the finding of Chapter 8). The 225 invoices with a negative balance (-220,131.88) are invoices credited
   after they were paid (197 of them in full): the credit memo posts to account 2060, not to receivables, and
   the credit is refunded (222 of the 225 by the as-of date), so they are amounts owed to customers, not
   negative receivables, and are left out of the aging.
*/

/* Model answer (Requirement (5), memo to the controller)

   To: the controller. Subject: the open balances at 2026-12-31.

   Receivables. 1,079 invoices from 203 customers are open, 4,418,804.32 in all: Current 780 invoices,
   3,655,971.50; 1-30 days 258 invoices, 745,674.84; 31-60 days 28 invoices, 16,711.26; 61-90 days 10
   invoices, 405.41; Over 90 days 3 invoices, 41.31. Almost everything past due is less than 30 days late
   (745,674.84 of 762,832.82), and the invoices more than 60 days past due hold only 446.72. Account 1020 is
   4,798,804.32; the 380,000.00 difference is the opening-balance line of JE-2024-000001, unsupported by any
   invoice, which should be investigated and, if not supported, written off against the opening equity. The 23
   customers who owe $50,000 or more hold 42.3% of the balance and are the key items to confirm.

   Receipts not invoiced. 1,150 receipt lines (1,020,992.80) were received but not billed by the year-end, and
   they agree with account 2020 (1,020,992.06) except for 0.74 of rounding. Most are December receipts, which
   are normal; 87 lines received in August to October (27,668.25) are more than two months old and should be
   followed up with the suppliers and purchasing: disputed or lost invoices, or receipts recorded against the
   wrong order.
*/

/* Model answer (Dispositions)

   A1-A2: no exception; the aging is the basis for the allowance and the confirmations. A3 (380,000.00): the
   unsupported opening line, reported as a finding. A4 (225 invoices): credits on paid invoices, refunded
   through account 2060; no exception for receivables, and the 3 not yet refunded are liabilities to
   customers. A5-A6: the 23 key items are selected for confirmation. A7-A8: agrees with account 2020 within
   0.74, rounding; no exception. A9-A10: the 87 lines older than two months are referred to purchasing for
   follow-up.
*/

/* Notes

   Exercise 12.2: Aging the Open Balances
   (1) Calculate the open balance of each sales invoice at 2026-12-31, as Tutorial 8.2 did: its GrandTotal,
      less the receipts applied and the credit memos dated by the as-of date. Keep the as-of date in a one-row
      CTE, as in Chapter 11, and keep the invoices with a balance above zero.
   (2) Age the open balances by days past due with CASE, in the buckets of @tbl-08-02, and reconcile their
      total to account 1020 Accounts Receivable. Explain the difference, and what the invoices with a negative
      balance are.
   (3) Total the open balance by customer, grouping by CustomerID, and stratify the customers at $1,000,
      $10,000, and $50,000. List the customers with $50,000 or more as the key items to confirm, with their
      share of the open balance.
   (4) List the goods receipt lines not fully invoiced at the end of fiscal 2026, valued at their receipt
      value for the part not yet invoiced, with the supplier and the receipt date, and bound the receipts and
      the invoices by the as-of date. Total the value by receipt month, and list the five largest suppliers.
   (5) Write a short memo (one half page) to the controller on the two open balances: their aging, the
      difference in account 1020, and the receipts more than two months old.
   Instructor note: receivables at 2026-12-31 (days past due = julianday of the as-of date less julianday of
      DueDate; Current is zero or less): 1,079 invoices with a positive open balance, 4,418,804.32, from 203
      customers. Current 780 invoices, 3,655,971.50; 1-30 days 258, 745,674.84; 31-60 days 28, 16,711.26;
      61-90 days 10, 405.41; over 90 days 3, 41.31, the aging of Tutorial 8.2. Account 1020 (AccountID 3) at
      2026-12-31 is 4,798,804.32; the 380,000.00 difference is the opening-balance line of JE-2024-000001,
      which no invoice supports (Chapter 8's finding). 225 invoices have a negative balance (-220,131.88 in
      all): credit memos on invoices already paid (197 of them in full), which post to account 2060 and are
      refunded (222 of the 225 by 2026-12-31), so they are not receivables. Strata by customer: under 1,000,
      32 customers, 11,266.04; 1,000-9,999, 65, 330,518.49; 10,000-49,999, 83, 2,206,317.97; 50,000 and over,
      23, 1,870,701.82, 42.3% of the balance, the key items of Tutorial 8.2. Receipts not invoiced: 1,150
      receipt lines, 1,020,992.80 (account 2020 is 1,020,992.06; the 0.74 is the rounding of each invoice
      line's clearing amount). By receipt month: 2026-12 804,428.99 (736 lines); 2026-11 188,895.56 (327);
      2026-10 23,921.61 (75); 2026-09 2,836.29 (11); 2026-08 910.34 (1). Largest suppliers: 17 (59 lines,
      64,236.70), 52 (30, 49,449.79), 27 (63, 47,596.03). Receipts from August to October are more than two
      months old and need follow-up (disputed invoices, lost invoices, or receipts recorded against the wrong
      order).

   Checks (each agreed on dataset release v2026.1 when this file was built):
   12.2: invoices with a positive balance: 1079
   12.2: open balance: 4,418,804.32
   12.2: customers: 203
   12.2: buckets: ['Current', '1-30 days', '31-60 days', '61-90 days', 'Over 90 days']
   12.2: Current invoices: 780
   12.2: Current balance: 3,655,971.50
   12.2: 1-30 days invoices: 258
   12.2: 1-30 days balance: 745,674.84
   12.2: 31-60 days invoices: 28
   12.2: 31-60 days balance: 16,711.26
   12.2: 61-90 days invoices: 10
   12.2: 61-90 days balance: 405.41
   12.2: Over 90 days invoices: 3
   12.2: Over 90 days balance: 41.31
   12.2: open invoices: 4,418,804.32
   12.2: account 1020: 4,798,804.32
   12.2: difference: 380,000.00
   12.2: the opening line of JE-2024-000001: 380,000.00
   12.2: invoices with a negative balance: 225
   12.2: their balance: -220,131.88
   12.2: paid in full before the credit: 197
   12.2: credits refunded by the as-of date: 222
   12.2: strata: ['Under 1,000', '1,000-9,999', '10,000-49,999', '50,000 and over']
   12.2: Under 1,000 customers: 32
   12.2: Under 1,000 balance: 11,266.04
   12.2: 1,000-9,999 customers: 65
   12.2: 1,000-9,999 balance: 330,518.49
   12.2: 10,000-49,999 customers: 83
   12.2: 10,000-49,999 balance: 2,206,317.97
   12.2: 50,000 and over customers: 23
   12.2: 50,000 and over balance: 1,870,701.82
   12.2: key items: 23
   12.2: their balance: 1,870,701.82
   12.2: their share of the balance: 0.42
   12.2: receipt lines: 1150
   12.2: value not invoiced (the rounded lines added up): 1,020,992.80
   12.2: value not invoiced: 1,020,992.80
   12.2: account 2020: 1,020,992.06
   12.2: difference (rounding of the clearing amounts): 0.74
   12.2: months: ['2026-12', '2026-11', '2026-10', '2026-09', '2026-08']
   12.2: 2026-12 lines: 736
   12.2: 2026-12 value: 804,428.99
   12.2: 2026-11 lines: 327
   12.2: 2026-11 value: 188,895.56
   12.2: 2026-10 lines: 75
   12.2: 2026-10 value: 23,921.61
   12.2: 2026-09 lines: 11
   12.2: 2026-09 value: 2,836.29
   12.2: 2026-08 lines: 1
   12.2: 2026-08 value: 910.34
   12.2: suppliers: [17, 52, 27, 100, 46]
   12.2: supplier 17 lines: 59
   12.2: supplier 17 value: 64,236.70
   12.2: supplier 52 lines: 30
   12.2: supplier 52 value: 49,449.79
   12.2: supplier 27 lines: 63
   12.2: supplier 27 value: 47,596.03
*/
