/* Ex 12.5.sql: the pay of employees who had left, and the approval of payroll registers and payments
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: registers after termination; registers by approver; self-approved registers; payments before approval */

-- Exercise 12.5, test R1: registers paid after the employee's termination date
-- Population: all payroll registers; expected: final paychecks only
SELECT pr.PayrollRegisterID, pr.EmployeeID, e.JobTitle,
    ec.CostCenterName AS EmployeeCenter,
    rc.CostCenterName AS RegisterCenter, e.TerminationDate,
    pp.PeriodStartDate, pp.PeriodEndDate, pp.PayDate, pr.GrossPay,
    (SELECT ROUND(AVG(p2.GrossPay), 2)
     FROM PayrollRegister AS p2
        INNER JOIN PayrollPeriod AS q2
            ON q2.PayrollPeriodID = p2.PayrollPeriodID
     WHERE p2.EmployeeID = pr.EmployeeID
        AND q2.PayDate <= e.TerminationDate
        AND p2.GrossPay > 0) AS UsualGrossPay,
    (SELECT COUNT(*)
     FROM PayrollPayment AS pay
     WHERE pay.PayrollRegisterID = pr.PayrollRegisterID) AS Payments
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    INNER JOIN CostCenter AS ec ON ec.CostCenterID = e.CostCenterID
    INNER JOIN CostCenter AS rc ON rc.CostCenterID = pr.CostCenterID
WHERE e.TerminationDate IS NOT NULL
    AND pp.PayDate > e.TerminationDate
ORDER BY pp.PayDate;  -- Result: 3 rows

-- Exercise 12.5, test R2: the chief executive's registers against those periods
-- Population: the chief executive's registers; expected: one in every pay period
WITH AfterTermination AS (
    SELECT pr.PayrollPeriodID
    FROM PayrollRegister AS pr
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    WHERE e.TerminationDate IS NOT NULL
        AND pp.PayDate > e.TerminationDate
)
SELECT
    (SELECT COUNT(DISTINCT PayrollPeriodID) FROM PayrollRegister)
        AS PeriodsWithRegisters,
    COUNT(*) AS ExecutiveRegisters,
    SUM(CASE WHEN pr.PayrollPeriodID IN (
        SELECT PayrollPeriodID FROM AfterTermination)
        THEN 1 ELSE 0 END) AS InThosePeriods,
    MIN(pr.GrossPay) AS LowestGross, MAX(pr.GrossPay) AS HighestGross
FROM PayrollRegister AS pr
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
WHERE e.JobTitle = 'Chief Executive Officer';  -- Result: 1 rows

-- Exercise 12.5, test R3: registers approved by each approver, and on their pay date
-- Population: all payroll registers; expected: approval shared, before the pay date
SELECT pr.ApprovedByEmployeeID, e.JobTitle, COUNT(*) AS Registers,
    SUM(CASE WHEN pr.ApprovedDate = pp.PayDate THEN 1 ELSE 0 END)
        AS ApprovedOnPayDate
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.ApprovedByEmployeeID
GROUP BY pr.ApprovedByEmployeeID, e.JobTitle
ORDER BY Registers DESC;  -- Result: 1 rows

-- Exercise 12.5, test R4: registers approved by the employee they pay
-- Population: all payroll registers; expected: no rows
SELECT pr.EmployeeID, e.JobTitle, COUNT(*) AS Registers,
    ROUND(SUM(pr.NetPay), 2) AS NetPay
FROM PayrollRegister AS pr
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
WHERE pr.ApprovedByEmployeeID = pr.EmployeeID
GROUP BY pr.EmployeeID, e.JobTitle;  -- Result: 1 rows

-- Exercise 12.5, test R5: payments made before their register was approved
-- Population: all payroll payments; expected: no rows
SELECT pay.PayrollPaymentID, pay.PayrollRegisterID, e.JobTitle,
    pay.PaymentDate, pr.ApprovedDate, pr.NetPay
FROM PayrollPayment AS pay
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollRegisterID = pay.PayrollRegisterID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
WHERE pay.PaymentDate < pr.ApprovedDate
ORDER BY pay.PayrollPaymentID;  -- Result: 3 rows

/* Model answer (Requirements (1) and (4))

   Three registers pay the Account Executive (employee 81, Sales cost center, terminated 2024-04-26) after the
   termination: 840 (period from 2024-04-22, paid 2024-05-10), 2646 (paid 2025-01-03), and 5420 (paid
   2026-01-02), 9,424.91 gross each, about four times the employee's usual gross pay of 2,217.25, all charged
   to the Executive cost center. Only 840, whose period includes the termination date, could be a final
   paycheck, and even it pays four times the usual amount. The chief executive has a register in every other
   pay period, at the same 9,424.91, but none in these three (test R2), so the chief executive's pay for those
   periods appears to have been recorded under employee 81; 2646 and 5420 have no payment record (Tutorial
   12.1).

   Isolated exceptions or a pattern: the post-termination and unpaid registers are isolated exceptions (three
   registers, one employee) to be traced to the bank records. The approval results are a pattern: one person,
   the Accounting Manager (employee 5), approved all 8,197 registers, each on its pay date, including the 77
   that pay the accounting manager (282,646.21 net), and three payments (2, 2647, 5421, 23,099.19 net) paid
   the chief financial officer the day before the register was approved. A single approver who approves their
   own pay, on the day of payment, is a weakness in the design of the control, not an occasional lapse.
*/

/* Model answer (Requirement (5), findings and recommendations)

   1. Pay after termination: registers 840, 2646, 5420 pay a former Account Executive the chief executive's
   amount; trace them to the bank, confirm with the chief executive, and correct the payroll master data.
   Recommendation: deactivate pay at termination and review registers of terminated employees each period.

   2. Unrecorded or missing payments: 2646 and 5420 are approved with no payment; determine whether cash left
   the bank. Recommendation: reconcile registers to payments and to the bank every pay period.

   3. One approver for every register, including the approver's own 77. Recommendation: a second approver for
   registers, and an independent approver (the controller) for the approver's own pay.

   4. Payments before approval (three payments to the chief financial officer). Recommendation: release
   payments only after the register is approved, enforced by the system.

   5. Add tests R1 to R5 to the query library and run them every pay period.
*/

/* Model answer (Dispositions)

   R1 and R2 (3 registers): deficiency, pay recorded under a terminated employee; referred to the chief audit
   executive for investigation. R3 and R4 (8,197 registers, 77 self-approved): design deficiency of the
   payroll approval. R5 (three payments): deficiency, follow up with the chief financial officer and the bank
   records.
*/

/* Notes

   Exercise 12.5: Who Was Paid, and Who Approved the Pay?
   (1) List the registers whose pay date is after the employee's termination date, with the job title, the
      employee's own cost center and the register's, the dates of the pay period, and the gross pay. Add the
      employee's usual gross pay before the termination with a correlated subquery in the SELECT list, and
      explain which registers could be a final paycheck.
   (2) Count the registers each employee approved, grouping by the approver's key, and how many were approved
      on their pay date.
   (3) Count the registers approved by the employee they pay, and the payments made before their register was
      approved, with their net pay.
   (4) For each result, state whether it is an isolated exception or a pattern, and what it says about the
      design of the payroll approval control.
   (5) Write a short list of findings and recommendations for the chief audit executive.
   Instructor note: (1) three registers pay the Account Executive (employee 81, Sales cost center, terminated
      2024-04-26) after the termination: 840 (period from 2024-04-22, paid 2024-05-10), 2646 (paid
      2025-01-03), and 5420 (paid 2026-01-02), 9,424.91 gross each, about four times the employee's usual
      gross pay (2,217.25) and the amount of the chief executive's register, all charged to the Executive cost
      center. The chief executive has a register in every other pay period but none in these three, so the
      chief executive's pay for them appears to have gone to employee 81. Only 840, whose period includes the
      termination date, could be a final paycheck, and even it pays four times the usual amount. 2646 and 5420
      are the registers of Tutorial 12.1 with no payment record. (2) One person, the Accounting Manager
      (employee 5), approved all 8,197 registers, each on its pay date. (3) 77 registers, net pay 282,646.21,
      are the Accounting Manager's own; three payments (2, 2647, and 5421, 23,099.19 net) pay the chief
      financial officer the day before the register was approved. (4) The unpaid and post-termination
      registers are isolated exceptions, to be traced to the bank records; a single approver who approves
      their own pay is a weakness in the design of the control. Suggested changes: a second approver for
      registers and for the approver's own pay, and payments released only after approval.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   12.5: registers: 3
   12.5: the registers: [840, 2646, 5420]
   12.5: one employee: [81]
   12.5: job title: Account Executive
   12.5: employee's cost center: Sales
   12.5: register's cost center: ['Executive']
   12.5: gross pay of each: [9424.91, 9424.91, 9424.91]
   12.5: usual gross pay: 2,217.25
   12.5: registers without a payment: [2646, 5420]
   12.5: register whose period includes the termination: 840
   12.5: pay periods with registers: 77
   12.5: chief executive's registers: 74
   12.5: in the periods of test R1: 0
   12.5: one in every other period: 74
   12.5: gross pay equal to test R1's: 9,424.91
   12.5: and the same every period: 9,424.91
   12.5: approvers: 1
   12.5: the approver: 5
   12.5: job title: Accounting Manager
   12.5: registers: 8197
   12.5: approved on the pay date: 8197
   12.5: employees: 1
   12.5: the employee: 5
   12.5: registers: 77
   12.5: net pay: 282,646.21
   12.5: payments: 3
   12.5: the payments: [2, 2647, 5421]
   12.5: net pay: 23,099.19
   12.5: paid to: ['Chief Financial Officer']
   12.5: one day before approval: True
*/
