/* Ex 12.3.sql: direct time recorded while each operation was open, by work center
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: the flag covers every direct entry with an operation; ratios by work center and year; the first months of 2024 */

-- Exercise 12.3, test T1: direct labor time flagged as recorded while the operation was open
-- Population: direct labor time with an operation; expected: recorded by the operation's end
WITH Flagged AS (
    SELECT lt.LaborTimeEntryID, lt.WorkDate, op.ActualEndDate,
        lt.RegularHours + lt.OvertimeHours AS Hours,
        CASE WHEN lt.WorkDate <= op.ActualEndDate THEN 1 ELSE 0 END
            AS WhileOpen
    FROM LaborTimeEntry AS lt
        INNER JOIN WorkOrderOperation AS op
            ON op.WorkOrderOperationID = lt.WorkOrderOperationID
    WHERE lt.LaborType = 'Direct Manufacturing'
)
SELECT strftime('%Y', WorkDate) AS WorkYear, COUNT(*) AS Entries,
    SUM(WhileOpen) AS EntriesWhileOpen,
    ROUND(SUM(Hours), 0) AS DirectHours,
    ROUND(SUM(CASE WHEN WhileOpen = 1 THEN Hours ELSE 0 END), 0)
        AS HoursWhileOpen,
    ROUND(SUM(CASE WHEN WhileOpen = 0 THEN Hours ELSE 0 END)
        / SUM(Hours), 3) AS ShareAfterEnd
FROM Flagged
GROUP BY WorkYear
ORDER BY WorkYear;  -- Result: 3 rows

-- Exercise 12.3, test T2: recorded against planned hours by work center, all hours and while open
-- Population: operations ended by 2026-12-11; expected: near 1 for every work center
SELECT EndYear, WorkCenterName, PlannedHours, RecordedHours, OpenHours,
    ROUND(RecordedHours / PlannedHours, 2) AS RecordedPerPlanned,
    OpenPerPlanned
FROM (
    SELECT strftime('%Y', op.ActualEndDate) AS EndYear,
        wc.WorkCenterName,
        ROUND(SUM(op.PlannedLoadHours), 0) AS PlannedHours,
        ROUND(SUM(lab.Hours), 0) AS RecordedHours,
        ROUND(SUM(lab.OpenHours), 0) AS OpenHours,
        ROUND(SUM(lab.OpenHours) / SUM(op.PlannedLoadHours), 2)
            AS OpenPerPlanned
    FROM WorkOrderOperation AS op
        INNER JOIN WorkCenter AS wc ON wc.WorkCenterID = op.WorkCenterID
        LEFT JOIN (
            SELECT lt.WorkOrderOperationID,
                SUM(lt.RegularHours + lt.OvertimeHours) AS Hours,
                SUM(CASE WHEN lt.WorkDate <= o.ActualEndDate
                    THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END)
                    AS OpenHours
            FROM LaborTimeEntry AS lt
                INNER JOIN WorkOrderOperation AS o
                    ON o.WorkOrderOperationID = lt.WorkOrderOperationID
            WHERE lt.LaborType = 'Direct Manufacturing'
            GROUP BY lt.WorkOrderOperationID
        ) AS lab ON lab.WorkOrderOperationID = op.WorkOrderOperationID
    WHERE op.ActualEndDate <= (SELECT MAX(WorkDate) FROM LaborTimeEntry)
    GROUP BY EndYear, wc.WorkCenterName
) AS centers
ORDER BY EndYear, WorkCenterName;  -- Result: 15 rows

-- Exercise 12.3, test T3: the work centers ranked by each ratio
-- Population: the rows of test T2; expected: the same ranking on both ratios
SELECT EndYear, WorkCenterName,
    ROUND(RecordedHours / PlannedHours, 2) AS RecordedPerPlanned,
    RANK() OVER (PARTITION BY EndYear
        ORDER BY RecordedHours / PlannedHours DESC) AS AllHoursRank,
    OpenPerPlanned,
    RANK() OVER (PARTITION BY EndYear
        ORDER BY OpenPerPlanned DESC) AS WhileOpenRank
FROM (
    SELECT strftime('%Y', op.ActualEndDate) AS EndYear,
        wc.WorkCenterName,
        ROUND(SUM(op.PlannedLoadHours), 0) AS PlannedHours,
        ROUND(SUM(lab.Hours), 0) AS RecordedHours,
        ROUND(SUM(lab.OpenHours), 0) AS OpenHours,
        ROUND(SUM(lab.OpenHours) / SUM(op.PlannedLoadHours), 2)
            AS OpenPerPlanned
    FROM WorkOrderOperation AS op
        INNER JOIN WorkCenter AS wc ON wc.WorkCenterID = op.WorkCenterID
        LEFT JOIN (
            SELECT lt.WorkOrderOperationID,
                SUM(lt.RegularHours + lt.OvertimeHours) AS Hours,
                SUM(CASE WHEN lt.WorkDate <= o.ActualEndDate
                    THEN lt.RegularHours + lt.OvertimeHours ELSE 0 END)
                    AS OpenHours
            FROM LaborTimeEntry AS lt
                INNER JOIN WorkOrderOperation AS o
                    ON o.WorkOrderOperationID = lt.WorkOrderOperationID
            WHERE lt.LaborType = 'Direct Manufacturing'
            GROUP BY lt.WorkOrderOperationID
        ) AS lab ON lab.WorkOrderOperationID = op.WorkOrderOperationID
    WHERE op.ActualEndDate <= (SELECT MAX(WorkDate) FROM LaborTimeEntry)
    GROUP BY EndYear, wc.WorkCenterName
) AS centers
ORDER BY EndYear, WhileOpenRank;  -- Result: 15 rows

-- Exercise 12.3, test T4: work orders, completions, shipments, and hours, January to July 2024
-- Population: fiscal 2024; expected: completions near shipments in every month
WITH Released AS (
    SELECT strftime('%Y-%m', ReleasedDate) AS Month,
        COUNT(*) AS WorkOrdersReleased
    FROM WorkOrder
    GROUP BY Month
),
Completed AS (
    SELECT strftime('%Y-%m', pc.CompletionDate) AS Month,
        SUM(pcl.QuantityCompleted) AS UnitsCompleted
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    GROUP BY Month
),
Shipped AS (
    SELECT strftime('%Y-%m', s.ShipmentDate) AS Month,
        SUM(sl.QuantityShipped) AS UnitsShipped
    FROM ShipmentLine AS sl
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
        INNER JOIN Item AS i ON i.ItemID = sl.ItemID
    WHERE i.SupplyMode = 'Manufactured'
    GROUP BY Month
),
Hours AS (
    SELECT strftime('%Y-%m', WorkDate) AS Month,
        SUM(CASE LaborType WHEN 'Direct Manufacturing'
            THEN RegularHours + OvertimeHours ELSE 0 END) AS DirectHours,
        SUM(CASE LaborType WHEN 'Indirect Manufacturing'
            THEN RegularHours + OvertimeHours ELSE 0 END) AS IndirectHours
    FROM LaborTimeEntry
    GROUP BY Month
)
SELECT r.Month, r.WorkOrdersReleased,
    ROUND(c.UnitsCompleted, 0) AS UnitsCompleted,
    ROUND(sh.UnitsShipped, 0) AS UnitsShipped,
    ROUND(c.UnitsCompleted - sh.UnitsShipped, 0) AS UnitsToStock,
    ROUND(h.DirectHours, 0) AS DirectHours,
    ROUND(h.IndirectHours, 0) AS IndirectHours
FROM Released AS r
    LEFT JOIN Completed AS c ON c.Month = r.Month
    LEFT JOIN Shipped AS sh ON sh.Month = r.Month
    LEFT JOIN Hours AS h ON h.Month = r.Month
WHERE r.Month BETWEEN '2024-01' AND '2024-07'
ORDER BY r.Month;  -- Result: 7 rows

-- Exercise 12.3, test T5: the share of direct time recorded after its operation ended, by month of 2024
-- Population: direct labor time of 2024 with an operation; expected: a small share
WITH Flagged AS (
    SELECT lt.LaborTimeEntryID, lt.WorkDate, op.ActualEndDate,
        lt.RegularHours + lt.OvertimeHours AS Hours,
        CASE WHEN lt.WorkDate <= op.ActualEndDate THEN 1 ELSE 0 END
            AS WhileOpen
    FROM LaborTimeEntry AS lt
        INNER JOIN WorkOrderOperation AS op
            ON op.WorkOrderOperationID = lt.WorkOrderOperationID
    WHERE lt.LaborType = 'Direct Manufacturing'
)
SELECT strftime('%Y-%m', WorkDate) AS WorkMonth,
    ROUND(SUM(CASE WHEN WhileOpen = 0 THEN Hours ELSE 0 END)
        / SUM(Hours), 3) AS ShareAfterEnd
FROM Flagged
WHERE WorkDate BETWEEN '2024-01-01' AND '2024-12-31'
GROUP BY WorkMonth
ORDER BY WorkMonth;  -- Result: 12 rows

/* Model answer (Requirement (3))

   On all direct hours, 2026 ranks Packing, Quality Assurance, Finishing and Test, Cutting, Assembly (4.19,
   4.01, 0.56, 0.41, 0.40): Packing and Quality Assurance record about four times their planned hours.
   Counting only the time recorded while each operation was open, the order becomes Quality Assurance,
   Finishing and Test, Assembly, Cutting, Packing (0.81, 0.39, 0.34, 0.29, 0.22): every work center is below
   plan, and Packing falls from first to last. The Packing excess was time charged after the operation had
   ended; Packing is the last operation of every routing, so time recorded late lands there. Quality Assurance
   ranks first while open, but its planned hours are the smallest of any work center, so a few hours move its
   ratio. In 2024 the in-window ratios were Assembly 0.62, Cutting 0.55, Finishing and Test 0.68, Packing
   0.38, Quality Assurance 1.28.
*/

/* Model answer (Requirement (4))

   From February to June 2024 the plant completed far more units than it shipped (test T4), about 12,000 units
   of stock in all: an inventory build that kept every hour on work orders, so almost no time was recorded as
   indirect. When releases and completions fell to the rate of shipments in July, the same 64 employees kept
   their hours, and the days with no work order to charge became indirect time. The share of direct time
   recorded after its operation ended stayed between 0.00 and 0.16 a month through June 2024 and first passed
   a quarter in July 2024 (0.41), the month surge days began in earnest.
*/

/* Model answer (Requirement (5), memo to the plant manager)

   To: the plant manager. Subject: what the operation-level time can support.

   Much of the direct time is recorded after the operation it is charged to has ended: 66% of the direct hours
   of 2026, against 19% in 2024. Counted only while the operations were open, every work center used less time
   than planned in 2026, and the apparent excess at Packing and Quality Assurance disappears. The comparison
   of work centers against plan therefore cannot be relied on: it measures where late time is parked, not how
   efficiently each work center works. The plant-level measure of Chapter 11 (all manufacturing hours against
   the standard hours of output) does not depend on which operation the time is charged to and is unaffected.

   What should change: time should be recorded against an operation only while it is open, with the system
   rejecting entries after the ActualEndDate; time with no open operation should be recorded as indirect time
   with a reason, and supervisors should review late entries weekly. Until then, efficiency should be reported
   at the plant level only.
*/

/* Model answer (Dispositions)

   T1 and T5: direct time recorded after the operation ended (65.8% of 2026's hours), a recording deficiency
   reported to the plant manager. T2 and T3: no work center exceeds plan on the time recorded while open; the
   Packing and Quality Assurance excess is explained by late recording, not by inefficiency. T4: the 2024
   stock build explains the months with little indirect time; no exception.
*/

/* Notes

   Exercise 12.3: Where Did the Time Go?
   (1) For each direct labor time entry, flag whether it was recorded on or before the operation's
      ActualEndDate.
   (2) Repeat the work-center comparison of Tutorial 11.2, with the planned hours of each work center and
      year, and two recorded-to-planned ratios: one for all direct hours, and one for the hours recorded while
      the operation was open.
   (3) Rank the work centers by each ratio, and describe how the ranking changes.
   (4) For each month from January to July 2024, count the work orders released and total the units completed
      and the manufactured units shipped. Explain why there is so little indirect time from February to May
      2024, and find the month in which the share of direct time recorded after its operation ended first
      passed a quarter.
   (5) Write a short memo (one half page) to the plant manager: what the operation-level data can and cannot
      support, and what should change in how time is recorded.
   Instructor note: counting only the time recorded while the operation was open, every work center falls
      below plan in fiscal 2026: Assembly 0.34, Cutting 0.29, Finishing and Test 0.39, Packing 0.22, Quality
      Assurance 0.81 (against all-hours ratios of 0.40, 0.41, 0.56, 4.19, 4.01; operations that ended by
      2026-12-11, the last day with time records, with hours rounded before dividing, as in Tutorial 11.2; the
      in-window ratios divide unrounded hours). In 2024 the in-window ratios were 0.62, 0.55, 0.68, 0.38,
      1.28. The Packing excess disappears, which shows that it came from time charged after the operation
      ended; Packing is the last operation of every routing, so late time lands there. January to July 2024:
      work orders released 336, 568, 680, 524, 515, 460, 328; units completed 348, 6,110, 6,280, 6,673, 4,524,
      5,877, 3,201; manufactured units shipped 2,018, 3,331, 3,182, 3,539, 3,673, 3,686, 3,311. From February
      to June the plant completed about 12,000 more units than it shipped, an inventory build that kept every
      hour on work orders; when releases and completions fell to the rate of shipments from July, the same 64
      employees kept their hours, and the unassigned days became indirect time. The late-recorded share was
      0.00-0.16 a month through June 2024 and 0.41 in July 2024, the month surge days began in earnest.
      Operation-level efficiency cannot be measured until time is recorded against open operations; the plant-
      level measure of Chapter 11 is unaffected.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   12.3: entries flagged: 51097
   12.3: 2024 direct hours (test H9): 60442
   12.3: 2024 share recorded after the end (test H9): 0.20
   12.3: 2025 direct hours (test H9): 57557
   12.3: 2025 share recorded after the end (test H9): 0.50
   12.3: 2026 direct hours (test H9): 62742
   12.3: 2026 share recorded after the end (test H9): 0.66
   12.3: work centers and years: 15
   12.3: Assembly 2026, all hours: 0.40
   12.3: Assembly 2026, while open: 0.34
   12.3: Assembly 2024, while open: 0.62
   12.3: Cutting 2026, all hours: 0.41
   12.3: Cutting 2026, while open: 0.29
   12.3: Cutting 2024, while open: 0.55
   12.3: Finishing and Test 2026, all hours: 0.56
   12.3: Finishing and Test 2026, while open: 0.39
   12.3: Finishing and Test 2024, while open: 0.68
   12.3: Packing 2026, all hours: 4.19
   12.3: Packing 2026, while open: 0.22
   12.3: Packing 2024, while open: 0.38
   12.3: Quality Assurance 2026, all hours: 4.01
   12.3: Quality Assurance 2026, while open: 0.81
   12.3: Quality Assurance 2024, while open: 1.28
   12.3: 2026 order on all hours: ['Packing Work Center', 'Quality Assurance Work Center', 'Finishing and Test
      Work Center', 'Cutting Work Center', 'Assembly Work Center']
   12.3: 2026 order while open: ['Quality Assurance Work Center', 'Finishing and Test Work Center', 'Assembly
      Work Center', 'Cutting Work Center', 'Packing Work Center']
   12.3: months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06', '2024-07']
   12.3: work orders released: [336, 568, 680, 524, 515, 460, 328]
   12.3: units completed: [348.0, 6110.0, 6280.0, 6673.0, 4524.0, 5877.0, 3201.0]
   12.3: manufactured units shipped: [2018.0, 3331.0, 3182.0, 3539.0, 3673.0, 3686.0, 3311.0]
   12.3: indirect hours by month: [4931, 97, 0, 80, 70, 2239, 3179]
   12.3: months: 12
   12.3: first month above a quarter: 2024-07
   12.3: its share: 0.41
   12.3: highest share before it: 0.16
*/
