/* Ex 12.4.sql: whether the overtime approval controls the growth in overtime
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 18,145 approvals by reason, approver, hours, and date; the surge days of test H8 */

-- Exercise 12.4, test O1: overtime approvals by year and reason code
-- Population: all 18,145 overtime approvals; expected: reasons that change with the overtime
SELECT strftime('%Y', WorkDate) AS WorkYear, ReasonCode,
    COUNT(*) AS Approvals,
    ROUND(COUNT(*) * 1.0 / SUM(COUNT(*)) OVER (
        PARTITION BY strftime('%Y', WorkDate)), 3) AS ShareOfYear
FROM OvertimeApproval
GROUP BY WorkYear, ReasonCode
ORDER BY WorkYear, ReasonCode;  -- Result: 12 rows

-- Exercise 12.4, test O2: approvals by approver, with the largest approver's share
-- Population: all overtime approvals; expected: approval shared among supervisors
SELECT oa.ApprovedByEmployeeID, e.JobTitle, COUNT(*) AS Approvals,
    ROUND(COUNT(*) * 1.0 / SUM(COUNT(*)) OVER (), 3) AS ShareOfApprovals
FROM OvertimeApproval AS oa
    INNER JOIN Employee AS e ON e.EmployeeID = oa.ApprovedByEmployeeID
GROUP BY oa.ApprovedByEmployeeID, e.JobTitle
ORDER BY Approvals DESC;  -- Result: 4 rows

-- Exercise 12.4, test O3: approved against requested hours, and approval against work date
-- Population: all overtime approvals; expected: some requests reduced, approvals in advance
SELECT COUNT(*) AS Approvals,
    SUM(CASE WHEN ApprovedHours = RequestedHours THEN 1 ELSE 0 END)
        AS HoursAsRequested,
    SUM(CASE WHEN ApprovedHours < RequestedHours THEN 1 ELSE 0 END)
        AS HoursReduced,
    SUM(CASE WHEN ApprovedDate < WorkDate THEN 1 ELSE 0 END)
        AS ApprovedInAdvance,
    SUM(CASE WHEN ApprovedDate = WorkDate THEN 1 ELSE 0 END)
        AS ApprovedOnWorkDate,
    SUM(CASE WHEN ApprovedDate > WorkDate THEN 1 ELSE 0 END)
        AS ApprovedAfter
FROM OvertimeApproval;  -- Result: 1 rows

-- Exercise 12.4, test O4: who approved the overtime of the surge days, and when
-- Population: manufacturing clock entries on the surge days of test H8; expected: approved in advance
WITH SurgeDays AS (
    SELECT tc.WorkDate
    FROM TimeClockEntry AS tc
        INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY tc.WorkDate
    HAVING COUNT(DISTINCT tc.RegularHours + tc.OvertimeHours) = 1
        AND COUNT(*) > 1
)
SELECT ap.JobTitle AS ApprovedBy,
    CASE
        WHEN oa.ApprovedDate IS NULL THEN 'No approval'
        WHEN oa.ApprovedDate < tc.WorkDate THEN 'Before the work date'
        WHEN oa.ApprovedDate = tc.WorkDate THEN 'On the work date'
        ELSE 'After the work date'
    END AS ApprovalTiming,
    COUNT(DISTINCT tc.WorkDate) AS SurgeDays, COUNT(*) AS ClockEntries,
    ROUND(SUM(tc.OvertimeHours), 0) AS OvertimeHours
FROM TimeClockEntry AS tc
    INNER JOIN SurgeDays AS sd ON sd.WorkDate = tc.WorkDate
    INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    LEFT JOIN OvertimeApproval AS oa
        ON oa.OvertimeApprovalID = tc.OvertimeApprovalID
    LEFT JOIN Employee AS ap ON ap.EmployeeID = oa.ApprovedByEmployeeID
WHERE cc.CostCenterName = 'Manufacturing'
GROUP BY ApprovedBy, ApprovalTiming;  -- Result: 1 rows

-- Exercise 12.4, test O5: manufacturing overtime on surge days and on other days, by year
-- Population: manufacturing clock entries; expected: growth spread over the year
WITH SurgeDays AS (
    SELECT tc.WorkDate
    FROM TimeClockEntry AS tc
        INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY tc.WorkDate
    HAVING COUNT(DISTINCT tc.RegularHours + tc.OvertimeHours) = 1
        AND COUNT(*) > 1
)
SELECT strftime('%Y', tc.WorkDate) AS WorkYear,
    ROUND(SUM(CASE WHEN sd.WorkDate IS NOT NULL
        THEN tc.OvertimeHours ELSE 0 END), 0) AS SurgeDayOvertime,
    ROUND(SUM(CASE WHEN sd.WorkDate IS NULL
        THEN tc.OvertimeHours ELSE 0 END), 0) AS OtherDayOvertime,
    ROUND(SUM(tc.OvertimeHours), 0) AS Overtime
FROM TimeClockEntry AS tc
    INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    LEFT JOIN SurgeDays AS sd ON sd.WorkDate = tc.WorkDate
WHERE cc.CostCenterName = 'Manufacturing'
GROUP BY WorkYear
ORDER BY WorkYear;  -- Result: 3 rows

/* Model answer (Requirement (5))

   The approval records overtime rather than authorizing it. The four reason codes (Backlog Recovery, Late
   Operation, Load Surge, Month-End Support) each hold about a quarter of the approvals in every year, so the
   reasons say nothing about why overtime grew. The Production Manager approved 16,676 of the 18,145 approvals
   (91.9%), every approval grants exactly the hours requested, and every one is dated on the work date itself:
   no request was ever reduced, and none was approved before the work. All 5,952 clock entries of the 93 surge
   days were approved by the Production Manager on the work date. Overtime on other days stayed about the same
   (6,273, 6,426, 5,918 hours), while overtime on surge days grew from 3,456 to 9,216 and 14,112 hours
   (+10,656, against -355 on other days): all the growth sits on days the same manager scheduled and approved.

   Two changes would make it a control: approval in advance of the shift, with a limit of overtime per
   employee and week above which a second approver outside production (such as the controller) must agree; and
   reason codes tied to a work order or a documented backlog, reviewed monthly by someone independent of the
   person who schedules the surge days.
*/

/* Model answer (Dispositions)

   O1: the reason codes carry no information, a design deficiency. O2: concentration of approval in the
   Production Manager (91.9%), a segregation-of-duties finding. O3: no approval reduces hours or precedes the
   work, so the approval is a record, not an authorization; reported as a design deficiency. O4 and O5: the
   surge-day overtime (14,112 hours in 2026) was scheduled and approved by one person on the day; referred to
   the controller for review of the surge days' business need.
*/

/* Notes

   Exercise 12.4: Is the Overtime Approval Doing Its Job?
   (1) Count the overtime approvals by year and reason code, and describe how the mix of reasons changed as
      overtime grew.
   (2) Count the approvals by approver and job title, and calculate the share approved by the largest
      approver.
   (3) Compare each approval's ApprovedHours with its RequestedHours, and its ApprovedDate with the WorkDate
      of the overtime.
   (4) For the surge days of Tutorial 12.3, report who approved the overtime and when, and compare the
      overtime on those days with the overtime on other days in each year.
   (5) Explain what the results say about the design of the overtime approval control, and suggest two changes
      that would make it a real control.
   Instructor note: 18,145 approvals, spread almost evenly over four reason codes in every year (Backlog
      Recovery, Late Operation, Load Surge, Month-End Support; about a quarter each), so the reasons carry no
      information about why overtime grew. The Production Manager approved 16,676 approvals (about 92%). Every
      approval grants exactly the hours requested, and every approval is dated on the work date itself, so no
      request was ever reduced or approved in advance. All 5,952 clock entries of the 93 surge days were
      approved by the Production Manager on the work date. Manufacturing overtime on other days stayed about
      the same (6,273, 6,426, 5,918 hours), while overtime on surge days grew from 3,456 to 9,216 and 14,112
      hours: all the growth. The control records overtime rather than authorizing it: approval in advance, a
      limit per employee and week, and informative reasons reviewed by someone outside production would make
      it a control.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   12.4: approvals: 18145
   12.4: reason codes: ['Backlog Recovery', 'Late Operation', 'Load Surge', 'Month-End Support']
   12.4: every share of a year between 0.2 and 0.3: True
   12.4: 2024 Backlog Recovery: 1178
   12.4: 2024 Late Operation: 1140
   12.4: 2024 Load Surge: 1155
   12.4: 2024 Month-End Support: 1154
   12.4: 2025 Backlog Recovery: 1602
   12.4: 2025 Late Operation: 1621
   12.4: 2025 Load Surge: 1561
   12.4: 2025 Month-End Support: 1557
   12.4: 2026 Backlog Recovery: 1762
   12.4: 2026 Late Operation: 1812
   12.4: 2026 Load Surge: 1793
   12.4: 2026 Month-End Support: 1810
   12.4: approvers: 4
   12.4: largest approver: 4
   12.4: its job title: Production Manager
   12.4: its approvals: 16676
   12.4: its share: 0.92
   12.4: approvals: 18145
   12.4: hours as requested (all): 18145
   12.4: hours reduced: 0
   12.4: approved in advance: 0
   12.4: approved on the work date (all): 18145
   12.4: approver and timing groups: 1
   12.4: approved by: Production Manager
   12.4: timing: On the work date
   12.4: surge days: 93
   12.4: clock entries: 5952
   12.4: years: ['2024', '2025', '2026']
   12.4: surge-day overtime: [3456, 9216, 14112]
   12.4: other-day overtime: [6273, 6426, 5918]
*/
