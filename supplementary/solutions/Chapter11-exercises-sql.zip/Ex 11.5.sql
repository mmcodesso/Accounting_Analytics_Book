/* Ex 11.5.sql: the five journal entry tests of Tutorial 8.3 and their risk score
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 851 entries; the counts by test and by score equal Tutorial 8.3's */

-- Requirements (1) and (2), step 1: the entries flagged by each test
-- Population: all 851 journal entries; expected: Tutorial 8.3's counts
WITH Flags AS (
    SELECT je.EntryNumber, je.EntryType, je.PostingDate, je.TotalAmount,
        CASE WHEN strftime('%w', je.CreatedDate) IN ('0', '6')
            THEN 1 ELSE 0 END AS Weekend,
        CASE WHEN date(je.CreatedDate) > je.PostingDate
            THEN 1 ELSE 0 END AS Backdated,
        CASE WHEN je.CreatedByEmployeeID = je.ApprovedByEmployeeID
            THEN 1 ELSE 0 END AS SelfApproved,
        CASE WHEN je.TotalAmount > COALESCE(e.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS AboveLimit,
        CASE WHEN je.TotalAmount = ROUND(je.TotalAmount / 1000, 0) * 1000
            THEN 1 ELSE 0 END AS RoundAmount
    FROM JournalEntry AS je
        LEFT JOIN Employee AS e ON e.EmployeeID = je.ApprovedByEmployeeID
)
SELECT COUNT(*) AS Entries, SUM(Weekend) AS Weekend,
    SUM(Backdated) AS Backdated, SUM(SelfApproved) AS SelfApproved,
    SUM(AboveLimit) AS AboveLimit, SUM(RoundAmount) AS RoundAmount
FROM Flags;  -- Result: 1 rows

-- Requirement (2), step 2: the entries at each risk score
-- Population: all journal entries; expected: 4 scores, as Tutorial 8.3
WITH Flags AS (
    SELECT je.EntryNumber, je.EntryType, je.PostingDate, je.TotalAmount,
        CASE WHEN strftime('%w', je.CreatedDate) IN ('0', '6')
            THEN 1 ELSE 0 END AS Weekend,
        CASE WHEN date(je.CreatedDate) > je.PostingDate
            THEN 1 ELSE 0 END AS Backdated,
        CASE WHEN je.CreatedByEmployeeID = je.ApprovedByEmployeeID
            THEN 1 ELSE 0 END AS SelfApproved,
        CASE WHEN je.TotalAmount > COALESCE(e.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS AboveLimit,
        CASE WHEN je.TotalAmount = ROUND(je.TotalAmount / 1000, 0) * 1000
            THEN 1 ELSE 0 END AS RoundAmount
    FROM JournalEntry AS je
        LEFT JOIN Employee AS e ON e.EmployeeID = je.ApprovedByEmployeeID
),
Scored AS (
    SELECT *,
        Weekend + Backdated + SelfApproved + AboveLimit + RoundAmount
            AS RiskScore
    FROM Flags
)
SELECT RiskScore, COUNT(*) AS Entries,
    ROUND(SUM(TotalAmount), 2) AS TotalAmount
FROM Scored
GROUP BY RiskScore
ORDER BY RiskScore;  -- Result: 4 rows

-- Requirement (4): the entries scoring 2 or more, ranked by score and amount
-- Population: the scored entries; expected: 8 entries, JE-2024-000001 first
WITH Flags AS (
    SELECT je.EntryNumber, je.EntryType, je.PostingDate, je.TotalAmount,
        CASE WHEN strftime('%w', je.CreatedDate) IN ('0', '6')
            THEN 1 ELSE 0 END AS Weekend,
        CASE WHEN date(je.CreatedDate) > je.PostingDate
            THEN 1 ELSE 0 END AS Backdated,
        CASE WHEN je.CreatedByEmployeeID = je.ApprovedByEmployeeID
            THEN 1 ELSE 0 END AS SelfApproved,
        CASE WHEN je.TotalAmount > COALESCE(e.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS AboveLimit,
        CASE WHEN je.TotalAmount = ROUND(je.TotalAmount / 1000, 0) * 1000
            THEN 1 ELSE 0 END AS RoundAmount
    FROM JournalEntry AS je
        LEFT JOIN Employee AS e ON e.EmployeeID = je.ApprovedByEmployeeID
),
Scored AS (
    SELECT *,
        Weekend + Backdated + SelfApproved + AboveLimit + RoundAmount
            AS RiskScore
    FROM Flags
)
SELECT RANK() OVER (ORDER BY RiskScore DESC, TotalAmount DESC)
        AS ReviewRank,
    EntryNumber, EntryType, PostingDate, TotalAmount, RiskScore,
    Weekend, Backdated, SelfApproved, AboveLimit, RoundAmount
FROM Scored
WHERE RiskScore >= 2
ORDER BY ReviewRank;  -- Result: 8 rows

-- Requirement (5), step 1: the tests saved as a view
-- Population: all journal entries; expected: the view is created
DROP VIEW IF EXISTS Ex11_5_JournalEntryTests;
CREATE VIEW Ex11_5_JournalEntryTests AS
WITH Flags AS (
    SELECT je.EntryNumber, je.EntryType, je.PostingDate, je.TotalAmount,
        CASE WHEN strftime('%w', je.CreatedDate) IN ('0', '6')
            THEN 1 ELSE 0 END AS Weekend,
        CASE WHEN date(je.CreatedDate) > je.PostingDate
            THEN 1 ELSE 0 END AS Backdated,
        CASE WHEN je.CreatedByEmployeeID = je.ApprovedByEmployeeID
            THEN 1 ELSE 0 END AS SelfApproved,
        CASE WHEN je.TotalAmount > COALESCE(e.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS AboveLimit,
        CASE WHEN je.TotalAmount = ROUND(je.TotalAmount / 1000, 0) * 1000
            THEN 1 ELSE 0 END AS RoundAmount
    FROM JournalEntry AS je
        LEFT JOIN Employee AS e ON e.EmployeeID = je.ApprovedByEmployeeID
),
Scored AS (
    SELECT *,
        Weekend + Backdated + SelfApproved + AboveLimit + RoundAmount
            AS RiskScore
    FROM Flags
)
SELECT EntryNumber, EntryType, PostingDate, TotalAmount, Weekend,
    Backdated, SelfApproved, AboveLimit, RoundAmount, RiskScore
FROM Scored;  -- Result: creates the view Ex11_5_JournalEntryTests

-- Requirement (5), step 2: the view rerun, by test
-- Population: the view; expected: the counts of step 1
SELECT COUNT(*) AS Entries, SUM(Weekend) AS Weekend,
    SUM(Backdated) AS Backdated, SUM(SelfApproved) AS SelfApproved,
    SUM(AboveLimit) AS AboveLimit, SUM(RoundAmount) AS RoundAmount,
    SUM(CASE WHEN RiskScore >= 2 THEN 1 ELSE 0 END) AS ScoreTwoOrMore
FROM Ex11_5_JournalEntryTests;  -- Result: 1 rows

/* Model answer (Requirement (3))

   The SQL tests give the counts of Tutorial 8.3 on all 851 journal entries: Weekend 17, Backdated 6,
   SelfApproved 7, AboveLimit 9, RoundAmount 4; scores 0: 818, 1: 25, 2: 7, 4: 1 (no entry scores 3, so that
   row does not appear). The highest score, 4, belongs to JE-2024-000001, the opening balance entry created by
   the chief financial officer. Weekend and Backdated read the time-stamped CreatedDate (strftime and date
   take the date part), and RoundAmount compares the amount with its value rounded to thousands, because the %
   operator truncates decimals in SQLite and is not safe on amounts.
*/

/* Model answer (Requirement (5))

   A saved query is stronger evidence than a formula copied down a column because it is one definition applied
   to the whole population: it cannot skip rows, be overwritten in a single cell, or be left behind when new
   entries are added, and anyone can rerun it on the same file and get the same result. Its text documents
   exactly how each flag is calculated, so a reviewer can inspect the test itself rather than sample the
   cells, and next year's entries are tested by running the view again, without rebuilding a workbook.
*/

/* Notes

   Exercise 11.5: Journal Entry Tests in SQL
   (1) Join JournalEntry to Employee on the approver, and write a CTE with five flags. Each flag is a CASE
      expression that returns 1 or 0: Weekend (created on a Saturday or Sunday, using strftime on
      CreatedDate), Backdated (created on a later day than its posting date), SelfApproved, AboveLimit
      (TotalAmount above the approver's MaxApprovalAmount), and RoundAmount (TotalAmount in exact thousands).
   (2) Add a RiskScore that sums the five flags, and count the entries flagged by each test and the entries at
      each score.
   (3) Compare the counts with your results from Tutorial 8.3.
   (4) List the entries with a score of 2 or more, ranked by score and then by TotalAmount, with RANK.
   (5) Save the query as a view, and explain in two or three sentences why a saved query is stronger audit
      evidence than a workbook formula copied down a column.
   Instructor note: 851 journal entries. Flags: Weekend 17, Backdated 6, SelfApproved 7, AboveLimit 9,
      RoundAmount 4; scores 0: 818, 1: 25, 2: 7, 4: 1 (no entry scores 3, so that row does not appear), the
      same as Chapter 8. Working formulas: Weekend strftime('%w', CreatedDate) IN ('0', '6'); Backdated
      date(CreatedDate) > PostingDate; RoundAmount TotalAmount = ROUND(TotalAmount / 1000, 0) * 1000 (the %
      operator truncates decimals in SQLite, so it is not safe on amounts); AboveLimit with a LEFT JOIN to
      Employee on ApprovedByEmployeeID. The score-4 entry is JE-2024-000001, the opening balance entry created
      by the chief financial officer.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   11.5: entries: 851
   11.5: Weekend flags: 17
   11.5: Backdated flags: 6
   11.5: SelfApproved flags: 7
   11.5: AboveLimit flags: 9
   11.5: RoundAmount flags: 4
   11.5: scores present: [0, 1, 2, 4]
   11.5: entries scoring 0: 818
   11.5: entries scoring 1: 25
   11.5: entries scoring 2: 7
   11.5: entries scoring 4: 1
   11.5: entries scoring 2 or more: 8
   11.5: first entry: JE-2024-000001
   11.5: its score: 4
   11.5: entries in the view: 851
   11.5: Weekend flags in the view: 17
   11.5: Backdated flags in the view: 6
   11.5: SelfApproved flags in the view: 7
   11.5: AboveLimit flags in the view: 9
   11.5: RoundAmount flags in the view: 4
   11.5: entries scoring 2 or more in the view: 8
*/
