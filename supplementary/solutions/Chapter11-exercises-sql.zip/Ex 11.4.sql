/* Ex 11.4.sql: is manufacturing overtime concentrated in a few employees?
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 64 employees with overtime in fiscal 2026; the running share reaches 1 */

-- Requirement (1): fiscal 2026 overtime hours by employee, by work date, with the job title
-- Population: manufacturing labor time of 2026; expected: 64 employees
SELECT lt.EmployeeID, e.JobTitle,
    ROUND(SUM(lt.OvertimeHours), 1) AS OvertimeHours
FROM LaborTimeEntry AS lt
    INNER JOIN Employee AS e ON e.EmployeeID = lt.EmployeeID
WHERE lt.LaborType <> 'NonManufacturing'
    AND lt.WorkDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY lt.EmployeeID, e.JobTitle
HAVING SUM(lt.OvertimeHours) > 0
ORDER BY OvertimeHours DESC, lt.EmployeeID;  -- Result: 64 rows

-- Requirement (2): the employees ranked, with a running share of all overtime
-- Population: the employees with overtime; expected: the running share reaches 1.000
WITH Overtime AS (
    SELECT lt.EmployeeID, e.JobTitle,
        SUM(lt.OvertimeHours) AS OvertimeHours
    FROM LaborTimeEntry AS lt
        INNER JOIN Employee AS e ON e.EmployeeID = lt.EmployeeID
    WHERE lt.LaborType <> 'NonManufacturing'
        AND lt.WorkDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY lt.EmployeeID, e.JobTitle
    HAVING SUM(lt.OvertimeHours) > 0
),
Running AS (
    SELECT EmployeeID, JobTitle, OvertimeHours,
        RANK() OVER (ORDER BY OvertimeHours DESC) AS OvertimeRank,
        ROW_NUMBER() OVER (ORDER BY OvertimeHours DESC, EmployeeID)
            AS RunningRank,
        SUM(OvertimeHours) OVER (ORDER BY OvertimeHours DESC, EmployeeID
            ROWS UNBOUNDED PRECEDING)
            / SUM(OvertimeHours) OVER () AS RunningShare
    FROM Overtime
)
SELECT EmployeeID, JobTitle, ROUND(OvertimeHours, 1) AS OvertimeHours,
    OvertimeRank, ROUND(RunningShare, 3) AS RunningShare
FROM Running
ORDER BY RunningRank;  -- Result: 64 rows

-- Requirement (3): the number of employees that account for half of the overtime
-- Population: the ranked employees; expected: 32 of 64
WITH Overtime AS (
    SELECT lt.EmployeeID, e.JobTitle,
        SUM(lt.OvertimeHours) AS OvertimeHours
    FROM LaborTimeEntry AS lt
        INNER JOIN Employee AS e ON e.EmployeeID = lt.EmployeeID
    WHERE lt.LaborType <> 'NonManufacturing'
        AND lt.WorkDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY lt.EmployeeID, e.JobTitle
    HAVING SUM(lt.OvertimeHours) > 0
),
Running AS (
    SELECT EmployeeID, JobTitle, OvertimeHours,
        RANK() OVER (ORDER BY OvertimeHours DESC) AS OvertimeRank,
        ROW_NUMBER() OVER (ORDER BY OvertimeHours DESC, EmployeeID)
            AS RunningRank,
        SUM(OvertimeHours) OVER (ORDER BY OvertimeHours DESC, EmployeeID
            ROWS UNBOUNDED PRECEDING)
            / SUM(OvertimeHours) OVER () AS RunningShare
    FROM Overtime
)
SELECT MIN(RunningRank) AS EmployeesForHalf,
    (SELECT COUNT(*) FROM Overtime) AS Employees,
    (SELECT ROUND(SUM(OvertimeHours), 0) FROM Overtime) AS TotalOvertime
FROM Running
WHERE RunningShare >= 0.5;  -- Result: 1 row (EmployeesForHalf = 32, Employees = 64, TotalOvertime = 20030.0)

-- Requirement (4): overtime hours and the average per employee by job title
-- Population: the employees with overtime; expected: 3 job titles
WITH Overtime AS (
    SELECT lt.EmployeeID, e.JobTitle,
        SUM(lt.OvertimeHours) AS OvertimeHours
    FROM LaborTimeEntry AS lt
        INNER JOIN Employee AS e ON e.EmployeeID = lt.EmployeeID
    WHERE lt.LaborType <> 'NonManufacturing'
        AND lt.WorkDate BETWEEN '2026-01-01' AND '2026-12-31'
    GROUP BY lt.EmployeeID, e.JobTitle
    HAVING SUM(lt.OvertimeHours) > 0
)
SELECT JobTitle, COUNT(*) AS Employees,
    ROUND(SUM(OvertimeHours), 0) AS OvertimeHours,
    ROUND(AVG(OvertimeHours), 1) AS AveragePerEmployee
FROM Overtime
GROUP BY JobTitle
ORDER BY OvertimeHours DESC;  -- Result: 3 rows

/* Model answer (Requirement (5), memo to the controller)

   To: the controller. Subject: is overtime a problem of a few people?

   In fiscal 2026, 64 employees recorded 20,030 hours of manufacturing overtime (labor time by work date; the
   payroll year of Chapter 10 gives 20,411). The largest totals are close together: employee 48 (Machine
   Operator) 348.8, employee 43 (Machine Operator) 338.2, employee 66 (Quality Technician) 336.7, employee 18
   (Assembler) 333.5, employee 62 (Machine Operator) 333.0. Half of the overtime is reached at rank 32, half
   of the employees, and the running share climbs in an almost straight line, which is what an even spread
   looks like; a concentrated pattern would reach half within a handful of names.

   By job title: Assemblers 24 employees, 7,483 hours (311.8 each); Machine Operators 22 employees, 6,931
   hours (315.0 each); Quality Technicians 18 employees, 5,616 hours (312.0 each). The averages are nearly the
   same, about six hours a week for every employee.

   The plant manager's claim is not supported: overtime is plant-wide, not the habit of a few people. It
   points to a plant-level cause, such as the surge days and the hours paid beyond the work that Chapter 12
   examines, rather than to individual scheduling, so the response should address how much overtime the plant
   plans and approves, not who works it.
*/

/* Notes

   Exercise 11.4: Is Overtime Concentrated?
   (1) Total the fiscal 2026 overtime hours of each employee from the manufacturing labor time, by work date,
      with the employee's job title.
   (2) Rank the employees by overtime hours, and add a running total of overtime as a share of the whole,
      ordered from the highest to the lowest.
   (3) Find how many employees account for half of the overtime.
   (4) Calculate the overtime hours and the average per employee by job title.
   (5) Write a short memo (one half page) to the controller answering the plant manager's claim.
   Instructor note: 64 employees recorded manufacturing overtime in fiscal 2026 (LaborType other than
      NonManufacturing, by WorkDate: 20,030 hours; the payroll year of Chapter 10 gives 20,411). The largest
      totals are close together: employee 48 (Machine Operator) 348.8 hours, 43 (Machine Operator) 338.2, 66
      (Quality Technician) 336.7, 18 (Assembler) 333.5, 62 (Machine Operator) 333.0. Half of the overtime is
      reached at rank 32, half of the employees, so overtime is spread evenly, about six hours a week each. By
      job title: Assemblers 24 employees, 7,483 hours (311.8 each); Machine Operators 22, 6,931 (315.0);
      Quality Technicians 18, 5,616 (312.0). The claim is not supported: overtime is plant-wide. A running
      share needs SUM(x) OVER (ORDER BY x DESC ROWS UNBOUNDED PRECEDING) divided by SUM(x) OVER (), both
      taught in the section on window functions; ROWS matters if two employees tie.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   11.4: employees with overtime: 64
   11.4: total overtime hours: 20,029.77
   11.4: rank 1 employee: 48
   11.4: rank 2 employee: 43
   11.4: rank 3 employee: 66
   11.4: rank 4 employee: 18
   11.4: rank 5 employee: 62
   11.4: employee 48 hours: 348.80
   11.4: employee 43 hours: 338.20
   11.4: employee 66 hours: 336.70
   11.4: employee 18 hours: 333.50
   11.4: employee 62 hours: 333.00
   11.4: employees: 64
   11.4: first employee: 48
   11.4: running share of the last employee: 1.00
   11.4: employees for half of the overtime: 32
   11.4: employees: 64
   11.4: total overtime hours: 20030
   11.4: job titles: 3
   11.4: Assemblers employees: 24
   11.4: Assemblers hours: 7483
   11.4: Assemblers average: 311.80
   11.4: Machine Operators employees: 22
   11.4: Machine Operators hours: 6931
   11.4: Machine Operators average: 315.00
   11.4: Quality Technicians employees: 18
   11.4: Quality Technicians hours: 5616
   11.4: Quality Technicians average: 312.00
*/
