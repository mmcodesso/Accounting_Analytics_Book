/* Ex 11.6.sql: requisitions just under the $5,000 approval limit, and runs that look split
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: the requisitions by $50 band; the runs of three equal amounts; the requisitions without an approver */

-- Requirement (1): requisitions in $50 bands from $4,700 to $5,250
-- Population: all purchase requisitions; expected: the band just below $5,000 the largest
WITH Amounts AS (
    SELECT RequisitionID, RequisitionNumber, RequestDate,
        RequestedByEmployeeID, ApprovedByEmployeeID, Status,
        ROUND(Quantity * EstimatedUnitCost, 2) AS Amount
    FROM PurchaseRequisition
)
SELECT 4700 + 50 * CAST((Amount - 4700) / 50 AS INTEGER) AS BandFrom,
    COUNT(*) AS Requisitions
FROM Amounts
WHERE Amount >= 4700 AND Amount < 5250
GROUP BY BandFrom
ORDER BY BandFrom;  -- Result: 11 rows

-- Requirement (2): the requisitions from $4,950.00 to $4,999.99
-- Population: all purchase requisitions; expected: 18 requisitions
WITH Amounts AS (
    SELECT RequisitionID, RequisitionNumber, RequestDate,
        RequestedByEmployeeID, ApprovedByEmployeeID, Status,
        ROUND(Quantity * EstimatedUnitCost, 2) AS Amount
    FROM PurchaseRequisition
)
SELECT a.RequisitionNumber, a.Amount, a.RequestDate, a.Status,
    a.RequestedByEmployeeID, rq.JobTitle AS RequestedBy,
    a.ApprovedByEmployeeID, ap.JobTitle AS ApprovedBy
FROM Amounts AS a
    INNER JOIN Employee AS rq ON rq.EmployeeID = a.RequestedByEmployeeID
    LEFT JOIN Employee AS ap ON ap.EmployeeID = a.ApprovedByEmployeeID
WHERE a.Amount BETWEEN 4950 AND 4999.99
ORDER BY a.Amount DESC, a.RequisitionNumber;  -- Result: 18 rows

-- Requirement (3): each run of three consecutive requisitions for the same amount
-- Population: requisitions in RequisitionID order; expected: the rows of each run
WITH Amounts AS (
    SELECT RequisitionID, RequisitionNumber, RequestDate,
        RequestedByEmployeeID, ApprovedByEmployeeID, Status,
        ROUND(Quantity * EstimatedUnitCost, 2) AS Amount
    FROM PurchaseRequisition
),
Neighbors AS (
    SELECT RequisitionID, Amount,
        LAG(Amount) OVER (ORDER BY RequisitionID) AS PreviousAmount,
        LEAD(Amount) OVER (ORDER BY RequisitionID) AS NextAmount,
        LAG(RequisitionID) OVER (ORDER BY RequisitionID) AS PreviousID,
        LEAD(RequisitionID) OVER (ORDER BY RequisitionID) AS NextID
    FROM Amounts
),
Runs AS (
    SELECT RequisitionID AS MiddleID, PreviousID, NextID
    FROM Neighbors
    WHERE Amount = PreviousAmount AND Amount = NextAmount
)
SELECT r.MiddleID, a.RequisitionID, a.RequisitionNumber, a.RequestDate,
    a.Amount, a.RequestedByEmployeeID, a.ApprovedByEmployeeID, a.Status
FROM Runs AS r
    INNER JOIN Amounts AS a
        ON a.RequisitionID BETWEEN r.PreviousID AND r.NextID
ORDER BY a.RequisitionID;  -- Result: 6 rows

-- Requirement (4): the requesters and approvers of each run
-- Population: the runs of three; expected: two runs, each with requisitions that have no approver
WITH Amounts AS (
    SELECT RequisitionID, RequisitionNumber, RequestDate,
        RequestedByEmployeeID, ApprovedByEmployeeID, Status,
        ROUND(Quantity * EstimatedUnitCost, 2) AS Amount
    FROM PurchaseRequisition
),
Neighbors AS (
    SELECT RequisitionID, Amount,
        LAG(Amount) OVER (ORDER BY RequisitionID) AS PreviousAmount,
        LEAD(Amount) OVER (ORDER BY RequisitionID) AS NextAmount,
        LAG(RequisitionID) OVER (ORDER BY RequisitionID) AS PreviousID,
        LEAD(RequisitionID) OVER (ORDER BY RequisitionID) AS NextID
    FROM Amounts
),
Runs AS (
    SELECT RequisitionID AS MiddleID, PreviousID, NextID
    FROM Neighbors
    WHERE Amount = PreviousAmount AND Amount = NextAmount
)
SELECT r.MiddleID, MIN(a.RequisitionNumber) AS FirstRequisition,
    MAX(a.RequisitionNumber) AS LastRequisition,
    MIN(a.RequestDate) AS RequestDate,
    GROUP_CONCAT(a.RequestedByEmployeeID, ', ') AS Requesters,
    GROUP_CONCAT(ap.JobTitle, ', ') AS Approvers,
    SUM(CASE WHEN a.ApprovedByEmployeeID IS NULL THEN 1 ELSE 0 END)
        AS WithoutApprover
FROM Runs AS r
    INNER JOIN Amounts AS a
        ON a.RequisitionID BETWEEN r.PreviousID AND r.NextID
    LEFT JOIN Employee AS ap ON ap.EmployeeID = a.ApprovedByEmployeeID
GROUP BY r.MiddleID
ORDER BY r.MiddleID;  -- Result: 2 rows

/* Model answer (Requirement (5), memo to the audit senior)

   To: the audit senior. Subject: requisitions just under the approval limit.

   Counting requisitions in $50 bands from $4,700 to $5,250 gives 2, 7, 7, 8, 4, 18, 9, 4, 9, 4, 5: the band
   from $4,950.00 to $4,999.99 holds 18, twice as many as its neighbors, just below the lowest nonzero
   approval limit of $5,000. LAG and LEAD find two runs of three consecutive requisitions for the same amount,
   4,990.92, each on January 1: PR-2025-004714 to 004716 on 2025-01-01 (requesters 80, 76, 80); PR-2026-013258
   to 013260 on 2026-01-01 (requesters 21, 74, 78). In each run two requisitions have no approver and the
   third was approved by the chief financial officer; all six were converted to purchase orders. The
   unapproved ones are among the six requisitions without an approver of Exercise 2.5, and all six of those
   fall just below $5,000 (4,990.92 to 4,993.92).

   The pattern is consistent with a purchase split to stay under the limit and with requisitions that bypassed
   approval. Next procedures: obtain the purchase orders and supplier invoices behind the two runs and test
   whether each run is a single need; ask the requesters and the purchasing manager why the requisitions were
   raised separately and how they were converted without approval; test the system control that should block
   conversion of an unapproved requisition; and extend the band test to the other approval limits and to
   requisitions of the same item and requester within a few days.
*/

/* Notes

   Exercise 11.6: Requisitions Just Under the Approval Threshold
   (1) Calculate each requisition's amount as Quantity times EstimatedUnitCost, rounded, and count the
      requisitions in each $50 band from $4,700 to $5,250.
   (2) List the requisitions from $4,950.00 to $4,999.99 with their requester, approver, request date, and
      status.
   (3) Use LAG and LEAD, ordered by RequisitionID, to find requisitions whose amount equals both the one
      before and the one after. List each run of three.
   (4) For each run, report the requesters and approvers, and whether any requisition has no approver.
   (5) Write a short memo (one half page) to the audit senior on what the tests found and on the procedures
      you would perform next.
   Instructor note: bands of $50 from 4,700: 2, 7, 7, 8, 4, 18 (4,950-4,999.99), 9 (5,000-5,049.99), 4, 9, 4,
      5. The band just below 5,000 holds twice as many as its neighbors. Two runs of three consecutive
      requisitions of 4,990.92, each on January 1: PR-2025-004714 to 004716 (2025-01-01, requesters 80, 76,
      80) and PR-2026-013258 to 013260 (2026-01-01, requesters 21, 74, 78). In each run, two requisitions have
      no approver (IDs 4714, 4715, 13258, 13259) and the third was approved by employee 2, the chief financial
      officer; all six were converted to purchase orders. The unapproved ones are among the six of Exercise
      2.5, and all six of those, the only requisitions without an approver, fall just below 5,000 (4,990.92 to
      4,993.92). LAG and LEAD flag only the middle row of each run (4715 and 13259); to list all three, keep
      the flagged rows in a CTE with LAG(RequisitionID) and LEAD(RequisitionID) and join back to the
      requisitions whose RequisitionID lies between them, or flag the first and last rows too with offsets of
      2. The approval limits in Employee are 0, 5,000 (two production employees), 25,000, and 250,000.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   11.6: bands: [4700, 4750, 4800, 4850, 4900, 4950, 5000, 5050, 5100, 5150, 5200]
   11.6: requisitions by band: [2, 7, 7, 8, 4, 18, 9, 4, 9, 4, 5]
   11.6: requisitions in the band: 18
   11.6: in the band without an approver: 6
   11.6: rows in the runs: 6
   11.6: middle rows flagged by LAG and LEAD: [4715, 13259]
   11.6: the requisitions: [4714, 4715, 4716, 13258, 13259, 13260]
   11.6: amount of every row: 4,990.92
   11.6: one amount: 1
   11.6: requisitions without an approver: [4714, 4715, 13258, 13259]
   11.6: statuses: ['Converted to PO']
   11.6: runs: 2
   11.6: run 1 first requisition: PR-2025-004714
   11.6: run 1 date: 2025-01-01
   11.6: run 1 requesters: ['76', '80', '80']
   11.6: run 1 without an approver: 2
   11.6: run 1 approver: Chief Financial Officer
   11.6: run 2 first requisition: PR-2026-013258
   11.6: run 2 date: 2026-01-01
   11.6: run 2 requesters: ['21', '74', '78']
   11.6: run 2 without an approver: 2
   11.6: run 2 approver: Chief Financial Officer
*/
