/* Ex 11.1.sql: the income statement and the balance sheet check from the ledger
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: the closes found by the as-of date; the trial balance nets to zero; assets equal liabilities, equity, and net income; net income equals the closing entry */

-- Requirement (1), step 1: the closing entries dated on the as-of date
-- Population: journal entries; expected: the two closes of 2026-12-31
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
        AND PostingDate = (SELECT AsOfDate FROM Params)
)
SELECT EntryNumber
FROM Closes
ORDER BY EntryNumber;  -- Result: 2 rows

-- Requirement (1), step 2: the pre-closing trial balance at the as-of date
-- Population: ledger rows to the as-of date without the closes; expected: balances net to zero
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
        AND PostingDate = (SELECT AsOfDate FROM Params)
),
TrialBalance AS (
    SELECT a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
)
SELECT COUNT(*) AS Accounts, ROUND(SUM(Balance), 2) AS NetBalance,
    ROUND(SUM(CASE WHEN Balance > 0 THEN Balance ELSE 0 END), 2)
        AS CreditBalances
FROM TrialBalance;  -- Result: 1 row (Accounts = 71, NetBalance = -0.0, CreditBalances = 67107722.36)

-- Requirement (2): each account assigned to a statement line with CASE
-- Population: the trial balance accounts; expected: eleven lines, none unassigned
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
        AND PostingDate = (SELECT AsOfDate FROM Params)
),
TrialBalance AS (
    SELECT a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
),
Lines AS (
    SELECT
        CASE
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Operating Revenue'
                THEN 'Operating revenue'
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Contra Revenue'
                THEN 'Contra revenue'
            WHEN AccountType = 'Expense' AND AccountSubType = 'COGS'
                THEN 'Cost of goods sold'
            WHEN AccountType = 'Expense'
                AND AccountSubType = 'Operating Expense'
                THEN 'Operating expenses'
            WHEN AccountType IN ('Revenue', 'Expense')
                THEN 'Other income and expense'
            WHEN AccountType = 'Asset' AND AccountSubType
                IN ('Current Asset', 'Contra Current Asset')
                THEN 'Current assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Fixed Asset'
                THEN 'Fixed assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Contra Fixed Asset'
                THEN 'Contra fixed assets'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Current Liability'
                THEN 'Current liabilities'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Long-Term Liability'
                THEN 'Long-term liabilities'
            WHEN AccountType = 'Equity' THEN 'Equity'
            ELSE 'Unassigned'
        END AS StatementLine,
        SUM(CASE WHEN AccountType = 'Asset'
            THEN -Balance ELSE Balance END) AS Amount
    FROM TrialBalance
    GROUP BY StatementLine
)
SELECT StatementLine, ROUND(Amount, 2) AS Amount
FROM Lines
ORDER BY StatementLine;  -- Result: 11 rows

-- Requirement (3): net revenue, gross margin, operating income, and net income
-- Population: the statement lines; expected: net income equal to Chapter 6's
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
        AND PostingDate = (SELECT AsOfDate FROM Params)
),
TrialBalance AS (
    SELECT a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
),
Lines AS (
    SELECT
        CASE
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Operating Revenue'
                THEN 'Operating revenue'
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Contra Revenue'
                THEN 'Contra revenue'
            WHEN AccountType = 'Expense' AND AccountSubType = 'COGS'
                THEN 'Cost of goods sold'
            WHEN AccountType = 'Expense'
                AND AccountSubType = 'Operating Expense'
                THEN 'Operating expenses'
            WHEN AccountType IN ('Revenue', 'Expense')
                THEN 'Other income and expense'
            WHEN AccountType = 'Asset' AND AccountSubType
                IN ('Current Asset', 'Contra Current Asset')
                THEN 'Current assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Fixed Asset'
                THEN 'Fixed assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Contra Fixed Asset'
                THEN 'Contra fixed assets'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Current Liability'
                THEN 'Current liabilities'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Long-Term Liability'
                THEN 'Long-term liabilities'
            WHEN AccountType = 'Equity' THEN 'Equity'
            ELSE 'Unassigned'
        END AS StatementLine,
        SUM(CASE WHEN AccountType = 'Asset'
            THEN -Balance ELSE Balance END) AS Amount
    FROM TrialBalance
    GROUP BY StatementLine
),
Totals AS (
    SELECT
        SUM(CASE StatementLine WHEN 'Operating revenue'
            THEN Amount ELSE 0 END) AS Revenue,
        SUM(CASE StatementLine WHEN 'Contra revenue'
            THEN Amount ELSE 0 END) AS ContraRevenue,
        SUM(CASE StatementLine WHEN 'Cost of goods sold'
            THEN Amount ELSE 0 END) AS COGS,
        SUM(CASE StatementLine WHEN 'Operating expenses'
            THEN Amount ELSE 0 END) AS OperatingExpenses,
        SUM(CASE StatementLine WHEN 'Other income and expense'
            THEN Amount ELSE 0 END) AS OtherIncomeExpense,
        SUM(CASE StatementLine WHEN 'Current assets'
            THEN Amount ELSE 0 END) AS CurrentAssets,
        SUM(CASE StatementLine WHEN 'Fixed assets'
            THEN Amount ELSE 0 END) AS FixedAssets,
        SUM(CASE StatementLine WHEN 'Contra fixed assets'
            THEN Amount ELSE 0 END) AS ContraFixedAssets,
        SUM(CASE StatementLine WHEN 'Current liabilities'
            THEN Amount ELSE 0 END) AS CurrentLiabilities,
        SUM(CASE StatementLine WHEN 'Long-term liabilities'
            THEN Amount ELSE 0 END) AS LongTermLiabilities,
        SUM(CASE StatementLine WHEN 'Equity'
            THEN Amount ELSE 0 END) AS Equity
    FROM Lines
)
SELECT ROUND(Revenue + ContraRevenue, 2) AS NetRevenue,
    ROUND(Revenue + ContraRevenue + COGS, 2) AS GrossMargin,
    ROUND(100.0 * (Revenue + ContraRevenue + COGS)
        / (Revenue + ContraRevenue), 2) AS GrossMarginPct,
    ROUND(Revenue + ContraRevenue + COGS + OperatingExpenses, 2)
        AS OperatingIncome,
    ROUND(100.0 * (Revenue + ContraRevenue + COGS + OperatingExpenses)
        / (Revenue + ContraRevenue), 2) AS OperatingIncomePct,
    ROUND(Revenue + ContraRevenue + COGS + OperatingExpenses
        + OtherIncomeExpense, 2) AS NetIncome
FROM Totals;  -- Result: 1 rows

-- Requirement (4): assets against liabilities, equity, and net income, and the closing entry
-- Population: the statement lines and the closes; expected: no difference, net income = JE-2026-000297
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
        AND PostingDate = (SELECT AsOfDate FROM Params)
),
TrialBalance AS (
    SELECT a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
),
Lines AS (
    SELECT
        CASE
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Operating Revenue'
                THEN 'Operating revenue'
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Contra Revenue'
                THEN 'Contra revenue'
            WHEN AccountType = 'Expense' AND AccountSubType = 'COGS'
                THEN 'Cost of goods sold'
            WHEN AccountType = 'Expense'
                AND AccountSubType = 'Operating Expense'
                THEN 'Operating expenses'
            WHEN AccountType IN ('Revenue', 'Expense')
                THEN 'Other income and expense'
            WHEN AccountType = 'Asset' AND AccountSubType
                IN ('Current Asset', 'Contra Current Asset')
                THEN 'Current assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Fixed Asset'
                THEN 'Fixed assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Contra Fixed Asset'
                THEN 'Contra fixed assets'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Current Liability'
                THEN 'Current liabilities'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Long-Term Liability'
                THEN 'Long-term liabilities'
            WHEN AccountType = 'Equity' THEN 'Equity'
            ELSE 'Unassigned'
        END AS StatementLine,
        SUM(CASE WHEN AccountType = 'Asset'
            THEN -Balance ELSE Balance END) AS Amount
    FROM TrialBalance
    GROUP BY StatementLine
),
Totals AS (
    SELECT
        SUM(CASE StatementLine WHEN 'Operating revenue'
            THEN Amount ELSE 0 END) AS Revenue,
        SUM(CASE StatementLine WHEN 'Contra revenue'
            THEN Amount ELSE 0 END) AS ContraRevenue,
        SUM(CASE StatementLine WHEN 'Cost of goods sold'
            THEN Amount ELSE 0 END) AS COGS,
        SUM(CASE StatementLine WHEN 'Operating expenses'
            THEN Amount ELSE 0 END) AS OperatingExpenses,
        SUM(CASE StatementLine WHEN 'Other income and expense'
            THEN Amount ELSE 0 END) AS OtherIncomeExpense,
        SUM(CASE StatementLine WHEN 'Current assets'
            THEN Amount ELSE 0 END) AS CurrentAssets,
        SUM(CASE StatementLine WHEN 'Fixed assets'
            THEN Amount ELSE 0 END) AS FixedAssets,
        SUM(CASE StatementLine WHEN 'Contra fixed assets'
            THEN Amount ELSE 0 END) AS ContraFixedAssets,
        SUM(CASE StatementLine WHEN 'Current liabilities'
            THEN Amount ELSE 0 END) AS CurrentLiabilities,
        SUM(CASE StatementLine WHEN 'Long-term liabilities'
            THEN Amount ELSE 0 END) AS LongTermLiabilities,
        SUM(CASE StatementLine WHEN 'Equity'
            THEN Amount ELSE 0 END) AS Equity
    FROM Lines
),
Closing AS (
    SELECT SUM(gl.Credit) - SUM(gl.Debit) AS ToRetainedEarnings
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 3030
        AND gl.VoucherNumber IN (SELECT EntryNumber FROM Closes)
)
SELECT ROUND(CurrentAssets + FixedAssets + ContraFixedAssets, 2)
        AS TotalAssets,
    ROUND(CurrentLiabilities + LongTermLiabilities, 2) AS Liabilities,
    ROUND(Equity, 2) AS Equity,
    ROUND(Revenue + ContraRevenue + COGS + OperatingExpenses
        + OtherIncomeExpense, 2) AS NetIncome,
    ROUND(CurrentAssets + FixedAssets + ContraFixedAssets
        - CurrentLiabilities - LongTermLiabilities - Equity
        - (Revenue + ContraRevenue + COGS + OperatingExpenses
            + OtherIncomeExpense), 2) AS Difference,
    ROUND((SELECT ToRetainedEarnings FROM Closing), 2)
        AS ClosingEntry
FROM Totals;  -- Result: 1 rows

-- Requirement (5), step 1: the statement saved as a view, without an ORDER BY
-- Population: the statement lines and totals; expected: the view is created
DROP VIEW IF EXISTS Ex11_1_IncomeStatement;
CREATE VIEW Ex11_1_IncomeStatement AS
WITH Params AS (
    SELECT '2026-12-31' AS AsOfDate
),
Closes AS (
    SELECT EntryNumber
    FROM JournalEntry
    WHERE EntryType LIKE 'Year-End Close%'
        AND PostingDate = (SELECT AsOfDate FROM Params)
),
TrialBalance AS (
    SELECT a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType,
        ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.PostingDate <= (SELECT AsOfDate FROM Params)
        AND gl.VoucherNumber NOT IN (SELECT EntryNumber FROM Closes)
    GROUP BY a.AccountID, a.AccountNumber, a.AccountName,
        a.AccountType, a.AccountSubType
),
Lines AS (
    SELECT
        CASE
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Operating Revenue'
                THEN 'Operating revenue'
            WHEN AccountType = 'Revenue'
                AND AccountSubType = 'Contra Revenue'
                THEN 'Contra revenue'
            WHEN AccountType = 'Expense' AND AccountSubType = 'COGS'
                THEN 'Cost of goods sold'
            WHEN AccountType = 'Expense'
                AND AccountSubType = 'Operating Expense'
                THEN 'Operating expenses'
            WHEN AccountType IN ('Revenue', 'Expense')
                THEN 'Other income and expense'
            WHEN AccountType = 'Asset' AND AccountSubType
                IN ('Current Asset', 'Contra Current Asset')
                THEN 'Current assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Fixed Asset'
                THEN 'Fixed assets'
            WHEN AccountType = 'Asset'
                AND AccountSubType = 'Contra Fixed Asset'
                THEN 'Contra fixed assets'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Current Liability'
                THEN 'Current liabilities'
            WHEN AccountType = 'Liability'
                AND AccountSubType = 'Long-Term Liability'
                THEN 'Long-term liabilities'
            WHEN AccountType = 'Equity' THEN 'Equity'
            ELSE 'Unassigned'
        END AS StatementLine,
        SUM(CASE WHEN AccountType = 'Asset'
            THEN -Balance ELSE Balance END) AS Amount
    FROM TrialBalance
    GROUP BY StatementLine
),
Totals AS (
    SELECT
        SUM(CASE StatementLine WHEN 'Operating revenue'
            THEN Amount ELSE 0 END) AS Revenue,
        SUM(CASE StatementLine WHEN 'Contra revenue'
            THEN Amount ELSE 0 END) AS ContraRevenue,
        SUM(CASE StatementLine WHEN 'Cost of goods sold'
            THEN Amount ELSE 0 END) AS COGS,
        SUM(CASE StatementLine WHEN 'Operating expenses'
            THEN Amount ELSE 0 END) AS OperatingExpenses,
        SUM(CASE StatementLine WHEN 'Other income and expense'
            THEN Amount ELSE 0 END) AS OtherIncomeExpense,
        SUM(CASE StatementLine WHEN 'Current assets'
            THEN Amount ELSE 0 END) AS CurrentAssets,
        SUM(CASE StatementLine WHEN 'Fixed assets'
            THEN Amount ELSE 0 END) AS FixedAssets,
        SUM(CASE StatementLine WHEN 'Contra fixed assets'
            THEN Amount ELSE 0 END) AS ContraFixedAssets,
        SUM(CASE StatementLine WHEN 'Current liabilities'
            THEN Amount ELSE 0 END) AS CurrentLiabilities,
        SUM(CASE StatementLine WHEN 'Long-term liabilities'
            THEN Amount ELSE 0 END) AS LongTermLiabilities,
        SUM(CASE StatementLine WHEN 'Equity'
            THEN Amount ELSE 0 END) AS Equity
    FROM Lines
)
SELECT StatementLine, ROUND(Amount, 2) AS Amount
FROM Lines
UNION ALL
SELECT 'Net revenue', ROUND(Revenue + ContraRevenue, 2)
FROM Totals
UNION ALL
SELECT 'Gross margin', ROUND(Revenue + ContraRevenue + COGS, 2)
FROM Totals
UNION ALL
SELECT 'Operating income',
    ROUND(Revenue + ContraRevenue + COGS + OperatingExpenses, 2)
FROM Totals
UNION ALL
SELECT 'Net income',
    ROUND(Revenue + ContraRevenue + COGS + OperatingExpenses
        + OtherIncomeExpense, 2)
FROM Totals
UNION ALL
SELECT 'Total assets',
    ROUND(CurrentAssets + FixedAssets + ContraFixedAssets, 2)
FROM Totals
UNION ALL
SELECT 'Liabilities, equity, and net income',
    ROUND(CurrentLiabilities + LongTermLiabilities + Equity
        + Revenue + ContraRevenue + COGS + OperatingExpenses
        + OtherIncomeExpense, 2)
FROM Totals;  -- Result: creates the view Ex11_1_IncomeStatement

-- Requirement (5), step 2: the view in statement order, sorted by a CASE expression
-- Population: the view; expected: seventeen lines in statement order
SELECT StatementLine, Amount
FROM Ex11_1_IncomeStatement
ORDER BY CASE StatementLine
    WHEN 'Operating revenue' THEN 1
    WHEN 'Contra revenue' THEN 2
    WHEN 'Net revenue' THEN 3
    WHEN 'Cost of goods sold' THEN 4
    WHEN 'Gross margin' THEN 5
    WHEN 'Operating expenses' THEN 6
    WHEN 'Operating income' THEN 7
    WHEN 'Other income and expense' THEN 8
    WHEN 'Net income' THEN 9
    WHEN 'Current assets' THEN 10
    WHEN 'Fixed assets' THEN 11
    WHEN 'Contra fixed assets' THEN 12
    WHEN 'Total assets' THEN 13
    WHEN 'Current liabilities' THEN 14
    WHEN 'Long-term liabilities' THEN 15
    WHEN 'Equity' THEN 16
    WHEN 'Liabilities, equity, and net income' THEN 17
    END;  -- Result: 17 rows

/* Model answer (Deliverable)

   The view reproduces Chapter 6's statements from the pre-closing trial balance at 2026-12-31 (71 accounts,
   closes JE-2026-000296 and JE-2026-000297 left out): operating revenue 29,973,822.48, contra revenue
   -242,764.56, net revenue 29,731,057.92, gross margin 11,096,754.29 (37.32% of net revenue), operating
   income 4,625,057.71 (15.56%), and net income 4,503,611.24, equal to the credit of JE-2026-000297 to
   retained earnings.

   Total assets of 39,328,524.11 equal liabilities of 13,896,428.43 plus equity of 20,928,484.44 plus net
   income, because the year's revenue and expense accounts have not yet been closed into retained earnings.
   The as-of date is the one parameter: the closes are found by their EntryType and that date, so changing the
   date in Params produces the statements of another year-end without any other edit.
*/

/* Notes

   Exercise 11.1: The Financial Statements from the Ledger
   (1) Write a CTE that holds the as-of date, a second that finds the year's closing entries to leave out (the
      journal entries whose EntryType begins with Year-End Close and whose PostingDate is the as-of date), and
      a third that builds the pre-closing trial balance at that date, with each account's type and subtype and
      its balance expressed as credits less debits. Read the date with a scalar subquery wherever it is
      needed.
   (2) Use a CASE expression on AccountType and AccountSubType to assign each account to a statement line:
      operating revenue, contra revenue, cost of goods sold, operating expenses, other income and expense,
      current assets, fixed assets, contra fixed assets, current liabilities, long-term liabilities, and
      equity.
   (3) Total the lines, and calculate net revenue, gross margin, operating income, and net income. Show gross
      margin and operating income as percentages of net revenue.
   (4) Show that total assets equal total liabilities plus equity plus net income, and compare net income with
      the closing entry of fiscal 2026 that moves it to retained earnings.
   (5) Save the query as a view, without an ORDER BY, and query the view with a CASE expression in ORDER BY
      that sorts the statement lines in statement order.
   Instructor note: pre-closing balances at 2026-12-31 (PostingDate <= '2026-12-31', without JE-2026-000296
      and JE-2026-000297), credits less debits by subtype: Operating Revenue 29,973,822.48; Contra Revenue
      -242,764.56; COGS -18,634,303.63; Operating Expense -6,471,696.58; Other Expense -28,946.47; Other
      Income or Expense -92,500.00. Net revenue 29,731,057.92; gross margin 11,096,754.29 (37.32%); operating
      income 4,625,057.71 (15.56%); net income 4,503,611.24, equal to the credit of JE-2026-000297 to retained
      earnings (Chapter 6). Assets: Current 37,236,780.57 + Fixed 4,354,000.00 - Contra Fixed 2,262,256.46 =
      39,328,524.11; liabilities 13,507,123.75 + 389,304.68 and equity 20,928,484.44 plus net income
      4,503,611.24 = 39,328,524.11. The Closing subtype (8010 Income Summary) has a zero balance before the
      closes. A CTE such as WITH Params AS (SELECT '2026-12-31' AS AsOfDate), read with (SELECT AsOfDate FROM
      Params), makes the date one parameter; the closes are found with EntryType LIKE 'Year-End Close%' AND
      PostingDate = AsOfDate (JE-2026-000296 and JE-2026-000297 at 2026-12-31), so nothing else changes with
      the year.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   11.1: closes found: 2
   11.1: first close: JE-2026-000296
   11.1: second close: JE-2026-000297
   11.1: accounts with postings: 71
   11.1: net of the balances: 0.00
   11.1: credit balances (equal to the debit balances of Tutorial 10.2): 67,107,722.36
   11.1: statement lines (no Unassigned line): 11
   11.1: Operating revenue: 29,973,822.48
   11.1: Contra revenue: -242,764.56
   11.1: Cost of goods sold: -18,634,303.63
   11.1: Operating expenses: -6,471,696.58
   11.1: Other income and expense: -121,446.47
   11.1: Current assets: 37,236,780.57
   11.1: Fixed assets: 4,354,000.00
   11.1: Contra fixed assets: -2,262,256.46
   11.1: Current liabilities: 13,507,123.75
   11.1: Long-term liabilities: 389,304.68
   11.1: Equity: 20,928,484.44
   11.1: net revenue: 29,731,057.92
   11.1: gross margin: 11,096,754.29
   11.1: gross margin %: 37.32
   11.1: operating income: 4,625,057.71
   11.1: operating income %: 15.56
   11.1: net income: 4,503,611.24
   11.1: total assets: 39,328,524.11
   11.1: liabilities: 13,896,428.43
   11.1: equity: 20,928,484.44
   11.1: liabilities, equity, and net income: 39,328,524.11
   11.1: difference: 0.00
   11.1: credit of JE-2026-000297 to retained earnings: 4,503,611.24
   11.1: lines in the view: 17
   11.1: statement order: ['Operating revenue', 'Contra revenue', 'Net revenue', 'Cost of goods sold', 'Gross
      margin', 'Operating expenses', 'Operating income', 'Other income and expense', 'Net income', 'Current
      assets', 'Fixed assets', 'Contra fixed assets', 'Total assets', 'Current liabilities', 'Long-term
      liabilities', 'Equity', 'Liabilities, equity, and net income']
   11.1: net income in the view: 4,503,611.24
   11.1: total assets in the view: 39,328,524.11
   11.1: liabilities, equity, and net income in the view: 39,328,524.11
*/
