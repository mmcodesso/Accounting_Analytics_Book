/* Ex 11.3.sql: items ranked by unit margin at list price within each product line
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 223 items with a list price; the three rankings agree; the top three of each group */

-- Requirement (1): the unit margin at list price and the margin percentage
-- Population: items with a list price; expected: 223 items
SELECT ItemGroup, ItemCode, ItemName, ListPrice, StandardCost,
    ROUND(ListPrice - StandardCost, 2) AS UnitMargin,
    ROUND(100.0 * (ListPrice - StandardCost) / ListPrice, 1) AS MarginPct
FROM Item
WHERE ListPrice IS NOT NULL
ORDER BY ItemGroup, UnitMargin DESC;  -- Result: 223 rows

-- Requirement (2), step 1: RANK, DENSE_RANK, and ROW_NUMBER within each item group
-- Population: items with a list price; expected: the three agree when no margins tie
WITH Margins AS (
    SELECT ItemGroup, ItemCode, ItemName, ListPrice, StandardCost,
        ROUND(ListPrice - StandardCost, 2) AS UnitMargin,
        ROUND(100.0 * (ListPrice - StandardCost) / ListPrice, 1)
            AS MarginPct
    FROM Item
    WHERE ListPrice IS NOT NULL
),
Ranked AS (
    SELECT ItemGroup, ItemCode, ItemName, UnitMargin, MarginPct,
        RANK() OVER w AS MarginRank,
        DENSE_RANK() OVER w AS MarginDenseRank,
        ROW_NUMBER() OVER w AS MarginRowNumber
    FROM Margins
    WINDOW w AS (PARTITION BY ItemGroup ORDER BY UnitMargin DESC)
)
SELECT ItemGroup, ItemCode, UnitMargin, MarginPct, MarginRank,
    MarginDenseRank, MarginRowNumber
FROM Ranked
ORDER BY ItemGroup, MarginRank;  -- Result: 223 rows

-- Requirement (2), step 2: the items whose three rankings differ
-- Population: the ranked items; expected: none, because no two items in a group share a margin
WITH Margins AS (
    SELECT ItemGroup, ItemCode, ItemName, ListPrice, StandardCost,
        ROUND(ListPrice - StandardCost, 2) AS UnitMargin,
        ROUND(100.0 * (ListPrice - StandardCost) / ListPrice, 1)
            AS MarginPct
    FROM Item
    WHERE ListPrice IS NOT NULL
),
Ranked AS (
    SELECT ItemGroup, ItemCode, ItemName, UnitMargin, MarginPct,
        RANK() OVER w AS MarginRank,
        DENSE_RANK() OVER w AS MarginDenseRank,
        ROW_NUMBER() OVER w AS MarginRowNumber
    FROM Margins
    WINDOW w AS (PARTITION BY ItemGroup ORDER BY UnitMargin DESC)
)
SELECT COUNT(*) AS Items,
    SUM(CASE WHEN MarginRank <> MarginRowNumber
        OR MarginDenseRank <> MarginRowNumber THEN 1 ELSE 0 END)
        AS RankingsDiffer
FROM Ranked;  -- Result: 1 row (Items = 223, RankingsDiffer = 0)

-- Requirement (3): the top three items of each item group, by an outer filter
-- Population: the ranked items; expected: 15 rows, three per group
WITH Margins AS (
    SELECT ItemGroup, ItemCode, ItemName, ListPrice, StandardCost,
        ROUND(ListPrice - StandardCost, 2) AS UnitMargin,
        ROUND(100.0 * (ListPrice - StandardCost) / ListPrice, 1)
            AS MarginPct
    FROM Item
    WHERE ListPrice IS NOT NULL
),
Ranked AS (
    SELECT ItemGroup, ItemCode, ItemName, UnitMargin, MarginPct,
        RANK() OVER w AS MarginRank,
        DENSE_RANK() OVER w AS MarginDenseRank,
        ROW_NUMBER() OVER w AS MarginRowNumber
    FROM Margins
    WINDOW w AS (PARTITION BY ItemGroup ORDER BY UnitMargin DESC)
)
SELECT ItemGroup, MarginRank, ItemCode, ItemName, UnitMargin, MarginPct
FROM Ranked
WHERE MarginRank <= 3
ORDER BY ItemGroup, MarginRank;  -- Result: 15 rows

-- Requirement (4): each group's highest and lowest unit margins and items, beside every item
-- Population: items with a list price; expected: 223 rows, each with its group's range
WITH Margins AS (
    SELECT ItemGroup, ItemCode, ItemName, ListPrice, StandardCost,
        ROUND(ListPrice - StandardCost, 2) AS UnitMargin,
        ROUND(100.0 * (ListPrice - StandardCost) / ListPrice, 1)
            AS MarginPct
    FROM Item
    WHERE ListPrice IS NOT NULL
)
SELECT ItemGroup, ItemCode, UnitMargin,
    MAX(UnitMargin) OVER (PARTITION BY ItemGroup) AS GroupHighest,
    MIN(UnitMargin) OVER (PARTITION BY ItemGroup) AS GroupLowest,
    COUNT(*) OVER (PARTITION BY ItemGroup) AS GroupItems
FROM Margins
ORDER BY ItemGroup, UnitMargin DESC;  -- Result: 223 rows

/* Model answer (Requirement (2))

   RANK gives tied rows the same rank and skips the ranks that follow (1, 2, 2, 4); DENSE_RANK gives ties the
   same rank without a gap (1, 2, 2, 3); ROW_NUMBER numbers every row once, breaking ties arbitrarily unless
   the ORDER BY decides them. They differ only where two items of a group share a unit margin. Here no two
   items in a group share one, so the three columns agree on every row (step 2 counts no differences), and the
   top three by any of them are the same items.
*/

/* Model answer (Requirement (5))

   Top items and ranges: Furniture FUR-CON-0032 (974.49, range 135.71 to 974.49); Textiles TXT-THR-0009
   (386.13, range 32.05 to 386.13); Lighting LGT-SCN-0026 (329.60, range 32.29 to 329.60); Services DSV-
   SPC-0001 (210.00, range 145.00 to 210.00); Accessories ACC-VAS-0032 (151.60, range 9.24 to 151.60).

   The Services items are design services whose StandardCost is zero, because their cost is the design staff's
   payroll, which posts to operating expense rather than to inventory (Chapter 6); their unit margin therefore
   equals their price. The measure is a gross margin at list price, not a contribution margin: for the 88
   manufactured items StandardCost includes fixed overhead, which does not vary with one more unit (the 131
   purchased finished goods carry none), and for every item it leaves out variable selling costs such as
   commissions, freight, and discounts. List price is also not the price charged, since price lists,
   overrides, and promotions lower it. For a pricing or product-mix decision, the product manager should use
   the variable cost and the net price.
*/

/* Notes

   Exercise 11.3: Ranking Items by Unit Margin Within Each Product Line
   (1) For every item with a list price, calculate the unit margin at list price, ListPrice minus
      StandardCost, and the margin as a percentage of ListPrice, both rounded.
   (2) Rank the items within each item group by unit margin with RANK, and add DENSE_RANK and ROW_NUMBER
      beside it. Explain when the three would differ, and whether they differ here.
   (3) Keep the top three items of each item group, using a CTE and an outer filter.
   (4) For each item group, show the highest and lowest unit margins and the number of items, using window
      functions rather than GROUP BY, so that each item row keeps its detail.
   (5) Explain why the Services items show a margin equal to their price, and why this measure is a gross
      margin at list price rather than a contribution margin.
   Instructor note: 223 items have a list price (Accessories 56, Furniture 85, Lighting 44, Services 4,
      Textiles 34). No two items in a group share a unit margin, so RANK, DENSE_RANK, and ROW_NUMBER agree.
      Top items: Furniture FUR-CON-0032 Willow Console Table Acacia Warm Walnut 48 in (974.49); Textiles TXT-
      THR-0009 Drift Throw Blanket Ivory Small (386.13); Lighting LGT-SCN-0026 Atlas Wall Sconce Brushed Brass
      (329.60); Services DSV-SPC-0001 Specification Development (210.00); Accessories ACC-VAS-0032 Harbor
      Decor Vase Ceramic Natural (151.60). Ranges: Furniture 135.71 to 974.49; Accessories 9.24 to 151.60;
      Lighting 32.29 to 329.60; Textiles 32.05 to 386.13; Services 145.00 to 210.00. Services carry a
      StandardCost of zero, because their cost is design staff payroll (Chapter 6). For the 88 manufactured
      items StandardCost includes fixed overhead (the 131 purchased finished goods carry none), and for every
      item the measure ignores variable selling costs such as commissions, freight, and discounts, so
      ListPrice minus StandardCost is not a contribution margin; list price is also not the price charged.
      Unrounded differences may show binary fractions; ROUND fixes the display.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   11.3: items: 223
   11.3: Accessories items: 56
   11.3: Furniture items: 85
   11.3: Lighting items: 44
   11.3: Services items: 4
   11.3: Textiles items: 34
   11.3: items ranked: 223
   11.3: Furniture rank 1: FUR-CON-0032: FUR-CON-0032
   11.3: Textiles rank 1: TXT-THR-0009: TXT-THR-0009
   11.3: Lighting rank 1: LGT-SCN-0026: LGT-SCN-0026
   11.3: Services rank 1: DSV-SPC-0001: DSV-SPC-0001
   11.3: Accessories rank 1: ACC-VAS-0032: ACC-VAS-0032
   11.3: items: 223
   11.3: items whose rankings differ: 0
   11.3: rows: 15
   11.3: Furniture top unit margin: 974.49
   11.3: Textiles top unit margin: 386.13
   11.3: Lighting top unit margin: 329.60
   11.3: Services top unit margin: 210.00
   11.3: Accessories top unit margin: 151.60
   11.3: rows: 223
   11.3: Furniture highest: 974.49
   11.3: Furniture lowest: 135.71
   11.3: Furniture items: 85
   11.3: Accessories highest: 151.60
   11.3: Accessories lowest: 9.24
   11.3: Accessories items: 56
   11.3: Lighting highest: 329.60
   11.3: Lighting lowest: 32.29
   11.3: Lighting items: 44
   11.3: Textiles highest: 386.13
   11.3: Textiles lowest: 32.05
   11.3: Textiles items: 34
   11.3: Services highest: 210.00
   11.3: Services lowest: 145.00
   11.3: Services items: 4
*/
