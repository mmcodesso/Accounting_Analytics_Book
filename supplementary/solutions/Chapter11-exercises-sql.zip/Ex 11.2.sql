/* Ex 11.2.sql: monthly revenue by product line with year-to-date and prior-year comparisons
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 180 months of five product lines; December year to date equals the trial balance */

-- Requirement (1): revenue by fiscal year, period, and account, without the closes
-- Population: postings to 4010-4040 and 4080, fiscal 2024-2026; expected: 180 rows
WITH Monthly AS (
    SELECT gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber,
        CASE a.AccountNumber
            WHEN 4010 THEN 'Furniture'
            WHEN 4020 THEN 'Lighting'
            WHEN 4030 THEN 'Textiles'
            WHEN 4040 THEN 'Accessories'
            WHEN 4080 THEN 'Services'
        END AS ProductLine,
        SUM(gl.Credit) - SUM(gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.FiscalYear BETWEEN 2024 AND 2026
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber
)
SELECT ProductLine, AccountNumber, FiscalYear, FiscalPeriod,
    ROUND(Revenue, 2) AS Revenue
FROM Monthly
ORDER BY ProductLine, FiscalYear, FiscalPeriod;  -- Result: 180 rows

-- Requirement (2): a year-to-date running total by product line and fiscal year
-- Population: the monthly revenue; expected: December 2026 year to date as the trial balance
WITH Monthly AS (
    SELECT gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber,
        CASE a.AccountNumber
            WHEN 4010 THEN 'Furniture'
            WHEN 4020 THEN 'Lighting'
            WHEN 4030 THEN 'Textiles'
            WHEN 4040 THEN 'Accessories'
            WHEN 4080 THEN 'Services'
        END AS ProductLine,
        SUM(gl.Credit) - SUM(gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.FiscalYear BETWEEN 2024 AND 2026
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber
)
SELECT ProductLine, FiscalYear, FiscalPeriod,
    ROUND(Revenue, 2) AS Revenue,
    ROUND(SUM(Revenue) OVER (PARTITION BY ProductLine, FiscalYear
            ORDER BY FiscalPeriod), 2) AS RevenueYTD
FROM Monthly
ORDER BY ProductLine, FiscalYear, FiscalPeriod;  -- Result: 180 rows

-- Requirement (3): the same month of the prior year with LAG, and the percentage change
-- Population: the monthly revenue; expected: no prior year for fiscal 2024
WITH Monthly AS (
    SELECT gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber,
        CASE a.AccountNumber
            WHEN 4010 THEN 'Furniture'
            WHEN 4020 THEN 'Lighting'
            WHEN 4030 THEN 'Textiles'
            WHEN 4040 THEN 'Accessories'
            WHEN 4080 THEN 'Services'
        END AS ProductLine,
        SUM(gl.Credit) - SUM(gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.FiscalYear BETWEEN 2024 AND 2026
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber
),
Compared AS (
    SELECT ProductLine, FiscalYear, FiscalPeriod, Revenue,
        SUM(Revenue) OVER (PARTITION BY ProductLine, FiscalYear
            ORDER BY FiscalPeriod) AS RevenueYTD,
        LAG(Revenue) OVER (PARTITION BY ProductLine, FiscalPeriod
            ORDER BY FiscalYear) AS PriorYear
    FROM Monthly
)
SELECT ProductLine, FiscalYear, FiscalPeriod,
    ROUND(Revenue, 2) AS Revenue, ROUND(RevenueYTD, 2) AS RevenueYTD,
    ROUND(PriorYear, 2) AS PriorYear,
    ROUND(100.0 * (Revenue - PriorYear) / PriorYear, 1) AS PctChange
FROM Compared
ORDER BY ProductLine, FiscalYear, FiscalPeriod;  -- Result: 180 rows

-- Requirement (4): December 2026 year to date against the trial balance of Tutorial 10.2
-- Population: the five revenue accounts at 2026-12-31; expected: no differences
WITH Monthly AS (
    SELECT gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber,
        CASE a.AccountNumber
            WHEN 4010 THEN 'Furniture'
            WHEN 4020 THEN 'Lighting'
            WHEN 4030 THEN 'Textiles'
            WHEN 4040 THEN 'Accessories'
            WHEN 4080 THEN 'Services'
        END AS ProductLine,
        SUM(gl.Credit) - SUM(gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.FiscalYear BETWEEN 2024 AND 2026
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber
),
YearToDate AS (
    SELECT ProductLine, AccountNumber, FiscalYear, FiscalPeriod,
        SUM(Revenue) OVER (PARTITION BY ProductLine, FiscalYear
            ORDER BY FiscalPeriod) AS RevenueYTD
    FROM Monthly
),
TrialBalance AS (
    SELECT a.AccountNumber,
        ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.PostingDate <= '2026-12-31'
        AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
    GROUP BY a.AccountNumber
)
SELECT y.ProductLine, y.AccountNumber,
    ROUND(y.RevenueYTD, 2) AS DecemberYTD, tb.Balance AS TrialBalance,
    ROUND(y.RevenueYTD - tb.Balance, 2) AS Difference
FROM YearToDate AS y
    INNER JOIN TrialBalance AS tb ON tb.AccountNumber = y.AccountNumber
WHERE y.FiscalYear = 2026 AND y.FiscalPeriod = 12
ORDER BY y.AccountNumber;  -- Result: 5 rows

-- Requirement (5): Furniture's months of fiscal 2026 ranked by the change against 2025
-- Population: Furniture, fiscal 2026; expected: largest decline October, largest increase November
WITH Monthly AS (
    SELECT gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber,
        CASE a.AccountNumber
            WHEN 4010 THEN 'Furniture'
            WHEN 4020 THEN 'Lighting'
            WHEN 4030 THEN 'Textiles'
            WHEN 4040 THEN 'Accessories'
            WHEN 4080 THEN 'Services'
        END AS ProductLine,
        SUM(gl.Credit) - SUM(gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.FiscalYear BETWEEN 2024 AND 2026
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear, gl.FiscalPeriod, a.AccountNumber
),
Compared AS (
    SELECT ProductLine, FiscalYear, FiscalPeriod, Revenue,
        SUM(Revenue) OVER (PARTITION BY ProductLine, FiscalYear
            ORDER BY FiscalPeriod) AS RevenueYTD,
        LAG(Revenue) OVER (PARTITION BY ProductLine, FiscalPeriod
            ORDER BY FiscalYear) AS PriorYear
    FROM Monthly
)
SELECT FiscalPeriod, ROUND(Revenue, 2) AS Revenue,
    ROUND(PriorYear, 2) AS PriorYear,
    ROUND(100.0 * (Revenue - PriorYear) / PriorYear, 1) AS PctChange,
    RANK() OVER (ORDER BY (Revenue - PriorYear) / PriorYear)
        AS DeclineRank
FROM Compared
WHERE ProductLine = 'Furniture' AND FiscalYear = 2026
ORDER BY DeclineRank;  -- Result: 12 rows

/* Model answer (Deliverable)

   Every December year-to-date figure of fiscal 2026 equals the trial balance of its account (Furniture
   17,398,287.56, Lighting 5,998,649.16, Textiles 3,278,211.11, Accessories 1,872,510.62, Services
   1,213,344.00; 29,761,002.45 in all), so the monthly report starts from the same numbers as the statements.
   The only journal entries to these accounts are the year-end closes, which the query leaves out by their
   EntryType.

   Furniture's largest decline against 2025 is October (1,314,620.10 against 1,700,781.60, -22.7%), and its
   largest increase is November (1,425,903.01 against 1,264,497.48, +12.8%). October 2025 was Furniture's
   highest month of 2025, so part of the decline is a high base. The fiscal 2026 Furniture promotion (Chapter
   6) priced orders in September and October, and its orders were invoiced through November and December, so
   the next step is to look at the timing of invoicing and promotions: Furniture revenue by invoice month and
   promotion, the order dates of the lines invoiced in each month, and the volume and price per unit behind
   each month, as the bridge of Tutorial 6.3 separates them.
*/

/* Notes

   Exercise 11.2: Monthly Revenue with Year-to-Date and Prior-Year Comparisons
   (1) Total the credits less debits posted to the revenue accounts 4010 to 4040 and 4080 by fiscal year,
      fiscal period, and account, leaving out the year-end closing entries. Use CASE to name each account's
      product line.
   (2) Add a year-to-date running total for each product line, partitioned by product line and fiscal year.
   (3) Add the revenue of the same month of the previous year with LAG, partitioned by product line, and the
      percentage change.
   (4) Confirm that the December year-to-date figures of fiscal 2026 equal the balances of accounts 4010 to
      4040 and 4080 in the trial balance of Tutorial 10.2.
   (5) For Furniture, identify the months of fiscal 2026 with the largest decline and the largest increase
      against the prior year, and suggest what you would look at to explain them.
   Instructor note: the only journal entries that post to the revenue accounts are the year-end closes
      (JE-2024-000265, JE-2025-000287, JE-2026-000296), so SourceDocumentType <> 'JournalEntry' removes
      exactly them. 180 rows (5 lines x 36 months). December year-to-date, fiscal 2026: Furniture
      17,398,287.56, Lighting 5,998,649.16, Textiles 3,278,211.11, Accessories 1,872,510.62, Services
      1,213,344.00, total 29,761,002.45, equal to the trial balance balances of those accounts (operating
      revenue in the trial balance also includes 4050 Freight, 212,820.03) and to the SalesInvoice postings of
      Exercise 10.1. Furniture, fiscal 2026 against 2025: largest decline October (1,314,620.10 against
      1,700,781.60, -22.7%), largest increase November (1,425,903.01 against 1,264,497.48, +12.8%). October
      2025 was Furniture's highest month of 2025; the fiscal 2026 promotion (Chapter 6) lowered prices in
      September and October and its orders were invoiced into November and December, so the timing of
      invoicing and promotions is the first thing to examine.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   11.2: rows (five lines x 36 months): 180
   11.2: product lines: 5
   11.2: Furniture December 2026 year to date: 17,398,287.56
   11.2: Lighting December 2026 year to date: 5,998,649.16
   11.2: Textiles December 2026 year to date: 3,278,211.11
   11.2: Accessories December 2026 year to date: 1,872,510.62
   11.2: Services December 2026 year to date: 1,213,344.00
   11.2: months without a prior year (fiscal 2024): 60
   11.2: Furniture October 2026: 1,314,620.10
   11.2: Furniture October 2025 (prior year): 1,700,781.60
   11.2: Furniture November 2025 (prior year): 1,264,497.48
   11.2: accounts compared: 5
   11.2: accounts with a difference: 0
   11.2: total of the trial balance: 29,761,002.45
   11.2: months: 12
   11.2: largest decline (month): 10
   11.2: largest decline (%): -22.70
   11.2: largest increase (month): 11
   11.2: largest increase (%): 12.80
   11.2: Furniture November 2026: 1,425,903.01
*/
