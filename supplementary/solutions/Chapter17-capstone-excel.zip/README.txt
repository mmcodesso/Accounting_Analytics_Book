Accounting Analytics: An Integrated Approach (2026 edition), instructor files
The Excel part of the solution to the Chapter 17 capstone case: Charles River Lender Package.xlsx

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.xlsx SHA-256 185d42bd069fad177fae23c5e30df93edc7cf2669f687236c8a9f29435388e09

The workbook answers the requirements that the case does in Excel. Its Solution Notes
worksheet lists the requirements, checks the results against the dataset, and repeats the
instructor notes. Its queries read C:\CharlesRiver\CharlesRiver.xlsx; point them at your copy with
Data > Get Data > Data Source Settings > Change Source, and choose Data > Refresh All.
These files are public, like the rest of the book. Try an exercise first, then compare your work.
