Accounting Analytics: An Integrated Approach (2026 edition), instructor files
Solutions to the Power BI exercises of Chapter 13: Chapter 13 Exercises - Solutions (a Power BI project)

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.xlsx SHA-256 185d42bd069fad177fae23c5e30df93edc7cf2669f687236c8a9f29435388e09

Open Chapter 13 Exercises - Solutions/Chapter 13 Exercises - Solutions.pbip in Power BI Desktop (the September 2026 release or later). Its queries read
C:\CharlesRiver\CharlesRiver.xlsx; point them at your copy with Home > Transform data > Data source settings >
Change Source, choose Home > Refresh, and save it as a .pbix file if you prefer. The Notes page lists the
exercises or requirements with the instructor notes; in DAX query view, the Checks tab tests every value.
These files are public, like the rest of the book. Try an exercise first, then compare your work.
