/* Case.sql: the plant's hours: corroboration, cost, the next year's plan, and the year-end close
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: populations profiled and linked; SurgeDays reconciles to Tutorial 12.3; the 5080 bridge adds up to the ledger; the plan's depreciation reproduces 2026's; the cutoff reruns Audit.sql L5, L6, L8 */

-- Requirement 1: profile of TimeClockPunch, its rows, dates, and columns not always filled in
-- Population: every punch; expected: 165,137 punches of 76 employees, 2024-01-01 to 2026-12-11
SELECT COUNT(*) AS Punches,
    COUNT(DISTINCT EmployeeID) AS Employees,
    COUNT(DISTINCT TimeClockEntryID) AS ClockEntries,
    MIN(WorkDate) AS FirstDate,
    MAX(WorkDate) AS LastDate,
    COUNT(EmployeeShiftRosterID) AS WithRoster,
    COUNT(WorkCenterID) AS WithWorkCenter
FROM TimeClockPunch;  -- Result: 1 rows

-- Requirement 1: the code columns of TimeClockPunch, PunchType and PunchSource
-- Population: every punch; expected: 4 punch types, all Badge; 3 fewer clock-outs than clock-ins
SELECT PunchType, PunchSource, COUNT(*) AS Punches
FROM TimeClockPunch
GROUP BY PunchType, PunchSource
ORDER BY Punches DESC, PunchType;  -- Result: 4 rows

-- Requirement 1: keys of TimeClockPunch that appear more than once, and punches without their clock entry
-- Population: every punch; expected: no clock entry with two punches of one type, no orphan
SELECT
    (SELECT COUNT(*)
     FROM (
         SELECT TimeClockEntryID, PunchType
         FROM TimeClockPunch
         GROUP BY TimeClockEntryID, PunchType
         HAVING COUNT(*) > 1
     ) AS t) AS RepeatedPunchTypes,
    (SELECT COUNT(*)
     FROM TimeClockPunch AS p
         LEFT JOIN TimeClockEntry AS tc
             ON tc.TimeClockEntryID = p.TimeClockEntryID
     WHERE tc.TimeClockEntryID IS NULL) AS PunchesWithoutEntry;  -- Result: 1 row (RepeatedPunchTypes = 0, PunchesWithoutEntry = 0)

-- Requirement 1: clock entries with a clock-in punch and no clock-out punch
-- Population: clock entries with punches; expected: 3 entries of employee 85, each on January 1
SELECT p.TimeClockEntryID, tc.EmployeeID, tc.WorkDate,
    tc.ClockStatus
FROM TimeClockPunch AS p
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = p.TimeClockEntryID
GROUP BY p.TimeClockEntryID, tc.EmployeeID, tc.WorkDate,
    tc.ClockStatus
HAVING SUM(CASE WHEN p.PunchType = 'Clock Out'
    THEN 1 ELSE 0 END) = 0
ORDER BY tc.WorkDate;  -- Result: 3 rows

-- Requirement 1: profile of EmployeeShiftRoster, with any employee rostered twice on one date
-- Population: every roster; expected: 53,002 rosters, no employee rostered twice
SELECT COUNT(*) AS Rosters,
    COUNT(DISTINCT EmployeeID) AS Employees,
    MIN(RosterDate) AS FirstDate,
    MAX(RosterDate) AS LastDate,
    COUNT(WorkCenterID) AS WithWorkCenter,
    (SELECT COUNT(*)
     FROM (
         SELECT EmployeeID, RosterDate
         FROM EmployeeShiftRoster
         GROUP BY EmployeeID, RosterDate
         HAVING COUNT(*) > 1
     ) AS t) AS RosteredTwice
FROM EmployeeShiftRoster;  -- Result: 1 rows

-- Requirement 1: the roster statuses
-- Population: every roster; expected: 3 statuses
SELECT RosterStatus, COUNT(*) AS Rosters
FROM EmployeeShiftRoster
GROUP BY RosterStatus
ORDER BY Rosters DESC;  -- Result: 3 rows

-- Requirement 1: who created the rosters
-- Population: every roster; expected: 4 department managers
SELECT r.CreatedByEmployeeID, e.JobTitle, COUNT(*) AS Rosters
FROM EmployeeShiftRoster AS r
    INNER JOIN Employee AS e
        ON e.EmployeeID = r.CreatedByEmployeeID
GROUP BY r.CreatedByEmployeeID, e.JobTitle
ORDER BY r.CreatedByEmployeeID;  -- Result: 4 rows

-- Requirement 1: profile of AttendanceException by type, with the columns not always filled in
-- Population: every exception; expected: 18 exceptions, 3 of each of 6 types, none reviewed
SELECT ExceptionType, Severity, Status,
    COUNT(*) AS Exceptions,
    COUNT(EmployeeShiftRosterID) AS WithRoster,
    COUNT(ShiftDefinitionID) AS WithShift,
    COUNT(ReviewedByEmployeeID) AS Reviewed,
    MIN(WorkDate) AS FirstDate,
    MAX(WorkDate) AS LastDate
FROM AttendanceException
GROUP BY ExceptionType, Severity, Status
ORDER BY ExceptionType;  -- Result: 6 rows

-- Requirement 1: profile of WorkCenterCalendar, with any work center and date that appears twice
-- Population: every calendar row; expected: 5,900 rows, 5 work centers, 2024-01-01 to 2027-03-25
SELECT COUNT(*) AS CalendarRows,
    COUNT(DISTINCT WorkCenterID) AS WorkCenters,
    MIN(CalendarDate) AS FirstDate,
    MAX(CalendarDate) AS LastDate,
    COUNT(DISTINCT WorkCenterID || ' ' || CalendarDate)
        AS CenterDates
FROM WorkCenterCalendar;  -- Result: 1 rows

-- Requirement 1: the calendar of 2026 by exception reason
-- Population: WorkCenterCalendar, 2026; expected: maintenance on 19 dates, reduced capacity on 53
SELECT ExceptionReason, IsWorkingDay,
    COUNT(DISTINCT CalendarDate) AS Dates,
    COUNT(*) AS CenterDays,
    ROUND(SUM(AvailableHours), 2) AS AvailableHours
FROM WorkCenterCalendar
WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY ExceptionReason, IsWorkingDay
ORDER BY IsWorkingDay DESC, ExceptionReason;  -- Result: 5 rows

-- Requirement 1: the working days and available hours of 2026
-- Population: WorkCenterCalendar, 2026; expected: 256 working days, 128,833.25 available hours
SELECT COUNT(DISTINCT CASE WHEN IsWorkingDay = 1
        THEN CalendarDate END) AS WorkingDays,
    ROUND(SUM(AvailableHours), 2) AS AvailableHours
FROM WorkCenterCalendar
WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31';  -- Result: 1 row (WorkingDays = 256, AvailableHours = 128833.25)

-- Requirement 1: punches whose employee or date differs from their clock entry's
-- Population: every punch; expected: 18 punches of 6 entries, all dated differently
SELECT p.TimeClockEntryID, COUNT(*) AS Punches,
    SUM(CASE WHEN p.WorkDate <> tc.WorkDate
        THEN 1 ELSE 0 END) AS OtherDate,
    SUM(CASE WHEN p.EmployeeID <> tc.EmployeeID
        THEN 1 ELSE 0 END) AS OtherEmployee
FROM TimeClockPunch AS p
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = p.TimeClockEntryID
WHERE p.WorkDate <> tc.WorkDate
    OR p.EmployeeID <> tc.EmployeeID
GROUP BY p.TimeClockEntryID
ORDER BY p.TimeClockEntryID;  -- Result: 6 rows

-- Requirement 1: clock entries whose roster is missing, of another employee, or of another date
-- Population: every clock entry; expected: every entry has its own roster; the 6 entries above are rostered on another date
SELECT tc.TimeClockEntryID, tc.EmployeeID, tc.WorkDate,
    r.EmployeeID AS RosterEmployeeID, r.RosterDate
FROM TimeClockEntry AS tc
    LEFT JOIN EmployeeShiftRoster AS r
        ON r.EmployeeShiftRosterID = tc.EmployeeShiftRosterID
WHERE r.EmployeeShiftRosterID IS NULL
    OR r.EmployeeID <> tc.EmployeeID
    OR r.RosterDate <> tc.WorkDate
ORDER BY tc.TimeClockEntryID;  -- Result: 6 rows

-- Requirement 1: punches detached from their clock entry's roster
-- Population: every punch; expected: 3 clock-in punches of employee 85, one on each January 1
SELECT p.TimeClockPunchID, p.EmployeeID, p.WorkDate,
    p.PunchType, p.EmployeeShiftRosterID,
    tc.EmployeeShiftRosterID AS EntryRosterID
FROM TimeClockPunch AS p
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = p.TimeClockEntryID
WHERE p.EmployeeShiftRosterID IS NULL
    OR p.EmployeeShiftRosterID <> tc.EmployeeShiftRosterID
ORDER BY p.TimeClockPunchID;  -- Result: 3 rows

-- Requirement 1: each attendance exception against its clock entry, with a disposition
-- Population: every exception; expected: 18 rows; exceptions 2, 3, 8, 9 name employee 86 on employee 85's entries
SELECT ae.AttendanceExceptionID, ae.ExceptionType, ae.WorkDate,
    ae.EmployeeID, tc.EmployeeID AS EntryEmployeeID,
    tc.TimeClockEntryID, tc.ClockStatus,
    CASE
        WHEN tc.TimeClockEntryID IS NULL
            THEN 'No clock entry: investigate'
        WHEN ae.EmployeeID <> tc.EmployeeID
            THEN 'Names another employee: correct the report'
        WHEN ae.ExceptionType = 'Paid Without Approved Clock'
            THEN 'Paid on a Pending entry (test H1): follow up'
        ELSE 'Isolated: record and close'
    END AS Disposition
FROM AttendanceException AS ae
    LEFT JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = ae.TimeClockEntryID
ORDER BY ae.AttendanceExceptionID;  -- Result: 18 rows

-- Requirement 1: the surge days saved as a view, with the SurgeDays CTE of test H9
-- Population: manufacturing clock entries by work date; expected: the view SurgeDays
DROP VIEW IF EXISTS SurgeDays;
CREATE VIEW SurgeDays AS
SELECT tc.WorkDate
FROM TimeClockEntry AS tc
    INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing'
GROUP BY tc.WorkDate
HAVING COUNT(DISTINCT tc.RegularHours + tc.OvertimeHours) = 1
    AND COUNT(*) > 1;  -- Result: creates the view SurgeDays

-- Requirement 1: the hourly manufacturing clock entries saved as a view, each with its DayType
-- Population: clock entries of hourly Manufacturing employees; expected: the view PlantEntries
DROP VIEW IF EXISTS PlantEntries;
CREATE VIEW PlantEntries AS
SELECT tc.TimeClockEntryID, tc.EmployeeID, tc.WorkDate,
    tc.EmployeeShiftRosterID, tc.OvertimeApprovalID,
    tc.ClockInTime, tc.ClockOutTime, tc.RegularHours,
    tc.OvertimeHours, e.BaseHourlyRate,
    CASE WHEN sd.WorkDate IS NULL THEN 'Ordinary'
        ELSE 'Surge' END AS DayType
FROM TimeClockEntry AS tc
    INNER JOIN Employee AS e ON e.EmployeeID = tc.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
    LEFT JOIN SurgeDays AS sd ON sd.WorkDate = tc.WorkDate
WHERE cc.CostCenterName = 'Manufacturing'
    AND e.PayClass = 'Hourly';  -- Result: creates the view PlantEntries

-- Requirement 1: the two views reconciled to the surge days and entries of Tutorial 12.3
-- Population: SurgeDays and PlantEntries; expected: 12, 32, 49 surge days and 768, 2,048, 3,136 surge entries
SELECT strftime('%Y', pe.WorkDate) AS WorkYear,
    (SELECT COUNT(*)
     FROM SurgeDays AS sd
     WHERE strftime('%Y', sd.WorkDate)
         = strftime('%Y', pe.WorkDate)) AS SurgeDays,
    SUM(CASE WHEN pe.DayType = 'Surge'
        THEN 1 ELSE 0 END) AS SurgeEntries,
    COUNT(DISTINCT CASE WHEN pe.DayType = 'Ordinary'
        THEN pe.WorkDate END) AS OrdinaryDays,
    SUM(CASE WHEN pe.DayType = 'Ordinary'
        THEN 1 ELSE 0 END) AS OrdinaryEntries
FROM PlantEntries AS pe
GROUP BY WorkYear
ORDER BY WorkYear;  -- Result: 3 rows

-- Requirement 2: surge days against ordinary days, attendance and clock-in times (conditional aggregation and a window)
-- Population: PlantEntries by work date; expected: 93 surge and 652 ordinary days; largest group on one clock-in time 32-33 on surge days
WITH Daily AS (
    SELECT WorkDate, DayType, COUNT(*) AS Employees,
        COUNT(DISTINCT ClockInTime) AS ClockInTimes
    FROM PlantEntries
    GROUP BY WorkDate, DayType
),
Groups AS (
    SELECT WorkDate, MAX(SameClockIn) AS LargestGroup
    FROM (
        SELECT WorkDate,
            COUNT(*) OVER (PARTITION BY WorkDate, ClockInTime)
                AS SameClockIn
        FROM PlantEntries
    ) AS t
    GROUP BY WorkDate
),
Plant AS (
    SELECT COUNT(*) AS HourlyEmployees
    FROM Employee AS e
        INNER JOIN CostCenter AS cc
            ON cc.CostCenterID = e.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
        AND e.PayClass = 'Hourly'
)
SELECT d.DayType, COUNT(*) AS Days,
    ROUND(AVG(d.Employees), 1) AS EmployeesPerDay,
    SUM(CASE WHEN d.Employees
        = (SELECT HourlyEmployees FROM Plant)
        THEN 1 ELSE 0 END) AS DaysAllPresent,
    ROUND(AVG(d.ClockInTimes), 1) AS ClockInTimesPerDay,
    ROUND(AVG(g.LargestGroup), 1) AS LargestGroupAverage,
    MIN(g.LargestGroup) AS LargestGroupMin,
    MAX(g.LargestGroup) AS LargestGroupMax
FROM Daily AS d
    INNER JOIN Groups AS g ON g.WorkDate = d.WorkDate
GROUP BY d.DayType
ORDER BY d.DayType DESC;  -- Result: 2 rows

-- Requirement 2: entries with meal punches, surge days against ordinary days
-- Population: PlantEntries; expected: every surge entry, 17,707 of 40,974 ordinary entries (43.2%)
WITH Meals AS (
    SELECT TimeClockEntryID
    FROM TimeClockPunch
    WHERE PunchType = 'Meal Start'
    GROUP BY TimeClockEntryID
)
SELECT pe.DayType, COUNT(*) AS Entries,
    COUNT(m.TimeClockEntryID) AS WithMealPunches,
    ROUND(COUNT(m.TimeClockEntryID) * 1.0 / COUNT(*), 3)
        AS MealShare
FROM PlantEntries AS pe
    LEFT JOIN Meals AS m
        ON m.TimeClockEntryID = pe.TimeClockEntryID
GROUP BY pe.DayType
ORDER BY pe.DayType DESC;  -- Result: 2 rows

-- Requirement 2: clock punches whose timestamp differs from their clock entry's times
-- Population: clock-in and clock-out punches; expected: 9 entries, all cited by attendance exceptions
SELECT COUNT(DISTINCT p.TimeClockEntryID) AS EntriesDiffering,
    COUNT(DISTINCT ae.TimeClockEntryID) AS CitedByExceptions
FROM TimeClockPunch AS p
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = p.TimeClockEntryID
    LEFT JOIN AttendanceException AS ae
        ON ae.TimeClockEntryID = p.TimeClockEntryID
WHERE (p.PunchType = 'Clock In'
        AND p.PunchTimestamp <> tc.ClockInTime)
    OR (p.PunchType = 'Clock Out'
        AND p.PunchTimestamp <> tc.ClockOutTime);  -- Result: 1 row (EntriesDiffering = 9, CitedByExceptions = 9)

-- Requirement 2: the rosters of the surge-day entries, their shifts, creator, and lead time
-- Population: surge entries with their rosters; expected: two shifts, 07:00-15:30, 15:00-23:30, 8.0 hours, created by the Production Manager seven days ahead
SELECT r.ScheduledStartTime, r.ScheduledEndTime,
    r.ScheduledHours, e.JobTitle AS CreatedBy,
    julianday(r.RosterDate) - julianday(r.CreatedDate)
        AS DaysAhead,
    COUNT(*) AS Entries
FROM PlantEntries AS pe
    INNER JOIN EmployeeShiftRoster AS r
        ON r.EmployeeShiftRosterID = pe.EmployeeShiftRosterID
    INNER JOIN Employee AS e
        ON e.EmployeeID = r.CreatedByEmployeeID
WHERE pe.DayType = 'Surge'
GROUP BY r.ScheduledStartTime, r.ScheduledEndTime,
    r.ScheduledHours, r.CreatedByEmployeeID, e.JobTitle,
    DaysAhead
ORDER BY r.ScheduledStartTime;  -- Result: 2 rows

-- Requirement 2: who creates the rosters of the Manufacturing employees
-- Population: rosters of Manufacturing employees; expected: the Production Manager alone
SELECT r.CreatedByEmployeeID, cr.JobTitle AS CreatedBy,
    COUNT(*) AS Rosters
FROM EmployeeShiftRoster AS r
    INNER JOIN Employee AS e ON e.EmployeeID = r.EmployeeID
    INNER JOIN CostCenter AS cc
        ON cc.CostCenterID = e.CostCenterID
    INNER JOIN Employee AS cr
        ON cr.EmployeeID = r.CreatedByEmployeeID
WHERE cc.CostCenterName = 'Manufacturing'
GROUP BY r.CreatedByEmployeeID, cr.JobTitle;  -- Result: 1 row (CreatedByEmployeeID = 4, CreatedBy = Production Manager, Rosters = 46926)

-- Requirement 2: minutes of clock time before and after the roster on surge days
-- Population: surge entries with their rosters; expected: 06:30-19:30, 14:30-03:30, 30 minutes early and 240 late, 12.5 hours against 8.0
WITH Outside AS (
    SELECT pe.DayType,
        substr(pe.ClockInTime, 12, 5) || '-'
            || substr(pe.ClockOutTime, 12, 5) AS ClockPattern,
        pe.RegularHours + pe.OvertimeHours AS ClockedHours,
        r.ScheduledHours,
        ROUND((julianday(r.RosterDate || ' '
            || r.ScheduledStartTime)
            - julianday(pe.ClockInTime)) * 1440) AS MinutesEarly,
        ROUND((julianday(pe.ClockOutTime)
            - julianday(r.RosterDate || ' '
            || r.ScheduledEndTime)) * 1440) AS MinutesLate
    FROM PlantEntries AS pe
        INNER JOIN EmployeeShiftRoster AS r
            ON r.EmployeeShiftRosterID = pe.EmployeeShiftRosterID
)
SELECT ClockPattern, ClockedHours, ScheduledHours,
    MinutesEarly, MinutesLate, COUNT(*) AS Entries
FROM Outside
WHERE DayType = 'Surge'
GROUP BY ClockPattern, ClockedHours, ScheduledHours,
    MinutesEarly, MinutesLate
ORDER BY ClockPattern;  -- Result: 2 rows

-- Requirement 2: rostered hours against the hours clocked, surge days against ordinary days
-- Population: PlantEntries with their rosters; expected: equal on 30,251 of 40,974 ordinary entries, on no surge entry
SELECT pe.DayType, COUNT(*) AS Entries,
    SUM(CASE WHEN ABS(r.ScheduledHours
        - (pe.RegularHours + pe.OvertimeHours)) < 0.005
        THEN 1 ELSE 0 END) AS RosterEqualsClock,
    ROUND(AVG(r.ScheduledHours), 2) AS RosteredHours,
    ROUND(AVG(pe.RegularHours + pe.OvertimeHours), 2)
        AS ClockedHours
FROM PlantEntries AS pe
    INNER JOIN EmployeeShiftRoster AS r
        ON r.EmployeeShiftRosterID = pe.EmployeeShiftRosterID
GROUP BY pe.DayType
ORDER BY pe.DayType DESC;  -- Result: 2 rows

-- Requirement 2: the Off Shift Clocking exceptions against their rosters, to find the rule
-- Population: Off Shift Clocking exceptions; expected: three clock-ins at 10:00 against a 08:00 start, 120 minutes late
SELECT ae.AttendanceExceptionID, ae.MinutesVariance,
    tc.ClockInTime, r.ScheduledStartTime,
    ROUND((julianday(tc.ClockInTime)
        - julianday(r.RosterDate || ' '
        || r.ScheduledStartTime)) * 1440) AS MinutesAfterStart
FROM AttendanceException AS ae
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = ae.TimeClockEntryID
    INNER JOIN EmployeeShiftRoster AS r
        ON r.EmployeeShiftRosterID = tc.EmployeeShiftRosterID
WHERE ae.ExceptionType = 'Off Shift Clocking'
ORDER BY ae.AttendanceExceptionID;  -- Result: 3 rows

-- Requirement 2: the Off Shift Clocking rule reperformed on every entry, and the exceptions raised
-- Population: PlantEntries with their rosters; expected: no surge entry arrives 120 minutes late or was flagged; 2,591 ordinary entries also leave more than 120 minutes late
WITH RuleMinutes AS (
    SELECT MIN(MinutesVariance) AS Minutes
    FROM AttendanceException
    WHERE ExceptionType = 'Off Shift Clocking'
),
Timing AS (
    SELECT pe.TimeClockEntryID, pe.DayType,
        (julianday(pe.ClockInTime)
            - julianday(r.RosterDate || ' '
            || r.ScheduledStartTime)) * 1440 AS Arrival,
        (julianday(pe.ClockOutTime)
            - julianday(r.RosterDate || ' '
            || r.ScheduledEndTime)) * 1440 AS Departure
    FROM PlantEntries AS pe
        INNER JOIN EmployeeShiftRoster AS r
            ON r.EmployeeShiftRosterID = pe.EmployeeShiftRosterID
),
Flagged AS (
    SELECT TimeClockEntryID
    FROM AttendanceException
    GROUP BY TimeClockEntryID
)
SELECT t.DayType, COUNT(*) AS Entries,
    SUM(CASE WHEN t.Arrival >= (SELECT Minutes FROM RuleMinutes)
        THEN 1 ELSE 0 END) AS LateArrivals,
    SUM(CASE WHEN t.Departure > (SELECT Minutes FROM RuleMinutes)
        THEN 1 ELSE 0 END) AS LateDepartures,
    COUNT(f.TimeClockEntryID) AS Flagged
FROM Timing AS t
    LEFT JOIN Flagged AS f
        ON f.TimeClockEntryID = t.TimeClockEntryID
GROUP BY t.DayType
ORDER BY t.DayType DESC;  -- Result: 2 rows

-- Requirement 2: the operation of the attendance-exception control, review and status by type
-- Population: every exception; expected: all 18 Open and none reviewed since 2024; 3 Paid Without Approved Clock on Pending entries; 4 name the wrong employee
SELECT ae.ExceptionType, COUNT(*) AS Exceptions,
    SUM(CASE WHEN ae.Status = 'Open' THEN 1 ELSE 0 END)
        AS StillOpen,
    COUNT(ae.ReviewedByEmployeeID) AS Reviewed,
    MIN(ae.WorkDate) AS Oldest,
    SUM(CASE WHEN tc.ClockStatus = 'Pending'
        THEN 1 ELSE 0 END) AS OnPendingEntries,
    SUM(CASE WHEN ae.EmployeeID <> tc.EmployeeID
        THEN 1 ELSE 0 END) AS NameAnotherEmployee
FROM AttendanceException AS ae
    INNER JOIN TimeClockEntry AS tc
        ON tc.TimeClockEntryID = ae.TimeClockEntryID
GROUP BY ae.ExceptionType
ORDER BY ae.ExceptionType;  -- Result: 6 rows

-- Requirement 2: the calendar status of each surge day
-- Population: SurgeDays with WorkCenterCalendar; expected: every surge day a working day; maintenance on 6, reduced capacity on 21
SELECT c.ExceptionReason, c.IsWorkingDay,
    COUNT(DISTINCT c.CalendarDate) AS SurgeDays
FROM SurgeDays AS sd
    INNER JOIN WorkCenterCalendar AS c
        ON c.CalendarDate = sd.WorkDate
GROUP BY c.ExceptionReason, c.IsWorkingDay
ORDER BY c.IsWorkingDay, c.ExceptionReason;  -- Result: 3 rows

-- Requirement 2: planned load against available hours, weeks with surge days against other weeks
-- Population: RoughCutCapacityPlan by Monday week through 2026-12-07, available hours once per work center and week; expected: surge weeks 0.568, 0.596, 0.585 against 0.687, 0.618, 0.614
WITH SurgeWeeks AS (
    SELECT date(WorkDate, '-6 days', 'weekday 1') AS WeekStart,
        COUNT(*) AS SurgeDays
    FROM SurgeDays
    GROUP BY WeekStart
),
Available AS (
    SELECT WeekStart, SUM(Hours) AS AvailableHours
    FROM (
        SELECT BucketWeekStartDate AS WeekStart, WorkCenterID,
            MAX(AvailableHours) AS Hours
        FROM RoughCutCapacityPlan
        GROUP BY BucketWeekStartDate, WorkCenterID
    ) AS t
    GROUP BY WeekStart
),
Planned AS (
    SELECT BucketWeekStartDate AS WeekStart,
        SUM(PlannedLoadHours) AS PlannedHours
    FROM RoughCutCapacityPlan
    GROUP BY BucketWeekStartDate
)
SELECT strftime('%Y', p.WeekStart) AS PlanYear,
    CASE WHEN sw.WeekStart IS NULL THEN 'No surge days'
        ELSE 'Surge days' END AS WeekType,
    COUNT(*) AS Weeks,
    ROUND(SUM(p.PlannedHours) / SUM(a.AvailableHours), 3)
        AS LoadShare
FROM Planned AS p
    INNER JOIN Available AS a ON a.WeekStart = p.WeekStart
    LEFT JOIN SurgeWeeks AS sw ON sw.WeekStart = p.WeekStart
WHERE p.WeekStart <= (
    SELECT date(MAX(WorkDate), '-6 days', 'weekday 1')
    FROM TimeClockEntry)
GROUP BY PlanYear, WeekType
ORDER BY PlanYear, WeekType DESC;  -- Result: 6 rows

-- Requirement 2: the reason codes and approver of the surge-day overtime
-- Population: approvals of surge entries; expected: four reason codes, 1,488 each, all approved by the Production Manager
SELECT oa.ReasonCode, oa.ApprovedByEmployeeID,
    ap.JobTitle AS ApprovedBy, COUNT(*) AS Approvals
FROM PlantEntries AS pe
    INNER JOIN OvertimeApproval AS oa
        ON oa.OvertimeApprovalID = pe.OvertimeApprovalID
    INNER JOIN Employee AS ap
        ON ap.EmployeeID = oa.ApprovedByEmployeeID
WHERE pe.DayType = 'Surge'
GROUP BY oa.ReasonCode, oa.ApprovedByEmployeeID, ap.JobTitle
ORDER BY oa.ReasonCode;  -- Result: 4 rows

-- Requirement 2: overtime approvals that cite an operation already ended before the work date
-- Population: approvals of PlantEntries; expected: 1,475 of 5,952 surge approvals cite one, every one ended; 497 of 2,397 on ordinary days
SELECT pe.DayType, COUNT(*) AS Approvals,
    COUNT(oa.WorkOrderOperationID) AS CiteOperation,
    SUM(CASE WHEN op.ActualEndDate < oa.WorkDate
        THEN 1 ELSE 0 END) AS OperationEnded
FROM PlantEntries AS pe
    INNER JOIN OvertimeApproval AS oa
        ON oa.OvertimeApprovalID = pe.OvertimeApprovalID
    LEFT JOIN WorkOrderOperation AS op
        ON op.WorkOrderOperationID = oa.WorkOrderOperationID
GROUP BY pe.DayType
ORDER BY pe.DayType DESC;  -- Result: 2 rows

-- Requirement 2: surge days by day of the week
-- Population: SurgeDays; expected: Monday 4, Tuesday 13, Wednesday 19, Thursday 26, Friday 31
SELECT strftime('%w', WorkDate) AS DayNumber,
    CASE strftime('%w', WorkDate)
        WHEN '1' THEN 'Monday' WHEN '2' THEN 'Tuesday'
        WHEN '3' THEN 'Wednesday' WHEN '4' THEN 'Thursday'
        WHEN '5' THEN 'Friday' ELSE 'Weekend'
    END AS Weekday,
    COUNT(*) AS SurgeDays
FROM SurgeDays
GROUP BY DayNumber
ORDER BY DayNumber;  -- Result: 5 rows

-- Requirement 2: absences recorded by cost center, the evidence that could explain attendance
-- Population: EmployeeAbsence; expected: none in Manufacturing in any year
SELECT cc.CostCenterName, COUNT(*) AS Absences,
    MIN(a.AbsenceDate) AS FirstDate,
    MAX(a.AbsenceDate) AS LastDate
FROM EmployeeAbsence AS a
    INNER JOIN Employee AS e ON e.EmployeeID = a.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
GROUP BY cc.CostCenterID, cc.CostCenterName
ORDER BY cc.CostCenterName;  -- Result: 3 rows

-- Requirement 3: hours clocked against the standard hours of the output, by work year
-- Population: PlantEntries; completions up to 2026-12-11, the last day with time records; expected: 1.180, 1.413, 1.511 hours per standard hour
WITH Output AS (
    SELECT strftime('%Y', pc.CompletionDate) AS WorkYear,
        SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
            AS StandardHours
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    WHERE pc.CompletionDate <= (SELECT MAX(WorkDate) FROM TimeClockEntry)
    GROUP BY WorkYear
),
Hours AS (
    SELECT strftime('%Y', WorkDate) AS WorkYear,
        SUM(RegularHours + OvertimeHours) AS ClockedHours,
        SUM(CASE WHEN DayType = 'Surge'
            THEN OvertimeHours ELSE 0 END) AS SurgeOvertime,
        SUM(CASE WHEN DayType = 'Ordinary'
            THEN OvertimeHours ELSE 0 END) AS OtherOvertime
    FROM PlantEntries
    GROUP BY WorkYear
)
SELECT h.WorkYear, ROUND(h.ClockedHours, 0) AS ClockedHours,
    ROUND(o.StandardHours, 0) AS StandardHours,
    ROUND(h.ClockedHours / o.StandardHours, 3)
        AS HoursPerStandardHour,
    ROUND(h.SurgeOvertime, 0) AS SurgeOvertime,
    ROUND(h.OtherOvertime, 0) AS OtherOvertime
FROM Hours AS h
    INNER JOIN Output AS o ON o.WorkYear = h.WorkYear
ORDER BY h.WorkYear;  -- Result: 3 rows

-- Requirement 3: the December values of MonthlyLaborEfficiency (Tutorial 11.3), the same measure on labor time
-- Population: the view; expected: trailing twelve months 1.18, 1.41, 1.51, as the time clock gives
SELECT Month, TTMDirect, TTMIndirect, TTMTotal
FROM MonthlyLaborEfficiency
WHERE Month LIKE '%-12'
ORDER BY Month;  -- Result: 3 rows

-- Requirement 3: Monday weeks of hours and output saved as a view, with the next six weeks' output
-- Population: PlantEntries and completions by Monday week through the week of 11 December 2026; expected: the view PlantWeeks
DROP VIEW IF EXISTS PlantWeeks;
CREATE VIEW PlantWeeks AS
WITH Hours AS (
    SELECT date(WorkDate, '-6 days', 'weekday 1') AS WeekStart,
        SUM(RegularHours + OvertimeHours) AS ClockedHours,
        COUNT(DISTINCT CASE WHEN DayType = 'Surge'
            THEN WorkDate END) AS SurgeDays
    FROM PlantEntries
    GROUP BY WeekStart
),
Output AS (
    SELECT date(pc.CompletionDate, '-6 days', 'weekday 1')
            AS WeekStart,
        SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit) AS StandardHours
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    GROUP BY WeekStart
)
SELECT h.WeekStart, h.ClockedHours, h.SurgeDays,
    COALESCE(o.StandardHours, 0) AS StandardHours,
    AVG(COALESCE(o.StandardHours, 0)) OVER (
        ORDER BY h.WeekStart
        ROWS BETWEEN 1 FOLLOWING AND 6 FOLLOWING
    ) AS NextSixWeeks
FROM Hours AS h
    LEFT JOIN Output AS o ON o.WeekStart = h.WeekStart
WHERE h.WeekStart <= (
    SELECT date(MAX(WorkDate), '-6 days', 'weekday 1')
    FROM TimeClockEntry);  -- Result: creates the view PlantWeeks

-- Requirement 3: the weeks of 2026 grouped by their number of surge days
-- Population: PlantWeeks, 2026; expected: 37 weeks without surge days at 1,555 hours and 1,087 standard hours
SELECT SurgeDays, COUNT(*) AS Weeks,
    ROUND(AVG(ClockedHours), 0) AS ClockedHours,
    ROUND(AVG(StandardHours), 0) AS StandardHours,
    ROUND(SUM(StandardHours) / SUM(ClockedHours), 2)
        AS StandardPerClocked,
    ROUND(AVG(NextSixWeeks), 0) AS NextSixWeeks
FROM PlantWeeks
WHERE WeekStart BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY SurgeDays
ORDER BY SurgeDays;  -- Result: 4 rows

-- Requirement 3: weeks with surge days against weeks without, and the weeks that follow them
-- Population: PlantWeeks, 2026, and every week without surge days from June 2024; expected: 12 surge weeks at 3,622 and 2,005, next six weeks 1,141 against 1,400
SELECT '2026' AS Period,
    CASE WHEN SurgeDays > 0 THEN 'Surge days'
        ELSE 'No surge days' END AS WeekType,
    COUNT(*) AS Weeks,
    ROUND(AVG(ClockedHours), 0) AS ClockedHours,
    ROUND(AVG(StandardHours), 0) AS StandardHours,
    ROUND(SUM(StandardHours) / SUM(ClockedHours), 2)
        AS StandardPerClocked,
    ROUND(AVG(NextSixWeeks), 0) AS NextSixWeeks
FROM PlantWeeks
WHERE WeekStart BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY WeekType
UNION ALL
SELECT 'After the first surge week', 'No surge days', COUNT(*),
    ROUND(AVG(ClockedHours), 0), ROUND(AVG(StandardHours), 0),
    ROUND(SUM(StandardHours) / SUM(ClockedHours), 2),
    ROUND(AVG(NextSixWeeks), 0)
FROM PlantWeeks
WHERE SurgeDays = 0
    AND WeekStart > (
        SELECT MIN(WeekStart) FROM PlantWeeks WHERE SurgeDays > 0)
ORDER BY Period, WeekType;  -- Result: 3 rows

-- Requirement 3: what limits the weekly comparison, lead times and completions dated on weekends
-- Population: work orders closed and completions of 2026; expected: lead time about 40 days; 1674 completions on weekends
SELECT
    (SELECT ROUND(AVG(julianday(CompletedDate)
        - julianday(ReleasedDate)), 1)
     FROM WorkOrder
     WHERE ClosedDate BETWEEN '2026-01-01' AND '2026-12-31') AS LeadTimeDays,
    (SELECT COUNT(*)
     FROM ProductionCompletion
     WHERE CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'
         AND strftime('%w', CompletionDate) IN ('0', '6'))
        AS WeekendCompletions,
    (SELECT COUNT(*)
     FROM ProductionCompletion
     WHERE CompletionDate BETWEEN '2026-01-01' AND '2026-12-31')
        AS Completions;  -- Result: 1 row (LeadTimeDays = 40.3, WeekendCompletions = 1674, Completions = 5314)

-- Requirement 3: the regular capacity the ordinary days used, against the surge-day overtime
-- Population: PlantEntries by work year; expected: unused straight time 52,606, 51,956, 38,417 hours against surge overtime 3,456, 9,216, 14,112
SELECT strftime('%Y', WorkDate) AS WorkYear,
    ROUND(AVG(CASE WHEN DayType = 'Ordinary'
        THEN RegularHours + OvertimeHours END), 2)
        AS OrdinaryHoursPerEntry,
    ROUND(SUM(CASE WHEN DayType = 'Ordinary' AND RegularHours < 8
        THEN 8 - RegularHours ELSE 0 END), 0)
        AS UnusedStraightTime,
    ROUND(SUM(CASE WHEN DayType = 'Surge'
        THEN OvertimeHours ELSE 0 END), 0) AS SurgeOvertime
FROM PlantEntries
GROUP BY WorkYear
ORDER BY WorkYear;  -- Result: 3 rows

-- Requirement 3: the cost of the surge-day overtime at base rates, the premium and the full cost, with the employer's taxes and benefits
-- Population: surge entries by work year, burden from the Manufacturing registers of the pay year; expected: 2026 premium 214,651.73 and full cost 643,955.19 with burden
WITH Burden AS (
    SELECT pp.FiscalYear,
        ROUND(SUM(pr.EmployerPayrollTax + pr.EmployerBenefits)
            / SUM(pr.GrossPay), 4) AS BurdenRate
    FROM PayrollRegister AS pr
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN CostCenter AS cc
            ON cc.CostCenterID = pr.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
    GROUP BY pp.FiscalYear
),
Surge AS (
    SELECT CAST(strftime('%Y', WorkDate) AS INTEGER) AS WorkYear,
        SUM(OvertimeHours) AS OvertimeHours,
        SUM(OvertimeHours * BaseHourlyRate) AS StraightTimeCost
    FROM PlantEntries
    WHERE DayType = 'Surge'
    GROUP BY WorkYear
)
SELECT s.WorkYear, ROUND(s.OvertimeHours, 0) AS OvertimeHours,
    b.BurdenRate,
    ROUND(s.StraightTimeCost * 0.5, 2) AS Premium,
    ROUND(s.StraightTimeCost * 0.5 * (1 + b.BurdenRate), 2)
        AS PremiumWithBurden,
    ROUND(s.StraightTimeCost * 1.5, 2) AS FullCost,
    ROUND(s.StraightTimeCost * 1.5 * (1 + b.BurdenRate), 2)
        AS FullCostWithBurden
FROM Surge AS s
    INNER JOIN Burden AS b ON b.FiscalYear = s.WorkYear
ORDER BY s.WorkYear;  -- Result: 3 rows

-- Requirement 3: accounts 1090 and 5080 by fiscal year saved as a view, the ledger lines of the bridge
-- Population: GLEntry, 1090 and 5080, closes excluded, with WorkOrderClose's material variance; expected: the view PlantLedger
DROP VIEW IF EXISTS PlantLedger;
CREATE VIEW PlantLedger AS
WITH Ledger AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountNumber = 1090
            AND gl.SourceDocumentType = 'PayrollSummary'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS Payroll,
        SUM(CASE WHEN a.AccountNumber = 1090
            AND gl.SourceDocumentType = 'JournalEntry'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS JournalEntries,
        SUM(CASE WHEN a.AccountNumber = 1090
            AND gl.SourceDocumentType = 'ProductionCompletion'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS Released,
        SUM(CASE WHEN a.AccountNumber = 1090
            THEN gl.Debit - gl.Credit ELSE 0 END) AS ChangeIn1090,
        SUM(CASE WHEN a.AccountNumber = 5080
            AND gl.SourceDocumentType <> 'WorkOrderClose'
            THEN gl.Debit - gl.Credit ELSE 0 END) AS DirectTo5080,
        SUM(CASE WHEN a.AccountNumber = 5080
            THEN gl.Debit - gl.Credit ELSE 0 END) AS Variance5080,
        COUNT(DISTINCT CASE WHEN a.AccountNumber = 1090
            AND gl.SourceDocumentType = 'PayrollSummary'
            THEN gl.PostingDate END) AS PayDates
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (1090, 5080)
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear
),
Material AS (
    SELECT CAST(strftime('%Y', CloseDate) AS INTEGER) AS FiscalYear,
        SUM(MaterialVarianceAmount) AS MaterialVariance
    FROM WorkOrderClose
    GROUP BY FiscalYear
)
SELECT l.FiscalYear, l.Payroll, l.JournalEntries, l.Released,
    l.ChangeIn1090, m.MaterialVariance, l.DirectTo5080,
    l.Variance5080, l.PayDates
FROM Ledger AS l
    INNER JOIN Material AS m ON m.FiscalYear = l.FiscalYear;  -- Result: creates the view PlantLedger

-- Requirement 3: the ledger lines of 5080 by fiscal year
-- Population: the view PlantLedger; expected: 5080 1,317,927.32 in 2024 and 2,265,636.88 in 2026
SELECT FiscalYear, ROUND(Payroll, 2) AS Payroll,
    ROUND(JournalEntries, 2) AS JournalEntries,
    ROUND(Released, 2) AS StandardReleased,
    ROUND(ChangeIn1090, 2) AS ChangeIn1090,
    ROUND(MaterialVariance, 2) AS MaterialVariance,
    ROUND(DirectTo5080, 2) AS DirectTo5080,
    ROUND(Variance5080, 2) AS Variance5080,
    ROUND(Payroll + JournalEntries - Released - ChangeIn1090, 2)
        AS ConversionVariance,
    ROUND(Payroll + JournalEntries - Released - ChangeIn1090
        + MaterialVariance + DirectTo5080 - Variance5080, 2)
        AS Unexplained
FROM PlantLedger
ORDER BY FiscalYear;  -- Result: 3 rows

-- Requirement 3: the bridge of 5080 from fiscal 2024 to fiscal 2026
-- Population: the view PlantLedger; expected: growth 947,709.56 = payroll 966,846.03 -8,473.29 91,787.08 -72,196.35 -9,378.15 -20,875.76
SELECT ROUND(c.Variance5080 - f.Variance5080, 2) AS Growth5080,
    ROUND(c.Payroll - f.Payroll, 2) AS Payroll,
    ROUND(c.JournalEntries - f.JournalEntries, 2)
        AS JournalEntries,
    ROUND(f.Released - c.Released, 2) AS StandardReleased,
    ROUND(f.ChangeIn1090 - c.ChangeIn1090, 2) AS ChangeIn1090,
    ROUND(c.MaterialVariance - f.MaterialVariance, 2)
        AS MaterialVariance,
    ROUND(c.DirectTo5080 - f.DirectTo5080, 2) AS DirectPostings
FROM PlantLedger AS f
    INNER JOIN PlantLedger AS c
        ON f.FiscalYear = 2024 AND c.FiscalYear = 2026;  -- Result: 1 rows

-- Requirement 3: the postings made directly to 5080, outside the work order closes
-- Population: GLEntry, 5080, closes excluded; expected: 2024's January payroll 11,520.94 and JE-2024-000005 9,354.82
SELECT gl.FiscalYear, gl.SourceDocumentType, gl.VoucherNumber,
    gl.PostingDate, ROUND(SUM(gl.Debit - gl.Credit), 2) AS Amount
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 5080
    AND gl.SourceDocumentType <> 'WorkOrderClose'
    AND gl.VoucherNumber NOT IN (
        SELECT EntryNumber
        FROM JournalEntry
        WHERE EntryType LIKE 'Year-End Close%')
GROUP BY gl.FiscalYear, gl.SourceDocumentType,
    gl.VoucherNumber, gl.PostingDate
ORDER BY gl.PostingDate;  -- Result: 2 rows

-- Requirement 3: three measures of the payroll line, the calendar, the hours beyond the work, and the surge premium
-- Population: PlantLedger, PlantEntries, completions to the last day with time records; expected: 237,379.26 + 673,995 + 162,084 = 1,073,459, 106,612 above the payroll line
WITH Output AS (
    SELECT strftime('%Y', pc.CompletionDate) AS WorkYear,
        SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
            AS StandardHours
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    WHERE pc.CompletionDate <= (SELECT MAX(WorkDate) FROM TimeClockEntry)
    GROUP BY WorkYear
),
Hours AS (
    SELECT strftime('%Y', WorkDate) AS WorkYear,
        SUM(RegularHours + OvertimeHours) AS ClockedHours,
        SUM(CASE WHEN DayType = 'Surge'
            THEN OvertimeHours * BaseHourlyRate ELSE 0 END)
            * 0.5 AS SurgePremium,
        ROUND(SUM((RegularHours + OvertimeHours) * BaseHourlyRate)
            / SUM(RegularHours + OvertimeHours), 4) AS Rate
    FROM PlantEntries
    GROUP BY WorkYear
),
Burden AS (
    SELECT ROUND(SUM(pr.EmployerPayrollTax + pr.EmployerBenefits)
            / SUM(pr.GrossPay), 4) AS BurdenRate
    FROM PayrollRegister AS pr
        INNER JOIN PayrollPeriod AS pp
            ON pp.PayrollPeriodID = pr.PayrollPeriodID
        INNER JOIN CostCenter AS cc
            ON cc.CostCenterID = pr.CostCenterID
    WHERE cc.CostCenterName = 'Manufacturing'
        AND pp.FiscalYear = 2026
),
Measures AS (
    SELECT lc.Payroll - lf.Payroll AS PayrollLine,
        (lc.PayDates - lf.PayDates) * lf.Payroll / lf.PayDates
            AS Calendar,
        hc.ClockedHours
            - hf.ClockedHours / ofy.StandardHours * oc.StandardHours
            AS HoursBeyond,
        hc.Rate * (1 + (SELECT BurdenRate FROM Burden))
            AS RateWithBurden,
        (hc.SurgePremium - hf.SurgePremium)
            * (1 + (SELECT BurdenRate FROM Burden)) AS PremiumGrowth
    FROM PlantLedger AS lf
        INNER JOIN PlantLedger AS lc ON lc.FiscalYear = 2026
        INNER JOIN Hours AS hf ON hf.WorkYear = '2024'
        INNER JOIN Hours AS hc ON hc.WorkYear = '2026'
        INNER JOIN Output AS ofy ON ofy.WorkYear = '2024'
        INNER JOIN Output AS oc ON oc.WorkYear = '2026'
    WHERE lf.FiscalYear = 2024
)
SELECT ROUND(PayrollLine, 2) AS PayrollLine,
    ROUND(Calendar, 2) AS Calendar,
    ROUND(HoursBeyond, 0) AS HoursBeyond,
    ROUND(HoursBeyond * RateWithBurden, 0) AS HoursBeyondCost,
    ROUND(PremiumGrowth, 0) AS PremiumGrowth,
    ROUND(Calendar + HoursBeyond * RateWithBurden
        + PremiumGrowth, 0) AS Together,
    ROUND(Calendar + HoursBeyond * RateWithBurden
        + PremiumGrowth - PayrollLine, 0) AS Excess
FROM Measures;  -- Result: 1 rows

-- Requirement 4: the depreciation of the equipment charged to 1090 saved as a view, by asset
-- Population: FixedAsset, DepreciationDebitAccountID of 1090; expected: the view PlantAssets, months counted as year x 12 + month - 1
DROP VIEW IF EXISTS PlantAssets;
CREATE VIEW PlantAssets AS
SELECT fa.AssetCode, fa.InServiceDate, fa.DisposalDate,
    fa.UsefulLifeMonths, fa.OriginalCost,
    ROUND(fa.OriginalCost * 1.0 / fa.UsefulLifeMonths, 2)
        AS Monthly,
    CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
        + CAST(strftime('%m', fa.InServiceDate) AS INTEGER)
        AS FirstMonth,
    CASE
        WHEN fa.DisposalDate IS NULL
            OR CAST(strftime('%Y', fa.DisposalDate) AS INTEGER) * 12
                + CAST(strftime('%m', fa.DisposalDate) AS INTEGER) - 2
                > CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
                + CAST(strftime('%m', fa.InServiceDate) AS INTEGER)
                - 1 + fa.UsefulLifeMonths
            THEN CAST(strftime('%Y', fa.InServiceDate) AS INTEGER) * 12
                + CAST(strftime('%m', fa.InServiceDate) AS INTEGER)
                - 1 + fa.UsefulLifeMonths
        ELSE CAST(strftime('%Y', fa.DisposalDate) AS INTEGER) * 12
            + CAST(strftime('%m', fa.DisposalDate) AS INTEGER) - 2
    END AS LastMonth
FROM FixedAsset AS fa
    INNER JOIN Account AS a
        ON a.AccountID = fa.DepreciationDebitAccountID
WHERE a.AccountNumber = 1090;  -- Result: creates the view PlantAssets

-- Requirement 4: each asset's depreciation in 2026 and 2027, and the 2026 total against the ledger
-- Population: PlantAssets; expected: 303,666.63 in 2026, equal to the ledger; 293,499.96 in 2027; MFG-0005 ends its life in December 2027
WITH Months AS (
    SELECT DISTINCT CAST(strftime('%Y', CalendarDate) AS INTEGER) * 12
        + CAST(strftime('%m', CalendarDate) AS INTEGER) - 1
        AS MonthIndex
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
)
SELECT pa.AssetCode, pa.InServiceDate, pa.DisposalDate, pa.Monthly,
    ROUND(pa.Monthly * (SELECT COUNT(*) FROM Months AS m
        WHERE m.MonthIndex BETWEEN pa.FirstMonth AND pa.LastMonth),
        2) AS Depreciation2026,
    ROUND(pa.Monthly * (SELECT COUNT(*) FROM Months AS m
        WHERE m.MonthIndex + 12
            BETWEEN pa.FirstMonth AND pa.LastMonth),
        2) AS Depreciation2027,
    pa.LastMonth - 2027 * 12 + 1 AS LastMonthOf2027
FROM PlantAssets AS pa
ORDER BY pa.AssetCode;  -- Result: 7 rows

-- Requirement 4: the monthly depreciation charged to 1090 in 2026
-- Population: PlantAssets against the months of 2026 in WorkCenterCalendar; expected: 24,625.00 in January, 26,958.33 from February (MFG-0007), 24,458.33 from June (MFG-0004)
WITH Months AS (
    SELECT DISTINCT strftime('%Y-%m', CalendarDate) AS Month,
        CAST(strftime('%Y', CalendarDate) AS INTEGER) * 12
            + CAST(strftime('%m', CalendarDate) AS INTEGER) - 1
            AS MonthIndex
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
)
SELECT m.Month, COUNT(*) AS Assets,
    ROUND(SUM(pa.Monthly), 2) AS Depreciation
FROM Months AS m
    INNER JOIN PlantAssets AS pa
        ON m.MonthIndex BETWEEN pa.FirstMonth AND pa.LastMonth
GROUP BY m.Month
ORDER BY m.Month;  -- Result: 12 rows

-- Requirement 4: the purchases behind the equipment placed in service in the window
-- Population: PlantAssets in service from 2024, their supplier invoices and orders; expected: MFG-0006 PO-2024-001942, MFG-0007 PO-2026-011104, each above its approver's limit
SELECT fa.AssetCode, fa.InServiceDate, fa.OriginalCost,
    po.PONumber, po.OrderTotal,
    ap.MaxApprovalAmount AS ApproverLimit
FROM FixedAsset AS fa
    INNER JOIN Account AS a
        ON a.AccountID = fa.DepreciationDebitAccountID
    INNER JOIN PurchaseInvoice AS pi
        ON pi.ReceivedDate = fa.InServiceDate
        AND ABS(pi.GrandTotal - fa.OriginalCost) < 0.005
    INNER JOIN PurchaseOrder AS po
        ON po.PurchaseOrderID = pi.PurchaseOrderID
    INNER JOIN Employee AS ap
        ON ap.EmployeeID = po.ApprovedByEmployeeID
WHERE a.AccountNumber = 1090
    AND fa.InServiceDate >= '2024-01-01'
    AND EXISTS (
        SELECT 1
        FROM PurchaseOrderLine AS pol
        WHERE pol.PurchaseOrderID = po.PurchaseOrderID
            AND pol.ItemID = fa.ItemID)
ORDER BY fa.AssetCode;  -- Result: 2 rows

-- Requirement 4: the standard cost of 2026's output, per standard hour
-- Population: completion lines of 2026; expected: 68,912.79 standard hours, 3,266,422.54 of conversion cost, 47.40 per standard hour
WITH Output AS (
    SELECT SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
            AS StandardHours,
        SUM(pcl.ExtendedStandardConversionCost) AS Conversion,
        SUM(pcl.ExtendedStandardDirectLaborCost) AS Labor,
        SUM(pcl.ExtendedStandardVariableOverheadCost
            + pcl.ExtendedStandardFixedOverheadCost) AS Overhead
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'
)
SELECT ROUND(StandardHours, 2) AS StandardHours,
    ROUND(Conversion, 2) AS StandardConversion,
    ROUND(Labor, 2) AS StandardLabor,
    ROUND(Overhead, 2) AS AppliedOverhead,
    ROUND(Conversion / StandardHours, 2) AS ConversionPerHour,
    ROUND(Labor / StandardHours, 2) AS LaborPerHour,
    ROUND(Overhead / StandardHours, 2) AS OverheadPerHour
FROM Output;  -- Result: 1 rows

-- Requirement 4: the salaried manufacturing staff and their 2026 gross pay
-- Population: Manufacturing registers of 2026, salaried employees; expected: Production Manager, Planner, Supervisor, 263,191.24
SELECT e.JobTitle, COUNT(DISTINCT pr.EmployeeID) AS Employees,
    ROUND(SUM(pr.GrossPay), 2) AS GrossPay
FROM PayrollRegister AS pr
    INNER JOIN PayrollPeriod AS pp
        ON pp.PayrollPeriodID = pr.PayrollPeriodID
    INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing'
    AND e.PayClass = 'Salary'
    AND pp.FiscalYear = 2026
GROUP BY e.JobTitle
ORDER BY e.JobTitle;  -- Result: 3 rows

-- Requirement 4: why the volume comes from output, the budget against units completed and the demand forecast against units ordered
-- Population: BudgetLine revenue of manufactured items, completions, current forecasts and orders of the product groups; expected: budget about three times output; forecast two to three times orders
WITH Budgeted AS (
    SELECT b.FiscalYear, SUM(b.Quantity) AS Units
    FROM BudgetLine AS b
        INNER JOIN Item AS i ON i.ItemID = b.ItemID
    WHERE b.BudgetCategory = 'Revenue'
        AND i.SupplyMode = 'Manufactured'
    GROUP BY b.FiscalYear
),
Completed AS (
    SELECT CAST(strftime('%Y', pc.CompletionDate) AS INTEGER)
            AS FiscalYear,
        SUM(pcl.QuantityCompleted) AS Units
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
    GROUP BY FiscalYear
),
Forecast AS (
    SELECT CAST(strftime('%Y', f.ForecastWeekStartDate) AS INTEGER)
            AS FiscalYear,
        SUM(f.ForecastQuantity) AS Units
    FROM DemandForecast AS f
        INNER JOIN Item AS i ON i.ItemID = f.ItemID
    WHERE f.IsCurrent = 1
        AND i.ItemGroup IN ('Furniture', 'Lighting', 'Textiles', 'Accessories')
    GROUP BY FiscalYear
),
Ordered AS (
    SELECT CAST(strftime('%Y', so.OrderDate) AS INTEGER)
            AS FiscalYear,
        SUM(sol.Quantity) AS Units
    FROM SalesOrderLine AS sol
        INNER JOIN SalesOrder AS so
            ON so.SalesOrderID = sol.SalesOrderID
        INNER JOIN Item AS i ON i.ItemID = sol.ItemID
    WHERE i.ItemGroup IN ('Furniture', 'Lighting', 'Textiles', 'Accessories')
    GROUP BY FiscalYear
)
SELECT c.FiscalYear,
    ROUND(b.Units / c.Units, 2) AS BudgetToCompleted,
    ROUND(f.Units / o.Units, 2) AS ForecastToOrdered
FROM Completed AS c
    INNER JOIN Budgeted AS b ON b.FiscalYear = c.FiscalYear
    INNER JOIN Forecast AS f ON f.FiscalYear = c.FiscalYear
    INNER JOIN Ordered AS o ON o.FiscalYear = c.FiscalYear
ORDER BY c.FiscalYear;  -- Result: 3 rows

-- Requirement 4: what the budget holds for Manufacturing
-- Population: BudgetLine of the Manufacturing cost center; expected: cost of goods sold only, no labor or overhead budget
SELECT b.FiscalYear, b.BudgetCategory, COUNT(*) AS Lines
FROM BudgetLine AS b
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = b.CostCenterID
WHERE cc.CostCenterName = 'Manufacturing'
GROUP BY b.FiscalYear, b.BudgetCategory
ORDER BY b.FiscalYear, b.BudgetCategory;  -- Result: 4 rows

-- Requirement 4: the 2027 plan, hours against regular capacity and conversion cost against standard, in three scenarios
-- Population: the Params CTE; expected: capacity 131,072 hours; expected variance 730,432, 1,107,366, 2,104,714
WITH Output AS (
    SELECT strftime('%Y', pc.CompletionDate) AS WorkYear,
        SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
            AS StandardHours,
        SUM(CASE WHEN pc.CompletionDate
                <= (SELECT MAX(WorkDate) FROM TimeClockEntry)
            THEN pcl.QuantityCompleted * i.StandardLaborHoursPerUnit
            ELSE 0 END) AS StandardHoursToCutoff,
        SUM(pcl.ExtendedStandardConversionCost) AS Conversion,
        SUM(pcl.ExtendedStandardDirectLaborCost) AS Labor,
        SUM(pcl.ExtendedStandardVariableOverheadCost
            + pcl.ExtendedStandardFixedOverheadCost) AS Overhead
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    GROUP BY WorkYear
),
Hours AS (
    SELECT strftime('%Y', WorkDate) AS WorkYear,
        SUM(RegularHours + OvertimeHours) AS ClockedHours,
        SUM((RegularHours + OvertimeHours) * BaseHourlyRate)
            AS StraightTimeCost,
        SUM(OvertimeHours * BaseHourlyRate) * 0.5 AS Premium
    FROM PlantEntries
    GROUP BY WorkYear
),
Months AS (
    SELECT DISTINCT CAST(strftime('%Y', CalendarDate) AS INTEGER) * 12
        + CAST(strftime('%m', CalendarDate) AS INTEGER) - 1 AS MonthIndex
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
),
Params AS (
    SELECT
        -- volume: the 2026 output in standard hours; the budget and the
        -- demand forecast run two to three times what the plant made
        (SELECT StandardHours FROM Output WHERE WorkYear = '2026')
            AS StandardHours,
        -- what completions released to 1090 at standard (the ledger),
        -- and the standard labor and overhead of the completion lines
        (SELECT Released FROM PlantLedger WHERE FiscalYear = 2026)
            AS StandardConversion,
        (SELECT Labor FROM Output WHERE WorkYear = '2026') AS StandardLabor,
        (SELECT Overhead FROM Output WHERE WorkYear = '2026')
            AS AppliedOverhead,
        -- hours per standard hour: the 2024 level (the target) and the
        -- 2026 level, on output up to the last day with time records
        (SELECT ROUND(h.ClockedHours / o.StandardHoursToCutoff, 2)
         FROM Hours AS h
             INNER JOIN Output AS o ON o.WorkYear = h.WorkYear
         WHERE h.WorkYear = '2024') AS TargetRatio,
        (SELECT ROUND(h.ClockedHours / o.StandardHoursToCutoff, 3)
         FROM Hours AS h
             INNER JOIN Output AS o ON o.WorkYear = h.WorkYear
         WHERE h.WorkYear = '2026') AS CurrentRatio,
        -- straight-time rate: 2026 base rates weighted by hours clocked
        (SELECT ROUND(StraightTimeCost / ClockedHours, 4)
         FROM Hours
         WHERE WorkYear = '2026') AS Rate,
        -- the 2026 overtime premium (half the base rate), all overtime
        (SELECT Premium FROM Hours WHERE WorkYear = '2026') AS Premium,
        -- burden: employer taxes and benefits over gross pay, on the
        -- Manufacturing registers of 2026
        (SELECT ROUND(SUM(pr.EmployerPayrollTax + pr.EmployerBenefits)
             / SUM(pr.GrossPay), 4)
         FROM PayrollRegister AS pr
             INNER JOIN PayrollPeriod AS pp
                 ON pp.PayrollPeriodID = pr.PayrollPeriodID
             INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
         WHERE cc.CostCenterName = 'Manufacturing'
             AND pp.FiscalYear = 2026) AS Burden,
        -- salaried manufacturing staff, 2026 gross pay
        (SELECT SUM(pr.GrossPay)
         FROM PayrollRegister AS pr
             INNER JOIN PayrollPeriod AS pp
                 ON pp.PayrollPeriodID = pr.PayrollPeriodID
             INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
             INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
         WHERE cc.CostCenterName = 'Manufacturing'
             AND e.PayClass = 'Salary'
             AND pp.FiscalYear = 2026) AS Salaried,
        -- factory overhead at the run rate of its 2026 entries to 1090
        (SELECT SUM(gl.Debit)
         FROM GLEntry AS gl
             INNER JOIN JournalEntry AS je
                 ON je.JournalEntryID = gl.SourceDocumentID
             INNER JOIN Account AS a ON a.AccountID = gl.AccountID
         WHERE gl.SourceDocumentType = 'JournalEntry'
             AND je.EntryType = 'Factory Overhead'
             AND a.AccountNumber = 1090
             AND gl.FiscalYear = 2026) AS FactoryOverhead,
        -- 2027 depreciation of the equipment charged to 1090 (PlantAssets):
        -- the months of 2027 are those of 2026 plus twelve
        (SELECT SUM(pa.Monthly)
         FROM PlantAssets AS pa
             INNER JOIN Months AS m
                 ON m.MonthIndex + 12 BETWEEN pa.FirstMonth AND pa.LastMonth)
            AS Depreciation,
        -- regular capacity: active hourly employees x 8 hours x the
        -- working days of 2026, because the calendar stops early in 2027
        (SELECT COUNT(*)
         FROM Employee AS e
             INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
         WHERE cc.CostCenterName = 'Manufacturing'
             AND e.PayClass = 'Hourly'
             AND e.IsActive = 1) AS Employees,
        (SELECT COUNT(DISTINCT CalendarDate)
         FROM WorkCenterCalendar
         WHERE IsWorkingDay = 1
             AND CalendarDate BETWEEN '2026-01-01' AND '2026-12-31')
            AS WorkingDays
),
Scenarios AS (
    SELECT 'Standard hours' AS Scenario, 1.0 AS Ratio,
        0 AS WithPremium, p.*
    FROM Params AS p
    UNION ALL
    SELECT '2024 level', p.TargetRatio, 0, p.*
    FROM Params AS p
    UNION ALL
    SELECT '2026 level with its overtime', p.CurrentRatio, 1, p.*
    FROM Params AS p
)
SELECT Scenario, Ratio,
    ROUND(StandardHours * Ratio, 0) AS HoursNeeded,
    Employees * 8 * WorkingDays AS RegularCapacity,
    CASE WHEN StandardHours * Ratio > Employees * 8 * WorkingDays
        THEN ROUND(StandardHours * Ratio
            - Employees * 8 * WorkingDays, 0)
        ELSE 0 END AS OvertimeNeeded,
    ROUND(StandardHours * Ratio * Rate * (1 + Burden), 0)
        AS HourlyLabor,
    ROUND(WithPremium * Premium * (1 + Burden), 0)
        AS OvertimePremium,
    ROUND(Salaried * (1 + Burden) + FactoryOverhead
        + Depreciation, 0) AS Overhead,
    ROUND(StandardHours * Ratio * Rate * (1 + Burden)
        + WithPremium * Premium * (1 + Burden)
        + Salaried * (1 + Burden) + FactoryOverhead
        + Depreciation, 0) AS ConversionCost,
    ROUND(StandardConversion, 0) AS StandardConversion,
    ROUND(StandardHours * Ratio * Rate * (1 + Burden)
        + WithPremium * Premium * (1 + Burden)
        + Salaried * (1 + Burden) + FactoryOverhead
        + Depreciation - StandardConversion, 0)
        AS ExpectedVariance
FROM Scenarios
ORDER BY Ratio;  -- Result: 3 rows

-- Requirement 4: the variance left at standard hours, by cause
-- Population: the Params CTE and 2026's completions; expected: labor rate with burden 30.39 against 28.28 (about 145,000), overhead 1,902,776 against 1,317,563 applied (about 585,000)
WITH Output AS (
    SELECT strftime('%Y', pc.CompletionDate) AS WorkYear,
        SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
            AS StandardHours,
        SUM(CASE WHEN pc.CompletionDate
                <= (SELECT MAX(WorkDate) FROM TimeClockEntry)
            THEN pcl.QuantityCompleted * i.StandardLaborHoursPerUnit
            ELSE 0 END) AS StandardHoursToCutoff,
        SUM(pcl.ExtendedStandardConversionCost) AS Conversion,
        SUM(pcl.ExtendedStandardDirectLaborCost) AS Labor,
        SUM(pcl.ExtendedStandardVariableOverheadCost
            + pcl.ExtendedStandardFixedOverheadCost) AS Overhead
    FROM ProductionCompletionLine AS pcl
        INNER JOIN ProductionCompletion AS pc
            ON pc.ProductionCompletionID = pcl.ProductionCompletionID
        INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
    GROUP BY WorkYear
),
Hours AS (
    SELECT strftime('%Y', WorkDate) AS WorkYear,
        SUM(RegularHours + OvertimeHours) AS ClockedHours,
        SUM((RegularHours + OvertimeHours) * BaseHourlyRate)
            AS StraightTimeCost,
        SUM(OvertimeHours * BaseHourlyRate) * 0.5 AS Premium
    FROM PlantEntries
    GROUP BY WorkYear
),
Months AS (
    SELECT DISTINCT CAST(strftime('%Y', CalendarDate) AS INTEGER) * 12
        + CAST(strftime('%m', CalendarDate) AS INTEGER) - 1 AS MonthIndex
    FROM WorkCenterCalendar
    WHERE CalendarDate BETWEEN '2026-01-01' AND '2026-12-31'
),
Params AS (
    SELECT
        -- volume: the 2026 output in standard hours; the budget and the
        -- demand forecast run two to three times what the plant made
        (SELECT StandardHours FROM Output WHERE WorkYear = '2026')
            AS StandardHours,
        -- what completions released to 1090 at standard (the ledger),
        -- and the standard labor and overhead of the completion lines
        (SELECT Released FROM PlantLedger WHERE FiscalYear = 2026)
            AS StandardConversion,
        (SELECT Labor FROM Output WHERE WorkYear = '2026') AS StandardLabor,
        (SELECT Overhead FROM Output WHERE WorkYear = '2026')
            AS AppliedOverhead,
        -- hours per standard hour: the 2024 level (the target) and the
        -- 2026 level, on output up to the last day with time records
        (SELECT ROUND(h.ClockedHours / o.StandardHoursToCutoff, 2)
         FROM Hours AS h
             INNER JOIN Output AS o ON o.WorkYear = h.WorkYear
         WHERE h.WorkYear = '2024') AS TargetRatio,
        (SELECT ROUND(h.ClockedHours / o.StandardHoursToCutoff, 3)
         FROM Hours AS h
             INNER JOIN Output AS o ON o.WorkYear = h.WorkYear
         WHERE h.WorkYear = '2026') AS CurrentRatio,
        -- straight-time rate: 2026 base rates weighted by hours clocked
        (SELECT ROUND(StraightTimeCost / ClockedHours, 4)
         FROM Hours
         WHERE WorkYear = '2026') AS Rate,
        -- the 2026 overtime premium (half the base rate), all overtime
        (SELECT Premium FROM Hours WHERE WorkYear = '2026') AS Premium,
        -- burden: employer taxes and benefits over gross pay, on the
        -- Manufacturing registers of 2026
        (SELECT ROUND(SUM(pr.EmployerPayrollTax + pr.EmployerBenefits)
             / SUM(pr.GrossPay), 4)
         FROM PayrollRegister AS pr
             INNER JOIN PayrollPeriod AS pp
                 ON pp.PayrollPeriodID = pr.PayrollPeriodID
             INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
         WHERE cc.CostCenterName = 'Manufacturing'
             AND pp.FiscalYear = 2026) AS Burden,
        -- salaried manufacturing staff, 2026 gross pay
        (SELECT SUM(pr.GrossPay)
         FROM PayrollRegister AS pr
             INNER JOIN PayrollPeriod AS pp
                 ON pp.PayrollPeriodID = pr.PayrollPeriodID
             INNER JOIN Employee AS e ON e.EmployeeID = pr.EmployeeID
             INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
         WHERE cc.CostCenterName = 'Manufacturing'
             AND e.PayClass = 'Salary'
             AND pp.FiscalYear = 2026) AS Salaried,
        -- factory overhead at the run rate of its 2026 entries to 1090
        (SELECT SUM(gl.Debit)
         FROM GLEntry AS gl
             INNER JOIN JournalEntry AS je
                 ON je.JournalEntryID = gl.SourceDocumentID
             INNER JOIN Account AS a ON a.AccountID = gl.AccountID
         WHERE gl.SourceDocumentType = 'JournalEntry'
             AND je.EntryType = 'Factory Overhead'
             AND a.AccountNumber = 1090
             AND gl.FiscalYear = 2026) AS FactoryOverhead,
        -- 2027 depreciation of the equipment charged to 1090 (PlantAssets):
        -- the months of 2027 are those of 2026 plus twelve
        (SELECT SUM(pa.Monthly)
         FROM PlantAssets AS pa
             INNER JOIN Months AS m
                 ON m.MonthIndex + 12 BETWEEN pa.FirstMonth AND pa.LastMonth)
            AS Depreciation,
        -- regular capacity: active hourly employees x 8 hours x the
        -- working days of 2026, because the calendar stops early in 2027
        (SELECT COUNT(*)
         FROM Employee AS e
             INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
         WHERE cc.CostCenterName = 'Manufacturing'
             AND e.PayClass = 'Hourly'
             AND e.IsActive = 1) AS Employees,
        (SELECT COUNT(DISTINCT CalendarDate)
         FROM WorkCenterCalendar
         WHERE IsWorkingDay = 1
             AND CalendarDate BETWEEN '2026-01-01' AND '2026-12-31')
            AS WorkingDays
)
SELECT Rate, Burden, ROUND(Salaried, 2) AS Salaried,
    ROUND(FactoryOverhead, 2) AS FactoryOverhead,
    ROUND(Depreciation, 2) AS Depreciation,
    ROUND(Rate * (1 + Burden), 2) AS RateWithBurden,
    ROUND(StandardLabor / StandardHours, 2)
        AS StandardRate,
    ROUND(Rate * (1 + Burden) * StandardHours
        - StandardLabor, 0) AS LaborExcess,
    ROUND(Salaried * (1 + Burden) + FactoryOverhead
        + Depreciation, 0) AS PlanOverhead,
    ROUND(AppliedOverhead, 0) AS AppliedOverhead,
    ROUND(Salaried * (1 + Burden) + FactoryOverhead + Depreciation
        - AppliedOverhead, 0) AS OverheadExcess,
    ROUND(StandardHours / (Employees * 8 * WorkingDays), 3)
        AS CapacityUsed
FROM Params;  -- Result: 1 rows

-- Requirement 5: the payroll owed at 2026-12-31, saved as a view: the last eight processed pay periods' cost per working day
-- Population: PayrollPeriod Processed, their registers, WorkCenterCalendar; expected: the view PayrollAccrual
DROP VIEW IF EXISTS PayrollAccrual;
CREATE VIEW PayrollAccrual AS
WITH Periods AS (
    SELECT PayrollPeriodID, PeriodStartDate, PeriodEndDate
    FROM PayrollPeriod
    WHERE Status = 'Processed'
    ORDER BY PeriodEndDate DESC
    LIMIT 8
),
Span AS (
    SELECT MIN(PeriodStartDate) AS FirstDay,
        MAX(PeriodEndDate) AS LastDay
    FROM Periods
),
Days AS (
    SELECT sp.FirstDay, sp.LastDay,
        (SELECT COUNT(DISTINCT c.CalendarDate)
         FROM WorkCenterCalendar AS c
         WHERE c.IsWorkingDay = 1
             AND c.CalendarDate BETWEEN sp.FirstDay AND sp.LastDay)
            AS PeriodDays,
        (SELECT COUNT(DISTINCT c.CalendarDate)
         FROM WorkCenterCalendar AS c
         WHERE c.IsWorkingDay = 1
             AND c.CalendarDate > sp.LastDay
             AND c.CalendarDate <= '2026-12-31') AS DaysLeft
    FROM Span AS sp
),
Centers AS (
    SELECT cc.CostCenterID, cc.CostCenterName,
        SUM(pr.GrossPay) AS GrossPay,
        SUM(pr.EmployerPayrollTax) AS EmployerTaxes,
        SUM(pr.EmployerBenefits) AS Benefits
    FROM PayrollRegister AS pr
        INNER JOIN CostCenter AS cc
            ON cc.CostCenterID = pr.CostCenterID
    WHERE pr.PayrollPeriodID IN (SELECT PayrollPeriodID FROM Periods)
    GROUP BY cc.CostCenterID, cc.CostCenterName
)
SELECT ce.CostCenterID, ce.CostCenterName,
    (SELECT FirstDay FROM Days) AS FirstDay,
    (SELECT LastDay FROM Days) AS LastDay,
    (SELECT PeriodDays FROM Days) AS PeriodDays,
    (SELECT DaysLeft FROM Days) AS DaysLeft,
    ce.GrossPay + ce.EmployerTaxes + ce.Benefits AS PeriodCost,
    ce.GrossPay / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days) AS GrossPay,
    ce.EmployerTaxes / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days) AS EmployerTaxes,
    ce.Benefits / (SELECT PeriodDays FROM Days)
        * (SELECT DaysLeft FROM Days) AS Benefits
FROM Centers AS ce;  -- Result: creates the view PayrollAccrual

-- Requirement 5: the accrual for 14-31 December 2026 in total
-- Population: the view PayrollAccrual; expected: 2,298,268.90 over 78 working days, 29,464.99 a day, x 13 days = 383,044.82
SELECT MIN(FirstDay) AS FirstDay, MAX(LastDay) AS LastDay,
    MAX(PeriodDays) AS PeriodDays, MAX(DaysLeft) AS DaysLeft,
    ROUND(SUM(PeriodCost), 2) AS PeriodCost,
    ROUND(SUM(PeriodCost) / MAX(PeriodDays), 2) AS CostPerDay,
    ROUND(SUM(GrossPay + EmployerTaxes + Benefits), 2) AS Accrual,
    ROUND(SUM(GrossPay), 2) AS GrossPay,
    ROUND(SUM(EmployerTaxes), 2) AS EmployerTaxes,
    ROUND(SUM(Benefits), 2) AS Benefits
FROM PayrollAccrual;  -- Result: 1 rows

-- Requirement 5: the accrual at 2026-12-31 by cost center
-- Population: the view PayrollAccrual; expected: 10 cost centers, Manufacturing 197,970.68
SELECT CostCenterName,
    ROUND(GrossPay + EmployerTaxes + Benefits, 2) AS Accrual,
    ROUND(GrossPay, 2) AS GrossPay
FROM PayrollAccrual
ORDER BY Accrual DESC;  -- Result: 10 rows

-- Requirement 5: the accounts each cost center's payroll is debited to, 2026
-- Population: PayrollSummary debits; expected: Manufacturing to 1090; each other cost center to one salary account and 6060
SELECT cc.CostCenterName, a.AccountNumber, a.AccountName,
    ROUND(SUM(gl.Debit), 2) AS Debits
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = gl.CostCenterID
WHERE gl.SourceDocumentType = 'PayrollSummary'
    AND gl.FiscalYear = 2026
    AND gl.Debit > 0
GROUP BY cc.CostCenterID, cc.CostCenterName, a.AccountID,
    a.AccountNumber, a.AccountName
ORDER BY cc.CostCenterName, a.AccountNumber;  -- Result: 19 rows

-- Requirement 5: the accounts the adjusting entries credit and debit for the employer's costs
-- Population: Account; expected: 2030 Accrued Payroll, the employer tax and benefit liabilities, 6060
SELECT AccountNumber, AccountName, AccountType, AccountSubType
FROM Account
WHERE AccountNumber IN (2030, 2032, 2033, 6060)
ORDER BY AccountNumber;  -- Result: 4 rows

-- Requirement 5: the 2025 work paid in fiscal 2026, saved as a view: the pay periods that cross 2025-12-31, by working day
-- Population: PayrollPeriod paid after 2025-12-31 that start by then; expected: the view PriorYearWork
DROP VIEW IF EXISTS PriorYearWork;
CREATE VIEW PriorYearWork AS
WITH Periods AS (
    SELECT pp.PayrollPeriodID, pp.PeriodNumber,
        pp.PeriodStartDate, pp.PeriodEndDate, pp.PayDate,
        (SELECT COUNT(DISTINCT c.CalendarDate)
         FROM WorkCenterCalendar AS c
         WHERE c.IsWorkingDay = 1
             AND c.CalendarDate BETWEEN pp.PeriodStartDate
                 AND pp.PeriodEndDate
             AND c.CalendarDate <= '2025-12-31') AS DaysInYear,
        (SELECT COUNT(DISTINCT c.CalendarDate)
         FROM WorkCenterCalendar AS c
         WHERE c.IsWorkingDay = 1
             AND c.CalendarDate BETWEEN pp.PeriodStartDate
                 AND pp.PeriodEndDate) AS WorkingDays
    FROM PayrollPeriod AS pp
    WHERE pp.PeriodStartDate <= '2025-12-31'
        AND pp.PayDate > '2025-12-31'
)
SELECT p.PeriodNumber, p.PeriodStartDate, p.PeriodEndDate,
    p.PayDate, p.DaysInYear, p.WorkingDays,
    SUM(pr.GrossPay + pr.EmployerPayrollTax + pr.EmployerBenefits)
        AS PeriodCost,
    SUM(CASE WHEN cc.CostCenterName = 'Manufacturing'
        THEN pr.GrossPay + pr.EmployerPayrollTax
            + pr.EmployerBenefits ELSE 0 END) AS Manufacturing
FROM Periods AS p
    INNER JOIN PayrollRegister AS pr
        ON pr.PayrollPeriodID = p.PayrollPeriodID
    INNER JOIN CostCenter AS cc ON cc.CostCenterID = pr.CostCenterID
GROUP BY p.PayrollPeriodID, p.PeriodNumber, p.PeriodStartDate,
    p.PeriodEndDate, p.PayDate, p.DaysInYear, p.WorkingDays;  -- Result: creates the view PriorYearWork

-- Requirement 5: the 2025 work in the registers paid in fiscal 2026
-- Population: the view PriorYearWork; expected: period of 2025-12-15 in full, 263,426.72, and 3 of 9 working days of the next, 102,494.47: 365,921.19
SELECT PeriodNumber, PeriodStartDate, PeriodEndDate, PayDate,
    DaysInYear, WorkingDays, ROUND(PeriodCost, 2) AS PeriodCost,
    ROUND(PeriodCost * DaysInYear / WorkingDays, 2)
        AS PriorYearWork,
    ROUND(Manufacturing * DaysInYear / WorkingDays, 2)
        AS ManufacturingPart
FROM PriorYearWork
ORDER BY PeriodStartDate;  -- Result: 2 rows

-- Requirement 5: test L8 of Audit.sql rerun, account 2030 by source document type
-- Population: account 2030 to 2026-12-31; expected: the opening 95,000.00 of JE-2024-000001 alone; the payroll postings net to zero
SELECT gl.SourceDocumentType, COUNT(*) AS Postings,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Balance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 2030 AND gl.PostingDate <= '2026-12-31'
GROUP BY gl.SourceDocumentType;  -- Result: 3 rows

-- Requirement 5: test L5 of Audit.sql rerun, revenue posted in another year than its delivery
-- Population: every sales invoice; expected: 19,540.86 of 2025 deliveries posted in 2026
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MIN(s.ShipmentDate) AS ShipmentDate,
        MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
),
Classified AS (
    SELECT si.SubTotal,
        strftime('%Y', sh.DeliveryDate) AS DeliveryYear,
        CASE
            WHEN strftime('%Y', p.PostingDate)
                    <> strftime('%Y', sh.DeliveryDate)
                THEN 'Revenue posted in another year'
            WHEN si.InvoiceDate < sh.ShipmentDate
                THEN 'Invoice dated before shipment'
            ELSE 'In the year of delivery'
        END AS Finding
    FROM SalesInvoice AS si
        INNER JOIN Shipped AS sh
            ON sh.SalesInvoiceID = si.SalesInvoiceID
        INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
)
SELECT Finding, DeliveryYear, COUNT(*) AS Invoices,
    ROUND(SUM(SubTotal), 2) AS SubTotal
FROM Classified
WHERE Finding <> 'In the year of delivery'
GROUP BY Finding, DeliveryYear
ORDER BY Finding, DeliveryYear;  -- Result: 5 rows

-- Requirement 5: test L6 of Audit.sql rerun, shipments never invoiced
-- Population: every shipment line; expected: 9 lines, 44,481.11 at order price, standard cost 22,895.78
SELECT s.ShipmentNumber, s.ShipmentDate, s.DeliveryDate,
    ROUND(sl.ExtendedStandardCost, 2) AS StandardCost,
    ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
        AS SalesValue
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL
ORDER BY s.ShipmentDate;  -- Result: 9 rows

-- Requirement 5: the revenue cutoff items saved as a view, by delivery and posting year
-- Population: invoices posted in another year than their latest delivery, and shipment lines never invoiced; expected: the view CutoffItems
DROP VIEW IF EXISTS CutoffItems;
CREATE VIEW CutoffItems AS
WITH Shipped AS (
    SELECT sil.SalesInvoiceID, MAX(s.DeliveryDate) AS DeliveryDate
    FROM SalesInvoiceLine AS sil
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    GROUP BY sil.SalesInvoiceID
),
Posted AS (
    SELECT SourceDocumentID AS SalesInvoiceID,
        MIN(PostingDate) AS PostingDate
    FROM GLEntry
    WHERE SourceDocumentType = 'SalesInvoice'
    GROUP BY SourceDocumentID
)
SELECT 'Posted in another year' AS Item, si.InvoiceNumber AS Document,
    strftime('%Y', sh.DeliveryDate) AS DeliveryYear,
    strftime('%Y', p.PostingDate) AS PostingYear,
    si.SubTotal AS Amount
FROM SalesInvoice AS si
    INNER JOIN Shipped AS sh ON sh.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Posted AS p ON p.SalesInvoiceID = si.SalesInvoiceID
WHERE strftime('%Y', p.PostingDate) <> strftime('%Y', sh.DeliveryDate)
UNION ALL
SELECT 'Never invoiced', s.ShipmentNumber,
    strftime('%Y', s.DeliveryDate), NULL,
    ROUND(sl.QuantityShipped * sol.UnitPrice * (1 - sol.Discount), 2)
FROM ShipmentLine AS sl
    INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    INNER JOIN SalesOrderLine AS sol
        ON sol.SalesOrderLineID = sl.SalesOrderLineID
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.ShipmentLineID = sl.ShipmentLineID
WHERE sil.SalesInvoiceLineID IS NULL;  -- Result: creates the view CutoffItems

-- Requirement 5: the proposed adjustments and their effect on fiscal 2026 net income and the balance sheet
-- Population: the views PayrollAccrual, PriorYearWork and CutoffItems, and Chapter 6's net income; expected: 4,503,611.24 - 17,123.63 + 24,940.25 = 4,511,427.86
WITH Measures AS (
    SELECT
        (SELECT ROUND(SUM(GrossPay + EmployerTaxes + Benefits), 2)
         FROM PayrollAccrual) AS AccrualAtYearEnd,
        (SELECT ROUND(SUM(PeriodCost * DaysInYear / WorkingDays), 2)
         FROM PriorYearWork) AS AccrualYearBefore,
        (SELECT ROUND(SUM(Amount), 2)
         FROM CutoffItems
         WHERE DeliveryYear = '2026') AS RevenueToAdd,
        (SELECT ROUND(SUM(Amount), 2)
         FROM CutoffItems
         WHERE DeliveryYear = '2025' AND PostingYear = '2026')
            AS RevenueToRemove,
        (SELECT ROUND(SUM(gl.Credit - gl.Debit), 2)
         FROM GLEntry AS gl
             INNER JOIN Account AS a ON a.AccountID = gl.AccountID
         WHERE a.AccountType IN ('Revenue', 'Expense')
             AND gl.FiscalYear = 2026
             AND gl.VoucherNumber NOT IN (
                 SELECT EntryNumber
                 FROM JournalEntry
                 WHERE EntryType LIKE 'Year-End Close%')) AS NetIncome
)
SELECT NetIncome,
    ROUND(AccrualYearBefore - AccrualAtYearEnd, 2) AS PayrollEffect,
    ROUND(RevenueToAdd - RevenueToRemove, 2) AS CutoffEffect,
    ROUND(NetIncome + AccrualYearBefore - AccrualAtYearEnd
        + RevenueToAdd - RevenueToRemove, 2) AS AdjustedNetIncome,
    ROUND((AccrualYearBefore - AccrualAtYearEnd + RevenueToAdd
        - RevenueToRemove) / NetIncome, 4) AS ShareOfNetIncome,
    AccrualAtYearEnd AS LiabilityAdded,
    RevenueToAdd AS ReceivablesAdded,
    ROUND(RevenueToRemove - AccrualYearBefore, 2)
        AS OpeningRetainedEarnings
FROM Measures;  -- Result: 1 rows

-- Requirement 5: actual conversion cost per standard hour against the standard, and the finished goods it would revalue
-- Population: PlantLedger and 2026's completions; account 1040 at 2026-12-31; expected: 78.77 against 47.40; finished goods 12,169,701.74
SELECT ROUND((pl.Payroll + pl.JournalEntries)
        / (SELECT SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
           FROM ProductionCompletionLine AS pcl
               INNER JOIN ProductionCompletion AS pc
                   ON pc.ProductionCompletionID = pcl.ProductionCompletionID
               INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
           WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'), 2)
        AS ActualPerStandardHour,
    ROUND(pl.Released
        / (SELECT SUM(pcl.QuantityCompleted * i.StandardLaborHoursPerUnit)
           FROM ProductionCompletionLine AS pcl
               INNER JOIN ProductionCompletion AS pc
                   ON pc.ProductionCompletionID = pcl.ProductionCompletionID
               INNER JOIN Item AS i ON i.ItemID = pcl.ItemID
           WHERE pc.CompletionDate BETWEEN '2026-01-01' AND '2026-12-31'), 2)
        AS StandardPerStandardHour,
    (SELECT ROUND(SUM(gl.Debit - gl.Credit), 2)
     FROM GLEntry AS gl
         INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 1040
         AND gl.PostingDate <= '2026-12-31') AS FinishedGoods
FROM PlantLedger AS pl
WHERE pl.FiscalYear = 2026;  -- Result: 1 row (ActualPerStandardHour = 78.77, StandardPerStandardHour = 47.4, FinishedGoods = 12169701.74)

-- Requirement 5: supplier invoices dated in 2025 and received in 2026, with the accrual that carried them
-- Population: PurchaseInvoice; expected: ASV0050-2025-040073, accrued by JE-2025-000188
SELECT pi.InvoiceNumber, pi.InvoiceDate, pi.ReceivedDate,
    pi.GrandTotal, je.EntryNumber AS AccrualEntry,
    je.PostingDate AS AccruedOn
FROM PurchaseInvoice AS pi
    LEFT JOIN PurchaseInvoiceLine AS pil
        ON pil.PurchaseInvoiceID = pi.PurchaseInvoiceID
        AND pil.AccrualJournalEntryID IS NOT NULL
    LEFT JOIN JournalEntry AS je
        ON je.JournalEntryID = pil.AccrualJournalEntryID
WHERE pi.InvoiceDate BETWEEN '2025-01-01' AND '2025-12-31'
    AND pi.ReceivedDate BETWEEN '2026-01-01' AND '2026-12-31'
ORDER BY pi.InvoiceNumber;  -- Result: 1 rows

/* Model answer (Requirement 2)

   Corroboration matrix. Supports the hours: every hourly employee present on every surge day (64 a day,
   against 62.8 on ordinary days, though 573 of 652 ordinary days also had all 64, so attendance says little);
   badge punches on every entry, with meal punches on every surge entry; more output completed in weeks with
   surge days (Requirement 3). Contradicts or leaves unexplained: about 2 clock-in times a day for the whole
   plant, so 32 or 33 employees share one timestamp (at most 25 on an ordinary day); overtime in no roster
   (every surge entry rostered for 8 hours on 07:00-15:30, 15:00-23:30, clocked 06:30-19:30 or 14:30-03:30);
   approvals that cite operations already finished (every one of the 1,475 surge-day approvals that cite an
   operation); no planned overload (planned load in surge weeks below the other weeks in every year); overtime
   on days with maintenance (6) or reduced capacity (21). Silent: absences, none recorded in Manufacturing in
   any year.

   Independence. The punches and the clock entries are one system (the punches repeat the entry's timestamps);
   the rosters and the overtime approvals come from the same manager, the Production Manager, who creates
   every manufacturing roster and approved every surge-day approval on the work date. Only the calendar, the
   capacity plan, and the output come from outside timekeeping, and none of them supports the hours.

   The control. The Off Shift Clocking rule tests arrival only (120 minutes after the scheduled start); surge
   arrivals are 30 minutes early and the 4-hour late departures count as approved overtime, so no surge entry
   could be flagged (design). All 18 exceptions are Open and none was reviewed in up to three years, among
   them three Paid Without Approved Clock and four that name the wrong employee (operation). The control
   failed in both.

   Two explanations fit the records: the hours were worked, and the time was entered for the plant as a block,
   which breaks the timekeeping control but not the pay; or the hours were not worked as recorded. Evidence
   outside the database would tell them apart: building access or gate logs, statements of supervisors and
   employees, security video, machine-run or utility data, and the timekeeping system's own log of who entered
   the punches. Until then the memo should call the hours unsupported.
*/

/* Model answer (Requirement 3)

   Output was flat while surge overtime quadrupled: standard hours 70,871, 66,109, 66,998 against surge
   overtime of 3,456, 9,216, 14,112 hours, with other overtime about 6,273 hours a year. In 2026 the 12 weeks
   with surge days completed more (2,005 standard hours against 1,087) but not in proportion to their hours
   (0.55 standard hours per hour clocked against 0.70), and the six weeks after them completed less (1,141
   against 1,400), which looks like work pulled forward rather than more work. The weekly comparison cannot
   match a week to its output exactly: completions lag the work by weeks (lead times of about 40 days in 2026)
   and post on weekends, when nobody clocks in.

   Capacity: ordinary days used about 5.3 hours per employee a day, leaving 38,417 straight-time hours unused
   in 2026 against 14,112 hours of surge overtime, so the overtime would have fitted into straight time more
   than twice over. Cost at base rates with the 14.14% burden: the premium alone 214,651.73 if the hours were
   needed, the full cost 643,955.19 if they were not.

   Bridge: 5080 grew 947,709.56 = payroll 966,846.03 + journal entries -8,473.29 + standard released 91,787.08
   + change in 1090 -72,196.35 + material -9,378.15 + direct postings -20,875.76. The payroll line is
   explained by the calendar (two more payrolls, 237,379.26), the hours beyond 2024's 1.18 hours per standard
   hour (22,180 hours, 673,995), and the growth of the surge premium (162,084); together 1,073,459, 106,612
   more than the payroll line, because the measures overlap and use different calendars: the hours follow work
   dates through 11 December, the payroll its pay dates, and the calendar measure 2024's average payroll,
   which includes the start-up month.
*/

/* Model answer (Requirement 4)

   Assumptions (the Params CTE): volume 68,912.79 standard hours, the 2026 output, because the budget plans
   about three times the units the plant completed and the demand forecast two to three times the units
   ordered, and no year has a manufacturing labor or overhead budget; a target of 1.18 hours per standard
   hour, the 2024 level; a straight-time rate of 26.62 an hour (the 2026 base rates weighted by hours) with a
   14.14% burden; 256 working days, from 2026, because the calendar stops early in 2027; Factory Overhead at
   its 2026 run rate, 1,308,869.06; and 2027 depreciation of 293,499.96 from FixedAsset, after the same
   schedule reproduced 2026's 303,666.63 to the cent. Salaried staff (Production Manager, Planner, Supervisor)
   cost 263,191.24 before the burden.

   Capacity: 64 employees x 8 hours x 256 days = 131,072 regular hours, against 68,913 hours needed at
   standard, 81,317 at 1.18, and 104,127 at the 2026 level of 1.511. No scenario needs overtime for capacity,
   so the plan should allow none as a routine.

   Conversion cost and expected variance: 3,996,855 and 730,432 at standard hours; 4,373,789 and 1,107,366 at
   the 2024 level; 5,371,136 and 2,104,714 at the 2026 level with its overtime premium, close to 2026's
   conversion variance of 2,159,138.03. Even at standard hours a variance remains: the labor rate with burden
   is 30.39 an hour against the standard 28.28 (about 145,000), and overhead of 1,902,776 is set against
   1,317,563 applied at 19.12 per standard hour (about 585,000), because the plant makes about 53% of its
   regular capacity. Keep the direct-hour standards, since direct time stays within them; review the rates,
   but do not raise the fixed overhead rate to absorb idle capacity (Requirement 5).
*/

/* Model answer (Requirement 5)

   Payroll accrual at 2026-12-31: the last eight processed periods (2026-08-24 to 2026-12-13) cost
   2,298,268.90 over 78 working days, 29,464.99 a day; 14-31 December has 13 working days, so the accrual is
   383,044.82 (gross 336,456.34, employer taxes 25,738.93, benefits 20,849.55). Entries: debit 1090 for
   Manufacturing (197,970.68) and each other cost center's salary account for its gross pay, and 6060 for the
   employer costs; credit 2030 for gross pay, 2032 for employer taxes, and 2033 for benefits. No completion
   releases standard cost against the manufacturing part, so it ends in 5080 and cost of goods sold.

   The year-end before was not accrued either: 365,921.19 of 2025 work (manufacturing 180,675.14) was charged
   to fiscal 2026. Recording both raises 2026 expense by only 17,123.63, while the liability at 2026-12-31
   rises by 383,044.82 and opening retained earnings fall by 365,921.19: the errors counterbalance in income
   but not on the balance sheet. The 95,000.00 in 2030 is the opening line of JE-2024-000001; no payroll ever
   cleared it, so it is not the year-end accrual: investigate it with the other unsupported opening balances
   of Chapter 8, and reverse it against opening retained earnings if nothing supports it, rather than netting
   it against the new accrual.

   ASC Topic 330: 2026's actual conversion cost was 78.77 per standard hour against the standard 47.40.
   Raising the standards to absorb it would carry idle capacity and unneeded hours into finished goods
   (12,169,701.74 at year-end) and defer them to later years. Idle capacity and hours beyond the work are
   abnormal, and they belong in 2026's cost of goods sold.

   Cutoff (L5, L6): fiscal 2026 revenue includes 19,540.86 of December 2025 deliveries and excludes 9 December
   2026 shipment lines never invoiced, 44,481.11 at order price, whose standard cost (22,895.78) is already in
   cost of goods sold: 24,940.25 more 2026 revenue. Adjusted net income 4,503,611.24 - 17,123.63 + 24,940.25 =
   4,511,427.86 (the ledger records no income tax), 0.17% of net income and immaterial; but the unrecorded
   liability of about 383,000 recurs every year, and the absence of any year-end payroll accrual is a
   deficiency in the close. ASV0050-2025-040073 is not a payables cutoff item: its accrual JE-2025-000188
   carried the liability at the year-end.
*/

/* Model answer (Requirement 6)

   Decision memo, in the order of the controller's questions. Auditing: the records outside the time clock do
   not support the surge-day hours as recorded, and the records that agree with them come from the same system
   (the punches) or the same manager (the rosters and the overtime approvals); the question goes to evidence
   outside the database, and the hours should be called unsupported, not fictitious. Managerial accounting:
   output was flat while surge overtime quadrupled; 2026 surge overtime cost 214,651.73 as a premium or
   643,955.19 in full; 5080 grew 947,709.56, almost all of it payroll charged to 1090. The 2027 plan at 1.18
   hours per standard hour needs 81,317 hours against 131,072 of regular capacity and expects a variance of
   about 1,107,366. Financial reporting: record the payroll accrual of 383,044.82 and the revenue cutoff
   (24,940.25), for adjusted net income of 4,511,427.86; keep the cost of the hours out of inventory.

   Recommendation: stop routine surge days and require overtime to be approved in advance against a plan, by
   someone outside production; review the open attendance exceptions and add a rule that compares overtime
   with the roster; have internal audit corroborate a sample of surge days with access logs and interviews;
   adopt a 2027 plan at about the 2024 level of hours per standard hour, with no routine overtime, since
   capacity allows it; keep the direct-hour standards and review the overhead rates on normal capacity; and
   record the year-end payroll accrual now and at every year-end.
*/

/* Notes

   Requirement 1: Build the case script and its populations (Chapters 9 and 10)
   Start Case.sql with its header, and give every query the two-line comment of the audit query library.
   Profile TimeClockPunch, EmployeeShiftRoster, AttendanceException, and WorkCenterCalendar with the tests of
      @tbl-10-03: the rows and dates each covers, the values of its code columns, the columns that are not
      always filled in, and any key that appears more than once.
   Test the links that the later requirements rely on: every punch to its clock entry, every clock entry to
      its roster, and every attendance exception to its clock entry, comparing the employee and the date on
      each side. Give each exception a disposition, but do not pursue the isolated ones further.
   Save the surge days as a view named SurgeDays, with the definition of the SurgeDays CTE in test H9 of
      Tutorial 12.3, and reconcile it to the surge days and clock entries that Tutorial 12.3 found. Then save
      a second view with one row for each hourly manufacturing clock entry and a DayType column of Surge or
      Ordinary, for the requirements that follow.
   Instructor note: TimeClockPunch holds 165,137 punches of 76 employees, 2024-01-01 to 2026-12-11, all with
      PunchSource Badge: Clock In 52,967, Clock Out 52,964 (the three missing belong to employee 85's January
      1 entries), Meal Start and Meal End 29,603 each; no punch lacks its clock entry, and no clock entry has
      two punches of one type. EmployeeShiftRoster has 53,002 rows (Scheduled 44,728, Reassigned 8,236, Absent
      38), no employee rostered twice on one date, created by the department managers 4 (Production Manager),
      5, 7, and 11. AttendanceException has 18 rows, three each of Duplicate Clock Day, Labor After Close,
      Missing Clock Out, Missing Final Punch, Off Shift Clocking, and Paid Without Approved Clock, all Open
      and never reviewed (ReviewedByEmployeeID is NULL on every row). WorkCenterCalendar has 5,900 rows, five
      work centers, 2024-01-01 to 2027-03-25; in 2026, 256 working days, with maintenance at some work center
      on 19 dates and reduced capacity on 53, and 128,833.25 available hours. Links: 18 punches carry a
      different date from their clock entry, the punches of the six clock entries behind the Duplicate Clock
      Day and Labor After Close exceptions (142, 289, 17855, 17926, 36082, 36149), whose roster dates also
      differ; 3 clock-in punches (1, 52951, 109493, employee 85 on each January 1) are detached from their
      roster; every clock entry has a roster of the same employee; exceptions 2, 3, 8, and 9 name employee 86,
      although their clock entries (17846 and 36072) belong to employee 85, so the exception report itself
      misattributes. SurgeDays: 12, 32, and 49 days, with 768, 2,048, and 3,136 hourly manufacturing entries
      (5,952), as in Tutorial 12.3. The isolated exceptions are the generator's planted anomalies; they need a
      disposition, not the memo's attention.

   Requirement 2: Test whether other records support the surge days (Chapters 10 to 12; auditing)
   Compare surge days with ordinary days for the hourly manufacturing employees, with conditional aggregation
      and a window function: the employees who clocked in each day, the number of different clock-in times,
      the largest group of employees sharing one clock-in time, the share of entries with meal punches, and
      the rostered hours against the hours clocked.
   Reperform the attendance-exception control. Measure each entry's minutes of clock time before and after its
      roster, find the rule behind the Off Shift Clocking exceptions that the system raised, and apply it to
      the surge-day entries. Decide whether the control failed in its design, in its operation, or both.
   Test the reasons behind the overtime against the plant's own plans: the calendar status of each surge day,
      the planned load of the weeks with surge days against other weeks in RoughCutCapacityPlan, and whether
      the operation that each surge-day overtime approval cites was still open on the work date. This tests
      the authorization of the overtime, where test H9 tested the labor time recorded against operations.
   Summarize your tests in a corroboration matrix: for each, whether it supports the hours, contradicts them,
      or says nothing, and whether its record is independent of the Production Manager and of the timekeeping
      system. Name two explanations that fit the records, and the evidence outside the database that would
      tell them apart.
   Instructor note: 93 surge days against 652 ordinary days, hourly manufacturing employees only. Employees
      per day 64.0 against 62.8, and 573 of the 652 ordinary days also had all 64, so attendance says little.
      Different clock-in times per day 2.0 against 22.4; the largest group sharing one clock-in timestamp is
      32 or 33 on every surge day (COUNT(*) OVER (PARTITION BY WorkDate, ClockInTime)), against 13.2 on
      average and 25 at most on ordinary days. Every surge entry (5,952) has meal punches, against 17,707 of
      the 40,974 ordinary entries (43.2%). The punches are all Badge punches whose timestamps equal the clock
      entry's (except on nine entries, all cited by attendance exceptions), so they repeat the timekeeping
      record rather than corroborate it. Rosters: every surge entry is rostered for a normal eight-hour shift,
      07:00-15:30 or 15:00-23:30, created seven days ahead by the Production Manager, who creates every
      manufacturing roster; the clock shows 06:30-19:30 or 14:30-03:30, 30 minutes early and 240 minutes late,
      12.5 hours against 8.0. On ordinary days the rostered hours equal the clocked hours on 30,251 of 40,974
      entries (73.8%), on surge days on none. The control: the three Off Shift Clocking exceptions are clock-
      ins 120 minutes after the scheduled start (10:00 against 08:00), so the rule tests arrival; surge
      arrivals are 30 minutes early and the four-hour late departures count as approved overtime, so no surge
      entry could be flagged, and the anti-join finds none flagged (2,591 ordinary entries also end more than
      120 minutes after their roster). Design: nothing compares overtime with a roster or a plan made in
      advance. Operation: all 18 exceptions are Open and none was reviewed in up to three years, among them
      the three Paid Without Approved Clock exceptions (the Pending entries of test H1) and four that name the
      wrong employee. Calendar: every surge day is a working day, but on 6 of them a work center was under
      maintenance and on 21 at reduced capacity. Rough-cut plan (Monday weeks, available hours taken once per
      work center and week, through 2026-12-07): planned load against available hours was 0.568, 0.596, and
      0.585 in weeks with surge days against 0.687, 0.618, and 0.614 in other weeks (2024-2026), so the surge
      weeks were not planned overloads; the four reason codes are used 1,488 times each on surge days.
      Approvals: 1,475 of the 5,952 surge-day approvals cite a work order operation, and every one of those
      operations had ended before the work date; on ordinary days 497 of the 2,397 cited operations had ended.
      Surge days fall mostly late in the week (Monday 4, Tuesday 13, Wednesday 19, Thursday 26, Friday 31).
      Matrix: supports: every employee present, badge punches, more output in surge weeks (Requirement 3);
      contradicts or unexplained: one clock-in time for half the plant at once, overtime in no roster,
      approvals citing finished work, no planned overload, overtime on maintenance and reduced-capacity days;
      silent: absences (none recorded in Manufacturing in any year). Independence: punches and clock entries
      are one system, rosters and overtime approvals come from the same manager, and only the calendar, the
      capacity plan, and the output come from outside timekeeping. Two explanations: the hours were worked and
      the time was entered for the plant as a block, which breaks the timekeeping control but not the pay; or
      the hours were not worked as recorded. Evidence outside the database: building access or gate logs,
      statements of supervisors and employees, security video, machine-run or utility data, and the
      timekeeping system's own log of who entered the punches.

   Requirement 3: What the hours produced and what they cost (Chapters 10 and 11; managerial accounting)
   Compare output with hours, first by year and then by week. For each Monday week through the week of 7
      December 2026, total the hours clocked and the standard hours of the units completed, and group the
      weeks by their number of surge days. Add the average output of the six weeks that follow each week, with
      a window frame. State what the weekly comparison can and cannot show, given how completions are dated.
   Measure how much of the plant's regular capacity the ordinary days used: the hours each employee clocked
      per day, and the straight-time hours left unused, against the overtime worked on surge days.
   Put a cost on the surge-day overtime in two ways, each with the employer's payroll taxes and benefits: the
      premium alone, if the hours were needed but could have been worked at straight time, and the full cost
      of the overtime, if they were not needed. Use the base rates in the Employee table, as test H5 did.
   Bridge the growth of account 5080 from fiscal 2024 to fiscal 2026 on the ledger. First split it into the
      ledger lines that make it up: the payroll charged to account 1090, the journal entries charged to it,
      the standard cost that completions released, the change in the balance of 1090, the material variance,
      and the postings made directly to 5080. Then explain the payroll line with three measures: the calendar,
      the straight-time cost of the hours beyond the 2024 hours per standard hour, and the growth of the surge
      premium. Explain why the three measures do not add up exactly to the payroll line.
   Instructor note: by year (work dates, output to 2026-12-11): hours 83,628, 93,391, 101,237 against standard
      hours 70,871, 66,109, 66,998 (1.180, 1.413, 1.511 hours per standard hour); surge-day overtime 3,456,
      9,216, 14,112 hours, other overtime 6,273, 6,426, 5,918. Output was flat while surge overtime
      quadrupled. Weekly (Monday weeks, date(WorkDate, '-6 days', 'weekday 1')), 2026: 37 weeks without surge
      days averaged 1,555 clocked hours and 1,087 standard hours completed (0.70), and the 12 weeks with surge
      days 3,622 and 2,005 (0.55), in detail 3 surge days 2 weeks (3,130 and 1,762), 4 surge days 7 weeks
      (3,601 and 1,482), 5 surge days 3 weeks (4,000 and 3,385); the six weeks after a week with surge days
      averaged 1,141 standard hours, against 1,400 after other weeks. June 2024 onward: 102 weeks without
      surge days, 1,500 and 1,108 (0.74). Surge weeks complete more but not in proportion to the hours, and
      the weeks after them complete less, which looks like work pulled forward rather than more work;
      completions lag the work by weeks (lead times of about 40 days in 2026) and post on weekends, so a week
      cannot be matched exactly to its output. Capacity on ordinary days: 4.92, 4.79, and 5.26 clocked hours
      per employee per day; unused straight-time hours (8 less regular hours, on entries with fewer than 8)
      52,606, 51,956, and 38,417, against surge overtime of 3,456, 9,216, and 14,112, so the 2026 surge
      overtime would have fit more than twice over into straight time. Cost at base rates: premium 46,055.52,
      122,814.72, 188,060.04 (214,651.73 with the 14.14% burden in 2026); full overtime 138,166.56,
      368,444.16, 564,180.12 (643,955.19 with burden in 2026). Bridge (ledger, closes excluded): 5080 rose
      from 1,317,927.32 to 2,265,636.88, +947,709.56 = payroll to 1090 +966,846.03 (2,848,551.11 to
      3,815,397.14) + journal entries -8,473.29 (1,621,008.98 to 1,612,535.69) + standard cost released
      +91,787.08 (3,358,209.62 to 3,266,422.54, released less) + change in 1090 -72,196.35 (the account fell
      by 69,824.09 in 2024 and rose by 2,372.26 in 2026) + material variance -9,378.15 (115,877.00 to
      106,498.85) + direct postings -20,875.76 (2024's January payroll, 11,520.94, and JE-2024-000005,
      9,354.82). The payroll line: calendar, two payrolls at 2024's average to 1090, 237,379.26; hours beyond
      2024's 1.18 hours per standard hour, 22,180 hours at the 2026 straight-time rate of 26.62 with burden,
      673,995; growth of the surge premium with burden, 162,084; together 1,073,459, which exceeds the payroll
      line by 106,612 because the measures overlap and use different calendars: the hours follow work dates
      through 11 December, the payroll pay dates, and the calendar measure 2024's average payroll, which
      includes the start-up month.

   Requirement 4: Plan the 2027 hours and conversion cost (Chapter 11, with the planning of Chapter 7;
      managerial accounting)
   Put the plan's assumptions in a one-row Params CTE, and record the value, source, and effect of each in the
      script's comments, as Chapter 7 documented a model:
   the volume, from the 2026 output, and why not from the budget or the demand forecast;
   a target of hours per standard hour;
   the straight-time rate and the burden;
   the working days, taken from 2026, because the calendar stops in March 2027;
   the run rate of the Factory Overhead journal entries;
   the 2027 depreciation of the manufacturing equipment in FixedAsset, after you reproduce from FixedAsset the
      depreciation that fiscal 2026 charged to account 1090.
   Compare the hours the plan needs with the plant's regular capacity, and decide how much routine overtime
      the plan should allow.
   Build the plan's conversion cost from hourly labor, the salaried manufacturing staff, factory overhead, and
      depreciation, and compare it with the standard conversion cost of the planned output. Put three ratios
      in a Scenarios CTE built with UNION ALL: standard hours, the 2024 level, and the 2026 level with its
      overtime. Show the expected variance of each.
   Explain the variance that remains even at standard hours, and decide whether the standards should change:
      the direct-hour standards and the overhead rates.
   Instructor note: volume: 2026 completions of 68,912.79 standard hours, whose standard conversion cost,
      3,266,422.54, is what completions released to 1090 (47.40 per standard hour); the budget plans about
      three times the units the plant completed and the demand forecast two to three times (Chapter 7), and no
      year has a manufacturing labor or overhead budget, only cost of goods sold at standard. Rate: 26.62 an
      hour (2026, hours-weighted base rate), burden 14.14%; salaried manufacturing staff 263,191.24 gross
      (Production Manager, Planner, Supervisor). Factory Overhead entries 1,308,869.06 in 2026. Depreciation:
      monthly OriginalCost / UsefulLifeMonths from the month after the in-service date, through the month
      before disposal, for assets whose DepreciationDebitAccountID is 92 (account 1090): 24,625.00 in January
      2026, 26,958.33 from February (MFG-0007, in service 2026-01-14), 24,458.33 from June (MFG-0004 disposed
      2026-06-05), 303,666.63 for the year, equal to the ledger; 2027: 24,458.33 a month, 293,499.96, and
      MFG-0005 reaches the end of its life in December 2027. MFG-0006 and MFG-0007 are the purchases behind
      PO-2024-001942 and PO-2026-011104, approved above authority in Tutorial 12.2. Capacity: 64 employees x 8
      hours x 256 working days = 131,072 regular hours (the calendar's available hours were 128,833.25 in
      2026); the plan needs 68,913 hours at 1.0, 81,317 at 1.18, and 104,127 at the 2026 level of 1.511, so no
      scenario needs overtime for capacity, and the plan should allow none as a routine. Conversion cost and
      expected variance: at 1.0, 3,996,855 and 730,432; at 1.18, 4,373,789 and 1,107,366; at the 2026 level
      with its overtime premium (266,521.04, 304,207.11 with burden), 5,371,136 and 2,104,714, close to the
      2,159,138.03 conversion variance of 2026. The variance left at standard hours comes from the labor rate
      with burden above the standard rate (30.39 against 28.28 an hour, about 145,000), and from overhead of
      1,902,776 (salaried staff, factory overhead, depreciation) against 1,317,563 applied at 19.12 per
      standard hour (about 585,000): the plant makes about 53% of its regular capacity, so the fixed overhead
      is spread over far fewer hours than the rates assume. Standards: keep the direct-hour standards, since
      direct time stays within them; review the rates, but do not raise the fixed overhead rate to absorb idle
      capacity (Requirement 5).

   Requirement 5: Close the fiscal 2026 statements (Chapters 11 and 12; financial reporting)
   Estimate the payroll cost of the work of 14 to 31 December 2026 by cost center. Take the cost per working
      day of the last eight processed pay periods, counting working days in WorkCenterCalendar, and multiply
      it by the working days left in the year. Write the adjusting entries, with the accounts that the payroll
      postings of each cost center use, and explain where the manufacturing part ends up.
   The year-end before was not accrued either. With the same working-day method, measure the 2025 work paid in
      fiscal 2026 from the registers of the pay periods that cross the year-end. Show the effect of recording
      both accruals on fiscal 2026 income and on the liability at 31 December 2026, and explain why they
      differ. Decide what to do about the balance that account 2030 has carried since the opening entry.
   Explain where the cost of the hours beyond the work belongs. The inventory standard of U.S. GAAP (FASB
      Accounting Standards Codification Topic 330) allocates fixed production overhead to inventory on the
      normal capacity of the production facilities, and charges abnormal amounts, such as idle facility
      expense, to the period in which they are incurred. Consider what raising the standards to absorb 2026's
      actual conversion cost would do to the finished goods inventory.
   Rerun tests L5 and L6 of Audit.sql for the revenue cutoff. Summarize the proposed adjustments and their
      effect on fiscal 2026 net income, starting from the net income of Chapter 6's income statement, and on
      the balance sheet, and judge whether they are material.
   Instructor note: the last eight processed periods (70-77, 2026-08-24 to 2026-12-13) cost 2,298,268.90 over
      78 working days, 29,464.99 a day; 14-31 December 2026 has 13 working days (25 December is a holiday), so
      the accrual is 383,044.82: gross pay 336,456.34, employer payroll taxes 25,738.93, benefits 20,849.55.
      By cost center: Manufacturing 197,970.68 (gross 173,440.12), Executive 42,080.32, Design Services
      27,818.05, Sales 23,206.37, Administration 19,301.65, Purchasing 18,982.21, Warehouse 17,730.79,
      Marketing 14,333.19, Customer Service 11,338.71, Research and Development 10,282.84. Entries: debit 1090
      for Manufacturing and the salary accounts of the other cost centers (6010-6050, 6230, 6240, 6250, 6280)
      for gross pay and 6060 Payroll Taxes and Benefits for the employer costs; credit 2030 Accrued Payroll
      for gross pay, 2032 for employer taxes, and 2033 for benefits. No completion releases standard cost
      against the manufacturing part, so it ends in 5080 and cost of goods sold. The 2025 year-end: period 52
      (2025-12-15 to 12-28, paid 2026-01-02) is all 2025 work, 263,426.72, and 3 of the 9 working days of
      period 53 (2025-12-29 to 2026-01-11) fall in 2025, 307,483.41 x 3/9 = 102,494.47, so 365,921.19 of 2025
      work (manufacturing 180,675.14) was charged to fiscal 2026. Recording both: fiscal 2026 expense rises by
      only 17,123.63 (383,044.82 less 365,921.19), while the liability at 2026-12-31 rises by 383,044.82 and
      opening retained earnings fall by 365,921.19; the errors counterbalance in income but not on the balance
      sheet. (Allocating by the hours actually worked, as Exercise 12.1 does for hourly labor, gives about
      335,000 for 2025.) The 95,000 in 2030 is the opening line of JE-2024-000001; no payroll in the data ever
      cleared it, so it is not the year-end accrual: investigate it with the other unsupported opening
      balances of Chapter 8, and reverse it against opening retained earnings if nothing supports it, rather
      than netting it against the new accrual. ASC 330: 2026's actual conversion cost was 78.77 per standard
      hour against the standard 47.40; raising the standards to absorb it would carry idle capacity and
      unneeded hours into finished goods (1040, 12,169,701.74 at year-end) and defer them to later years.
      Standards that approximate actual cost are acceptable, and an ordinary variance from out-of-date
      standards could be spread between inventory and cost of sales, so the argument rests on the causes this
      Part found: idle capacity and hours beyond the work are abnormal, and they belong in 2026's cost of
      goods sold. Cutoff (L5, L6): fiscal 2026 revenue includes 19,540.86 of December 2025 deliveries and
      excludes 9 December 2026 shipment lines never invoiced, 44,481.11 at order price, whose standard cost
      (22,895.78) is already in cost of goods sold; the net effect on 2026 revenue is +24,940.25, with
      receivables +44,481.11 and opening retained earnings +19,540.86. Adjusted 2026 net income: 4,503,611.24
      - 17,123.63 + 24,940.25 = 4,511,427.86 (the ledger records no income tax). Materiality: the effect on
      income is under 0.2% and immaterial, but the unrecorded liability of about 383,000 recurs every year,
      and the absence of any year-end payroll accrual is a deficiency in the close; the supplier invoice
      ASV0050-2025-040073 (3,266.27, received 2026-01-01) is not a payables cutoff item: its October 2025
      accrual, JE-2025-000188, carried the liability at the year-end.

   Requirement 6: Write the decision memo
   Write a memorandum of no more than two pages to the controller, organized in the order of her questions:
   Auditing: what the records outside the time clock show about the surge-day hours, how independent they are,
      which explanations remain open and what evidence would settle them, and what the attendance-exception
      control needs.
   Managerial accounting: what the extra hours produced and what they cost, the bridge of the variance, and
      the 2027 plan with its assumptions and the overtime it allows.
   Financial reporting: the proposed adjustments to the fiscal 2026 statements, their effect, and why the cost
      of the hours stays out of inventory.
   Close the memo with your recommendation.
   Instructor note: a strong memo does not conclude that the hours were fictitious. The records outside
      timekeeping do not support the surge-day hours as recorded, and the ones that agree with them come from
      the same system or the same manager; the question goes to the evidence outside the database. The
      recommendation: stop routine surge days and require overtime to be approved in advance against a plan,
      by someone outside production; review the open attendance exceptions and add a rule that compares
      overtime with the roster; have internal audit corroborate a sample of surge days with access logs and
      interviews; adopt a 2027 plan at about the 2024 level of hours per standard hour, with no routine
      overtime, since capacity allows it; keep the direct-hour standards and review the overhead rates on
      normal capacity; and record the year-end payroll accrual now and at every year-end.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   Requirement 1: punches: 165137
   Requirement 1: employees: 76
   Requirement 1: clock entries with punches: every clock entry: 52967
   Requirement 1: first date: 2024-01-01
   Requirement 1: last date: 2026-12-11
   Requirement 1: punches without a roster (the detached clock-ins): 3
   Requirement 1: punch types: ['Clock In', 'Clock Out', 'Meal End', 'Meal Start']
   Requirement 1: sources: ['Badge']
   Requirement 1: Clock In punches: 52967
   Requirement 1: Clock Out punches: 52964
   Requirement 1: Meal End punches: 29603
   Requirement 1: Meal Start punches: 29603
   Requirement 1: entries with two punches of one type: 0
   Requirement 1: punches without their clock entry: 0
   Requirement 1: entries without a clock-out: 3
   Requirement 1: their employee: [85]
   Requirement 1: their dates: ['2024-01-01', '2025-01-01', '2026-01-01']
   Requirement 1: rosters: 53002
   Requirement 1: employees rostered twice on one date: 0
   Requirement 1: statuses and counts: [['Scheduled', 44728], ['Reassigned', 8236], ['Absent', 38]]
   Requirement 1: creators and their titles: [[4, 'Production Manager'], [5, 'Accounting Manager'], [7,
      'Warehouse Manager'], [11, 'Customer Service Manager']]
   Requirement 1: exception types: ['Duplicate Clock Day', 'Labor After Close', 'Missing Clock Out', 'Missing
      Final Punch', 'Off Shift Clocking', 'Paid Without Approved Clock']
   Requirement 1: exceptions of each type: [3, 3, 3, 3, 3, 3]
   Requirement 1: statuses: ['Open']
   Requirement 1: exceptions reviewed: 0
   Requirement 1: rows: 5900
   Requirement 1: work centers: 5
   Requirement 1: first date: 2024-01-01
   Requirement 1: last date: 2027-03-25
   Requirement 1: no work center and date twice: 5900
   Requirement 1: maintenance dates: 19
   Requirement 1: reduced-capacity dates: 53
   Requirement 1: available hours: 128,833.25
   Requirement 1: working days: 256
   Requirement 1: available hours: 128,833.25
   Requirement 1: the clock entries: [142, 289, 17855, 17926, 36082, 36149]
   Requirement 1: punches dated differently: 18
   Requirement 1: punches of another employee: 0
   Requirement 1: the entries rostered on another date: [142, 289, 17855, 17926, 36082, 36149]
   Requirement 1: entries without a roster of the same employee: 0
   Requirement 1: the punches: [1, 52951, 109493]
   Requirement 1: their employee: [85]
   Requirement 1: all clock-in punches: ['Clock In']
   Requirement 1: their dates: ['2024-01-01', '2025-01-01', '2026-01-01']
   Requirement 1: exceptions: 18
   Requirement 1: exceptions without their clock entry: 0
   Requirement 1: exceptions naming another employee: [2, 3, 8, 9]
   Requirement 1: the employee they name: [86]
   Requirement 1: the owner of their clock entries: [85]
   Requirement 1: their clock entries: [17846, 36072]
   Requirement 1: work years: ['2024', '2025', '2026']
   Requirement 1: surge days by year: [12, 32, 49]
   Requirement 1: surge entries by year: [768, 2048, 3136]
   Requirement 1: ordinary days by year: [235, 223, 194]
   Requirement 1: ordinary entries by year: [15033, 14145, 11796]
   Requirement 1: surge entries in all: 5952
   Requirement 2: Surge days: 93
   Requirement 2: Surge employees per day: 64.00
   Requirement 2: Surge days with every hourly employee present: 93
   Requirement 2: Surge different clock-in times per day: 2.00
   Requirement 2: Surge largest group sharing one clock-in time, average: 32.60
   Requirement 2: Surge largest group, at most: 33
   Requirement 2: Ordinary days: 652
   Requirement 2: Ordinary employees per day: 62.80
   Requirement 2: Ordinary days with every hourly employee present: 573
   Requirement 2: Ordinary different clock-in times per day: 22.40
   Requirement 2: Ordinary largest group sharing one clock-in time, average: 13.20
   Requirement 2: Ordinary largest group, at most: 25
   Requirement 2: Surge largest group, at least: 32
   Requirement 2: hourly employees present on every surge day: 64
   Requirement 2: Surge entries: 5952
   Requirement 2: Surge entries with meal punches: 5952
   Requirement 2: Ordinary entries: 40974
   Requirement 2: Ordinary entries with meal punches: 17707
   Requirement 2: ordinary share: 0.43
   Requirement 2: entries whose punches differ: 9
   Requirement 2: of them cited by exceptions: 9
   Requirement 2: the rostered shifts: ['07:00-15:30', '15:00-23:30']
   Requirement 2: rostered hours: [8.0]
   Requirement 2: created by: ['Production Manager']
   Requirement 2: days ahead: [7.0]
   Requirement 2: surge entries: 5952
   Requirement 2: creators: ['Production Manager']
   Requirement 2: clock patterns: ['06:30-19:30', '14:30-03:30']
   Requirement 2: clocked hours: [12.5]
   Requirement 2: minutes early: [30.0]
   Requirement 2: minutes late: [240.0]
   Requirement 2: Surge entries: 5952
   Requirement 2: Surge entries rostered for the hours clocked: 0
   Requirement 2: Ordinary entries: 40974
   Requirement 2: Ordinary entries rostered for the hours clocked: 30251
   Requirement 2: exceptions: 3
   Requirement 2: minutes after the scheduled start: [120.0]
   Requirement 2: as the exceptions record them: [120]
   Requirement 2: clock-in times: ['10:00']
   Requirement 2: scheduled starts: ['08:00']
   Requirement 2: surge entries arriving late by the rule: 0
   Requirement 2: surge entries leaving late by the rule (all of them): 5952
   Requirement 2: surge entries flagged: 0
   Requirement 2: ordinary entries leaving more than the rule's minutes late: 2591
   Requirement 2: open exceptions: 18
   Requirement 2: reviewed: 0
   Requirement 2: oldest exception: 2024-01-01
   Requirement 2: Paid Without Approved Clock on Pending entries: 3
   Requirement 2: exceptions naming another employee: 4
   Requirement 2: working days only: [1]
   Requirement 2: surge days with maintenance: 6
   Requirement 2: surge days with reduced capacity: 21
   Requirement 2: 2024 surge weeks: 0.57
   Requirement 2: 2024 other weeks: 0.69
   Requirement 2: 2025 surge weeks: 0.60
   Requirement 2: 2025 other weeks: 0.62
   Requirement 2: 2026 surge weeks: 0.58
   Requirement 2: 2026 other weeks: 0.61
   Requirement 2: reason codes, one approver each: 4
   Requirement 2: approvals per reason code: [1488]
   Requirement 2: approved by: ['Production Manager']
   Requirement 2: Surge approvals: 5952
   Requirement 2: Surge cited: 1475
   Requirement 2: Surge ended: 1475
   Requirement 2: Ordinary approvals: 10723
   Requirement 2: Ordinary cited: 2397
   Requirement 2: Ordinary ended: 497
   Requirement 2: surge days by weekday: [['Monday', 4], ['Tuesday', 13], ['Wednesday', 19], ['Thursday', 26],
      ['Friday', 31]]
   Requirement 2: cost centers with absences: ['Administration', 'Customer Service', 'Warehouse']
   Requirement 2: absences in Manufacturing: False
   Requirement 3: 2024 hours clocked: 83,627.69
   Requirement 3: 2024 standard hours: 70,871.42
   Requirement 3: 2024 hours per standard hour: 1.18
   Requirement 3: 2024 surge overtime: 3,456.00
   Requirement 3: 2024 other overtime: 6,273.00
   Requirement 3: 2025 hours clocked: 93,390.69
   Requirement 3: 2025 standard hours: 66,109.40
   Requirement 3: 2025 hours per standard hour: 1.41
   Requirement 3: 2025 surge overtime: 9,216.00
   Requirement 3: 2025 other overtime: 6,425.72
   Requirement 3: 2026 hours clocked: 101,237.00
   Requirement 3: 2026 standard hours: 66,997.83
   Requirement 3: 2026 hours per standard hour: 1.51
   Requirement 3: 2026 surge overtime: 14,112.00
   Requirement 3: 2026 other overtime: 5,917.77
   Requirement 3: Decembers: ['2024-12', '2025-12', '2026-12']
   Requirement 3: 2024 TTMTotal against the time clock, to two decimals: 1.18
   Requirement 3: 2025 TTMTotal against the time clock, to two decimals: 1.41
   Requirement 3: 2026 TTMTotal against the time clock, to two decimals: 1.51
   Requirement 3: surge days per week: [0, 3, 4, 5]
   Requirement 3: 0 surge days: weeks: 37
   Requirement 3: 0 surge days: hours: 1,555.38
   Requirement 3: 0 surge days: standard hours: 1,086.55
   Requirement 3: 0 surge days: next six weeks: 1,400.27
   Requirement 3: 3 surge days: weeks: 2
   Requirement 3: 3 surge days: hours: 3,130.12
   Requirement 3: 3 surge days: standard hours: 1,762.03
   Requirement 3: 3 surge days: next six weeks: 1,127.53
   Requirement 3: 4 surge days: weeks: 7
   Requirement 3: 4 surge days: hours: 3,600.59
   Requirement 3: 4 surge days: standard hours: 1,482.42
   Requirement 3: 4 surge days: next six weeks: 1,153.57
   Requirement 3: 5 surge days: weeks: 3
   Requirement 3: 5 surge days: hours: 4,000.00
   Requirement 3: 5 surge days: standard hours: 3,384.90
   Requirement 3: 5 surge days: next six weeks: 1,126.23
   Requirement 3: surge weeks: weeks: 12
   Requirement 3: surge weeks: hours: 3,622.03
   Requirement 3: surge weeks: standard hours: 2,004.64
   Requirement 3: surge weeks: standard per clocked hour: 0.55
   Requirement 3: surge weeks: next six weeks: 1,141.38
   Requirement 3: other weeks: weeks: 37
   Requirement 3: other weeks: hours: 1,555.38
   Requirement 3: other weeks: standard hours: 1,086.55
   Requirement 3: other weeks: standard per clocked hour: 0.70
   Requirement 3: other weeks: next six weeks: 1,400.27
   Requirement 3: weeks without surge days since the first: weeks: 102
   Requirement 3: weeks without surge days since the first: hours: 1,499.92
   Requirement 3: weeks without surge days since the first: standard hours: 1,107.96
   Requirement 3: weeks without surge days since the first: standard per clocked hour: 0.74
   Requirement 3: weeks without surge days since the first: next six weeks: 1,321.81
   Requirement 3: lead time in days: 40.30
   Requirement 3: completions on weekends: 1674
   Requirement 3: 2024 hours per ordinary entry: 4.92
   Requirement 3: 2024 unused straight time: 52,605.57
   Requirement 3: 2024 surge overtime: 3,456.00
   Requirement 3: 2025 hours per ordinary entry: 4.79
   Requirement 3: 2025 unused straight time: 51,956.38
   Requirement 3: 2025 surge overtime: 9,216.00
   Requirement 3: 2026 hours per ordinary entry: 5.26
   Requirement 3: 2026 unused straight time: 38,417.38
   Requirement 3: 2026 surge overtime: 14,112.00
   Requirement 3: 2024 premium: 46,055.52
   Requirement 3: 2024 full cost: 138,166.56
   Requirement 3: 2025 premium: 122,814.72
   Requirement 3: 2025 full cost: 368,444.16
   Requirement 3: 2026 premium: 188,060.04
   Requirement 3: 2026 full cost: 564,180.12
   Requirement 3: 2026 burden: 0.14
   Requirement 3: 2026 premium with burden: 214,651.73
   Requirement 3: 2026 full cost with burden: 643,955.19
   Requirement 3: 2024 Payroll: 2,848,551.11
   Requirement 3: 2024 JournalEntries: 1,621,008.98
   Requirement 3: 2024 StandardReleased: 3,358,209.62
   Requirement 3: 2024 ChangeIn1090: -69,824.09
   Requirement 3: 2024 MaterialVariance: 115,877.00
   Requirement 3: 2024 DirectTo5080: 20,875.76
   Requirement 3: 2024 Variance5080: 1,317,927.32
   Requirement 3: 2025 Payroll: 3,349,880.59
   Requirement 3: 2025 JournalEntries: 1,563,751.50
   Requirement 3: 2025 StandardReleased: 3,133,789.00
   Requirement 3: 2025 ChangeIn1090: 20,721.28
   Requirement 3: 2025 MaterialVariance: 102,828.27
   Requirement 3: 2025 DirectTo5080: 0
   Requirement 3: 2025 Variance5080: 1,861,950.08
   Requirement 3: 2026 Payroll: 3,815,397.14
   Requirement 3: 2026 JournalEntries: 1,612,535.69
   Requirement 3: 2026 StandardReleased: 3,266,422.54
   Requirement 3: 2026 ChangeIn1090: 2,372.26
   Requirement 3: 2026 MaterialVariance: 106,498.85
   Requirement 3: 2026 DirectTo5080: 0
   Requirement 3: 2026 Variance5080: 2,265,636.88
   Requirement 3: 2026 conversion variance, as WorkOrderClose records it: 2,159,138.03
   Requirement 3: unexplained, every year: [0.0, 0.0, 0.0]
   Requirement 3: growth of 5080: 947,709.56
   Requirement 3: payroll charged to 1090: 966,846.03
   Requirement 3: journal entries charged to 1090: -8,473.29
   Requirement 3: standard cost released: 91,787.08
   Requirement 3: change in 1090: -72,196.35
   Requirement 3: material variance: -9,378.15
   Requirement 3: direct postings: -20,875.76
   Requirement 3: the lines add up to the growth: 0.00
   Requirement 3: payroll posted to 5080: 11,520.94
   Requirement 3: journal entry posted to 5080: ['JE-2024-000005', 9354.82]
   Requirement 3: total: 20,875.76
   Requirement 3: payroll line: 966,846.03
   Requirement 3: calendar: 237,379.26
   Requirement 3: hours beyond the 2024 level: 22,180.11
   Requirement 3: their cost: 673,995.30
   Requirement 3: growth of the surge premium: 162,083.96
   Requirement 3: together: 1,073,458.52
   Requirement 3: excess over the payroll line: 106,612.49
   Requirement 4: assets: ['MFG-0001', 'MFG-0002', 'MFG-0003', 'MFG-0004', 'MFG-0005', 'MFG-0006', 'MFG-0007']
   Requirement 4: MFG-0001 2026 and 2027: [78000.0, 78000.0]
   Requirement 4: MFG-0002 2026 and 2027: [52500.0, 52500.0]
   Requirement 4: MFG-0003 2026 and 2027: [60000.0, 60000.0]
   Requirement 4: MFG-0004 2026 and 2027: [12500.0, 0.0]
   Requirement 4: MFG-0005 2026 and 2027: [30000.0, 30000.0]
   Requirement 4: MFG-0006 2026 and 2027: [45000.0, 45000.0]
   Requirement 4: MFG-0007 2026 and 2027: [25666.63, 27999.96]
   Requirement 4: 2026 total: 303,666.63
   Requirement 4: 2026 total equals the ledger: 303,666.63
   Requirement 4: 2027 total: 293,499.96
   Requirement 4: 2027 a month: 24,458.33
   Requirement 4: MFG-0005 last month in 2027: 12
   Requirement 4: months: 12
   Requirement 4: January: 24,625.00
   Requirement 4: the year: 303,666.63
   Requirement 4: from February (MFG-0007): 26,958.33
   Requirement 4: from June (MFG-0004): 24,458.33
   Requirement 4: assets and their purchase orders: [['MFG-0006', 'PO-2024-001942'], ['MFG-0007',
      'PO-2026-011104']]
   Requirement 4: each above its approver's limit: [True, True]
   Requirement 4: standard hours: 68,912.79
   Requirement 4: standard conversion of the completion lines: 3,266,421.95
   Requirement 4: equal to what completions released to 1090, within a dollar: 3,266,422.54
   Requirement 4: conversion per standard hour: 47.40
   Requirement 4: labor per standard hour: 28.28
   Requirement 4: applied overhead: 1,317,562.72
   Requirement 4: overhead per standard hour: 19.12
   Requirement 4: standard labor: 1,948,859.23
   Requirement 4: job titles: ['Production Manager', 'Production Planner', 'Production Supervisor']
   Requirement 4: their gross pay: 263,191.24
   Requirement 4: 2026 budget to units completed: 3.09
   Requirement 4: 2024 forecast to orders: 2.33
   Requirement 4: 2025 forecast to orders: 2.57
   Requirement 4: 2026 forecast to orders: 2.88
   Requirement 4: budget categories: ['COGS']
   Requirement 4: scenarios: ['Standard hours', '2024 level', '2026 level with its overtime']
   Requirement 4: ratios: [1.0, 1.18, 1.511]
   Requirement 4: Standard hours: hours needed: 68,912.79
   Requirement 4: 2024 level: hours needed: 81,317.09
   Requirement 4: 2026 level with its overtime: hours needed: 104,127.23
   Requirement 4: regular capacity: [131072, 131072, 131072]
   Requirement 4: overtime needed for capacity: [0, 0, 0]
   Requirement 4: overtime premium with burden: 304,207.00
   Requirement 4: plan overhead: 1,902,775.50
   Requirement 4: Standard hours: conversion cost: 3,996,854.56
   Requirement 4: 2024 level: conversion cost: 4,373,788.79
   Requirement 4: 2026 level with its overtime: conversion cost: 5,371,136.06
   Requirement 4: Standard hours: expected variance: 730,432.02
   Requirement 4: 2024 level: expected variance: 1,107,366.25
   Requirement 4: 2026 level with its overtime: expected variance: 2,104,713.52
   Requirement 4: straight-time rate: 26.62
   Requirement 4: burden: 0.14
   Requirement 4: salaried staff: 263,191.24
   Requirement 4: factory overhead run rate: 1,308,869.06
   Requirement 4: 2027 depreciation: 293,499.96
   Requirement 4: rate with burden: 30.39
   Requirement 4: standard labor rate: 28.28
   Requirement 4: labor excess: 145,219.82
   Requirement 4: plan overhead: 1902776
   Requirement 4: applied overhead: 1317563
   Requirement 4: overhead excess: 585,212.78
   Requirement 4: capacity used: 0.53
   Requirement 5: first day: 2026-08-24
   Requirement 5: last day: 2026-12-13
   Requirement 5: working days of the eight periods: 78
   Requirement 5: working days left: 13
   Requirement 5: cost of the eight periods: 2,298,268.90
   Requirement 5: cost per working day: 29,464.99
   Requirement 5: accrual: 383,044.82
   Requirement 5: gross pay: 336,456.34
   Requirement 5: employer taxes: 25,738.93
   Requirement 5: benefits: 20,849.55
   Requirement 5: cost centers: ['Manufacturing', 'Executive', 'Design Services', 'Sales', 'Administration',
      'Purchasing', 'Warehouse', 'Marketing', 'Customer Service', 'Research and Development']
   Requirement 5: Manufacturing gross pay: 173,440.12
   Requirement 5: Manufacturing accrual: 197,970.68
   Requirement 5: Executive accrual: 42,080.32
   Requirement 5: Design Services accrual: 27,818.05
   Requirement 5: Sales accrual: 23,206.37
   Requirement 5: Administration accrual: 19,301.65
   Requirement 5: Purchasing accrual: 18,982.21
   Requirement 5: Warehouse accrual: 17,730.79
   Requirement 5: Marketing accrual: 14,333.19
   Requirement 5: Customer Service accrual: 11,338.71
   Requirement 5: Research and Development accrual: 10,282.84
   Requirement 5: Manufacturing: [1090]
   Requirement 5: every account by cost center: {'Executive': [6050, 6060], 'Sales': [6010, 6060],
      'Warehouse': [6020, 6060], 'Manufacturing': [1090], 'Purchasing': [6060, 6230], 'Administration': [6030,
      6060], 'Customer Service': [6040, 6060], 'Research and Development': [6060, 6250], 'Marketing': [6060,
      6240], 'Design Services': [6060, 6280]}
   Requirement 5: account names: [[2030, 'Accrued Payroll'], [2032, 'Employer Payroll Taxes Payable'], [2033,
      'Employee Benefits and Other Deductions Payable'], [6060, 'Payroll Taxes and Benefits']]
   Requirement 5: periods: ['2025-12-15', '2025-12-29']
   Requirement 5: period in full: 263,426.72
   Requirement 5: working days of the crossing period in the year: [3, 9]
   Requirement 5: crossing period's cost: 307,483.41
   Requirement 5: its share: 102,494.47
   Requirement 5: total: 365,921.19
   Requirement 5: manufacturing part: 180,675.14
   Requirement 5: opening line: 95,000.00
   Requirement 5: the payroll postings net: 0.00
   Requirement 5: the balance: 95,000.00
   Requirement 5: 2025 deliveries posted in another year: 19,540.86
   Requirement 5: lines: 9
   Requirement 5: value at order price: 44,481.11
   Requirement 5: standard cost: 22,895.78
   Requirement 5: recorded net income (Chapter 6): 4,503,611.24
   Requirement 5: payroll effect on income: -17,123.63
   Requirement 5: cutoff effect on income: 24,940.25
   Requirement 5: adjusted net income: 4,511,427.86
   Requirement 5: share of net income: 0.00
   Requirement 5: liability added: 383,044.82
   Requirement 5: receivables added: 44,481.11
   Requirement 5: opening retained earnings: -346,380.33
   Requirement 5: actual per standard hour: 78.77
   Requirement 5: standard per standard hour: 47.40
   Requirement 5: finished goods: 12,169,701.74
   Requirement 5: invoices: ['ASV0050-2025-040073']
   Requirement 5: amounts: [3266.27]
   Requirement 5: their accruals: ['JE-2025-000188']
   Requirement 5: accrued before the year-end: [True]
*/
