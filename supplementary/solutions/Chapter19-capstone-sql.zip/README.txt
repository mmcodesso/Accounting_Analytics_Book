Accounting Analytics: An Integrated Approach (2026 edition), instructor files
The SQL part of the solution to the Chapter 19 capstone case (Credits.sql)

Built from Charles River dataset release v2026.1 (fiscal 2024–2026).
CharlesRiver.sqlite SHA-256 de861968e07412d71032b6ed6a0fb8eb9825cf6911886b1597c4a628a914474c

Credits.sql

Open a script in DB Browser for SQLite (Execute SQL > Open SQL file(s)) on a working copy of
CharlesRiver.sqlite. Each query ends with its result on this dataset release, and the notes block at
the end repeats the requirements and the instructor notes and lists the values checked.
These files are public, like the rest of the book. Try an exercise first, then compare your work.
