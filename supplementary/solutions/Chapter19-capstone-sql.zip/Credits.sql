/* Credits.sql: the customer credits cycle, fiscal 2024 to 2026: map, reconciliations, and tests
   Database: CharlesRiver_Capstone.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-06 on dataset v2026.1
   Checks: each population against the ledger by year; every link both ways; document numbers for gaps; authority, separation, and timing of credits and refunds; the credits recomputed; lapping */

-- Requirement 1, test M1: a data profile of each of the cycle's tables (Chapter 10)
-- Population: every row of the eleven tables; expected: unique keys, dates in the window, nothing missing
SELECT 'SalesReturn' AS TableName, COUNT(*) AS Records,
    COUNT(DISTINCT ReturnNumber) AS DistinctKeys,
    MIN(ReturnDate) AS FirstDate, MAX(ReturnDate) AS LastDate,
    COUNT(DISTINCT CustomerID) AS Customers, NULL AS Amount,
    SUM(CASE WHEN ReturnDate IS NULL OR CustomerID IS NULL
        OR ReceivedByEmployeeID IS NULL THEN 1 ELSE 0 END) AS Missing
FROM SalesReturn
UNION ALL
SELECT 'SalesReturnLine', COUNT(*), COUNT(DISTINCT SalesReturnLineID),
    NULL, NULL, NULL, ROUND(SUM(ExtendedStandardCost), 2),
    SUM(CASE WHEN SalesReturnID IS NULL OR ShipmentLineID IS NULL
        THEN 1 ELSE 0 END)
FROM SalesReturnLine
UNION ALL
SELECT 'CreditMemo', COUNT(*), COUNT(DISTINCT CreditMemoNumber),
    MIN(CreditMemoDate), MAX(CreditMemoDate), COUNT(DISTINCT CustomerID),
    ROUND(SUM(GrandTotal), 2),
    SUM(CASE WHEN SalesReturnID IS NULL OR OriginalSalesInvoiceID IS NULL
        OR ApprovedByEmployeeID IS NULL THEN 1 ELSE 0 END)
FROM CreditMemo
UNION ALL
SELECT 'CreditMemoLine', COUNT(*), COUNT(DISTINCT CreditMemoLineID),
    NULL, NULL, NULL, ROUND(SUM(LineTotal), 2),
    SUM(CASE WHEN CreditMemoID IS NULL OR SalesReturnLineID IS NULL
        THEN 1 ELSE 0 END)
FROM CreditMemoLine
UNION ALL
SELECT 'CustomerRefund', COUNT(*), COUNT(DISTINCT RefundNumber),
    MIN(RefundDate), MAX(RefundDate), COUNT(DISTINCT CustomerID),
    ROUND(SUM(Amount), 2),
    SUM(CASE WHEN CreditMemoID IS NULL OR ApprovedByEmployeeID IS NULL
        THEN 1 ELSE 0 END)
FROM CustomerRefund
UNION ALL
SELECT 'SalesCommissionAdjustment', COUNT(*),
    COUNT(DISTINCT AdjustmentNumber), MIN(AdjustmentDate),
    MAX(AdjustmentDate), COUNT(DISTINCT CustomerID),
    ROUND(SUM(CommissionAdjustmentAmount), 2),
    SUM(CASE WHEN CreditMemoLineID IS NULL
        OR SalesCommissionAccrualID IS NULL THEN 1 ELSE 0 END)
FROM SalesCommissionAdjustment
UNION ALL
SELECT 'SalesCommissionAccrual', COUNT(*), COUNT(DISTINCT AccrualNumber),
    MIN(AccrualDate), MAX(AccrualDate), COUNT(DISTINCT CustomerID),
    ROUND(SUM(CommissionAmount), 2),
    SUM(CASE WHEN SalesInvoiceLineID IS NULL THEN 1 ELSE 0 END)
FROM SalesCommissionAccrual
UNION ALL
SELECT 'SalesCommissionPayment', COUNT(*), COUNT(DISTINCT PaymentNumber),
    MIN(PaymentDate), MAX(PaymentDate), NULL,
    ROUND(SUM(NetPaymentAmount), 2),
    SUM(CASE WHEN ApprovedByEmployeeID IS NULL THEN 1 ELSE 0 END)
FROM SalesCommissionPayment
UNION ALL
SELECT 'SalesCommissionRate', COUNT(*),
    COUNT(DISTINCT SalesCommissionRateID), MIN(EffectiveStartDate),
    MAX(EffectiveEndDate), NULL, NULL,
    SUM(CASE WHEN ApprovedByEmployeeID IS NULL THEN 1 ELSE 0 END)
FROM SalesCommissionRate
UNION ALL
SELECT 'CashReceipt', COUNT(*), COUNT(DISTINCT ReceiptNumber),
    MIN(ReceiptDate), MAX(ReceiptDate), COUNT(DISTINCT CustomerID),
    ROUND(SUM(Amount), 2),
    SUM(CASE WHEN DepositDate IS NULL OR RecordedByEmployeeID IS NULL
        THEN 1 ELSE 0 END)
FROM CashReceipt
UNION ALL
SELECT 'CashReceiptApplication', COUNT(*),
    COUNT(DISTINCT CashReceiptApplicationID), MIN(ApplicationDate),
    MAX(ApplicationDate), NULL, ROUND(SUM(AppliedAmount), 2),
    SUM(CASE WHEN CashReceiptID IS NULL OR SalesInvoiceID IS NULL
        OR AppliedByEmployeeID IS NULL THEN 1 ELSE 0 END)
FROM CashReceiptApplication;  -- Result: 11 rows

-- Requirement 1, test M2: the values of each status, reason, and method column
-- Population: returns, credits, refunds, and clawbacks; expected: a few valid values each
SELECT 'SalesReturn' AS TableName, 'Status' AS ColumnName,
    Status AS Value, COUNT(*) AS Records, NULL AS Amount
FROM SalesReturn
GROUP BY Status
UNION ALL
SELECT 'SalesReturn', 'ReasonCode', ReasonCode, COUNT(*), NULL
FROM SalesReturn
GROUP BY ReasonCode
UNION ALL
SELECT 'CreditMemo', 'Status', Status, COUNT(*), ROUND(SUM(GrandTotal), 2)
FROM CreditMemo
GROUP BY Status
UNION ALL
SELECT 'CustomerRefund', 'PaymentMethod', PaymentMethod, COUNT(*),
    ROUND(SUM(Amount), 2)
FROM CustomerRefund
GROUP BY PaymentMethod
UNION ALL
SELECT 'SalesCommissionAdjustment', 'Status', Status, COUNT(*),
    ROUND(SUM(CommissionAdjustmentAmount), 2)
FROM SalesCommissionAdjustment
GROUP BY Status
ORDER BY TableName, ColumnName, Records DESC;  -- Result: 15 rows

-- Requirement 1, test M3: the days between the cycle's steps
-- Population: every credit and refund; expected: credits within days of the return, refunds within weeks
SELECT 'Return to credit' AS Step, COUNT(*) AS Documents,
    MIN(julianday(cm.CreditMemoDate) - julianday(sr.ReturnDate))
        AS MinDays,
    MAX(julianday(cm.CreditMemoDate) - julianday(sr.ReturnDate))
        AS MaxDays,
    ROUND(AVG(julianday(cm.CreditMemoDate) - julianday(sr.ReturnDate)), 1)
        AS MeanDays,
    SUM(CASE WHEN cm.CreditMemoDate = sr.ReturnDate THEN 1 ELSE 0 END)
        AS SameDay,
    SUM(CASE WHEN julianday(cm.CreditMemoDate)
        - julianday(sr.ReturnDate) > 30 THEN 1 ELSE 0 END) AS Over30Days
FROM CreditMemo AS cm
    INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = cm.SalesReturnID
UNION ALL
SELECT 'Credit to approval', COUNT(*),
    MIN(julianday(ApprovedDate) - julianday(CreditMemoDate)),
    MAX(julianday(ApprovedDate) - julianday(CreditMemoDate)),
    ROUND(AVG(julianday(ApprovedDate) - julianday(CreditMemoDate)), 1),
    SUM(CASE WHEN ApprovedDate = CreditMemoDate THEN 1 ELSE 0 END),
    SUM(CASE WHEN julianday(ApprovedDate)
        - julianday(CreditMemoDate) > 30 THEN 1 ELSE 0 END)
FROM CreditMemo
UNION ALL
SELECT 'Credit to refund', COUNT(*),
    MIN(julianday(rf.RefundDate) - julianday(cm.CreditMemoDate)),
    MAX(julianday(rf.RefundDate) - julianday(cm.CreditMemoDate)),
    ROUND(AVG(julianday(rf.RefundDate) - julianday(cm.CreditMemoDate)), 1),
    SUM(CASE WHEN rf.RefundDate = cm.CreditMemoDate THEN 1 ELSE 0 END),
    SUM(CASE WHEN julianday(rf.RefundDate)
        - julianday(cm.CreditMemoDate) > 30 THEN 1 ELSE 0 END)
FROM CustomerRefund AS rf
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
UNION ALL
SELECT 'Refund to clearing', COUNT(*),
    MIN(julianday(ClearedDate) - julianday(RefundDate)),
    MAX(julianday(ClearedDate) - julianday(RefundDate)),
    ROUND(AVG(julianday(ClearedDate) - julianday(RefundDate)), 1),
    SUM(CASE WHEN ClearedDate = RefundDate THEN 1 ELSE 0 END),
    SUM(CASE WHEN julianday(ClearedDate)
        - julianday(RefundDate) > 30 THEN 1 ELSE 0 END)
FROM CustomerRefund;  -- Result: 4 rows

-- Requirement 1, test M4: every link of the cycle tested both ways with anti-joins
-- Population: the cycle's documents and lines; expected: no orphan in any direction
SELECT 'Return lines without a shipment line' AS Link, COUNT(*) AS Orphans
FROM SalesReturnLine AS x
    LEFT JOIN ShipmentLine AS y
        ON y.ShipmentLineID = x.ShipmentLineID
WHERE y.ShipmentLineID IS NULL
UNION ALL
SELECT 'Return lines without a return', COUNT(*)
FROM SalesReturnLine AS x
    LEFT JOIN SalesReturn AS y
        ON y.SalesReturnID = x.SalesReturnID
WHERE y.SalesReturnID IS NULL
UNION ALL
SELECT 'Returns without a credit', COUNT(*)
FROM SalesReturn AS x
    LEFT JOIN CreditMemo AS y
        ON y.SalesReturnID = x.SalesReturnID
WHERE y.CreditMemoID IS NULL
UNION ALL
SELECT 'Credits without a return', COUNT(*)
FROM CreditMemo AS x
    LEFT JOIN SalesReturn AS y
        ON y.SalesReturnID = x.SalesReturnID
WHERE y.SalesReturnID IS NULL
UNION ALL
SELECT 'Credits without an invoice', COUNT(*)
FROM CreditMemo AS x
    LEFT JOIN SalesInvoice AS y
        ON y.SalesInvoiceID = x.OriginalSalesInvoiceID
WHERE y.SalesInvoiceID IS NULL
UNION ALL
SELECT 'Credit lines without a credit', COUNT(*)
FROM CreditMemoLine AS x
    LEFT JOIN CreditMemo AS y
        ON y.CreditMemoID = x.CreditMemoID
WHERE y.CreditMemoID IS NULL
UNION ALL
SELECT 'Credit lines without a return line', COUNT(*)
FROM CreditMemoLine AS x
    LEFT JOIN SalesReturnLine AS y
        ON y.SalesReturnLineID = x.SalesReturnLineID
WHERE y.SalesReturnLineID IS NULL
UNION ALL
SELECT 'Return lines without a credit line', COUNT(*)
FROM SalesReturnLine AS x
    LEFT JOIN CreditMemoLine AS y
        ON y.SalesReturnLineID = x.SalesReturnLineID
WHERE y.CreditMemoLineID IS NULL
UNION ALL
SELECT 'Refunds without a credit', COUNT(*)
FROM CustomerRefund AS x
    LEFT JOIN CreditMemo AS y
        ON y.CreditMemoID = x.CreditMemoID
WHERE y.CreditMemoID IS NULL
UNION ALL
SELECT 'Refunded credits without a refund', COUNT(*)
FROM CreditMemo AS x
    LEFT JOIN CustomerRefund AS y
        ON y.CreditMemoID = x.CreditMemoID
WHERE y.CustomerRefundID IS NULL
    AND x.Status = 'Refunded'
UNION ALL
SELECT 'Clawbacks without a credit line', COUNT(*)
FROM SalesCommissionAdjustment AS x
    LEFT JOIN CreditMemoLine AS y
        ON y.CreditMemoLineID = x.CreditMemoLineID
WHERE y.CreditMemoLineID IS NULL
UNION ALL
SELECT 'Credit lines without a clawback', COUNT(*)
FROM CreditMemoLine AS x
    LEFT JOIN SalesCommissionAdjustment AS y
        ON y.CreditMemoLineID = x.CreditMemoLineID
WHERE y.SalesCommissionAdjustmentID IS NULL
UNION ALL
SELECT 'Clawbacks without an accrual', COUNT(*)
FROM SalesCommissionAdjustment AS x
    LEFT JOIN SalesCommissionAccrual AS y
        ON y.SalesCommissionAccrualID = x.SalesCommissionAccrualID
WHERE y.SalesCommissionAccrualID IS NULL
UNION ALL
SELECT 'Applications without a receipt', COUNT(*)
FROM CashReceiptApplication AS x
    LEFT JOIN CashReceipt AS y
        ON y.CashReceiptID = x.CashReceiptID
WHERE y.CashReceiptID IS NULL
UNION ALL
SELECT 'Applications without an invoice', COUNT(*)
FROM CashReceiptApplication AS x
    LEFT JOIN SalesInvoice AS y
        ON y.SalesInvoiceID = x.SalesInvoiceID
WHERE y.SalesInvoiceID IS NULL;  -- Result: 15 rows

-- Requirement 1, test M5: the cycle's documents traced to the ledger both ways
-- Population: the six documents and their GLEntry rows; expected: every document posted, no orphan row
SELECT 'SalesReturn' AS Document,
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        LEFT JOIN SalesReturn AS x
            ON x.SalesReturnID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'SalesReturn'
        AND x.SalesReturnID IS NULL) AS PostingsWithoutDocument,
    (SELECT COUNT(*)
     FROM SalesReturn AS x
     WHERE NOT EXISTS (
        SELECT 1
        FROM GLEntry AS gl
        WHERE gl.SourceDocumentType = 'SalesReturn'
            AND gl.SourceDocumentID = x.SalesReturnID)) AS DocumentsNotPosted
UNION ALL
SELECT 'CreditMemo',
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        LEFT JOIN CreditMemo AS x
            ON x.CreditMemoID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'CreditMemo'
        AND x.CreditMemoID IS NULL),
    (SELECT COUNT(*)
     FROM CreditMemo AS x
     WHERE NOT EXISTS (
        SELECT 1
        FROM GLEntry AS gl
        WHERE gl.SourceDocumentType = 'CreditMemo'
            AND gl.SourceDocumentID = x.CreditMemoID))
UNION ALL
SELECT 'CustomerRefund',
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        LEFT JOIN CustomerRefund AS x
            ON x.CustomerRefundID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'CustomerRefund'
        AND x.CustomerRefundID IS NULL),
    (SELECT COUNT(*)
     FROM CustomerRefund AS x
     WHERE NOT EXISTS (
        SELECT 1
        FROM GLEntry AS gl
        WHERE gl.SourceDocumentType = 'CustomerRefund'
            AND gl.SourceDocumentID = x.CustomerRefundID))
UNION ALL
SELECT 'SalesCommissionAdjustment',
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        LEFT JOIN SalesCommissionAdjustment AS x
            ON x.SalesCommissionAdjustmentID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'SalesCommissionAdjustment'
        AND x.SalesCommissionAdjustmentID IS NULL),
    (SELECT COUNT(*)
     FROM SalesCommissionAdjustment AS x
     WHERE NOT EXISTS (
        SELECT 1
        FROM GLEntry AS gl
        WHERE gl.SourceDocumentType = 'SalesCommissionAdjustment'
            AND gl.SourceDocumentID = x.SalesCommissionAdjustmentID))
UNION ALL
SELECT 'CashReceipt',
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        LEFT JOIN CashReceipt AS x
            ON x.CashReceiptID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'CashReceipt'
        AND x.CashReceiptID IS NULL),
    (SELECT COUNT(*)
     FROM CashReceipt AS x
     WHERE NOT EXISTS (
        SELECT 1
        FROM GLEntry AS gl
        WHERE gl.SourceDocumentType = 'CashReceipt'
            AND gl.SourceDocumentID = x.CashReceiptID))
UNION ALL
SELECT 'CashReceiptApplication',
    (SELECT COUNT(*)
     FROM GLEntry AS gl
        LEFT JOIN CashReceiptApplication AS x
            ON x.CashReceiptApplicationID = gl.SourceDocumentID
     WHERE gl.SourceDocumentType = 'CashReceiptApplication'
        AND x.CashReceiptApplicationID IS NULL),
    (SELECT COUNT(*)
     FROM CashReceiptApplication AS x
     WHERE NOT EXISTS (
        SELECT 1
        FROM GLEntry AS gl
        WHERE gl.SourceDocumentType = 'CashReceiptApplication'
            AND gl.SourceDocumentID = x.CashReceiptApplicationID));  -- Result: 6 rows

-- Requirement 1, test M6: the document numbers of each series and year tested for gaps (Chapter 8)
-- Population: return, credit, refund, and clawback numbers; expected: no gaps, continuing across years
WITH Numbers AS (
    SELECT 'SR' AS Series,
        CAST(SUBSTR(ReturnNumber, 4, 4) AS INTEGER) AS FiscalYear,
        CAST(SUBSTR(ReturnNumber, 9) AS INTEGER) AS Sequence
    FROM SalesReturn
    UNION ALL
    SELECT 'CM', CAST(SUBSTR(CreditMemoNumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(CreditMemoNumber, 9) AS INTEGER)
    FROM CreditMemo
    UNION ALL
    SELECT 'RF', CAST(SUBSTR(RefundNumber, 4, 4) AS INTEGER),
        CAST(SUBSTR(RefundNumber, 9) AS INTEGER)
    FROM CustomerRefund
    UNION ALL
    SELECT 'SCAJ', CAST(SUBSTR(AdjustmentNumber, 6, 4) AS INTEGER),
        CAST(SUBSTR(AdjustmentNumber, 11) AS INTEGER)
    FROM SalesCommissionAdjustment
),
ByYear AS (
    SELECT Series, FiscalYear, MIN(Sequence) AS FirstNumber,
        MAX(Sequence) AS LastNumber, COUNT(*) AS Documents,
        COUNT(DISTINCT Sequence) AS DistinctNumbers
    FROM Numbers
    GROUP BY Series, FiscalYear
)
SELECT Series, FiscalYear, FirstNumber, LastNumber, Documents,
    LastNumber - FirstNumber + 1 - DistinctNumbers AS Gaps,
    Documents - DistinctNumbers AS Repeats,
    FirstNumber - 1 - LAG(LastNumber) OVER (
        PARTITION BY Series ORDER BY FiscalYear) AS BreakFromLastYear
FROM ByYear
ORDER BY Series, FiscalYear;  -- Result: 12 rows

-- Requirement 1, test M7: the ledger's postings of the cycle, by source document and account
-- Population: the GLEntry rows of the six documents; expected: each document on its own few accounts
SELECT gl.SourceDocumentType, a.AccountNumber, a.AccountName,
    SUM(CASE WHEN gl.Debit > 0 THEN 1 ELSE 0 END) AS DebitRows,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    SUM(CASE WHEN gl.Credit > 0 THEN 1 ELSE 0 END) AS CreditRows,
    ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType IN ('SalesReturn',
    'CreditMemo',
    'CustomerRefund',
    'SalesCommissionAdjustment',
    'CashReceipt',
    'CashReceiptApplication')
GROUP BY gl.SourceDocumentType, a.AccountNumber, a.AccountName
ORDER BY gl.SourceDocumentType, a.AccountNumber;  -- Result: 18 rows

-- Requirement 1, test M8: who records each document, by job title and cost center
-- Population: the person each document names; expected: customer service handles cash and credits
WITH People AS (
    SELECT 'SalesReturn' AS Document, 'Received' AS Role,
        ReceivedByEmployeeID AS EmployeeID
    FROM SalesReturn
    UNION ALL
    SELECT 'CreditMemo', 'Approved', ApprovedByEmployeeID
    FROM CreditMemo
    UNION ALL
    SELECT 'CustomerRefund', 'Approved', ApprovedByEmployeeID
    FROM CustomerRefund
    UNION ALL
    SELECT 'SalesCommissionAdjustment', 'Approved', ApprovedByEmployeeID
    FROM SalesCommissionAdjustment
    UNION ALL
    SELECT 'CashReceipt', 'Recorded', RecordedByEmployeeID
    FROM CashReceipt
    UNION ALL
    SELECT 'CashReceiptApplication', 'Applied', AppliedByEmployeeID
    FROM CashReceiptApplication
)
SELECT p.Document, p.Role, e.JobTitle, cc.CostCenterName,
    COUNT(*) AS Documents, COUNT(DISTINCT p.EmployeeID) AS Employees
FROM People AS p
    INNER JOIN Employee AS e ON e.EmployeeID = p.EmployeeID
    LEFT JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
GROUP BY p.Document, p.Role, e.JobTitle, cc.CostCenterName
ORDER BY p.Document, Documents DESC;  -- Result: 14 rows

-- Requirement 2, test G1: the credits reconciled to the ledger by fiscal year
-- Population: every credit memo and its GLEntry rows; expected: no difference in any year
WITH Credits AS (
    SELECT CAST(strftime('%Y', CreditMemoDate) AS INTEGER) AS FiscalYear,
        COUNT(*) AS Credits, SUM(SubTotal) AS SubTotal,
        SUM(FreightCreditAmount) AS Freight, SUM(TaxAmount) AS Tax,
        SUM(GrandTotal) AS GrandTotal
    FROM CreditMemo
    GROUP BY FiscalYear
),
Ledger AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountNumber = 4060 THEN gl.Debit ELSE 0 END)
            AS Dr4060,
        SUM(CASE WHEN a.AccountNumber = 4050 THEN gl.Debit ELSE 0 END)
            AS Dr4050,
        SUM(CASE WHEN a.AccountNumber = 2050 THEN gl.Debit ELSE 0 END)
            AS Dr2050,
        SUM(CASE WHEN a.AccountNumber = 1020 THEN gl.Credit ELSE 0 END)
            AS Cr1020,
        SUM(CASE WHEN a.AccountNumber = 2060 THEN gl.Credit ELSE 0 END)
            AS Cr2060
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'CreditMemo'
    GROUP BY gl.FiscalYear
)
SELECT c.FiscalYear, c.Credits, ROUND(c.SubTotal, 2) AS SubTotal,
    ROUND(l.Dr4060, 2) AS Dr4060, ROUND(c.Freight, 2) AS Freight,
    ROUND(l.Dr4050, 2) AS Dr4050, ROUND(c.Tax, 2) AS Tax,
    ROUND(l.Dr2050, 2) AS Dr2050, ROUND(c.GrandTotal, 2) AS GrandTotal,
    ROUND(l.Cr1020, 2) AS Cr1020, ROUND(l.Cr2060, 2) AS Cr2060,
    ROUND(c.SubTotal - l.Dr4060 + c.Freight - l.Dr4050
        + c.Tax - l.Dr2050, 2) AS DebitDifference,
    ROUND(c.GrandTotal - l.Cr1020 - l.Cr2060, 2) AS CreditDifference
FROM Credits AS c
    LEFT JOIN Ledger AS l ON l.FiscalYear = c.FiscalYear
ORDER BY c.FiscalYear;  -- Result: 3 rows

-- Requirement 2, test G2: the returns' standard cost reconciled to inventory and cost of goods sold
-- Population: every return line and the returns' GLEntry rows; expected: no difference in any year
WITH Returns AS (
    SELECT CAST(strftime('%Y', sr.ReturnDate) AS INTEGER) AS FiscalYear,
        SUM(srl.ExtendedStandardCost) AS AtStandard
    FROM SalesReturnLine AS srl
        INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = srl.SalesReturnID
    GROUP BY FiscalYear
),
Ledger AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountNumber = 1040 THEN gl.Debit ELSE 0 END)
            AS Dr1040,
        SUM(CASE WHEN a.AccountNumber = 5010 THEN gl.Credit ELSE 0 END)
            AS Cr5010,
        SUM(CASE WHEN a.AccountNumber = 5020 THEN gl.Credit ELSE 0 END)
            AS Cr5020,
        SUM(CASE WHEN a.AccountNumber = 5030 THEN gl.Credit ELSE 0 END)
            AS Cr5030,
        SUM(CASE WHEN a.AccountNumber = 5040 THEN gl.Credit ELSE 0 END)
            AS Cr5040
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'SalesReturn'
    GROUP BY gl.FiscalYear
)
SELECT r.FiscalYear, ROUND(r.AtStandard, 2) AS AtStandard,
    ROUND(l.Dr1040, 2) AS Dr1040, ROUND(l.Cr5010, 2) AS Cr5010,
    ROUND(l.Cr5020, 2) AS Cr5020, ROUND(l.Cr5030, 2) AS Cr5030,
    ROUND(l.Cr5040, 2) AS Cr5040,
    ROUND(r.AtStandard - l.Dr1040, 2) AS Difference
FROM Returns AS r
    LEFT JOIN Ledger AS l ON l.FiscalYear = r.FiscalYear
ORDER BY r.FiscalYear;  -- Result: 3 rows

-- Requirement 2, test G3: the refunds reconciled to cash and 2060 by fiscal year
-- Population: every refund and its GLEntry rows; expected: no difference in any year
WITH Refunds AS (
    SELECT CAST(strftime('%Y', RefundDate) AS INTEGER) AS FiscalYear,
        COUNT(*) AS Refunds, SUM(Amount) AS Amount
    FROM CustomerRefund
    GROUP BY FiscalYear
),
Ledger AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountNumber = 1010 THEN gl.Credit ELSE 0 END)
            AS Cr1010,
        SUM(CASE WHEN a.AccountNumber = 2060 THEN gl.Debit ELSE 0 END)
            AS Dr2060
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'CustomerRefund'
    GROUP BY gl.FiscalYear
)
SELECT r.FiscalYear, r.Refunds, ROUND(r.Amount, 2) AS Amount,
    ROUND(l.Cr1010, 2) AS Cr1010, ROUND(l.Dr2060, 2) AS Dr2060,
    ROUND(r.Amount - l.Cr1010, 2) AS Difference1010,
    ROUND(r.Amount - l.Dr2060, 2) AS Difference2060
FROM Refunds AS r
    LEFT JOIN Ledger AS l ON l.FiscalYear = r.FiscalYear
ORDER BY r.FiscalYear;  -- Result: 3 rows

-- Requirement 2, test G4: the clawbacks reconciled to 2034 and 6290, beside the accruals and payments
-- Population: every clawback, accrual, and commission payment; expected: no difference in any year
WITH Clawbacks AS (
    SELECT CAST(strftime('%Y', AdjustmentDate) AS INTEGER) AS FiscalYear,
        SUM(CommissionAdjustmentAmount) AS Clawbacks
    FROM SalesCommissionAdjustment
    GROUP BY FiscalYear
),
Ledger AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN a.AccountNumber = 2034 THEN gl.Debit ELSE 0 END)
            AS Dr2034,
        SUM(CASE WHEN a.AccountNumber = 6290 THEN gl.Credit ELSE 0 END)
            AS Cr6290
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'SalesCommissionAdjustment'
    GROUP BY gl.FiscalYear
)
SELECT c.FiscalYear, ROUND(c.Clawbacks, 2) AS Clawbacks,
    ROUND(l.Dr2034, 2) AS Dr2034, ROUND(l.Cr6290, 2) AS Cr6290,
    ROUND(c.Clawbacks - l.Dr2034, 2) AS Difference,
    (SELECT ROUND(SUM(CommissionAmount), 2)
     FROM SalesCommissionAccrual
     WHERE CAST(strftime('%Y', AccrualDate) AS INTEGER) = c.FiscalYear)
        AS Accruals,
    (SELECT ROUND(SUM(NetPaymentAmount), 2)
     FROM SalesCommissionPayment
     WHERE CAST(strftime('%Y', PaymentDate) AS INTEGER) = c.FiscalYear)
        AS Payments
FROM Clawbacks AS c
    LEFT JOIN Ledger AS l ON l.FiscalYear = c.FiscalYear
WHERE c.FiscalYear BETWEEN 2024 AND 2026
ORDER BY c.FiscalYear;  -- Result: 3 rows

-- Requirement 2, test G5: the receipts and applications reconciled to cash, 2060, and receivables
-- Population: every receipt and application and their GLEntry rows; expected: no difference in any year
WITH Receipts AS (
    SELECT CAST(strftime('%Y', ReceiptDate) AS INTEGER) AS FiscalYear,
        SUM(Amount) AS Receipts
    FROM CashReceipt
    GROUP BY FiscalYear
),
Applications AS (
    SELECT CAST(strftime('%Y', ApplicationDate) AS INTEGER) AS FiscalYear,
        SUM(AppliedAmount) AS Applications
    FROM CashReceiptApplication
    GROUP BY FiscalYear
),
Ledger AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN gl.SourceDocumentType = 'CashReceipt'
            AND a.AccountNumber = 1010 THEN gl.Debit ELSE 0 END) AS Dr1010,
        SUM(CASE WHEN gl.SourceDocumentType = 'CashReceipt'
            AND a.AccountNumber = 2060 THEN gl.Credit ELSE 0 END) AS Cr2060,
        SUM(CASE WHEN gl.SourceDocumentType = 'CashReceiptApplication'
            AND a.AccountNumber = 2060 THEN gl.Debit ELSE 0 END) AS Dr2060,
        SUM(CASE WHEN gl.SourceDocumentType = 'CashReceiptApplication'
            AND a.AccountNumber = 1020 THEN gl.Credit ELSE 0 END) AS Cr1020
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType IN ('CashReceipt',
        'CashReceiptApplication')
    GROUP BY gl.FiscalYear
)
SELECT r.FiscalYear, ROUND(r.Receipts, 2) AS Receipts,
    ROUND(l.Dr1010, 2) AS Dr1010, ROUND(l.Cr2060, 2) AS Cr2060,
    ROUND(ap.Applications, 2) AS Applications,
    ROUND(l.Dr2060, 2) AS Dr2060, ROUND(l.Cr1020, 2) AS Cr1020,
    ROUND(r.Receipts - l.Dr1010, 2) AS ReceiptDifference,
    ROUND(ap.Applications - l.Cr1020, 2) AS ApplicationDifference
FROM Receipts AS r
    LEFT JOIN Applications AS ap ON ap.FiscalYear = r.FiscalYear
    LEFT JOIN Ledger AS l ON l.FiscalYear = r.FiscalYear
WHERE r.FiscalYear BETWEEN 2024 AND 2026
ORDER BY r.FiscalYear;  -- Result: 3 rows

-- Requirement 2, test G6: account 2060 rolled forward to each year-end, flow by flow
-- Population: every GLEntry row on 2060 to the base year's end; expected: large flows, small balances
WITH Flows AS (
    SELECT gl.FiscalYear,
        SUM(CASE WHEN gl.SourceDocumentType = 'CashReceipt'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS Receipts,
        SUM(CASE WHEN gl.SourceDocumentType = 'CreditMemo'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS Credits,
        SUM(CASE WHEN gl.SourceDocumentType = 'CashReceiptApplication'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS Applications,
        SUM(CASE WHEN gl.SourceDocumentType = 'CustomerRefund'
            THEN gl.Credit - gl.Debit ELSE 0 END) AS Refunds,
        SUM(CASE WHEN gl.SourceDocumentType NOT IN ('CashReceipt',
                'CreditMemo', 'CashReceiptApplication', 'CustomerRefund')
            THEN gl.Credit - gl.Debit ELSE 0 END) AS Other,
        SUM(gl.Credit - gl.Debit) AS NetChange
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 2060 AND gl.PostingDate <= '2026-12-31'
    GROUP BY gl.FiscalYear
)
SELECT FiscalYear,
    ROUND(SUM(NetChange) OVER (ORDER BY FiscalYear) - NetChange, 2)
        AS Opening,
    ROUND(Receipts, 2) AS Receipts, ROUND(Credits, 2) AS Credits,
    ROUND(Applications, 2) AS Applications, ROUND(Refunds, 2) AS Refunds,
    ROUND(Other, 2) AS Other,
    ROUND(SUM(NetChange) OVER (ORDER BY FiscalYear), 2) AS Closing
FROM Flows
ORDER BY FiscalYear;  -- Result: 3 rows

-- Requirement 2, test G7: the items in each year-end balance of 2060: credits not yet refunded
-- Population: the credits' 2060 postings and the refunds to each year-end; expected: they equal G6
WITH YearEnds AS (
    SELECT DISTINCT FiscalYear, FiscalYear || '-12-31' AS YearEnd
    FROM GLEntry
    WHERE FiscalYear BETWEEN 2024 AND 2026
),
CreditsTo2060 AS (
    SELECT gl.SourceDocumentID AS CreditMemoID, gl.PostingDate,
        gl.Credit - gl.Debit AS Amount
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 2060 AND gl.SourceDocumentType = 'CreditMemo'
),
Posted AS (
    SELECT ye.FiscalYear, c.CreditMemoID, SUM(c.Amount) AS Posted
    FROM YearEnds AS ye
        INNER JOIN CreditsTo2060 AS c ON c.PostingDate <= ye.YearEnd
    GROUP BY ye.FiscalYear, c.CreditMemoID
),
Refunded AS (
    SELECT ye.FiscalYear, rf.CreditMemoID, SUM(rf.Amount) AS Refunded
    FROM YearEnds AS ye
        INNER JOIN CustomerRefund AS rf ON rf.RefundDate <= ye.YearEnd
    GROUP BY ye.FiscalYear, rf.CreditMemoID
)
SELECT p.FiscalYear, cm.CreditMemoNumber, cm.CreditMemoDate, cm.Status,
    ROUND(p.Posted - COALESCE(rd.Refunded, 0), 2) AS OpenIn2060
FROM Posted AS p
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = p.CreditMemoID
    LEFT JOIN Refunded AS rd
        ON rd.FiscalYear = p.FiscalYear
        AND rd.CreditMemoID = p.CreditMemoID
WHERE p.Posted - COALESCE(rd.Refunded, 0) > 0.005
ORDER BY p.FiscalYear, cm.CreditMemoNumber;  -- Result: 8 rows

-- Requirement 2, test G8: account 2034 reconciled at 2026-12-31 to the commission records
-- Population: accruals, commission payments, and clawbacks to the year-end; expected: no difference
SELECT
    (SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
     FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
     WHERE a.AccountNumber = 2034
        AND gl.PostingDate <= '2026-12-31') AS Balance2034,
    (SELECT ROUND(SUM(CommissionAmount), 2)
     FROM SalesCommissionAccrual
     WHERE AccrualDate <= '2026-12-31') AS Accruals,
    (SELECT ROUND(SUM(NetPaymentAmount), 2)
     FROM SalesCommissionPayment
     WHERE PaymentDate <= '2026-12-31') AS Payments,
    (SELECT ROUND(SUM(CommissionAdjustmentAmount), 2)
     FROM SalesCommissionAdjustment
     WHERE AdjustmentDate <= '2026-12-31') AS Clawbacks,
    (SELECT COUNT(*)
     FROM SalesCommissionAdjustment AS sca
     WHERE NOT EXISTS (
        SELECT 1
        FROM SalesCommissionPaymentLine AS pl
        WHERE pl.SourceDocumentType = 'SalesCommissionAdjustment'
            AND pl.SourceDocumentID = sca.SalesCommissionAdjustmentID))
        AS ClawbacksNotYetNetted;  -- Result: 1 rows

-- Requirement 2, test G9: what the reconciliations leave out: the year-end closes on 4060 and 6290
-- Population: the closes' rows on the two accounts; expected: one row a year on each
SELECT a.AccountNumber, je.EntryNumber, je.PostingDate,
    ROUND(SUM(gl.Debit), 2) AS Debits, ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    INNER JOIN JournalEntry AS je ON je.EntryNumber = gl.VoucherNumber
WHERE a.AccountNumber IN (4060, 6290)
    AND je.EntryType LIKE 'Year-End Close%'
GROUP BY a.AccountNumber, je.EntryNumber, je.PostingDate
ORDER BY a.AccountNumber, je.PostingDate;  -- Result: 6 rows

-- Requirement 3, test P1: the return rate on revenue by year, and the expectation at the prior rate
-- Population: debits to 4060 and SalesInvoice revenue postings, closes left out; expected: rising rates
WITH Revenue AS (
    SELECT gl.FiscalYear, SUM(gl.Credit - gl.Debit) AS Revenue
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        AND gl.SourceDocumentType = 'SalesInvoice'
    GROUP BY gl.FiscalYear
),
Returns AS (
    SELECT gl.FiscalYear, SUM(gl.Debit) AS Returns4060
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 4060
        AND gl.VoucherNumber NOT IN (
            SELECT EntryNumber
            FROM JournalEntry
            WHERE EntryType LIKE 'Year-End Close%')
    GROUP BY gl.FiscalYear
),
Rates AS (
    SELECT rv.FiscalYear, rv.Revenue, rt.Returns4060,
        rt.Returns4060 / rv.Revenue AS ReturnRate
    FROM Revenue AS rv
        INNER JOIN Returns AS rt ON rt.FiscalYear = rv.FiscalYear
    WHERE rv.FiscalYear BETWEEN 2024 AND 2026
)
SELECT FiscalYear, ROUND(Revenue, 2) AS Revenue,
    ROUND(Returns4060, 2) AS Returns4060,
    ROUND(ReturnRate, 5) AS ReturnRate,
    ROUND(LAG(ReturnRate) OVER (ORDER BY FiscalYear) * Revenue, 2)
        AS ExpectedAtPriorRate,
    ROUND(Returns4060 - LAG(ReturnRate) OVER (ORDER BY FiscalYear)
        * Revenue, 2) AS Difference
FROM Rates
ORDER BY FiscalYear;  -- Result: 3 rows

-- Requirement 3, test P2: income before income taxes as recorded (the base of materiality)
-- Population: revenue and expense postings, closes left out (no tax account); expected: one row a year
SELECT gl.FiscalYear,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS IncomeBeforeTaxes
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountType IN ('Revenue', 'Expense')
    AND gl.FiscalYear BETWEEN 2024 AND 2026
    AND gl.VoucherNumber NOT IN (
        SELECT EntryNumber
        FROM JournalEntry
        WHERE EntryType LIKE 'Year-End Close%')
GROUP BY gl.FiscalYear
ORDER BY gl.FiscalYear;  -- Result: 3 rows

-- Requirement 4, test T1: authority for credits and refunds against the approver's limit, by job title
-- Population: every credit and refund (MaxApprovalAmount, blank as 0); expected: none above the limit
WITH Approvals AS (
    SELECT 'CreditMemo' AS Document, cm.GrandTotal AS Amount,
        cm.ApprovedByEmployeeID AS EmployeeID
    FROM CreditMemo AS cm
    UNION ALL
    SELECT 'CustomerRefund', rf.Amount, rf.ApprovedByEmployeeID
    FROM CustomerRefund AS rf
)
SELECT ap.Document, e.JobTitle, COUNT(*) AS Documents,
    ROUND(SUM(ap.Amount), 2) AS Amount,
    MAX(COALESCE(e.MaxApprovalAmount, 0)) AS HighestLimit,
    SUM(CASE WHEN ap.Amount > COALESCE(e.MaxApprovalAmount, 0)
        THEN 1 ELSE 0 END) AS AboveLimit,
    ROUND(SUM(CASE WHEN ap.Amount > COALESCE(e.MaxApprovalAmount, 0)
        THEN ap.Amount ELSE 0 END), 2) AS AboveLimitAmount
FROM Approvals AS ap
    INNER JOIN Employee AS e ON e.EmployeeID = ap.EmployeeID
GROUP BY ap.Document, e.JobTitle
ORDER BY ap.Document, Documents DESC;  -- Result: 5 rows

-- Requirement 4, test T2: documents recorded or approved outside the person's employment dates
-- Population: every return, credit, refund, clawback, receipt, and application; expected: no rows
WITH People AS (
    SELECT ReturnNumber AS DocumentNumber, ReturnDate AS DocumentDate,
        ReceivedByEmployeeID AS EmployeeID
    FROM SalesReturn
    UNION ALL
    SELECT CreditMemoNumber, CreditMemoDate, ApprovedByEmployeeID
    FROM CreditMemo
    UNION ALL
    SELECT RefundNumber, RefundDate, ApprovedByEmployeeID
    FROM CustomerRefund
    UNION ALL
    SELECT AdjustmentNumber, AdjustmentDate, ApprovedByEmployeeID
    FROM SalesCommissionAdjustment
    UNION ALL
    SELECT ReceiptNumber, ReceiptDate, RecordedByEmployeeID
    FROM CashReceipt
    UNION ALL
    SELECT CAST(CashReceiptApplicationID AS TEXT), ApplicationDate,
        AppliedByEmployeeID
    FROM CashReceiptApplication
)
SELECT p.DocumentNumber, p.DocumentDate, e.EmployeeID, e.JobTitle,
    e.HireDate, e.TerminationDate
FROM People AS p
    INNER JOIN Employee AS e ON e.EmployeeID = p.EmployeeID
WHERE p.DocumentDate < e.HireDate
    OR (e.TerminationDate IS NOT NULL
        AND p.DocumentDate > e.TerminationDate)
ORDER BY p.DocumentDate;  -- Result: 0 rows

-- Requirement 4, test T3: separation of duties: the credit's approver handled the invoice's cash
-- Population: every credit and the receipts applied to its invoice; expected: no rows
WITH Handled AS (
    SELECT cm.CreditMemoID,
        MAX(CASE WHEN cra.AppliedByEmployeeID = cm.ApprovedByEmployeeID
            THEN 1 ELSE 0 END) AS AppliedCash,
        MAX(CASE WHEN cra.AppliedByEmployeeID = cm.ApprovedByEmployeeID
                AND cra.ApplicationDate <= cm.CreditMemoDate
            THEN 1 ELSE 0 END) AS AppliedByCreditDate,
        MAX(CASE WHEN cr.RecordedByEmployeeID = cm.ApprovedByEmployeeID
            THEN 1 ELSE 0 END) AS RecordedCash
    FROM CreditMemo AS cm
        INNER JOIN CashReceiptApplication AS cra
            ON cra.SalesInvoiceID = cm.OriginalSalesInvoiceID
        INNER JOIN CashReceipt AS cr ON cr.CashReceiptID = cra.CashReceiptID
    GROUP BY cm.CreditMemoID
)
SELECT cm.CreditMemoNumber, cm.CreditMemoDate,
    CAST(strftime('%Y', cm.CreditMemoDate) AS INTEGER) AS FiscalYear,
    ROUND(cm.GrandTotal, 2) AS GrandTotal,
    cm.ApprovedByEmployeeID, h.AppliedCash, h.AppliedByCreditDate,
    h.RecordedCash
FROM Handled AS h
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = h.CreditMemoID
WHERE h.AppliedCash = 1 OR h.RecordedCash = 1
ORDER BY cm.CreditMemoNumber;  -- Result: 356 rows

-- Requirement 4, test T4: the refund's approver and the return's receiver against the credit's approver
-- Population: every refund and credit; expected: never the same person, returns received in the warehouse
SELECT
    (SELECT COUNT(*)
     FROM CustomerRefund AS rf
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
     WHERE rf.ApprovedByEmployeeID = cm.ApprovedByEmployeeID)
        AS RefundApprovedByCreditApprover,
    (SELECT COUNT(*)
     FROM CreditMemo AS cm
        INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = cm.SalesReturnID
     WHERE sr.ReceivedByEmployeeID = cm.ApprovedByEmployeeID)
        AS ReturnReceivedByCreditApprover,
    (SELECT COUNT(*)
     FROM SalesReturn AS sr
        INNER JOIN Employee AS e ON e.EmployeeID = sr.ReceivedByEmployeeID
        INNER JOIN CostCenter AS cc ON cc.CostCenterID = e.CostCenterID
     WHERE cc.CostCenterName <> 'Warehouse') AS ReceivedOutsideWarehouse;  -- Result: 1 row (RefundApprovedByCreditApprover = 0, ReturnReceivedByCreditApprover = 0, ReceivedOutsideWarehouse = 0)

-- Requirement 4, test T5: the preparer against the approver: whom GLEntry.CreatedByEmployeeID names
-- Population: ledger rows of the cycle, sales invoices, and supplier payments; expected: a separate preparer
SELECT 'SalesReturn' AS Document,
    'ReceivedByEmployeeID' AS NamedPerson,
    COUNT(*) AS LedgerRows,
    SUM(CASE WHEN gl.CreatedByEmployeeID = x.ReceivedByEmployeeID
        THEN 1 ELSE 0 END) AS CreatedByThatPerson
FROM GLEntry AS gl
    INNER JOIN SalesReturn AS x
        ON x.SalesReturnID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'SalesReturn'
UNION ALL
SELECT 'CreditMemo',
    'ApprovedByEmployeeID',
    COUNT(*),
    SUM(CASE WHEN gl.CreatedByEmployeeID = x.ApprovedByEmployeeID
        THEN 1 ELSE 0 END)
FROM GLEntry AS gl
    INNER JOIN CreditMemo AS x
        ON x.CreditMemoID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'CreditMemo'
UNION ALL
SELECT 'CustomerRefund',
    'ApprovedByEmployeeID',
    COUNT(*),
    SUM(CASE WHEN gl.CreatedByEmployeeID = x.ApprovedByEmployeeID
        THEN 1 ELSE 0 END)
FROM GLEntry AS gl
    INNER JOIN CustomerRefund AS x
        ON x.CustomerRefundID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'CustomerRefund'
UNION ALL
SELECT 'SalesCommissionAdjustment',
    'ApprovedByEmployeeID',
    COUNT(*),
    SUM(CASE WHEN gl.CreatedByEmployeeID = x.ApprovedByEmployeeID
        THEN 1 ELSE 0 END)
FROM GLEntry AS gl
    INNER JOIN SalesCommissionAdjustment AS x
        ON x.SalesCommissionAdjustmentID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'SalesCommissionAdjustment'
UNION ALL
SELECT 'CashReceipt',
    'RecordedByEmployeeID',
    COUNT(*),
    SUM(CASE WHEN gl.CreatedByEmployeeID = x.RecordedByEmployeeID
        THEN 1 ELSE 0 END)
FROM GLEntry AS gl
    INNER JOIN CashReceipt AS x
        ON x.CashReceiptID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'CashReceipt'
UNION ALL
SELECT 'CashReceiptApplication',
    'AppliedByEmployeeID',
    COUNT(*),
    SUM(CASE WHEN gl.CreatedByEmployeeID = x.AppliedByEmployeeID
        THEN 1 ELSE 0 END)
FROM GLEntry AS gl
    INNER JOIN CashReceiptApplication AS x
        ON x.CashReceiptApplicationID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'CashReceiptApplication'
UNION ALL
SELECT 'SalesInvoice', 'none: ' || MIN(e.JobTitle), COUNT(*),
    COUNT(DISTINCT gl.CreatedByEmployeeID)
FROM GLEntry AS gl
    INNER JOIN Employee AS e ON e.EmployeeID = gl.CreatedByEmployeeID
WHERE gl.SourceDocumentType = 'SalesInvoice'
UNION ALL
SELECT 'DisbursementPayment', 'none: ' || MIN(e.JobTitle), COUNT(*),
    COUNT(DISTINCT gl.CreatedByEmployeeID)
FROM GLEntry AS gl
    INNER JOIN Employee AS e ON e.EmployeeID = gl.CreatedByEmployeeID
WHERE gl.SourceDocumentType = 'DisbursementPayment';  -- Result: 8 rows

-- Requirement 4, test T6: refunds dated before the last payment on the credited invoice
-- Population: every refund and the applications to its credit's invoice; expected: no rows
WITH LastPayment AS (
    SELECT SalesInvoiceID, MAX(ApplicationDate) AS LastPaymentDate
    FROM CashReceiptApplication
    GROUP BY SalesInvoiceID
)
SELECT rf.RefundNumber, rf.RefundDate,
    CAST(strftime('%Y', rf.RefundDate) AS INTEGER) AS FiscalYear,
    ROUND(rf.Amount, 2) AS Amount, si.InvoiceNumber, si.DueDate,
    lp.LastPaymentDate,
    julianday(lp.LastPaymentDate) - julianday(rf.RefundDate)
        AS DaysUntilPaid,
    CASE WHEN rf.RefundDate < si.DueDate THEN 1 ELSE 0 END
        AS BeforeDueDate,
    CASE WHEN NOT EXISTS (
            SELECT 1
            FROM CashReceiptApplication AS cra
            WHERE cra.SalesInvoiceID = si.SalesInvoiceID
                AND cra.ApplicationDate <= rf.RefundDate)
        THEN 1 ELSE 0 END AS NothingPaidYet
FROM CustomerRefund AS rf
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
    INNER JOIN SalesInvoice AS si
        ON si.SalesInvoiceID = cm.OriginalSalesInvoiceID
    INNER JOIN LastPayment AS lp ON lp.SalesInvoiceID = si.SalesInvoiceID
WHERE lp.LastPaymentDate > rf.RefundDate
ORDER BY rf.RefundNumber;  -- Result: 58 rows

-- Requirement 4, test T7: the cause of T6: credits posted to 2060 while nothing was paid
-- Population: the credits' postings to 1020 and 2060; expected: credits on unpaid invoices reduce 1020
WITH Parts AS (
    SELECT gl.SourceDocumentID AS CreditMemoID,
        SUM(CASE WHEN a.AccountNumber = 1020 THEN gl.Credit ELSE 0 END)
            AS To1020,
        SUM(CASE WHEN a.AccountNumber = 2060 THEN gl.Credit ELSE 0 END)
            AS To2060
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'CreditMemo'
    GROUP BY gl.SourceDocumentID
)
SELECT COUNT(*) AS Credits,
    SUM(CASE WHEN p.To2060 > 0 THEN 1 ELSE 0 END) AS CreditsTo2060,
    SUM(CASE WHEN p.To2060 > 0 AND p.To1020 > 0 THEN 1 ELSE 0 END)
        AS CreditsToBoth,
    SUM(CASE WHEN p.To2060 > 0 AND NOT EXISTS (
            SELECT 1
            FROM CashReceiptApplication AS cra
            WHERE cra.SalesInvoiceID = cm.OriginalSalesInvoiceID
                AND cra.ApplicationDate <= cm.CreditMemoDate)
        THEN 1 ELSE 0 END) AS To2060WithNothingPaid
FROM Parts AS p
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = p.CreditMemoID;  -- Result: 1 rows

-- Requirement 4, test T8: the clawbacks tested for completeness and accuracy
-- Population: every credit line and clawback; expected: one per line, the accrual's rate, exact amounts
SELECT 'Credit line without a clawback' AS Issue,
    CAST(cml.CreditMemoLineID AS TEXT) AS Document, NULL AS Base,
    NULL AS Rate, NULL AS Amount, NULL AS Recomputed
FROM CreditMemoLine AS cml
WHERE NOT EXISTS (
    SELECT 1
    FROM SalesCommissionAdjustment AS sca
    WHERE sca.CreditMemoLineID = cml.CreditMemoLineID)
UNION ALL
SELECT 'Base is not the line total', sca.AdjustmentNumber,
    sca.CommissionBaseReductionAmount, sca.CommissionRatePct,
    sca.CommissionAdjustmentAmount, cml.LineTotal
FROM SalesCommissionAdjustment AS sca
    INNER JOIN CreditMemoLine AS cml
        ON cml.CreditMemoLineID = sca.CreditMemoLineID
WHERE ABS(sca.CommissionBaseReductionAmount - cml.LineTotal) > 0.004
UNION ALL
SELECT 'Rate is not the accrual''s', sca.AdjustmentNumber,
    sca.CommissionBaseReductionAmount, sca.CommissionRatePct,
    sca.CommissionAdjustmentAmount, sac.CommissionRatePct
FROM SalesCommissionAdjustment AS sca
    INNER JOIN SalesCommissionAccrual AS sac
        ON sac.SalesCommissionAccrualID = sca.SalesCommissionAccrualID
WHERE ABS(sca.CommissionRatePct - sac.CommissionRatePct) > 0.0000001
UNION ALL
SELECT 'Amount is not ROUND(base x rate, 2)', sca.AdjustmentNumber,
    sca.CommissionBaseReductionAmount, sca.CommissionRatePct,
    sca.CommissionAdjustmentAmount,
    ROUND(sca.CommissionBaseReductionAmount * sca.CommissionRatePct, 2)
FROM SalesCommissionAdjustment AS sca
WHERE ABS(sca.CommissionAdjustmentAmount - ROUND(
    sca.CommissionBaseReductionAmount * sca.CommissionRatePct, 2)) > 0.004
UNION ALL
SELECT 'Not the credit''s date or approver', sca.AdjustmentNumber,
    NULL, NULL, sca.CommissionAdjustmentAmount, NULL
FROM SalesCommissionAdjustment AS sca
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = sca.CreditMemoID
WHERE sca.AdjustmentDate <> cm.CreditMemoDate
    OR sca.ApprovedByEmployeeID <> cm.ApprovedByEmployeeID
ORDER BY Issue, Document;  -- Result: 3 rows

-- Requirement 4, test T9: one refund per credit, equal to the credit's part posted to 2060
-- Population: every refund and refunded credit; expected: one each, equal amounts
WITH To2060 AS (
    SELECT gl.SourceDocumentID AS CreditMemoID, SUM(gl.Credit) AS To2060
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE gl.SourceDocumentType = 'CreditMemo' AND a.AccountNumber = 2060
    GROUP BY gl.SourceDocumentID
)
SELECT COUNT(*) AS Refunds,
    COUNT(DISTINCT rf.CreditMemoID) AS CreditsRefunded,
    (SELECT COUNT(*)
     FROM CreditMemo
     WHERE Status = 'Refunded') AS CreditsWithStatusRefunded,
    SUM(CASE WHEN ABS(rf.Amount - COALESCE(t.To2060, 0)) < 0.005
        THEN 1 ELSE 0 END) AS RefundEqualTo2060Part
FROM CustomerRefund AS rf
    LEFT JOIN To2060 AS t ON t.CreditMemoID = rf.CreditMemoID;  -- Result: 1 rows

-- Requirement 4, test T10: the refund flags, one row per refund (Export to CSV as RefundFlags.csv)
-- Population: every refund; definitions in the case text; expected: flags concentrated on few refunds
WITH LastPayment AS (
    SELECT SalesInvoiceID, MAX(ApplicationDate) AS LastPaymentDate
    FROM CashReceiptApplication
    GROUP BY SalesInvoiceID
),
InvoiceMethods AS (
    SELECT DISTINCT cra.SalesInvoiceID, cr.PaymentMethod
    FROM CashReceiptApplication AS cra
        INNER JOIN CashReceipt AS cr ON cr.CashReceiptID = cra.CashReceiptID
),
DueInvoices AS (
    SELECT rf.CustomerRefundID, rf.RefundDate, si.SalesInvoiceID,
        si.GrandTotal
    FROM CustomerRefund AS rf
        INNER JOIN SalesInvoice AS si
            ON si.CustomerID = rf.CustomerID
            AND si.InvoiceDate <= rf.RefundDate
            AND si.DueDate < rf.RefundDate
),
PaidThen AS (
    SELECT di.CustomerRefundID, di.SalesInvoiceID,
        SUM(cra.AppliedAmount) AS Paid
    FROM DueInvoices AS di
        INNER JOIN CashReceiptApplication AS cra
            ON cra.SalesInvoiceID = di.SalesInvoiceID
            AND cra.ApplicationDate <= di.RefundDate
    GROUP BY di.CustomerRefundID, di.SalesInvoiceID
),
CreditedThen AS (
    SELECT di.CustomerRefundID, di.SalesInvoiceID,
        SUM(cm.GrandTotal) AS Credited
    FROM DueInvoices AS di
        INNER JOIN CreditMemo AS cm
            ON cm.OriginalSalesInvoiceID = di.SalesInvoiceID
            AND cm.CreditMemoDate <= di.RefundDate
    GROUP BY di.CustomerRefundID, di.SalesInvoiceID
),
PastDue AS (
    SELECT di.CustomerRefundID,
        SUM(di.GrandTotal - COALESCE(pt.Paid, 0)
            - COALESCE(ct.Credited, 0)) AS PastDue
    FROM DueInvoices AS di
        LEFT JOIN PaidThen AS pt
            ON pt.CustomerRefundID = di.CustomerRefundID
            AND pt.SalesInvoiceID = di.SalesInvoiceID
        LEFT JOIN CreditedThen AS ct
            ON ct.CustomerRefundID = di.CustomerRefundID
            AND ct.SalesInvoiceID = di.SalesInvoiceID
    WHERE di.GrandTotal - COALESCE(pt.Paid, 0)
        - COALESCE(ct.Credited, 0) > 0.005
    GROUP BY di.CustomerRefundID
),
Flags AS (
    SELECT rf.RefundNumber, rf.RefundDate, rf.CustomerID, rf.Amount,
        CASE WHEN rf.Amount > COALESCE(ra.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS AboveLimit,
        CASE WHEN cm.GrandTotal > COALESCE(ca.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS CreditAboveLimit,
        CASE WHEN EXISTS (
                SELECT 1
                FROM InvoiceMethods AS im
                WHERE im.SalesInvoiceID = cm.OriginalSalesInvoiceID
                    AND im.PaymentMethod = rf.PaymentMethod)
            THEN 0 ELSE 1 END AS MethodMismatch,
        CASE WHEN lp.LastPaymentDate > rf.RefundDate
            THEN 1 ELSE 0 END AS BeforePayment,
        COALESCE(pd.PastDue, 0) AS PastDue
    FROM CustomerRefund AS rf
        INNER JOIN Employee AS ra ON ra.EmployeeID = rf.ApprovedByEmployeeID
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
        INNER JOIN Employee AS ca ON ca.EmployeeID = cm.ApprovedByEmployeeID
        LEFT JOIN LastPayment AS lp
            ON lp.SalesInvoiceID = cm.OriginalSalesInvoiceID
        LEFT JOIN PastDue AS pd
            ON pd.CustomerRefundID = rf.CustomerRefundID
)
SELECT RefundNumber, RefundDate,
    CAST(strftime('%Y', RefundDate) AS INTEGER) AS FiscalYear,
    CustomerID, Amount, AboveLimit, CreditAboveLimit, MethodMismatch,
    BeforePayment, ROUND(PastDue, 2) AS PastDue,
    CASE WHEN PastDue >= Amount THEN 1 ELSE 0 END
        AS PastDueAtLeastRefund,
    CASE WHEN PastDue > 0 THEN 1 ELSE 0 END AS PastDueAny,
    AboveLimit + CreditAboveLimit + MethodMismatch + BeforePayment
        + CASE WHEN PastDue >= Amount THEN 1 ELSE 0 END AS Score
FROM Flags
ORDER BY RefundNumber;  -- Result: 222 rows

-- Requirement 4, test T11: the exceptions of the four rule tests in one list by year (UNION ALL)
-- Population: tests T1, T3, and T6 on every credit and refund; expected: no rows
WITH LastPayment AS (
    SELECT SalesInvoiceID, MAX(ApplicationDate) AS LastPaymentDate
    FROM CashReceiptApplication
    GROUP BY SalesInvoiceID
),
Exceptions AS (
    SELECT 'CM AboveLimit' AS TestID, cm.CreditMemoNumber AS DocumentNumber,
        cm.CreditMemoDate AS DocumentDate, cm.GrandTotal AS Amount
    FROM CreditMemo AS cm
        INNER JOIN Employee AS e ON e.EmployeeID = cm.ApprovedByEmployeeID
    WHERE cm.GrandTotal > COALESCE(e.MaxApprovalAmount, 0)
    UNION ALL
    SELECT 'CM CashAndCredit', cm.CreditMemoNumber, cm.CreditMemoDate,
        cm.GrandTotal
    FROM CreditMemo AS cm
    WHERE EXISTS (
        SELECT 1
        FROM CashReceiptApplication AS cra
        WHERE cra.SalesInvoiceID = cm.OriginalSalesInvoiceID
            AND cra.AppliedByEmployeeID = cm.ApprovedByEmployeeID)
    UNION ALL
    SELECT 'RF AboveLimit', rf.RefundNumber, rf.RefundDate, rf.Amount
    FROM CustomerRefund AS rf
        INNER JOIN Employee AS e ON e.EmployeeID = rf.ApprovedByEmployeeID
    WHERE rf.Amount > COALESCE(e.MaxApprovalAmount, 0)
    UNION ALL
    SELECT 'RF BeforePayment', rf.RefundNumber, rf.RefundDate, rf.Amount
    FROM CustomerRefund AS rf
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
        INNER JOIN LastPayment AS lp
            ON lp.SalesInvoiceID = cm.OriginalSalesInvoiceID
    WHERE lp.LastPaymentDate > rf.RefundDate
)
SELECT CAST(strftime('%Y', DocumentDate) AS INTEGER) AS FiscalYear,
    TestID, DocumentNumber, DocumentDate, ROUND(Amount, 2) AS Amount
FROM Exceptions
ORDER BY FiscalYear, TestID, DocumentNumber;  -- Result: 841 rows

-- Requirement 4, test T12: the Accounting Manager's share of the cycle's and payroll's approvals
-- Population: commission rates, accruals, payments, refunds, and payroll registers; expected: spread out
WITH Manager AS (
    SELECT EmployeeID
    FROM Employee
    WHERE JobTitle = 'Accounting Manager'
)
SELECT 'Commission rates approved' AS Activity, COUNT(*) AS Documents,
    SUM(CASE WHEN ApprovedByEmployeeID IN (SELECT EmployeeID FROM Manager)
        THEN 1 ELSE 0 END) AS ByAccountingManager
FROM SalesCommissionRate
UNION ALL
SELECT 'Commission accruals created', COUNT(*),
    SUM(CASE WHEN CreatedByEmployeeID IN (SELECT EmployeeID FROM Manager)
        THEN 1 ELSE 0 END)
FROM SalesCommissionAccrual
UNION ALL
SELECT 'Commission payments approved', COUNT(*),
    SUM(CASE WHEN ApprovedByEmployeeID IN (SELECT EmployeeID FROM Manager)
        THEN 1 ELSE 0 END)
FROM SalesCommissionPayment
UNION ALL
SELECT 'Refunds approved', COUNT(*),
    SUM(CASE WHEN ApprovedByEmployeeID IN (SELECT EmployeeID FROM Manager)
        THEN 1 ELSE 0 END)
FROM CustomerRefund
UNION ALL
SELECT 'Payroll registers approved', COUNT(*),
    SUM(CASE WHEN ApprovedByEmployeeID IN (SELECT EmployeeID FROM Manager)
        THEN 1 ELSE 0 END)
FROM PayrollRegister;  -- Result: 5 rows

-- Requirement 6, test K1: the sampling population: key items and the remainder, with the data attribute
-- Population: every refund; key items 5,000 or more, or a customer over 10,000; expected: a few
WITH CustomerTotals AS (
    SELECT CustomerID, SUM(Amount) AS CustomerRefunds
    FROM CustomerRefund
    GROUP BY CustomerID
),
LastPayment AS (
    SELECT SalesInvoiceID, MAX(ApplicationDate) AS LastPaymentDate
    FROM CashReceiptApplication
    GROUP BY SalesInvoiceID
),
Refunds AS (
    SELECT rf.RefundNumber, rf.RefundDate, rf.CustomerID, rf.Amount,
        ct.CustomerRefunds,
        CASE WHEN rf.Amount >= 5000
                OR ct.CustomerRefunds > 10000
            THEN 'Key item' ELSE 'Remainder' END AS Stratum,
        CASE WHEN lp.LastPaymentDate > rf.RefundDate
            THEN 1 ELSE 0 END AS BeforePayment
    FROM CustomerRefund AS rf
        INNER JOIN CustomerTotals AS ct ON ct.CustomerID = rf.CustomerID
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
        LEFT JOIN LastPayment AS lp
            ON lp.SalesInvoiceID = cm.OriginalSalesInvoiceID
)
SELECT Stratum, COUNT(*) AS Refunds, ROUND(SUM(Amount), 2) AS Amount,
    SUM(BeforePayment) AS BeforePayment
FROM Refunds
GROUP BY Stratum
ORDER BY Stratum;  -- Result: 2 rows

-- Requirement 6, test K2: the key items, taken in full
-- Population: the key items of K1; expected: each listed with why it is key
WITH CustomerTotals AS (
    SELECT CustomerID, SUM(Amount) AS CustomerRefunds
    FROM CustomerRefund
    GROUP BY CustomerID
),
LastPayment AS (
    SELECT SalesInvoiceID, MAX(ApplicationDate) AS LastPaymentDate
    FROM CashReceiptApplication
    GROUP BY SalesInvoiceID
),
Refunds AS (
    SELECT rf.RefundNumber, rf.RefundDate, rf.CustomerID, rf.Amount,
        ct.CustomerRefunds,
        CASE WHEN rf.Amount >= 5000
                OR ct.CustomerRefunds > 10000
            THEN 'Key item' ELSE 'Remainder' END AS Stratum,
        CASE WHEN lp.LastPaymentDate > rf.RefundDate
            THEN 1 ELSE 0 END AS BeforePayment
    FROM CustomerRefund AS rf
        INNER JOIN CustomerTotals AS ct ON ct.CustomerID = rf.CustomerID
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
        LEFT JOIN LastPayment AS lp
            ON lp.SalesInvoiceID = cm.OriginalSalesInvoiceID
)
SELECT RefundNumber, RefundDate, CustomerID, ROUND(Amount, 2) AS Amount,
    ROUND(CustomerRefunds, 2) AS CustomerRefunds,
    CASE WHEN Amount >= 5000 THEN 'Amount'
        ELSE 'Customer' END AS KeyBecause,
    BeforePayment
FROM Refunds
WHERE Stratum = 'Key item'
ORDER BY RefundNumber;  -- Result: 7 rows

-- Requirement 7, test S1: each credit line recomputed from its return, shipment, and invoice lines
-- Population: every credit line; expected: every line traced, no quantity, price, or total off
WITH Lines AS (
    SELECT cml.CreditMemoLineID, cml.Quantity, cml.UnitPrice,
        cml.Discount, cml.LineTotal, sl.QuantityShipped,
        sil.UnitPrice AS InvoicePrice, sil.Discount AS InvoiceDiscount,
        sil.SalesInvoiceID, cm.OriginalSalesInvoiceID
    FROM CreditMemoLine AS cml
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = cml.CreditMemoID
        INNER JOIN SalesReturnLine AS srl
            ON srl.SalesReturnLineID = cml.SalesReturnLineID
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = srl.ShipmentLineID
        LEFT JOIN SalesInvoiceLine AS sil
            ON sil.ShipmentLineID = sl.ShipmentLineID
)
SELECT COUNT(*) AS CreditLines,
    SUM(CASE WHEN SalesInvoiceID = OriginalSalesInvoiceID
        THEN 1 ELSE 0 END) AS TracedToTheInvoice,
    SUM(CASE WHEN Quantity > QuantityShipped THEN 1 ELSE 0 END)
        AS AboveShipped,
    (SELECT COUNT(*)
     FROM (SELECT ShipmentLineID
           FROM SalesReturnLine
           GROUP BY ShipmentLineID
           HAVING COUNT(*) > 1)) AS ShipmentLinesReturnedTwice,
    SUM(CASE WHEN InvoicePrice IS NULL
        OR ABS(UnitPrice - InvoicePrice) > 0.004
        OR Discount <> InvoiceDiscount THEN 1 ELSE 0 END)
        AS PriceOrDiscountOff,
    SUM(CASE WHEN ABS(LineTotal
        - ROUND(Quantity * UnitPrice * (1 - Discount), 2)) > 0.004
        THEN 1 ELSE 0 END) AS LineTotalOff,
    GROUP_CONCAT(CASE WHEN ABS(LineTotal
        - ROUND(Quantity * UnitPrice * (1 - Discount), 2)) > 0.004
        THEN CreditMemoLineID END) AS LinesOff
FROM Lines;  -- Result: 1 rows

-- Requirement 7, test S2: each credit recomputed: its invoice, lines, tax, freight, and total
-- Population: every credit memo; expected: none above its invoice, tax on SubTotal plus freight
WITH Rate AS (
    SELECT ROUND(SUM(TaxAmount) / SUM(SubTotal + FreightCreditAmount), 3)
        AS TaxRate
    FROM CreditMemo
),
Credits AS (
    SELECT cm.CreditMemoID, cm.OriginalSalesInvoiceID, cm.SubTotal,
        cm.FreightCreditAmount, cm.TaxAmount, cm.GrandTotal,
        si.GrandTotal AS InvoiceTotal, si.FreightAmount AS InvoiceFreight,
        (SELECT SUM(cml.LineTotal)
         FROM CreditMemoLine AS cml
         WHERE cml.CreditMemoID = cm.CreditMemoID) AS LinesTotal
    FROM CreditMemo AS cm
        INNER JOIN SalesInvoice AS si
            ON si.SalesInvoiceID = cm.OriginalSalesInvoiceID
)
SELECT COUNT(*) AS Credits,
    COUNT(DISTINCT OriginalSalesInvoiceID) AS Invoices,
    (SELECT TaxRate FROM Rate) AS TaxRate,
    SUM(CASE WHEN GrandTotal > InvoiceTotal + 0.005 THEN 1 ELSE 0 END)
        AS AboveInvoice,
    SUM(CASE WHEN ABS(SubTotal - LinesTotal) > 0.004 THEN 1 ELSE 0 END)
        AS SubTotalNotLines,
    SUM(CASE WHEN ABS(TaxAmount - ROUND((SubTotal + FreightCreditAmount)
        * (SELECT TaxRate FROM Rate), 2)) > 0.005 THEN 1 ELSE 0 END)
        AS TaxOff,
    SUM(CASE WHEN ABS(TaxAmount - ROUND(SubTotal
        * (SELECT TaxRate FROM Rate), 2)) > 0.011 THEN 1 ELSE 0 END)
        AS TaxOffOnSubTotalAlone,
    SUM(CASE WHEN FreightCreditAmount > 0.005 THEN 1 ELSE 0 END)
        AS WithFreight,
    SUM(CASE WHEN FreightCreditAmount > InvoiceFreight + 0.005
        THEN 1 ELSE 0 END) AS FreightAboveInvoice,
    SUM(CASE WHEN ABS(GrandTotal - SubTotal - FreightCreditAmount
        - TaxAmount) > 0.004 THEN 1 ELSE 0 END) AS TotalNotParts
FROM Credits;  -- Result: 1 rows

-- Requirement 7, test S3: the open items in 2060 at 2026-12-31
-- Population: credits posted to 2060 by the year-end and not refunded by it; expected: G7's last items
WITH Posted AS (
    SELECT gl.SourceDocumentID AS CreditMemoID, SUM(gl.Credit) AS To2060
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    WHERE a.AccountNumber = 2060 AND gl.SourceDocumentType = 'CreditMemo'
        AND gl.PostingDate <= '2026-12-31'
    GROUP BY gl.SourceDocumentID
),
Refunded AS (
    SELECT CreditMemoID, SUM(Amount) AS Refunded
    FROM CustomerRefund
    WHERE RefundDate <= '2026-12-31'
    GROUP BY CreditMemoID
)
SELECT cm.CreditMemoNumber, cm.CreditMemoDate, cm.Status, cm.CustomerID,
    si.InvoiceNumber, ROUND(p.To2060 - COALESCE(rd.Refunded, 0), 2)
        AS OpenIn2060,
    julianday('2026-12-31') - julianday(cm.CreditMemoDate) AS DaysOpen
FROM Posted AS p
    INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = p.CreditMemoID
    INNER JOIN SalesInvoice AS si
        ON si.SalesInvoiceID = cm.OriginalSalesInvoiceID
    LEFT JOIN Refunded AS rd ON rd.CreditMemoID = p.CreditMemoID
WHERE p.To2060 - COALESCE(rd.Refunded, 0) > 0.005
ORDER BY cm.CreditMemoNumber;  -- Result: 3 rows

-- Requirement 7, test S4: what returned goods were put back into inventory at, by reason
-- Population: every return line; expected: standard cost, with no write-down for damaged goods
SELECT sr.ReasonCode, COUNT(*) AS ReturnLines,
    ROUND(SUM(CASE WHEN strftime('%Y', sr.ReturnDate) = '2024'
        THEN srl.ExtendedStandardCost ELSE 0 END), 2) AS Restocked2024,
    ROUND(SUM(CASE WHEN strftime('%Y', sr.ReturnDate) = '2025'
        THEN srl.ExtendedStandardCost ELSE 0 END), 2) AS Restocked2025,
    ROUND(SUM(CASE WHEN strftime('%Y', sr.ReturnDate) = '2026'
        THEN srl.ExtendedStandardCost ELSE 0 END), 2) AS Restocked2026,
    ROUND(SUM(srl.ExtendedStandardCost), 2) AS Restocked,
    ROUND(SUM(ROUND(srl.QuantityReturned * i.StandardCost, 2)), 2)
        AS AtStandardCost,
    SUM(CASE WHEN ABS(srl.ExtendedStandardCost
        - ROUND(srl.QuantityReturned * i.StandardCost, 2)) > 0.011
        THEN 1 ELSE 0 END) AS LinesOffStandard,
    ROUND(SUM(CASE WHEN ABS(srl.ExtendedStandardCost
        - ROUND(srl.QuantityReturned * i.StandardCost, 2)) > 0.011
        THEN ROUND(srl.QuantityReturned * i.StandardCost, 2)
            - srl.ExtendedStandardCost ELSE 0 END), 2) AS BelowStandard
FROM SalesReturnLine AS srl
    INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = srl.SalesReturnID
    INNER JOIN Item AS i ON i.ItemID = srl.ItemID
GROUP BY sr.ReasonCode
ORDER BY Restocked DESC;  -- Result: 5 rows

-- Requirement 7, test S5: lapping: receipts against invoices, deposits, and applications
-- Population: every receipt and application; expected: own customer's invoices, short delays, fully applied
WITH Applied AS (
    SELECT cra.CashReceiptApplicationID, cra.CashReceiptID,
        cra.AppliedAmount, cra.ApplicationDate, cr.ReceiptDate,
        cr.CustomerID AS ReceiptCustomer, si.CustomerID AS InvoiceCustomer,
        si.InvoiceDate
    FROM CashReceiptApplication AS cra
        INNER JOIN CashReceipt AS cr ON cr.CashReceiptID = cra.CashReceiptID
        INNER JOIN SalesInvoice AS si ON si.SalesInvoiceID = cra.SalesInvoiceID
),
AppliedByReceipt AS (
    SELECT CashReceiptID, SUM(AppliedAmount) AS Applied
    FROM CashReceiptApplication
    GROUP BY CashReceiptID
)
SELECT
    (SELECT SUM(CASE WHEN ReceiptCustomer <> InvoiceCustomer
        THEN 1 ELSE 0 END) FROM Applied) AS OtherCustomersInvoice,
    (SELECT MIN(julianday(DepositDate) - julianday(ReceiptDate))
     FROM CashReceipt) AS MinDepositDays,
    (SELECT MAX(julianday(DepositDate) - julianday(ReceiptDate))
     FROM CashReceipt) AS MaxDepositDays,
    (SELECT MIN(julianday(ApplicationDate) - julianday(
        CASE WHEN InvoiceDate > ReceiptDate THEN InvoiceDate
            ELSE ReceiptDate END)) FROM Applied) AS MinApplicationLag,
    (SELECT MAX(julianday(ApplicationDate) - julianday(
        CASE WHEN InvoiceDate > ReceiptDate THEN InvoiceDate
            ELSE ReceiptDate END)) FROM Applied) AS MaxApplicationLag,
    (SELECT COUNT(*)
     FROM CashReceipt AS cr
        LEFT JOIN AppliedByReceipt AS ab
            ON ab.CashReceiptID = cr.CashReceiptID
     WHERE ab.Applied IS NULL OR ABS(cr.Amount - ab.Applied) > 0.005)
        AS NotFullyApplied,
    (SELECT COUNT(DISTINCT CashReceiptID)
     FROM Applied
     WHERE ReceiptDate < InvoiceDate) AS ReceiptsBeforeInvoice,
    (SELECT COUNT(*)
     FROM Applied
     WHERE ReceiptDate < InvoiceDate) AS ApplicationsBeforeInvoice,
    (SELECT ROUND(SUM(AppliedAmount), 2)
     FROM Applied
     WHERE ReceiptDate < InvoiceDate) AS AmountBeforeInvoice;  -- Result: 1 rows

-- Requirement 7, test S6: the largest refund's timeline, from shipment to last receipt, with who acted
-- Population: the refund's credit, return, invoice, shipments, receipts, and clawbacks; expected: no gaps
WITH Refund AS (
    SELECT rf.CustomerRefundID, rf.RefundNumber, rf.RefundDate,
        rf.Amount, rf.PaymentMethod, rf.ApprovedByEmployeeID,
        rf.ClearedDate, cm.CreditMemoID, cm.CreditMemoNumber,
        cm.CreditMemoDate, cm.GrandTotal AS CreditTotal,
        cm.ApprovedByEmployeeID AS CreditApproverID, cm.SalesReturnID,
        cm.OriginalSalesInvoiceID AS SalesInvoiceID
    FROM CustomerRefund AS rf
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
    WHERE rf.Amount = (SELECT MAX(Amount) FROM CustomerRefund)
),
Steps AS (
    SELECT DISTINCT s.ShipmentDate AS StepDate, 1 AS StepOrder,
        'Shipment' AS Step, s.ShipmentNumber AS Document,
        'Shipped by ' || s.ShippedBy || '; delivered ' || s.DeliveryDate
            AS Detail,
        'Warehouse' AS Who
    FROM Refund AS r
        INNER JOIN SalesInvoiceLine AS sil
            ON sil.SalesInvoiceID = r.SalesInvoiceID
        INNER JOIN ShipmentLine AS sl
            ON sl.ShipmentLineID = sil.ShipmentLineID
        INNER JOIN Shipment AS s ON s.ShipmentID = sl.ShipmentID
    UNION ALL
    SELECT si.InvoiceDate, 2, 'Sales invoice', si.InvoiceNumber,
        printf('%.2f', si.GrandTotal) || ', due ' || si.DueDate,
        'Customer ' || si.CustomerID
    FROM Refund AS r
        INNER JOIN SalesInvoice AS si ON si.SalesInvoiceID = r.SalesInvoiceID
    UNION ALL
    SELECT cr.ReceiptDate, 3, 'Cash receipt', cr.ReceiptNumber,
        cr.PaymentMethod || ', ' || printf('%.2f', cra.AppliedAmount)
            || ' applied on ' || cra.ApplicationDate,
        'Recorded by ' || er.JobTitle || ' ' || er.EmployeeID
            || '; applied by ' || ea.JobTitle || ' ' || ea.EmployeeID
    FROM Refund AS r
        INNER JOIN CashReceiptApplication AS cra
            ON cra.SalesInvoiceID = r.SalesInvoiceID
        INNER JOIN CashReceipt AS cr ON cr.CashReceiptID = cra.CashReceiptID
        INNER JOIN Employee AS er ON er.EmployeeID = cr.RecordedByEmployeeID
        INNER JOIN Employee AS ea ON ea.EmployeeID = cra.AppliedByEmployeeID
    UNION ALL
    SELECT sr.ReturnDate, 4, 'Sales return', sr.ReturnNumber,
        sr.ReasonCode,
        'Received by ' || e.JobTitle || ' ' || e.EmployeeID
    FROM Refund AS r
        INNER JOIN SalesReturn AS sr ON sr.SalesReturnID = r.SalesReturnID
        INNER JOIN Employee AS e ON e.EmployeeID = sr.ReceivedByEmployeeID
    UNION ALL
    SELECT r.CreditMemoDate, 5, 'Credit memo', r.CreditMemoNumber,
        printf('%.2f', r.CreditTotal) || '; to 2060 '
            || printf('%.2f', (SELECT COALESCE(SUM(gl.Credit), 0)
                FROM GLEntry AS gl
                    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
                WHERE gl.SourceDocumentType = 'CreditMemo'
                    AND gl.SourceDocumentID = r.CreditMemoID
                    AND a.AccountNumber = 2060))
            || '; invoice unpaid '
            || printf('%.2f', (SELECT si.GrandTotal
                - COALESCE(SUM(cra.AppliedAmount), 0)
                FROM SalesInvoice AS si
                    LEFT JOIN CashReceiptApplication AS cra
                        ON cra.SalesInvoiceID = si.SalesInvoiceID
                        AND cra.ApplicationDate <= r.CreditMemoDate
                WHERE si.SalesInvoiceID = r.SalesInvoiceID)),
        'Approved by ' || e.JobTitle || ' ' || e.EmployeeID
            || ', limit ' || COALESCE(e.MaxApprovalAmount, 0)
    FROM Refund AS r
        INNER JOIN Employee AS e ON e.EmployeeID = r.CreditApproverID
    UNION ALL
    SELECT sca.AdjustmentDate, 6, 'Commission clawback',
        sca.AdjustmentNumber, printf('%.2f', sca.CommissionAdjustmentAmount),
        'Approved by ' || e.JobTitle || ' ' || e.EmployeeID
    FROM Refund AS r
        INNER JOIN SalesCommissionAdjustment AS sca
            ON sca.CreditMemoID = r.CreditMemoID
        INNER JOIN Employee AS e ON e.EmployeeID = sca.ApprovedByEmployeeID
    UNION ALL
    SELECT r.RefundDate, 7, 'Customer refund', r.RefundNumber,
        printf('%.2f', r.Amount) || ' by ' || r.PaymentMethod
            || ' on weekday ' || strftime('%w', r.RefundDate)
            || ' (0 = Sunday); cleared ' || r.ClearedDate,
        'Approved by ' || e.JobTitle || ' ' || e.EmployeeID
            || ', limit ' || COALESCE(e.MaxApprovalAmount, 0)
    FROM Refund AS r
        INNER JOIN Employee AS e ON e.EmployeeID = r.ApprovedByEmployeeID
)
SELECT StepDate, Step, Document, Detail, Who
FROM Steps
ORDER BY StepDate, StepOrder, Document;  -- Result: 10 rows

-- Requirement 10, test E1: the register's four new tests: exceptions, population, and rate per 1,000
-- Population: test T11's exceptions, all credits and refunds; expected: rates the register can follow
WITH LastPayment AS (
    SELECT SalesInvoiceID, MAX(ApplicationDate) AS LastPaymentDate
    FROM CashReceiptApplication
    GROUP BY SalesInvoiceID
),
Tests AS (
    SELECT 'CM AboveLimit' AS TestID,
        CAST(strftime('%Y', cm.CreditMemoDate) AS INTEGER) AS FiscalYear,
        CASE WHEN cm.GrandTotal > COALESCE(e.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END AS Exception
    FROM CreditMemo AS cm
        INNER JOIN Employee AS e ON e.EmployeeID = cm.ApprovedByEmployeeID
    UNION ALL
    SELECT 'CM CashAndCredit',
        CAST(strftime('%Y', cm.CreditMemoDate) AS INTEGER),
        CASE WHEN EXISTS (
                SELECT 1
                FROM CashReceiptApplication AS cra
                WHERE cra.SalesInvoiceID = cm.OriginalSalesInvoiceID
                    AND cra.AppliedByEmployeeID = cm.ApprovedByEmployeeID)
            THEN 1 ELSE 0 END
    FROM CreditMemo AS cm
    UNION ALL
    SELECT 'RF AboveLimit', CAST(strftime('%Y', rf.RefundDate) AS INTEGER),
        CASE WHEN rf.Amount > COALESCE(e.MaxApprovalAmount, 0)
            THEN 1 ELSE 0 END
    FROM CustomerRefund AS rf
        INNER JOIN Employee AS e ON e.EmployeeID = rf.ApprovedByEmployeeID
    UNION ALL
    SELECT 'RF BeforePayment',
        CAST(strftime('%Y', rf.RefundDate) AS INTEGER),
        CASE WHEN lp.LastPaymentDate > rf.RefundDate THEN 1 ELSE 0 END
    FROM CustomerRefund AS rf
        INNER JOIN CreditMemo AS cm ON cm.CreditMemoID = rf.CreditMemoID
        LEFT JOIN LastPayment AS lp
            ON lp.SalesInvoiceID = cm.OriginalSalesInvoiceID
)
SELECT TestID, FiscalYear, COUNT(*) AS Population,
    SUM(Exception) AS Exceptions,
    ROUND(SUM(Exception) * 1000.0 / COUNT(*), 1) AS RatePer1000
FROM Tests
GROUP BY TestID, FiscalYear
ORDER BY TestID, FiscalYear;  -- Result: 12 rows

/* Model answer (Requirement 1)

   The map rests on the records: 612 returns (637 lines), 612 credit memos (632,245.91), 222 refunds
   (216,718.42), 637 clawbacks (10,832.09), 7,409 receipts, and 27,117 applications (M1). Every link holds in
   both directions (M4), every document posts and every posting has its document (M5), and the numbers of each
   series run without gaps and continue across years (M6). M7 shows each document on its own accounts: credits
   debit 4060, 4050, and 2050 and credit 1020 or 2060 (28 credits post to both); returns debit 1040 and credit
   cost of goods sold; refunds move cash out of 2060; receipts and applications pass through 2060.

   What the records evidence at each control point (fig-19-01): the return's receipt in the warehouse (who
   received it and when, M8), the credit's approval (approver and date, equal to the credit date on all 612),
   the refund's approval and clearing, the clawback, and the receipt, deposit, and application of cash. What
   they cannot evidence: the inspection of the goods (C1), the customer's request for a refund, the payee and
   bank account a refund was paid to (C8), any delegation of authority beyond Employee.MaxApprovalAmount, and
   who prepared a credit or a refund (no table records a preparer; test T5).
*/

/* Model answer (Requirement 2)

   Every population reconciles to the ledger to the cent in every year (G1 to G5): the credits' SubTotal
   equals the debits to 4060 (145,655.35, 201,104.38, 242,764.56), their freight 4050, their tax 2050, and
   their totals the credits to 1020 and 2060; the returns' standard cost equals the debits to 1040 and the
   credits to cost of goods sold by account; the refunds equal the credits to cash and the debits to 2060; the
   clawbacks equal the debits to 2034 and the credits to 6290; and the receipts and applications equal the
   cash, 2060, and receivables postings.

   Account 2060 is a hub: tens of millions pass through it each year (G6), while its balance at the year-ends
   is 3,105.75, 1,008.67, 3,413.46. Each balance is credits posted to 2060 and not yet refunded (G7):
   CM-2024-000147 2,641.08, CM-2024-000158 464.67 at the end of 2024; CM-2025-000329, CM-2025-000375,
   CM-2025-000376 at the end of 2025; and the 3 Issued credits CM-2026-000583, CM-2026-000605, CM-2026-000607
   at the end of 2026. Account 2034 holds 48,858.55 at 2026-12-31, the accruals less the payments and
   clawbacks (G8; 18 clawbacks not yet netted in a payment).

   Excluded, and why: the year-end closes, 3 rows on 4060 (589,524.29) and 3 on 6290 (1,650,773.32) (G9),
   which reverse the year's balances rather than record credits or commissions; and the ledger's 2027 rows,
   which hold only supplier payments. Each document is assigned to the year of its own date, the year its
   postings carry.
*/

/* Model answer (Requirement 4)

   Definitions used. Authority: a document above its approver's MaxApprovalAmount (a blank limit read as 0),
   the only authority the records hold; a delegation of authority for credits and refunds, if one exists, is
   outside them. Cash and credit: the credit's approver applied a receipt to the credited invoice (T3;
   recorded or applied, 356). Before payment: the refund is dated before the last application on the credited
   invoice (T6). Past due: on the refund date, an invoice of the customer dated by then, less the applications
   and credits dated by then, still open with its DueDate before the refund date (T10). Method mismatch: no
   receipt applied to the credited invoice used the refund's method.

   Results. 414 credits (421,606.55) exceed their approver's limit, all approved by customer service
   representatives with a limit of 0; 163 refunds (145,938.94) exceed theirs, while the Accounting Manager's
   59 are within limit (T1). No document falls outside its person's employment (T2). The credit's approver
   applied cash to the credited invoice on 206 credits (214,824.39; 44 by the credit date) (T3); no refund
   approver approved the credit, and every return was received in the warehouse by someone other than the
   credit's approver (T4). 58 refunds (71,306.30) precede the customer's last payment, 41 of them before any
   payment (T6); the cause is in T7: 106 of the 225 credits posted to 2060 were posted when nothing had been
   paid, so a refundable balance existed before the cash did. 124 refunds were paid to customers whose past-
   due balance was at least the refund (127,395.76), and 153 went by a method none of the invoice's receipts
   used, an anomaly to follow up (T10). The clawbacks are complete and at the accrual's rate; the 3 amounts T8
   lists are exact half-cent products that SQLite's ROUND, in binary floating point, puts a cent lower, not
   errors. Every refunded credit has exactly one refund equal to its 2060 part (T9).

   The preparer against the approver cannot be tested: neither CreditMemo nor CustomerRefund records a
   preparer, and on their ledger rows GLEntry.CreatedByEmployeeID names the approver every time (1,988 and 444
   rows, T5), as it names the chief executive on every sales invoice row and the CFO on every supplier
   payment: it records the posting convention, not who keyed the document, so it is no evidence of self-
   approval either way. T12 adds the design point: the Accounting Manager approved all 8 commission rates,
   created all 27,933 accruals, approved all 196 commission payments and 8,197 of 8,197 payroll registers, and
   59 refunds, including the largest.
*/

/* Model answer (Requirement 7)

   The balances test clean. Every one of the 637 credit lines traces to its return, shipment, and invoice
   lines, none returns more than was shipped and no shipment line was returned twice, and price and discount
   equal the invoice line's (S1); LineTotal is ROUND(Q x P x (1 - D), 2) except a half-cent on line 84, an
   exact half-cent product. The 612 credits are on as many invoices, none above its invoice, with SubTotal
   equal to the lines and tax at 6.5% of SubTotal plus freight on all of them (S2); a test on SubTotal alone
   would flag the 99 credits with freight. 2060 holds 3 Issued credits at the year-end (S3). Returned goods go
   back at standard cost, with no write-down for damaged goods: Damaged 77,248.17, Damaged and Quality Concern
   137,606.43 (61,146.00 in 2026), a valuation follow-up (S4); 17 lines of less than one unit sit 547.29 below
   standard.

   Lapping (S5): no receipt is applied to another customer's invoice, deposits follow receipts within 2 days,
   every application falls within 2 days of the later of the receipt and invoice dates, and every receipt is
   fully applied; the 491 receipts applied to invoices dated after them are deposits held in 2060, not
   lapping. A first-digit test does not suit these populations, on Chapter 8's criteria: Benford's Law
   describes large populations of amounts that combine many quantities, span several orders of magnitude, and
   have no built-in maximum, while the 612 credits and 222 refunds are too few to judge conformity, their
   amounts are prices set by people times the quantities returned, plus tax, and each credit is capped by its
   invoice.

   Timeline (S6): SH-2025-004100 shipped 2025-04-27 (FedEx Freight), delivered 04-30; SI-2025-008932 dated
   04-30, 18,774.16, due 06-14 (customer 128); CR-2025-003258 05-17, check, 5,692.75 applied (recorded and
   applied by the Customer Service Manager); SR-2025-000255 06-06, Damaged (15.71 of 15.71 FUR-DSK-0071; 2.62
   of 6.86 FUR-CTB-0045), received by a Shipping Clerk; CM-2025-000255 06-09, 17,745.96, the largest credit of
   the three years, approved by representative 115 with a limit of 0, all to 2060 while 13,081.41 of the
   invoice was unpaid; clawbacks SCAJ-2025-000268/269 (321.33 and 11.93); RF-2025-000097 06-15, a Sunday,
   wire, approved by the Accounting Manager (within the 25,000 limit), cleared 06-18; CR-2025-003473 06-17,
   check, 9,891.91 applied (recorded and applied on 06-19 by the Customer Service Manager); CR-2025-003342
   06-18, check, 3,189.50 applied (recorded by representative 97, applied on 06-19 by representative 115, the
   credit's approver); the invoice was settled on 06-19. Disposition: follow up, not a conclusion. Evidence
   outside the database that would settle it: the wire confirmation's beneficiary and account against the
   customer's known bank details; a confirmation from the customer of the credit and the refund; the receiving
   and inspection record and any carrier claim; the customer's written request; and why the refund went by
   wire to a customer who paid this invoice by check, and why before its checks arrived.
*/

/* Notes

   Requirement 1: Map the cycle from its records (Chapters 3, 10, and 12)
   The map comes from the records, not from a description of how the process should work. That takes joins,
      anti-joins, and counts over the cycle's tables and the ledger, which is work for a query.
   In Credits.sql, profile each of the cycle's tables with the tests of Chapter 10's data profile.
   Test every link with anti-joins: return lines to shipment lines, credits to returns and invoices, credit
      lines to return lines, refunds to credits, and clawbacks to credit lines and accruals. Test the document
      numbers for gaps, as Chapter 8 did.
   Build a matrix of the ledger's postings by source document and account, and list who records each document,
      by job title.
   Mark on the figure what the records can evidence at each control point and what they cannot.
   Instructor note: returns 612 (637 lines), 2024-01-25 to 2026-12-24, 162 customers; Credited 390, Refunded
      222; reasons Late Delivery 141, Wrong Item 120, Customer Remorse 119, Damaged 117, Quality Concern 115;
      received by Inventory Specialists 243, Shipping Clerks 240, the Warehouse Manager 129. Credit memos 612
      (637 lines), 2024-01-28 to 2026-12-26: Applied 387 (385,514.61), Refunded 222 (243,317.84), Issued 3
      (3,413.46), total 632,245.91; approved by Customer Service Representatives 414 and the Customer Service
      Manager 198; ApprovedDate equals CreditMemoDate on all 612; 0-3 days after the return (mean 1.4, 175 the
      same day). Refunds 222 (216,718.42), one per refunded credit, 2024-02-17 to 2026-12-22, 2-94 days after
      the credit (mean 11.0; 14 over 30 days), cleared 0-3 days later; approved by Administrative Specialists
      84, Staff Accountants 79, the Accounting Manager 59. Clawbacks 637 (10,832.09), one per credit line,
      same date and approver as the credit. Receipts 7,409 (87,896,623.29) recorded by customer service
      (manager 2,493, representatives 4,916); 27,117 applications, all by customer service. No orphans in any
      direction; numbers run without gaps and continue across years (SR and CM 1-158, 159-390, 391-612; RF
      1-55, 56-139, 140-222; SCAJ 1-167, 168-405, 406-637). Posting matrix (GL rows): CreditMemo Dr 4060 637
      rows 589,524.29, Dr 4050 99 rows 4,133.82, Dr 2050 612 rows 38,587.80, Cr 1020 415 rows 412,114.03, Cr
      2060 225 rows 220,131.88 (28 credits post to both); SalesReturn Dr 1040 325,840.19, Cr 5010-5040;
      CustomerRefund Dr 2060, Cr 1010 216,718.42; SalesCommissionAdjustment Dr 2034, Cr 6290 10,832.09;
      CashReceipt Dr 1010, Cr 2060 (14,818 rows); CashReceiptApplication Dr 2060, Cr 1020 (54,234 rows).
      GLEntry.CreatedByEmployeeID equals the document's approver, recorder, or applier on 100% of the cycle's
      rows (and is the CEO on every SalesInvoice row, the CFO on every DisbursementPayment row), and neither
      CreditMemo nor CustomerRefund has a preparer column: the records cannot show who prepared a credit or a
      refund, which is not evidence of self-approval. No document was recorded by anyone before hire or after
      termination. The records cannot evidence C1's inspection of the goods, C8's payee and account, or the
      customer's request; the generator's AnomalyLog plants nothing in this cycle, so every pattern found here
      comes from how the data were produced, which the notes below name where it matters.

   Requirement 2: Reconcile each population to the ledger (Chapters 8 and 12)
   Every later test assumes that the populations are complete. Two-sided totals by year, without the closes,
      are a query.
   By fiscal year, reconcile the credits to the ledger: their subtotal to 4060, freight to 4050, tax to 2050,
      and their totals to the credits to receivables and 2060. Reconcile the returns' standard cost to
      inventory and to cost of goods sold by account, the refunds to cash and 2060, the clawbacks to 2034 and
      6290, and the receipts and applications to cash and receivables.
   Roll 2060 forward to each year-end and name the items in each balance, and reconcile 2034 at the end of
      fiscal 2026.
   State what you excluded and why.
   Instructor note: credits 158 / 232 / 222; SubTotal = 4060 145,655.35 / 201,104.38 / 242,764.56
      (589,524.29); freight = 4050 1,227.26 / 1,109.93 / 1,796.63; tax = 2050 9,547.39 / 13,143.88 / 15,896.53
      (38,587.80); GrandTotal 156,430.00 / 215,358.19 / 260,457.72 = Cr 1020 108,295.50 / 130,873.42 /
      172,945.11 + Cr 2060 48,134.50 / 84,484.77 / 87,512.61. Returns at standard = 1040 76,390.25 /
      111,321.12 / 138,128.82 (325,840.19); COGS credits 5010 40,502.86 / 73,787.18 / 96,026.14, 5020
      16,781.43 / 17,985.54 / 25,386.87, 5030 13,125.13 / 12,655.71 / 11,366.42, 5040 5,980.83 / 6,892.69 /
      5,349.39. Refunds 55 / 84 / 83 = 45,028.75 / 86,581.85 / 85,107.82 to 1010 and 2060. Clawbacks 2,694.49
      / 3,768.06 / 4,369.54 to 2034 and 6290 (accruals 521,989.10 / 568,898.84 / 570,717.47; payments
      470,066.75 / 566,286.93 / 565,561.09). Receipts = applications = 24,574,608.36 / 31,633,933.20 /
      31,688,081.73, Dr 1010 and Cr 1020. 2060 at the year-ends 3,105.75 (CM-2024-000147 2,641.08;
      CM-2024-000158 464.67) / 1,008.67 (CM-2025-000329, -000375, -000376) / 3,413.46 (Issued CM-2026-000583
      1,503.06, -000605 912.97, -000607 997.43). 2034 at 2026-12-31 48,858.55. Excluded: the closes on 4060 (3
      rows, 589,524.29) and 6290 (3 rows).

   Requirement 3: Assess the risks and set materiality (Chapters 6 and 8)
   A planning workbook keeps its parameters in cells that every later test refers to, which is what Excel is
      for.
   Compute overall materiality under the chief audit executive's condition, performance materiality at 75% of
      it, and a clearly trivial threshold at 5% of it.
   Build an analytical expectation of fiscal 2026 returns from the 2025 return rate (the debits to account
      4060 over the revenue that sales invoices posted to the product and service accounts), and compare it
      with the ledger. Explain why the 2024 rate would make a poorer expectation.
   Brainstorm the fraud risks with @tbl-19-01 and AS 2401's three conditions, mapped to the people and
      documents of the figure.
   Build a risk-and-control matrix: risk, assertion, control point, test, tool, and whether the evidence lies
      in the database or outside it.
   Instructor note: income before income taxes as recorded, 4,503,611.24: materiality 225,180.56, performance
      materiality 168,885.42, clearly trivial 11,259.03. Return rate on revenue (SalesInvoice postings to
      4010-4040 and 4080: 27,313,074.43 / 29,372,768.96 / 29,761,002.45): 0.533% / 0.685% / 0.816%; 2026
      expectation at the 2025 rate 203,762.47 against 242,764.56, a difference of +39,002.09 (+19.1%), above
      clearly trivial and below performance materiality: investigate (Requirement 5). The 2024 rate
      (expectation 158,709.68, +53.0%) understates, because fiscal 2024 had no earlier sales to return. Risk
      ratings: refunds high (cash leaves; a small team approves); credits high (revenue reduction and
      concealment); cash application moderate (lapping); clawbacks low in amount but part of employees' pay. A
      strong matrix sees that customer service records receipts, applies cash, approves credits, and approves
      clawbacks: incompatible duties.

   Requirement 4: Test the controls on every document (Chapters 10 to 12)
   Each test joins a document to the people who handled it and to the cash on the invoice behind it, across
      the whole population. Write each test under a two-line comment, as in Audit.sql, stating its population
      and its expected result.
   Test authority for credits and for refunds against the approver's limit, and the approvers' employment
      dates.
   Test separation of duties: the credit approver against the people who recorded or applied cash on the
      credited invoice, the refund approver against the credit approver, and the person who received the
      return against the credit approver. Try to test the preparer against the approver, and explain why the
      records cannot answer.
   Test whether each refund was paid before the customer's payment on the credited invoice arrived, and
      whether the customer had a past-due balance on the refund date that could have been offset. State the
      definition you use.
   Compare each refund's method with the methods of the receipts on the credited invoice, and test the
      clawbacks for completeness and accuracy and the refunds for one per credit.
   Combine the exceptions in one list by year with UNION ALL, and export the refund flags as RefundFlags.csv.
   Instructor note: credits above the approver's limit 414 / 421,606.55 (104 / 157 / 153 a year) [153 /
      172,307.40], all approved by customer service representatives with a limit of 0; the manager's 25,000 is
      never exceeded. Credit approver also applied cash to the credited invoice: 206 / 214,824.39 (60 / 77 /
      69) [69 / 68,514.82]; on or before the credit date 44 / 42,044.83 [14]; recorded or applied 356 /
      376,965.42. Refunds above the limit 163 / 145,938.94 (Staff Accountants 79 / 71,555.36, Administrative
      Specialists 84 / 74,383.58; 43 / 61 / 59 a year) [59 / 56,131.84]; the Accounting Manager's 59
      (70,779.48) are within limit. Refunds dated before the last payment on the credited invoice 58 /
      71,306.30 (10 / 29 / 19) [19 / 24,893.21]; before any payment 41 / 36,034.57 [14 / 16,670.59]; 28 also
      before the invoice's due date; the payment arrived 1-19 days later (mean 5.6). Cause: credits are split
      between 1020 and 2060 by the invoice's final payments, so 106 of the 225 credits to 2060 were posted
      when nothing had been paid; this is how the records were produced, but the control does not check it.
      Past due at the refund date (as of the refund date: GrandTotal less applications and credits dated by
      then, DueDate before the refund date): 132 / 132,999.46; past due at least the refund 124 / 127,395.76
      [48 / 52,039.44]. Method mismatch 153 / 161,000.36 [56 / 62,483.48]: no customer pays by one method
      only, and a refund method chosen at random across four methods would mismatch about this often, so it is
      an anomaly to follow up, not a rule. Clean: employment dates; refund approver never the credit approver;
      returns always received in the warehouse; one refund per credit, equal to the credit's 2060 part (222 of
      222); a clawback for every credit line (637), base = line total and rate = the accrual's; amount = base
      x rate rounded half up (SQLite's ROUND(base x rate, 2) gives a cent less on SCAJ-2024-000128,
      SCAJ-2025-000347, -000368, exact half-cent products stored just below the half in binary floating
      point); 619 clawbacks netted in later commission payments, 18 pending at the end of 2026. Optional
      design note: the Accounting Manager approved all 8 commission rates (which end 2026-12-31), created all
      27,933 accruals, and approved all 196 commission payments.

   Requirement 6: Sample what the database cannot show (Chapter 8)
   The selection and its evaluation are worksheet work, with the random selection Chapter 8 taught.
   Define three attributes that need evidence outside the database: a written request from the customer, a
      payee checked against the customer master by someone independent, and, for refunds of returns coded
      Damaged, an inspection record of the goods.
   Choose the confidence level, tolerable deviation rate, and expected deviation rate, and take the sample
      size from @tbl-19-03.
   From the refunds of fiscal 2024 to 2026, take the key items in full: every refund of $5,000 or more, and
      every refund to a customer whose refunds over the three years exceed $10,000. Select the rest with
      RANDARRAY and SORTBY, freeze the selection with Paste Values, and record the date and parameters.
   Write the evaluation rule before you test: the upper deviation limit for zero to three deviations.
   Apply the same sample to one attribute the data can test, the refund dated before the customer's payment,
      and compare the sample's conclusion with Requirement 4's result for the whole population.
   The database holds no documents, so you cannot complete the three attributes here. Deliver the sampling
      plan, the frozen selection, and the rule for evaluating it, and do not invent results.
   Instructor note: key items 7 refunds, 31,628.48 (RF-2025-000097, -000109, -000113, -000120, -000134,
      RF-2026-000158, -000218); remainder 215 (185,089.94). Expected parameters 95% / 5% / 0%, so n = 59 (27%
      of 215; the large-population table is conservative). Upper limits at n = 59: 0 deviations 4.95%, 1
      7.79%, 2 10.29%, 3 12.62%; only zero deviations supports reliance at 5%. Data attribute: 52 of the 215
      deviate (24.2%), and 6 of the 7 key items; a sample of 59 expects 14.3, and about 93% of draws give 10
      to 19 (P(X <= 9) = 0.041, P(X <= 19) = 0.967), with upper limits of about 27% at 10, 35% at 14, and 44%
      at 19: every plausible draw concludes the control is ineffective, as the population did. Point: where
      the data allow, a population test replaces the sample; sampling remains for evidence outside the
      database. No document results exist, so the deliverable is the plan, the frozen selection, and the
      decision rule; do not invent results.

   Requirement 7: Test the balances, and follow the largest refund (Chapters 8 and 12)
   Recompute each credit line from its return, shipment, and invoice lines: the quantity no more than was
      shipped, the price and discount equal to the invoice's, and the credits on any invoice no more than its
      total. Recompute the tax and freight on each credit and the amount of each clawback, and list the open
      items in 2060 at the end of 2026.
   Measure what returned goods were put back into inventory at, by reason.
   Test for lapping: receipts applied to another customer's invoices, delays from receipt to deposit and from
      receipt to application, and receipts applied to invoices dated after them. Explain why a first-digit
      test does not suit these populations, using Chapter 8's criteria.
   Build a timeline of the largest refund, from the shipment to the last receipt on its invoice, with who did
      each step. Record a disposition, and list the evidence outside the database that would settle it.
   Instructor note: substantive tests clean: 637 of 637 credit lines trace to their return, shipment, and
      invoice lines; no quantity above shipped and no shipment line returned twice; price and discount equal
      the invoice line's; LineTotal = ROUND(Q x P x (1 - D), 2) except a half-cent on credit line 84; 612
      credits on 612 distinct invoices, none above its invoice; SubTotal = the lines; tax = 6.5% of (SubTotal
      + freight credit) on all 612 (a test on SubTotal alone falsely flags the 99 credits with freight); no
      freight credit above the invoice's freight. Restocked at standard cost, except 17 return lines of less
      than one unit, costed at the quantity times the shipment line's extended cost (547.29 below standard,
      175.48 of it Damaged and Quality Concern): Damaged 77,248.17 (11,606.17 / 25,617.84 / 40,024.16) and
      Damaged plus Quality Concern 137,606.43 (2026: 61,146.00): a valuation follow-up. Lapping clean: no
      application to another customer's invoice; deposits 0-2 days after receipt; every application within 2
      days of the later of receipt and invoice date; every receipt fully applied; 491 receipts (526
      applications, 395,196.29) were applied to invoices dated after the receipt, deposits held in 2060, not
      lapping. First digits: 612 credits and 222 refunds are too few, and their amounts are prices times
      quantities plus tax. Timeline: SH-2025-004100 shipped 2025-04-27 (FedEx Freight), delivered 04-30;
      SI-2025-008932 dated 04-30, 18,774.16, due 06-14 (customer 128); CR-2025-003258 05-17, check, 5,692.75
      applied (recorded and applied by the Customer Service Manager); SR-2025-000255 06-06, Damaged (15.71 of
      15.71 FUR-DSK-0071; 2.62 of 6.86 FUR-CTB-0045), received by a Shipping Clerk; CM-2025-000255 06-09,
      17,745.96, the largest credit of the three years, approved by representative 115 with a limit of 0, all
      to 2060 while 13,081.41 of the invoice was unpaid; clawbacks SCAJ-2025-000268/269 (321.33 and 11.93);
      RF-2025-000097 06-15, a Sunday, wire, approved by the Accounting Manager (within the 25,000 limit),
      cleared 06-18; CR-2025-003473 06-17, check, 9,891.91 applied (recorded and applied on 06-19 by the
      Customer Service Manager); CR-2025-003342 06-18, check, 3,189.50 applied (recorded by representative 97,
      applied on 06-19 by representative 115, the credit's approver); the invoice was settled on 06-19.
      Disposition: follow up, not a conclusion. Evidence: the wire confirmation's beneficiary and account
      against the customer's known bank details; a confirmation from the customer of the credit and the
      refund; the receiving and inspection record and any carrier claim; the customer's written request; why
      the refund went by wire to a customer who paid this invoice by check, and why before its checks arrived.

   Requirement 10: Keep the tests running (Chapter 16)
   The register in Audit Monitoring.pbix already runs the rule tests of Chapters 8 and 12 with every refresh.
      Adding this cycle's rules there, under the change control Chapter 16 described, turns the audit into
      monitoring.
   Add four rule tests to the Tests table: credits above authority, credits approved by someone who handled
      the invoice's cash, refunds above authority, and refunds dated before the customer's payment. Add the
      processes Credit memos and Refunds to the populations.
   Keep the refund method and the missing offset as anomaly tests, outside the register of rules.
   Give the historical exceptions of the new tests one design-finding treatment, as Chapter 16 treated the
      payroll registers' self-approval: record them once, as a single finding about the control's design with
      the date by which it will be fixed, and review only the exceptions dated after that date, so that they
      do not flood the review.
   If you did not build Audit Monitoring.pbix in Chapter 16, build a small register in Credits Analytics.pbix
      instead: a Tests table entered with Enter data, and an exceptions table that appends the documents each
      of the four tests flags.
   Recheck the date through which the register's data run, and record the change.
   Instructor note: exceptions and rates per 1,000 (2024 / 2025 / 2026; three years): CM AboveLimit 414 (104 /
      157 / 153; 658.2 / 676.7 / 689.2; 676.5); CM CashAndCredit 206 (60 / 77 / 69; 379.7 / 331.9 / 310.8;
      336.6); RF AboveLimit 163 (43 / 61 / 59; 781.8 / 726.2 / 710.8; 734.2); RF BeforePayment 58 (10 / 29 /
      19; 181.8 / 345.2 / 228.9; 261.3). Populations: credits 158 / 232 / 222, refunds 55 / 84 / 83. The
      register grows from 151 to 992 rows, (TestID, DocumentNumber) still unique. For BeforePayment, group the
      applications by invoice for the last ApplicationDate and merge it; for CashAndCredit, merge the
      applications and test whether the credit's approver is among their appliers. Data Through stays
      2026-12-18 (payroll); credits end 2026-12-26 and refunds 2026-12-22. After remediation, the two
      authority tests should fall to zero; the other two are the ones that would catch the next case.

   Milestone 1: Plan the audit
   (Requirements 1 to 3): the map of the cycle, the reconciliations, materiality, and the risk-and-control
      matrix.
   Instructor note: 612 returns, 612 credit memos (632,245.91), 222 refunds (216,718.42), 637 clawbacks
      (10,832.09); credit SubTotal equals 4060 in every year (145,655.35 / 201,104.38 / 242,764.56); 2060 at
      the year-ends 3,105.75 / 1,008.67 / 3,413.46; materiality 225,180.56, performance 168,885.42, clearly
      trivial 11,259.03; 2026 expectation at the 2025 rate 203,762.47 against 242,764.56.

   Milestone 2: Test controls and balances
   (Requirements 4 to 7): the control tests, the analytics report, the sampling plan with its frozen
      selection, and the substantive tests and timeline.
   Instructor note: credits above the approver's limit 414 (421,606.55); credit approver also applied cash to
      the invoice 206; refunds above limit 163 (145,938.94); refunds dated before the customer's payment 58
      (71,306.30); key items 7 refunds (31,628.48), sample of 59 from the remaining 215; the largest refund
      RF-2025-000097, 17,745.96, paid while 13,081.41 was unpaid.

   Milestone 3: Evaluate and report
   (Requirements 8 to 10): the evaluation of deficiencies, the report to the committee, and the continuing
      tests.
   Instructor note: two significant deficiencies (credits; refunds), the Accounting Manager's concentration a
      deficiency, no material weakness; register additions 414, 206, 163, and 58 exceptions.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   Requirement 1: tables profiled: 11
   Requirement 1: SalesReturn rows: 612
   Requirement 1: SalesReturn keys unique: 612
   Requirement 1: SalesReturn first date: 2024-01-25
   Requirement 1: SalesReturn last date: 2026-12-24
   Requirement 1: SalesReturn customers: 162
   Requirement 1: SalesReturnLine rows: 637
   Requirement 1: SalesReturnLine keys unique: 637
   Requirement 1: SalesReturnLine amount: 325,840.19
   Requirement 1: CreditMemo rows: 612
   Requirement 1: CreditMemo keys unique: 612
   Requirement 1: CreditMemo first date: 2024-01-28
   Requirement 1: CreditMemo last date: 2026-12-26
   Requirement 1: CreditMemo customers: 162
   Requirement 1: CreditMemo amount: 632,245.91
   Requirement 1: CreditMemoLine rows: 637
   Requirement 1: CreditMemoLine keys unique: 637
   Requirement 1: CreditMemoLine amount: 589,524.29
   Requirement 1: CustomerRefund rows: 222
   Requirement 1: CustomerRefund keys unique: 222
   Requirement 1: CustomerRefund first date: 2024-02-17
   Requirement 1: CustomerRefund last date: 2026-12-22
   Requirement 1: CustomerRefund customers: 103
   Requirement 1: CustomerRefund amount: 216,718.42
   Requirement 1: SalesCommissionAdjustment rows: 637
   Requirement 1: SalesCommissionAdjustment keys unique: 637
   Requirement 1: SalesCommissionAdjustment amount: 10,832.09
   Requirement 1: CashReceipt rows: 7409
   Requirement 1: CashReceipt keys unique: 7409
   Requirement 1: CashReceipt amount: 87,896,623.29
   Requirement 1: CashReceiptApplication rows: 27117
   Requirement 1: CashReceiptApplication keys unique: 27117
   Requirement 1: CashReceiptApplication amount: 87,896,623.29
   Requirement 1: missing keys, dates, or people: 0
   Requirement 1: returns Credited: 390
   Requirement 1: returns Refunded: 222
   Requirement 1: returns Late Delivery: 141
   Requirement 1: returns Wrong Item: 120
   Requirement 1: returns Customer Remorse: 119
   Requirement 1: returns Damaged: 117
   Requirement 1: returns Quality Concern: 115
   Requirement 1: credits Applied: 387
   Requirement 1: credits Applied amount: 385,514.61
   Requirement 1: credits Refunded: 222
   Requirement 1: credits Refunded amount: 243,317.84
   Requirement 1: credits Issued: 3
   Requirement 1: credits Issued amount: 3,413.46
   Requirement 1: refunds by Check: 48
   Requirement 1: refunds by Credit Card: 58
   Requirement 1: refunds by Wire Transfer: 56
   Requirement 1: refunds by ACH: 60
   Requirement 1: return to credit, fewest days: 0
   Requirement 1: return to credit, most days: 3
   Requirement 1: return to credit, mean days: 1.40
   Requirement 1: credits on the day of the return: 175
   Requirement 1: credits approved on their date: 612
   Requirement 1: credit to refund, fewest days: 2
   Requirement 1: credit to refund, most days: 94
   Requirement 1: credit to refund, mean days: 11.00
   Requirement 1: refunds more than 30 days after the credit: 14
   Requirement 1: refund to clearing, fewest days: 0
   Requirement 1: refund to clearing, most days: 3
   Requirement 1: links tested: 15
   Requirement 1: orphans: 0
   Requirement 1: documents traced: 6
   Requirement 1: postings without a document: 0
   Requirement 1: documents not posted: 0
   Requirement 1: series and years: 12
   Requirement 1: gaps: 0
   Requirement 1: repeated numbers: 0
   Requirement 1: breaks between years: 0
   Requirement 1: returns' ranges: 1-158, 159-390, 391-612
   Requirement 1: credits' ranges: 1-158, 159-390, 391-612
   Requirement 1: refunds' ranges: 1-55, 56-139, 140-222
   Requirement 1: clawbacks' ranges: 1-167, 168-405, 406-637
   Requirement 1: credits Cr 1020: 412,114.03
   Requirement 1: credits Cr 1020 rows: 415
   Requirement 1: credits Cr 2060: 220,131.88
   Requirement 1: credits Cr 2060 rows: 225
   Requirement 1: credits Dr 2050: 38,587.80
   Requirement 1: credits Dr 2050 rows: 612
   Requirement 1: credits Dr 4050: 4,133.82
   Requirement 1: credits Dr 4050 rows: 99
   Requirement 1: credits Dr 4060: 589,524.29
   Requirement 1: credits Dr 4060 rows: 637
   Requirement 1: returns Dr 1040: 325,840.19
   Requirement 1: returns Cr cost of goods sold: 325,840.19
   Requirement 1: refunds Cr 1010: 216,718.42
   Requirement 1: refunds Dr 2060: 216,718.42
   Requirement 1: clawbacks Cr 6290: 10,832.09
   Requirement 1: clawbacks Dr 2034: 10,832.09
   Requirement 1: receipt rows: 14818
   Requirement 1: application rows: 54234
   Requirement 1: accounts of the receipts: [1010, 2060]
   Requirement 1: accounts of the applications: [1020, 2060]
   Requirement 1: SalesReturn received by Inventory Specialist: 243
   Requirement 1: SalesReturn received by Shipping Clerk: 240
   Requirement 1: SalesReturn received by Warehouse Manager: 129
   Requirement 1: CreditMemo approved by Customer Service Representative: 414
   Requirement 1: CreditMemo approved by Customer Service Manager: 198
   Requirement 1: CustomerRefund approved by Administrative Specialist: 84
   Requirement 1: CustomerRefund approved by Staff Accountant: 79
   Requirement 1: CustomerRefund approved by Accounting Manager: 59
   Requirement 1: receipts recorded by the Customer Service Manager: 2493
   Requirement 1: receipts recorded by Customer Service Representatives: 4916
   Requirement 1: applications by customer service: 27117
   Requirement 1: returns received in the warehouse: 612
   Requirement 2: years: [2024, 2025, 2026]
   Requirement 2: Credits by year: [158, 232, 222]
   Requirement 2: SubTotal by year: [145655.35, 201104.38, 242764.56]
   Requirement 2: Dr4060 by year: [145655.35, 201104.38, 242764.56]
   Requirement 2: Freight by year: [1227.26, 1109.93, 1796.63]
   Requirement 2: Dr4050 by year: [1227.26, 1109.93, 1796.63]
   Requirement 2: Tax by year: [9547.39, 13143.88, 15896.53]
   Requirement 2: Dr2050 by year: [9547.39, 13143.88, 15896.53]
   Requirement 2: GrandTotal by year: [156430.0, 215358.19, 260457.72]
   Requirement 2: Cr1020 by year: [108295.5, 130873.42, 172945.11]
   Requirement 2: Cr2060 by year: [48134.5, 84484.77, 87512.61]
   Requirement 2: SubTotal less 4060, freight less 4050, tax less 2050: [0.0, 0.0, 0.0]
   Requirement 2: GrandTotal less the credits to 1020 and 2060: [0.0, 0.0, 0.0]
   Requirement 2: Milestone 1: credit SubTotal equals 4060 in every year: [145655.35, 201104.38, 242764.56]
   Requirement 2: returns at standard by year: [76390.25, 111321.12, 138128.82]
   Requirement 2: Dr 1040 by year: [76390.25, 111321.12, 138128.82]
   Requirement 2: differences: [0.0, 0.0, 0.0]
   Requirement 2: Cr 5010 by year: [40502.86, 73787.18, 96026.14]
   Requirement 2: Cr 5020 by year: [16781.43, 17985.54, 25386.87]
   Requirement 2: Cr 5030 by year: [13125.13, 12655.71, 11366.42]
   Requirement 2: Cr 5040 by year: [5980.83, 6892.69, 5349.39]
   Requirement 2: refunds by year: [55, 84, 83]
   Requirement 2: amount by year: [45028.75, 86581.85, 85107.82]
   Requirement 2: Cr 1010 by year: [45028.75, 86581.85, 85107.82]
   Requirement 2: differences: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
   Requirement 2: clawbacks by year: [2694.49, 3768.06, 4369.54]
   Requirement 2: Cr 6290 by year: [2694.49, 3768.06, 4369.54]
   Requirement 2: differences: [0.0, 0.0, 0.0]
   Requirement 2: accruals by year: [521989.1, 568898.84, 570717.47]
   Requirement 2: payments by year: [470066.75, 566286.93, 565561.09]
   Requirement 2: receipts by year: [24574608.36, 31633933.2, 31688081.73]
   Requirement 2: applications by year: [24574608.36, 31633933.2, 31688081.73]
   Requirement 2: Cr 1020 by year: [24574608.36, 31633933.2, 31688081.73]
   Requirement 2: differences: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
   Requirement 2: years: [2024, 2025, 2026]
   Requirement 2: closing balances: [3105.75, 1008.67, 3413.46]
   Requirement 2: balances from the ledger: [3105.75, 1008.67, 3413.46]
   Requirement 2: other postings: [0.0, 0.0, 0.0]
   Requirement 2: opening of the first year: 0.00
   Requirement 2: Milestone 1: 2060 at the year-ends: [3105.75, 1008.67, 3413.46]
   Requirement 2: 2024 items: ['CM-2024-000147', 'CM-2024-000158']
   Requirement 2: 2025 items: ['CM-2025-000329', 'CM-2025-000375', 'CM-2025-000376']
   Requirement 2: 2026 items: ['CM-2026-000583', 'CM-2026-000605', 'CM-2026-000607']
   Requirement 2: 2024 items total the balance: 3,105.75
   Requirement 2: 2025 items total the balance: 1,008.67
   Requirement 2: 2026 items total the balance: 3,413.46
   Requirement 2: CM-2024-000147 open at 2024: 2,641.08
   Requirement 2: CM-2024-000158 open at 2024: 464.67
   Requirement 2: CM-2025-000329 open at 2025: 246.79
   Requirement 2: CM-2025-000375 open at 2025: 372.84
   Requirement 2: CM-2025-000376 open at 2025: 389.04
   Requirement 2: CM-2026-000583 open at 2026: 1,503.06
   Requirement 2: CM-2026-000605 open at 2026: 912.97
   Requirement 2: CM-2026-000607 open at 2026: 997.43
   Requirement 2: 2034 at the year-end: 48,858.55
   Requirement 2: accruals less payments less clawbacks: 48,858.55
   Requirement 2: clawbacks pending at the year-end: 18
   Requirement 2: closes on 4060: 3
   Requirement 2: closes on 4060, amount: 589,524.29
   Requirement 2: closes on 6290: 3
   Requirement 2: closes on 6290, amount: 1,650,773.32
   Requirement 3: revenue by year: [27313074.43, 29372768.96, 29761002.45]
   Requirement 3: rates by year: [0.00533, 0.00685, 0.00816]
   Requirement 3: 2026 returns: 242,764.56
   Requirement 3: 2026 expectation at the 2025 rate: 203,762.47
   Requirement 3: difference: 39,002.09
   Requirement 3: difference as a share of the expectation: 0.19
   Requirement 3: 2026 expectation at the 2024 rate: 158,709.68
   Requirement 3: 2026 returns over the 2024-rate expectation: 0.53
   Requirement 3: 2026 income before income taxes: 4,503,611.24
   Requirement 3: materiality (5%): 225,180.56
   Requirement 3: performance materiality (75%): 168,885.42
   Requirement 3: clearly trivial (5%): 11,259.03
   Requirement 4: document and job title rows: 5
   Requirement 4: CreditMemo by Customer Service Representative: 414
   Requirement 4: CreditMemo by Customer Service Representative, above the limit: 414
   Requirement 4: CreditMemo by Customer Service Representative, amount above the limit: 421,606.55
   Requirement 4: CreditMemo by Customer Service Manager: 198
   Requirement 4: CreditMemo by Customer Service Manager, above the limit: 0
   Requirement 4: CreditMemo by Customer Service Manager, amount above the limit: 0.00
   Requirement 4: CustomerRefund by Staff Accountant: 79
   Requirement 4: CustomerRefund by Staff Accountant, above the limit: 79
   Requirement 4: CustomerRefund by Staff Accountant, amount above the limit: 71,555.36
   Requirement 4: CustomerRefund by Administrative Specialist: 84
   Requirement 4: CustomerRefund by Administrative Specialist, above the limit: 84
   Requirement 4: CustomerRefund by Administrative Specialist, amount above the limit: 74,383.58
   Requirement 4: CustomerRefund by Accounting Manager: 59
   Requirement 4: CustomerRefund by Accounting Manager, above the limit: 0
   Requirement 4: CustomerRefund by Accounting Manager, amount above the limit: 0.00
   Requirement 4: credits above the limit: 414
   Requirement 4: credits above the limit, amount: 421,606.55
   Requirement 4: refunds above the limit: 163
   Requirement 4: refunds above the limit, amount: 145,938.94
   Requirement 4: the credit approvers above their limit (limit 0): [('Customer Service Representative', 0.0)]
   Requirement 4: the Accounting Manager's refunds within limit: (59, 0)
   Requirement 4: the Accounting Manager's refunds, amount: 70,779.48
   Requirement 4: documents outside employment: 0
   Requirement 4: credits whose approver recorded or applied the invoice's cash: 356
   Requirement 4: amount: 376,965.42
   Requirement 4: credits whose approver applied the invoice's cash: 206
   Requirement 4: those credits, amount: 214,824.39
   Requirement 4: by year: [60, 77, 69]
   Requirement 4: 2026 amount: 68,514.82
   Requirement 4: applied on or before the credit date: 44
   Requirement 4: those credits, amount: 42,044.83
   Requirement 4: the credits applied by the approver: ['CM-2024-000006', 'CM-2024-000012', 'CM-2024-000016',
      'CM-2024-000018', 'CM-2024-000019', 'CM-2024-000022', 'CM-2024-000025', 'CM-2024-000026',
      'CM-2024-000027', 'CM-2024-000033', 'CM-2024-000035', 'CM-2024-000040', 'CM-2024-000047',
      'CM-2024-000050', 'CM-2024-000051', 'CM-2024-000056', 'CM-2024-000061', 'CM-2024-000062',
      'CM-2024-000064', 'CM-2024-000067', 'CM-2024-000068', 'CM-2024-000069', 'CM-2024-000074',
      'CM-2024-000075', 'CM-2024-000079', 'CM-2024-000080', 'CM-2024-000081', 'CM-2024-000082',
      'CM-2024-000085', 'CM-2024-000089', 'CM-2024-000092', 'CM-2024-000095', 'CM-2024-000097',
      'CM-2024-000098', 'CM-2024-000100', 'CM-2024-000104', 'CM-2024-000105', 'CM-2024-000106',
      'CM-2024-000114', 'CM-2024-000115', 'CM-2024-000116', 'CM-2024-000117', 'CM-2024-000119',
      'CM-2024-000120', 'CM-2024-000122', 'CM-2024-000123', 'CM-2024-000124', 'CM-2024-000126',
      'CM-2024-000127', 'CM-2024-000135', 'CM-2024-000136', 'CM-2024-000140', 'CM-2024-000141',
      'CM-2024-000144', 'CM-2024-000146', 'CM-2024-000148', 'CM-2024-000150', 'CM-2024-000155',
      'CM-2024-000156', 'CM-2024-000157', 'CM-2025-000159', 'CM-2025-000164', 'CM-2025-000165',
      'CM-2025-000166', 'CM-2025-000169', 'CM-2025-000171', 'CM-2025-000173', 'CM-2025-000176',
      'CM-2025-000178', 'CM-2025-000184', 'CM-2025-000186', 'CM-2025-000190', 'CM-2025-000191',
      'CM-2025-000198', 'CM-2025-000204', 'CM-2025-000205', 'CM-2025-000207', 'CM-2025-000208',
      'CM-2025-000209', 'CM-2025-000212', 'CM-2025-000214', 'CM-2025-000215', 'CM-2025-000219',
      'CM-2025-000222', 'CM-2025-000223', 'CM-2025-000231', 'CM-2025-000232', 'CM-2025-000234',
      'CM-2025-000235', 'CM-2025-000239', 'CM-2025-000240', 'CM-2025-000243', 'CM-2025-000247',
      'CM-2025-000252', 'CM-2025-000253', 'CM-2025-000255', 'CM-2025-000256', 'CM-2025-000257',
      'CM-2025-000259', 'CM-2025-000261', 'CM-2025-000263', 'CM-2025-000265', 'CM-2025-000270',
      'CM-2025-000276', 'CM-2025-000277', 'CM-2025-000278', 'CM-2025-000282', 'CM-2025-000284',
      'CM-2025-000287', 'CM-2025-000288', 'CM-2025-000297', 'CM-2025-000299', 'CM-2025-000302',
      'CM-2025-000305', 'CM-2025-000308', 'CM-2025-000309', 'CM-2025-000316', 'CM-2025-000319',
      'CM-2025-000324', 'CM-2025-000327', 'CM-2025-000332', 'CM-2025-000333', 'CM-2025-000335',
      'CM-2025-000339', 'CM-2025-000350', 'CM-2025-000358', 'CM-2025-000359', 'CM-2025-000360',
      'CM-2025-000361', 'CM-2025-000363', 'CM-2025-000367', 'CM-2025-000369', 'CM-2025-000371',
      'CM-2025-000380', 'CM-2025-000381', 'CM-2025-000383', 'CM-2025-000390', 'CM-2026-000391',
      'CM-2026-000396', 'CM-2026-000397', 'CM-2026-000400', 'CM-2026-000402', 'CM-2026-000403',
      'CM-2026-000405', 'CM-2026-000406', 'CM-2026-000408', 'CM-2026-000409', 'CM-2026-000410',
      'CM-2026-000412', 'CM-2026-000413', 'CM-2026-000417', 'CM-2026-000422', 'CM-2026-000423',
      'CM-2026-000427', 'CM-2026-000437', 'CM-2026-000438', 'CM-2026-000439', 'CM-2026-000442',
      'CM-2026-000455', 'CM-2026-000461', 'CM-2026-000462', 'CM-2026-000463', 'CM-2026-000466',
      'CM-2026-000470', 'CM-2026-000471', 'CM-2026-000473', 'CM-2026-000475', 'CM-2026-000477',
      'CM-2026-000485', 'CM-2026-000486', 'CM-2026-000487', 'CM-2026-000488', 'CM-2026-000493',
      'CM-2026-000498', 'CM-2026-000501', 'CM-2026-000512', 'CM-2026-000514', 'CM-2026-000515',
      'CM-2026-000517', 'CM-2026-000518', 'CM-2026-000524', 'CM-2026-000527', 'CM-2026-000528',
      'CM-2026-000534', 'CM-2026-000542', 'CM-2026-000548', 'CM-2026-000549', 'CM-2026-000554',
      'CM-2026-000559', 'CM-2026-000562', 'CM-2026-000563', 'CM-2026-000566', 'CM-2026-000567',
      'CM-2026-000572', 'CM-2026-000574', 'CM-2026-000575', 'CM-2026-000576', 'CM-2026-000581',
      'CM-2026-000586', 'CM-2026-000588', 'CM-2026-000592', 'CM-2026-000593', 'CM-2026-000594',
      'CM-2026-000595', 'CM-2026-000605', 'CM-2026-000607']
   Requirement 4: early ones: 44
   Requirement 4: early ones in 2026: 14
   Requirement 4: refunds approved by the credit's approver: 0
   Requirement 4: returns received by the credit's approver: 0
   Requirement 4: returns received outside the warehouse: 0
   Requirement 4: SalesReturn rows created by the person the document names: 1274
   Requirement 4: CreditMemo rows created by the person the document names: 1988
   Requirement 4: CustomerRefund rows created by the person the document names: 444
   Requirement 4: SalesCommissionAdjustment rows created by the person the document names: 1274
   Requirement 4: CashReceipt rows created by the person the document names: 14818
   Requirement 4: CashReceiptApplication rows created by the person the document names: 54234
   Requirement 4: SalesReturn rows: 1274
   Requirement 4: CreditMemo rows: 1988
   Requirement 4: CustomerRefund rows: 444
   Requirement 4: SalesCommissionAdjustment rows: 1274
   Requirement 4: CashReceipt rows: 14818
   Requirement 4: CashReceiptApplication rows: 54234
   Requirement 4: sales invoice rows created by: ['none: Chief Executive Officer', 1]
   Requirement 4: supplier payment rows created by: ['none: Chief Financial Officer', 1]
   Requirement 4: refunds before the payment: 58
   Requirement 4: amount: 71,306.30
   Requirement 4: by year: [10, 29, 19]
   Requirement 4: 2026 amount: 24,893.21
   Requirement 4: before any payment: 41
   Requirement 4: before any payment, amount: 36,034.57
   Requirement 4: before any payment in 2026: [14, 16670.59]
   Requirement 4: also before the due date: 28
   Requirement 4: fewest days until paid: 1
   Requirement 4: most days until paid: 19
   Requirement 4: mean days until paid: 5.60
   Requirement 4: credits: 612
   Requirement 4: credits to 2060: 225
   Requirement 4: credits to both: 28
   Requirement 4: credits to 2060 with nothing paid: 106
   Requirement 4: exceptions (half-cent products only): 3
   Requirement 4: the clawbacks SQLite's ROUND puts a cent lower: ['SCAJ-2024-000128', 'SCAJ-2025-000347',
      'SCAJ-2025-000368']
   Requirement 4: each a cent above SQLite's ROUND: [0.01, 0.01, 0.01]
   Requirement 4: each an exact half-cent product: [0.5, 0.5, 0.5]
   Requirement 4: refunds: 222
   Requirement 4: credits refunded: 222
   Requirement 4: credits with status Refunded: 222
   Requirement 4: refunds equal to the credit's 2060 part: 222
   Requirement 4: refunds: 222
   Requirement 4: every refund's five flags and score equal the notes' definitions: True
   Requirement 4: refunds above the limit: 163
   Requirement 4: refunds of credits above the limit: 151
   Requirement 4: method mismatch: 153
   Requirement 4: method mismatch, amount: 161,000.36
   Requirement 4: method mismatch in 2026: 56
   Requirement 4: before payment: 58
   Requirement 4: past due on the refund date: 132
   Requirement 4: past due on the refund date, refunds' amount: 132,999.46
   Requirement 4: past due at least the refund: 124
   Requirement 4: past due at least the refund, amount: 127,395.76
   Requirement 4: past due at least the refund in 2026: [48, 52039.44]
   Requirement 4: scores 0 to 5: [4, 18, 53, 83, 44, 20]
   Requirement 4: refunds scoring 4 or 5, amount: 80,776.86
   Requirement 4: exceptions: 841
   Requirement 4: tests: ['CM AboveLimit', 'CM CashAndCredit', 'RF AboveLimit', 'RF BeforePayment']
   Requirement 4: each test and document once: 841
   Requirement 4: CM AboveLimit documents: ['CM-2024-000001', 'CM-2024-000003', 'CM-2024-000004',
      'CM-2024-000005', 'CM-2024-000007', 'CM-2024-000008', 'CM-2024-000009', 'CM-2024-000010',
      'CM-2024-000013', 'CM-2024-000014', 'CM-2024-000016', 'CM-2024-000017', 'CM-2024-000018',
      'CM-2024-000019', 'CM-2024-000021', 'CM-2024-000022', 'CM-2024-000024', 'CM-2024-000025',
      'CM-2024-000026', 'CM-2024-000028', 'CM-2024-000029', 'CM-2024-000030', 'CM-2024-000032',
      'CM-2024-000033', 'CM-2024-000034', 'CM-2024-000036', 'CM-2024-000037', 'CM-2024-000038',
      'CM-2024-000042', 'CM-2024-000043', 'CM-2024-000045', 'CM-2024-000048', 'CM-2024-000049',
      'CM-2024-000050', 'CM-2024-000051', 'CM-2024-000052', 'CM-2024-000053', 'CM-2024-000054',
      'CM-2024-000055', 'CM-2024-000056', 'CM-2024-000057', 'CM-2024-000058', 'CM-2024-000061',
      'CM-2024-000065', 'CM-2024-000066', 'CM-2024-000067', 'CM-2024-000068', 'CM-2024-000071',
      'CM-2024-000072', 'CM-2024-000073', 'CM-2024-000075', 'CM-2024-000076', 'CM-2024-000077',
      'CM-2024-000083', 'CM-2024-000084', 'CM-2024-000087', 'CM-2024-000088', 'CM-2024-000091',
      'CM-2024-000093', 'CM-2024-000094', 'CM-2024-000096', 'CM-2024-000097', 'CM-2024-000098',
      'CM-2024-000099', 'CM-2024-000100', 'CM-2024-000101', 'CM-2024-000102', 'CM-2024-000105',
      'CM-2024-000106', 'CM-2024-000107', 'CM-2024-000108', 'CM-2024-000109', 'CM-2024-000111',
      'CM-2024-000113', 'CM-2024-000114', 'CM-2024-000116', 'CM-2024-000117', 'CM-2024-000118',
      'CM-2024-000119', 'CM-2024-000120', 'CM-2024-000121', 'CM-2024-000123', 'CM-2024-000124',
      'CM-2024-000127', 'CM-2024-000130', 'CM-2024-000132', 'CM-2024-000133', 'CM-2024-000134',
      'CM-2024-000135', 'CM-2024-000136', 'CM-2024-000137', 'CM-2024-000138', 'CM-2024-000140',
      'CM-2024-000141', 'CM-2024-000142', 'CM-2024-000144', 'CM-2024-000145', 'CM-2024-000148',
      'CM-2024-000149', 'CM-2024-000150', 'CM-2024-000151', 'CM-2024-000154', 'CM-2024-000155',
      'CM-2024-000156', 'CM-2025-000159', 'CM-2025-000160', 'CM-2025-000161', 'CM-2025-000163',
      'CM-2025-000165', 'CM-2025-000166', 'CM-2025-000167', 'CM-2025-000169', 'CM-2025-000170',
      'CM-2025-000172', 'CM-2025-000174', 'CM-2025-000175', 'CM-2025-000176', 'CM-2025-000177',
      'CM-2025-000178', 'CM-2025-000179', 'CM-2025-000181', 'CM-2025-000183', 'CM-2025-000184',
      'CM-2025-000185', 'CM-2025-000187', 'CM-2025-000189', 'CM-2025-000190', 'CM-2025-000191',
      'CM-2025-000192', 'CM-2025-000193', 'CM-2025-000195', 'CM-2025-000196', 'CM-2025-000197',
      'CM-2025-000198', 'CM-2025-000199', 'CM-2025-000201', 'CM-2025-000202', 'CM-2025-000203',
      'CM-2025-000205', 'CM-2025-000206', 'CM-2025-000207', 'CM-2025-000211', 'CM-2025-000212',
      'CM-2025-000213', 'CM-2025-000215', 'CM-2025-000216', 'CM-2025-000217', 'CM-2025-000219',
      'CM-2025-000221', 'CM-2025-000222', 'CM-2025-000223', 'CM-2025-000226', 'CM-2025-000227',
      'CM-2025-000228', 'CM-2025-000229', 'CM-2025-000230', 'CM-2025-000231', 'CM-2025-000233',
      'CM-2025-000234', 'CM-2025-000236', 'CM-2025-000238', 'CM-2025-000239', 'CM-2025-000240',
      'CM-2025-000241', 'CM-2025-000243', 'CM-2025-000244', 'CM-2025-000245', 'CM-2025-000246',
      'CM-2025-000249', 'CM-2025-000250', 'CM-2025-000251', 'CM-2025-000254', 'CM-2025-000255',
      'CM-2025-000260', 'CM-2025-000261', 'CM-2025-000263', 'CM-2025-000265', 'CM-2025-000267',
      'CM-2025-000268', 'CM-2025-000269', 'CM-2025-000270', 'CM-2025-000271', 'CM-2025-000272',
      'CM-2025-000273', 'CM-2025-000274', 'CM-2025-000276', 'CM-2025-000277', 'CM-2025-000278',
      'CM-2025-000279', 'CM-2025-000281', 'CM-2025-000282', 'CM-2025-000283', 'CM-2025-000284',
      'CM-2025-000285', 'CM-2025-000286', 'CM-2025-000288', 'CM-2025-000289', 'CM-2025-000290',
      'CM-2025-000291', 'CM-2025-000292', 'CM-2025-000293', 'CM-2025-000295', 'CM-2025-000296',
      'CM-2025-000297', 'CM-2025-000298', 'CM-2025-000300', 'CM-2025-000301', 'CM-2025-000302',
      'CM-2025-000303', 'CM-2025-000304', 'CM-2025-000308', 'CM-2025-000309', 'CM-2025-000312',
      'CM-2025-000313', 'CM-2025-000315', 'CM-2025-000316', 'CM-2025-000317', 'CM-2025-000320',
      'CM-2025-000321', 'CM-2025-000322', 'CM-2025-000323', 'CM-2025-000324', 'CM-2025-000326',
      'CM-2025-000328', 'CM-2025-000329', 'CM-2025-000330', 'CM-2025-000332', 'CM-2025-000333',
      'CM-2025-000335', 'CM-2025-000336', 'CM-2025-000337', 'CM-2025-000338', 'CM-2025-000341',
      'CM-2025-000342', 'CM-2025-000343', 'CM-2025-000344', 'CM-2025-000348', 'CM-2025-000349',
      'CM-2025-000350', 'CM-2025-000351', 'CM-2025-000354', 'CM-2025-000356', 'CM-2025-000360',
      'CM-2025-000361', 'CM-2025-000366', 'CM-2025-000368', 'CM-2025-000369', 'CM-2025-000370',
      'CM-2025-000371', 'CM-2025-000373', 'CM-2025-000374', 'CM-2025-000376', 'CM-2025-000378',
      'CM-2025-000380', 'CM-2025-000381', 'CM-2025-000382', 'CM-2025-000385', 'CM-2025-000386',
      'CM-2025-000387', 'CM-2025-000388', 'CM-2025-000390', 'CM-2026-000391', 'CM-2026-000392',
      'CM-2026-000393', 'CM-2026-000396', 'CM-2026-000397', 'CM-2026-000398', 'CM-2026-000399',
      'CM-2026-000401', 'CM-2026-000402', 'CM-2026-000403', 'CM-2026-000406', 'CM-2026-000407',
      'CM-2026-000408', 'CM-2026-000410', 'CM-2026-000411', 'CM-2026-000412', 'CM-2026-000413',
      'CM-2026-000416', 'CM-2026-000417', 'CM-2026-000418', 'CM-2026-000419', 'CM-2026-000420',
      'CM-2026-000422', 'CM-2026-000423', 'CM-2026-000424', 'CM-2026-000425', 'CM-2026-000426',
      'CM-2026-000429', 'CM-2026-000430', 'CM-2026-000431', 'CM-2026-000434', 'CM-2026-000436',
      'CM-2026-000437', 'CM-2026-000440', 'CM-2026-000442', 'CM-2026-000447', 'CM-2026-000450',
      'CM-2026-000451', 'CM-2026-000452', 'CM-2026-000453', 'CM-2026-000454', 'CM-2026-000457',
      'CM-2026-000458', 'CM-2026-000459', 'CM-2026-000460', 'CM-2026-000461', 'CM-2026-000463',
      'CM-2026-000464', 'CM-2026-000465', 'CM-2026-000466', 'CM-2026-000467', 'CM-2026-000468',
      'CM-2026-000469', 'CM-2026-000470', 'CM-2026-000471', 'CM-2026-000472', 'CM-2026-000473',
      'CM-2026-000475', 'CM-2026-000476', 'CM-2026-000477', 'CM-2026-000478', 'CM-2026-000480',
      'CM-2026-000481', 'CM-2026-000483', 'CM-2026-000484', 'CM-2026-000486', 'CM-2026-000487',
      'CM-2026-000489', 'CM-2026-000490', 'CM-2026-000492', 'CM-2026-000493', 'CM-2026-000496',
      'CM-2026-000498', 'CM-2026-000499', 'CM-2026-000501', 'CM-2026-000506', 'CM-2026-000507',
      'CM-2026-000510', 'CM-2026-000511', 'CM-2026-000512', 'CM-2026-000513', 'CM-2026-000514',
      'CM-2026-000516', 'CM-2026-000517', 'CM-2026-000518', 'CM-2026-000519', 'CM-2026-000520',
      'CM-2026-000524', 'CM-2026-000525', 'CM-2026-000526', 'CM-2026-000530', 'CM-2026-000532',
      'CM-2026-000533', 'CM-2026-000535', 'CM-2026-000537', 'CM-2026-000538', 'CM-2026-000539',
      'CM-2026-000540', 'CM-2026-000541', 'CM-2026-000543', 'CM-2026-000544', 'CM-2026-000546',
      'CM-2026-000547', 'CM-2026-000548', 'CM-2026-000549', 'CM-2026-000550', 'CM-2026-000551',
      'CM-2026-000552', 'CM-2026-000553', 'CM-2026-000555', 'CM-2026-000556', 'CM-2026-000557',
      'CM-2026-000558', 'CM-2026-000559', 'CM-2026-000560', 'CM-2026-000562', 'CM-2026-000563',
      'CM-2026-000564', 'CM-2026-000566', 'CM-2026-000567', 'CM-2026-000568', 'CM-2026-000569',
      'CM-2026-000570', 'CM-2026-000572', 'CM-2026-000573', 'CM-2026-000574', 'CM-2026-000576',
      'CM-2026-000579', 'CM-2026-000580', 'CM-2026-000581', 'CM-2026-000583', 'CM-2026-000584',
      'CM-2026-000585', 'CM-2026-000586', 'CM-2026-000587', 'CM-2026-000588', 'CM-2026-000590',
      'CM-2026-000593', 'CM-2026-000594', 'CM-2026-000595', 'CM-2026-000596', 'CM-2026-000597',
      'CM-2026-000598', 'CM-2026-000599', 'CM-2026-000600', 'CM-2026-000601', 'CM-2026-000604',
      'CM-2026-000605', 'CM-2026-000606', 'CM-2026-000608', 'CM-2026-000609', 'CM-2026-000610',
      'CM-2026-000611']
   Requirement 4: CM AboveLimit by year: [104, 157, 153]
   Requirement 4: CM AboveLimit amount: 421,606.55
   Requirement 4: CM CashAndCredit documents: ['CM-2024-000006', 'CM-2024-000012', 'CM-2024-000016',
      'CM-2024-000018', 'CM-2024-000019', 'CM-2024-000022', 'CM-2024-000025', 'CM-2024-000026',
      'CM-2024-000027', 'CM-2024-000033', 'CM-2024-000035', 'CM-2024-000040', 'CM-2024-000047',
      'CM-2024-000050', 'CM-2024-000051', 'CM-2024-000056', 'CM-2024-000061', 'CM-2024-000062',
      'CM-2024-000064', 'CM-2024-000067', 'CM-2024-000068', 'CM-2024-000069', 'CM-2024-000074',
      'CM-2024-000075', 'CM-2024-000079', 'CM-2024-000080', 'CM-2024-000081', 'CM-2024-000082',
      'CM-2024-000085', 'CM-2024-000089', 'CM-2024-000092', 'CM-2024-000095', 'CM-2024-000097',
      'CM-2024-000098', 'CM-2024-000100', 'CM-2024-000104', 'CM-2024-000105', 'CM-2024-000106',
      'CM-2024-000114', 'CM-2024-000115', 'CM-2024-000116', 'CM-2024-000117', 'CM-2024-000119',
      'CM-2024-000120', 'CM-2024-000122', 'CM-2024-000123', 'CM-2024-000124', 'CM-2024-000126',
      'CM-2024-000127', 'CM-2024-000135', 'CM-2024-000136', 'CM-2024-000140', 'CM-2024-000141',
      'CM-2024-000144', 'CM-2024-000146', 'CM-2024-000148', 'CM-2024-000150', 'CM-2024-000155',
      'CM-2024-000156', 'CM-2024-000157', 'CM-2025-000159', 'CM-2025-000164', 'CM-2025-000165',
      'CM-2025-000166', 'CM-2025-000169', 'CM-2025-000171', 'CM-2025-000173', 'CM-2025-000176',
      'CM-2025-000178', 'CM-2025-000184', 'CM-2025-000186', 'CM-2025-000190', 'CM-2025-000191',
      'CM-2025-000198', 'CM-2025-000204', 'CM-2025-000205', 'CM-2025-000207', 'CM-2025-000208',
      'CM-2025-000209', 'CM-2025-000212', 'CM-2025-000214', 'CM-2025-000215', 'CM-2025-000219',
      'CM-2025-000222', 'CM-2025-000223', 'CM-2025-000231', 'CM-2025-000232', 'CM-2025-000234',
      'CM-2025-000235', 'CM-2025-000239', 'CM-2025-000240', 'CM-2025-000243', 'CM-2025-000247',
      'CM-2025-000252', 'CM-2025-000253', 'CM-2025-000255', 'CM-2025-000256', 'CM-2025-000257',
      'CM-2025-000259', 'CM-2025-000261', 'CM-2025-000263', 'CM-2025-000265', 'CM-2025-000270',
      'CM-2025-000276', 'CM-2025-000277', 'CM-2025-000278', 'CM-2025-000282', 'CM-2025-000284',
      'CM-2025-000287', 'CM-2025-000288', 'CM-2025-000297', 'CM-2025-000299', 'CM-2025-000302',
      'CM-2025-000305', 'CM-2025-000308', 'CM-2025-000309', 'CM-2025-000316', 'CM-2025-000319',
      'CM-2025-000324', 'CM-2025-000327', 'CM-2025-000332', 'CM-2025-000333', 'CM-2025-000335',
      'CM-2025-000339', 'CM-2025-000350', 'CM-2025-000358', 'CM-2025-000359', 'CM-2025-000360',
      'CM-2025-000361', 'CM-2025-000363', 'CM-2025-000367', 'CM-2025-000369', 'CM-2025-000371',
      'CM-2025-000380', 'CM-2025-000381', 'CM-2025-000383', 'CM-2025-000390', 'CM-2026-000391',
      'CM-2026-000396', 'CM-2026-000397', 'CM-2026-000400', 'CM-2026-000402', 'CM-2026-000403',
      'CM-2026-000405', 'CM-2026-000406', 'CM-2026-000408', 'CM-2026-000409', 'CM-2026-000410',
      'CM-2026-000412', 'CM-2026-000413', 'CM-2026-000417', 'CM-2026-000422', 'CM-2026-000423',
      'CM-2026-000427', 'CM-2026-000437', 'CM-2026-000438', 'CM-2026-000439', 'CM-2026-000442',
      'CM-2026-000455', 'CM-2026-000461', 'CM-2026-000462', 'CM-2026-000463', 'CM-2026-000466',
      'CM-2026-000470', 'CM-2026-000471', 'CM-2026-000473', 'CM-2026-000475', 'CM-2026-000477',
      'CM-2026-000485', 'CM-2026-000486', 'CM-2026-000487', 'CM-2026-000488', 'CM-2026-000493',
      'CM-2026-000498', 'CM-2026-000501', 'CM-2026-000512', 'CM-2026-000514', 'CM-2026-000515',
      'CM-2026-000517', 'CM-2026-000518', 'CM-2026-000524', 'CM-2026-000527', 'CM-2026-000528',
      'CM-2026-000534', 'CM-2026-000542', 'CM-2026-000548', 'CM-2026-000549', 'CM-2026-000554',
      'CM-2026-000559', 'CM-2026-000562', 'CM-2026-000563', 'CM-2026-000566', 'CM-2026-000567',
      'CM-2026-000572', 'CM-2026-000574', 'CM-2026-000575', 'CM-2026-000576', 'CM-2026-000581',
      'CM-2026-000586', 'CM-2026-000588', 'CM-2026-000592', 'CM-2026-000593', 'CM-2026-000594',
      'CM-2026-000595', 'CM-2026-000605', 'CM-2026-000607']
   Requirement 4: CM CashAndCredit by year: [60, 77, 69]
   Requirement 4: CM CashAndCredit amount: 214,824.39
   Requirement 4: RF AboveLimit documents: ['RF-2024-000001', 'RF-2024-000002', 'RF-2024-000003',
      'RF-2024-000004', 'RF-2024-000005', 'RF-2024-000007', 'RF-2024-000008', 'RF-2024-000009',
      'RF-2024-000010', 'RF-2024-000011', 'RF-2024-000012', 'RF-2024-000013', 'RF-2024-000015',
      'RF-2024-000016', 'RF-2024-000019', 'RF-2024-000020', 'RF-2024-000021', 'RF-2024-000024',
      'RF-2024-000025', 'RF-2024-000026', 'RF-2024-000028', 'RF-2024-000030', 'RF-2024-000031',
      'RF-2024-000032', 'RF-2024-000033', 'RF-2024-000034', 'RF-2024-000036', 'RF-2024-000037',
      'RF-2024-000038', 'RF-2024-000039', 'RF-2024-000041', 'RF-2024-000042', 'RF-2024-000043',
      'RF-2024-000044', 'RF-2024-000045', 'RF-2024-000046', 'RF-2024-000047', 'RF-2024-000049',
      'RF-2024-000050', 'RF-2024-000051', 'RF-2024-000053', 'RF-2024-000054', 'RF-2024-000055',
      'RF-2025-000056', 'RF-2025-000057', 'RF-2025-000058', 'RF-2025-000059', 'RF-2025-000060',
      'RF-2025-000061', 'RF-2025-000062', 'RF-2025-000063', 'RF-2025-000065', 'RF-2025-000066',
      'RF-2025-000068', 'RF-2025-000069', 'RF-2025-000070', 'RF-2025-000071', 'RF-2025-000072',
      'RF-2025-000073', 'RF-2025-000074', 'RF-2025-000075', 'RF-2025-000078', 'RF-2025-000079',
      'RF-2025-000080', 'RF-2025-000082', 'RF-2025-000083', 'RF-2025-000084', 'RF-2025-000087',
      'RF-2025-000090', 'RF-2025-000091', 'RF-2025-000092', 'RF-2025-000093', 'RF-2025-000094',
      'RF-2025-000096', 'RF-2025-000098', 'RF-2025-000100', 'RF-2025-000101', 'RF-2025-000102',
      'RF-2025-000104', 'RF-2025-000105', 'RF-2025-000107', 'RF-2025-000108', 'RF-2025-000109',
      'RF-2025-000110', 'RF-2025-000112', 'RF-2025-000113', 'RF-2025-000114', 'RF-2025-000115',
      'RF-2025-000116', 'RF-2025-000117', 'RF-2025-000122', 'RF-2025-000123', 'RF-2025-000125',
      'RF-2025-000126', 'RF-2025-000127', 'RF-2025-000128', 'RF-2025-000129', 'RF-2025-000131',
      'RF-2025-000132', 'RF-2025-000133', 'RF-2025-000134', 'RF-2025-000135', 'RF-2025-000137',
      'RF-2025-000138', 'RF-2026-000140', 'RF-2026-000142', 'RF-2026-000143', 'RF-2026-000144',
      'RF-2026-000145', 'RF-2026-000146', 'RF-2026-000148', 'RF-2026-000149', 'RF-2026-000150',
      'RF-2026-000151', 'RF-2026-000152', 'RF-2026-000154', 'RF-2026-000155', 'RF-2026-000156',
      'RF-2026-000159', 'RF-2026-000161', 'RF-2026-000163', 'RF-2026-000164', 'RF-2026-000166',
      'RF-2026-000167', 'RF-2026-000170', 'RF-2026-000171', 'RF-2026-000172', 'RF-2026-000173',
      'RF-2026-000174', 'RF-2026-000175', 'RF-2026-000176', 'RF-2026-000177', 'RF-2026-000178',
      'RF-2026-000182', 'RF-2026-000183', 'RF-2026-000184', 'RF-2026-000186', 'RF-2026-000187',
      'RF-2026-000188', 'RF-2026-000189', 'RF-2026-000190', 'RF-2026-000192', 'RF-2026-000193',
      'RF-2026-000194', 'RF-2026-000196', 'RF-2026-000197', 'RF-2026-000199', 'RF-2026-000201',
      'RF-2026-000202', 'RF-2026-000204', 'RF-2026-000205', 'RF-2026-000207', 'RF-2026-000208',
      'RF-2026-000212', 'RF-2026-000213', 'RF-2026-000214', 'RF-2026-000215', 'RF-2026-000216',
      'RF-2026-000217', 'RF-2026-000218', 'RF-2026-000220', 'RF-2026-000221', 'RF-2026-000222']
   Requirement 4: RF AboveLimit by year: [43, 61, 59]
   Requirement 4: RF AboveLimit amount: 145,938.94
   Requirement 4: RF BeforePayment documents: ['RF-2024-000001', 'RF-2024-000002', 'RF-2024-000004',
      'RF-2024-000007', 'RF-2024-000011', 'RF-2024-000012', 'RF-2024-000033', 'RF-2024-000036',
      'RF-2024-000047', 'RF-2024-000052', 'RF-2025-000057', 'RF-2025-000059', 'RF-2025-000063',
      'RF-2025-000064', 'RF-2025-000065', 'RF-2025-000066', 'RF-2025-000074', 'RF-2025-000075',
      'RF-2025-000080', 'RF-2025-000081', 'RF-2025-000084', 'RF-2025-000085', 'RF-2025-000086',
      'RF-2025-000087', 'RF-2025-000088', 'RF-2025-000094', 'RF-2025-000095', 'RF-2025-000096',
      'RF-2025-000097', 'RF-2025-000103', 'RF-2025-000105', 'RF-2025-000112', 'RF-2025-000113',
      'RF-2025-000118', 'RF-2025-000119', 'RF-2025-000120', 'RF-2025-000134', 'RF-2025-000135',
      'RF-2025-000136', 'RF-2026-000142', 'RF-2026-000143', 'RF-2026-000152', 'RF-2026-000154',
      'RF-2026-000158', 'RF-2026-000167', 'RF-2026-000180', 'RF-2026-000182', 'RF-2026-000188',
      'RF-2026-000196', 'RF-2026-000202', 'RF-2026-000203', 'RF-2026-000204', 'RF-2026-000205',
      'RF-2026-000206', 'RF-2026-000208', 'RF-2026-000218', 'RF-2026-000219', 'RF-2026-000221']
   Requirement 4: RF BeforePayment by year: [10, 29, 19]
   Requirement 4: RF BeforePayment amount: 71,306.30
   Requirement 4: CM AboveLimit in 2026: [153, 172307.4]
   Requirement 4: CM CashAndCredit in 2026: [69, 68514.82]
   Requirement 4: RF AboveLimit in 2026: [59, 56131.84]
   Requirement 4: RF BeforePayment in 2026: [19, 24893.21]
   Requirement 4: Milestone 2: credits above the approver's limit: 414
   Requirement 4: Milestone 2: credit approver applied the invoice's cash: 206
   Requirement 4: Milestone 2: refunds above the limit: 163
   Requirement 4: Milestone 2: refunds before the customer's payment: 58
   Requirement 4: Milestone 3: register additions by test: [414, 206, 163, 58]
   Requirement 4: commission rates: [8, 8]
   Requirement 4: accruals: [27933, 27933]
   Requirement 4: commission payments: [196, 196]
   Requirement 4: refunds: [222, 59]
   Requirement 4: payroll registers: [8197, 8197]
   Requirement 6: key items: 7
   Requirement 6: key items, amount: 31,628.48
   Requirement 6: key items before payment: 6
   Requirement 6: remainder: 215
   Requirement 6: remainder, amount: 185,089.94
   Requirement 6: remainder before payment: 52
   Requirement 6: the key items: ['RF-2025-000097', 'RF-2025-000109', 'RF-2025-000113', 'RF-2025-000120',
      'RF-2025-000134', 'RF-2026-000158', 'RF-2026-000218']
   Requirement 6: their amount: 31,628.48
   Requirement 7: credit lines: 637
   Requirement 7: traced: 637
   Requirement 7: above shipped: 0
   Requirement 7: returned twice: 0
   Requirement 7: price or discount off: 0
   Requirement 7: line totals off (half-cent roundings): 1
   Requirement 7: the lines: 84
   Requirement 7: credits: 612
   Requirement 7: distinct invoices: 612
   Requirement 7: tax rate: 0.07
   Requirement 7: above the invoice: 0
   Requirement 7: SubTotal not the lines: 0
   Requirement 7: tax off: 0
   Requirement 7: a test on SubTotal alone flags the credits with freight: 99
   Requirement 7: credits with freight: 99
   Requirement 7: freight above the invoice's: 0
   Requirement 7: totals not their parts: 0
   Requirement 7: open items: ['CM-2026-000583', 'CM-2026-000605', 'CM-2026-000607']
   Requirement 7: their amounts: [1503.06, 912.97, 997.43]
   Requirement 7: their status: ['Issued', 'Issued', 'Issued']
   Requirement 7: the balance of 2060: 3,413.46
   Requirement 7: Damaged by year: [11606.17, 25617.84, 40024.16]
   Requirement 7: Damaged: 77,248.17
   Requirement 7: Damaged and Quality Concern: 137,606.43
   Requirement 7: Damaged and Quality Concern in 2026: 61,146.00
   Requirement 7: lines restocked off standard: 17
   Requirement 7: below standard by: 547.29
   Requirement 7: of which Damaged and Quality Concern: 175.48
   Requirement 7: all returns restocked: 325,840.19
   Requirement 7: applications to another customer's invoice: 0
   Requirement 7: fewest days to deposit: 0
   Requirement 7: most days to deposit: 2
   Requirement 7: fewest days to application: 0
   Requirement 7: most days to application: 2
   Requirement 7: receipts not fully applied: 0
   Requirement 7: receipts applied to later invoices: 491
   Requirement 7: those applications: 526
   Requirement 7: those amounts: 395,196.29
   Requirement 7: the largest refund: RF-2025-000097
   Requirement 7: its date: 2025-06-15
   Requirement 7: its amount and method: 17745.96 by Wire Transfer
   Requirement 7: its weekday: True
   Requirement 7: its approver: Accounting Manager 5
   Requirement 7: the credit: CM-2025-000255
   Requirement 7: the credit's approver: Customer Service Representative 115
   Requirement 7: the credit all to 2060: 17745.96
   Requirement 7: unpaid on the credit date: 13081.41
   Requirement 7: the invoice: SI-2025-008932
   Requirement 7: the return: SR-2025-000255
   Requirement 7: the return's reason: Damaged
   Requirement 7: the shipments: ['SH-2025-004100']
   Requirement 7: the receipts: ['CR-2025-003258', 'CR-2025-003342', 'CR-2025-003473']
   Requirement 7: the clawbacks: ['SCAJ-2025-000268', 'SCAJ-2025-000269']
   Requirement 7: the last payment after the refund: True
   Requirement 7: first step: SH-2025-004100
   Requirement 7: the steps in date order: [('2025-04-27', 'Shipment', 'SH-2025-004100'), ('2025-04-30',
      'Sales invoice', 'SI-2025-008932'), ('2025-05-17', 'Cash receipt', 'CR-2025-003258'), ('2025-06-06',
      'Sales return', 'SR-2025-000255'), ('2025-06-09', 'Credit memo', 'CM-2025-000255'), ('2025-06-09',
      'Commission clawback', 'SCAJ-2025-000268'), ('2025-06-09', 'Commission clawback', 'SCAJ-2025-000269'),
      ('2025-06-15', 'Customer refund', 'RF-2025-000097'), ('2025-06-17', 'Cash receipt', 'CR-2025-003473'),
      ('2025-06-18', 'Cash receipt', 'CR-2025-003342')]
   Requirement 7: the shipments' carriers and delivery dates: ['Shipped by FedEx Freight; delivered
      2025-04-30']
   Requirement 7: the invoice's total and due date: 18774.16, due 2025-06-14
   Requirement 7: the customer: Customer 128
   Requirement 7: the receipts' amounts applied and their dates: [('CR-2025-003258', '5692.75', '2025-05-17'),
      ('CR-2025-003342', '3189.50', '2025-06-19'), ('CR-2025-003473', '9891.91', '2025-06-19')]
   Requirement 7: the return's receiver: Shipping Clerk 110
   Requirement 7: the refund's clearing date: 2025-06-18
   Requirement 10: rows: 12
   Requirement 10: CM AboveLimit by year: [104, 157, 153]
   Requirement 10: CM AboveLimit rates per 1,000: [658.2, 676.7, 689.2]
   Requirement 10: CM CashAndCredit by year: [60, 77, 69]
   Requirement 10: CM CashAndCredit rates per 1,000: [379.7, 331.9, 310.8]
   Requirement 10: RF AboveLimit by year: [43, 61, 59]
   Requirement 10: RF AboveLimit rates per 1,000: [781.8, 726.2, 710.8]
   Requirement 10: RF BeforePayment by year: [10, 29, 19]
   Requirement 10: RF BeforePayment rates per 1,000: [181.8, 345.2, 228.9]
   Requirement 10: credit populations: [158, 232, 222]
   Requirement 10: refund populations: [55, 84, 83]
   Requirement 10: rows the register adds: 841
*/
