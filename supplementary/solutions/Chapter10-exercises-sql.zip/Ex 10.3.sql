/* Ex 10.3.sql: average order value by customer
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: 5,819 orders from 211 customers; grouping by name merges Brown LLC into one row */

-- Requirement (1): orders and average order value by customer
-- Population: SalesOrder, every order; expected: 211 customers, Glenn-Estrada first
SELECT c.CustomerID, c.CustomerName, c.CustomerSegment,
    COUNT(*) AS Orders,
    ROUND(SUM(so.OrderTotal), 2) AS TotalOrdered,
    ROUND(AVG(so.OrderTotal), 2) AS AverageOrder
FROM SalesOrder AS so
    INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
GROUP BY c.CustomerID, c.CustomerName, c.CustomerSegment
ORDER BY AverageOrder DESC;  -- Result: 211 rows

-- Requirement (1): all orders, the customers who placed them, and the average
-- Population: SalesOrder; expected: 5,819 orders, 211 customers, average 15,036.96
SELECT COUNT(*) AS Orders,
    COUNT(DISTINCT CustomerID) AS Customers,
    ROUND(AVG(OrderTotal), 2) AS AverageOrder
FROM SalesOrder;  -- Result: 1 row (Orders = 5819, Customers = 211, AverageOrder = 15036.96)

-- Requirement (1): the customers in the master file
-- Population: Customer; expected: 220, so 9 have no orders
SELECT COUNT(*) AS Customers
FROM Customer;  -- Result: 1 row (Customers = 220)

-- Requirement (2): the same analysis grouped by CustomerName
-- Population: as (1); expected: 210 rows, one fewer than (1)
SELECT c.CustomerName, COUNT(*) AS Orders,
    ROUND(SUM(so.OrderTotal), 2) AS TotalOrdered,
    ROUND(AVG(so.OrderTotal), 2) AS AverageOrder
FROM SalesOrder AS so
    INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
GROUP BY c.CustomerName
ORDER BY AverageOrder DESC;  -- Result: 210 rows

-- Requirement (2): names that cover more than one customer with orders
-- Population: as (1); expected: Brown LLC, 2 customers
SELECT c.CustomerName,
    COUNT(DISTINCT c.CustomerID) AS Customers,
    COUNT(*) AS Orders
FROM SalesOrder AS so
    INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
GROUP BY c.CustomerName
HAVING COUNT(DISTINCT c.CustomerID) > 1;  -- Result: 1 row (CustomerName = Brown LLC, Customers = 2, Orders = 71)

-- Requirement (2): every customer whose name another customer shares, with its orders
-- Population: Customer, shared names; expected: 4 customers, Smith Ltd with orders only on customer 170
SELECT c.CustomerID, c.CustomerName, c.CustomerSegment,
    COUNT(so.SalesOrderID) AS Orders,
    ROUND(AVG(so.OrderTotal), 2) AS AverageOrder
FROM Customer AS c
    LEFT JOIN SalesOrder AS so ON so.CustomerID = c.CustomerID
WHERE c.CustomerName IN (
    SELECT CustomerName
    FROM Customer
    GROUP BY CustomerName
    HAVING COUNT(*) > 1
)
GROUP BY c.CustomerID, c.CustomerName, c.CustomerSegment
ORDER BY c.CustomerName, c.CustomerID;  -- Result: 4 rows

-- Requirement (3): the ten highest averages among customers with at least 20 orders
-- Population: as (1), HAVING 20 orders or more; expected: Glenn-Estrada first
SELECT c.CustomerID, c.CustomerName, c.CustomerSegment,
    COUNT(*) AS Orders,
    ROUND(AVG(so.OrderTotal), 2) AS AverageOrder
FROM SalesOrder AS so
    INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
GROUP BY c.CustomerID, c.CustomerName, c.CustomerSegment
HAVING COUNT(*) >= 20
ORDER BY AverageOrder DESC
LIMIT 10;  -- Result: 10 rows

-- Requirement (4): orders and average order value by segment
-- Population: as (1); expected: 5 segments, Strategic highest
SELECT c.CustomerSegment, COUNT(*) AS Orders,
    COUNT(DISTINCT c.CustomerID) AS Customers,
    ROUND(AVG(so.OrderTotal), 2) AS AverageOrder
FROM SalesOrder AS so
    INNER JOIN Customer AS c ON c.CustomerID = so.CustomerID
GROUP BY c.CustomerSegment
ORDER BY AverageOrder DESC;  -- Result: 5 rows

/* Model answer (Requirement (5), note for the sales manager)

   Order size differs sharply by segment: Strategic 1,136 orders averaging 23,386.13; Wholesale 2,771 orders
   averaging 15,993.96; Design Services 239 orders averaging 14,742.20; Design Trade 956 orders averaging
   10,062.99; Small Business 717 orders averaging 4,840.43. A Strategic order averages about 4.8 times a Small
   Business order, so the segment mix matters as much as the number of orders. Across all 5,819 orders the
   average is 15,036.96, and the customers with the largest orders are Glenn-Estrada (26,202.95 over 54
   orders), Miller-Hernandez and Eaton, Robertson and Grant.

   Requirement (1) groups by CustomerID because the key identifies a customer and the name does not: grouping
   by name returns 210 rows instead of 211, because two different customers are named Brown LLC, customer 5
   (Design Trade, 20 orders averaging 10,258.01) and customer 173 (Strategic, 51 orders averaging 24,276.43).
   By name they merge into one row of 71 orders averaging 20,327.58, which describes neither customer. (Smith
   Ltd is also shared, but only customer 170 has orders, so it does not merge here.)
*/

/* Notes

   Exercise 10.3: Average Order Value by Customer
   (1) Join SalesOrder to Customer and calculate, for each customer, the number of orders, the total
      OrderTotal, and the average order value, grouped by CustomerID. Sort by average order value from the
      largest down.
   (2) Repeat requirement (1) grouped by CustomerName instead of CustomerID. Compare the number of rows, and
      find the customer names that appear in more than one row of requirement (1).
   (3) Use HAVING to keep only the customers with at least 20 orders, and list the ten with the highest
      average order value.
   (4) Calculate the number of orders and the average order value by CustomerSegment.
   (5) Write two or three sentences for the sales manager on how order size differs by segment, and explain
      why the grouping in requirement (1) is the right one.
   Instructor note: 5,819 orders from 211 customers (9 customers have none); overall average order value
      15,036.96. Highest averages: customer 136 Glenn-Estrada (54 orders, 26,202.95), 169 Miller-Hernandez
      (50, 25,394.03), 78 Eaton, Robertson and Grant (44, 25,350.26). Grouping by name returns one row fewer:
      the two Brown LLCs, customer 5 (Design Trade, 20 orders, average 10,258.01) and customer 173 (Strategic,
      51 orders, 24,276.43), merge into one row of 71 orders averaging 20,327.58. (The two Smith Ltd customers
      do not merge in this query, because only customer 170 has orders.) By segment: Strategic 1,136 orders,
      23,386.13; Wholesale 2,771, 15,993.96; Design Services 239, 14,742.20; Design Trade 956, 10,062.99;
      Small Business 717, 4,840.43.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   10.3: customers: 211
   10.3: orders: 5819
   10.3: rank 1: (136, 'Glenn-Estrada', 54, 26202.95)
   10.3: rank 2: (169, 'Miller-Hernandez', 50, 25394.03)
   10.3: rank 3: (78, 'Eaton, Robertson and Grant', 44, 25350.26)
   10.3: orders: 5819
   10.3: customers with orders: 211
   10.3: average order: 15,036.96
   10.3: customers: 220
   10.3: customers without orders: 9
   10.3: rows: 210
   10.3: rows fewer than (1): 1
   10.3: Brown LLC orders: 71
   10.3: Brown LLC average: 20,327.58
   10.3: names: ['Brown LLC']
   10.3: customers: 2
   10.3: orders: 71
   10.3: customers and orders: [(5, 'Brown LLC', 20), (173, 'Brown LLC', 51), (170, 'Smith Ltd', 11), (220,
      'Smith Ltd', 0)]
   10.3: customer 5: ('Design Trade', 20, 10258.01)
   10.3: customer 173: ('Strategic', 51, 24276.43)
   10.3: the ten customers: [136, 169, 78, 208, 138, 20, 161, 173, 141, 51]
   10.3: fewest orders among them (at least 20): True
   10.3: segments in order: ['Strategic', 'Wholesale', 'Design Services', 'Design Trade', 'Small Business']
   10.3: Strategic: (1136, 21, 23386.13)
   10.3: Wholesale: (2771, 79, 15993.96)
   10.3: Design Services: (239, 19, 14742.2)
   10.3: Design Trade: (956, 41, 10062.99)
   10.3: Small Business: (717, 51, 4840.43)
*/
