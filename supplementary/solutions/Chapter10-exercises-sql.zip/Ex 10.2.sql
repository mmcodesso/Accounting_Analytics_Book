/* Ex 10.2.sql: tracing a sale from the ledger to its documents
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: SI-2025-007947 posts four balanced rows; 9,525 fiscal 2026 SourceLineIDs tested, none orphaned */

-- Requirement (1): the ledger rows posted by SI-2025-007947
-- Population: GLEntry, SalesInvoice 7947; expected: four rows on 2025-03-05
SELECT gl.GLEntryID, gl.PostingDate, a.AccountNumber,
    a.AccountName, gl.Debit, gl.Credit, gl.SourceLineID,
    gl.Description
FROM GLEntry AS gl
    INNER JOIN SalesInvoice AS si
        ON gl.SourceDocumentType = 'SalesInvoice'
        AND si.SalesInvoiceID = gl.SourceDocumentID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE si.InvoiceNumber = 'SI-2025-007947'
ORDER BY gl.GLEntryID;  -- Result: 4 rows

-- Requirement (1): debits against credits and the invoice's total
-- Population: as above; expected: debits = credits = GrandTotal = 787.48
SELECT si.InvoiceNumber, si.SubTotal, si.FreightAmount,
    si.TaxAmount, si.GrandTotal,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
    INNER JOIN SalesInvoice AS si
        ON gl.SourceDocumentType = 'SalesInvoice'
        AND si.SalesInvoiceID = gl.SourceDocumentID
WHERE si.InvoiceNumber = 'SI-2025-007947'
GROUP BY si.SalesInvoiceID, si.InvoiceNumber, si.SubTotal,
    si.FreightAmount, si.TaxAmount, si.GrandTotal;  -- Result: 1 rows

-- Requirement (1): the trap, ledger rows whose SourceDocumentID is 7947 in any document
-- Population: GLEntry; expected: 38 rows from 11 document types
SELECT COUNT(*) AS Postings,
    COUNT(DISTINCT SourceDocumentType) AS DocumentTypes
FROM GLEntry
WHERE SourceDocumentID = 7947;  -- Result: 1 row (Postings = 38, DocumentTypes = 11)

-- Requirement (2): SI-2025-007947 with its customer, lines and items
-- Population: SalesInvoice 7947; expected: customer 135, 1 line
SELECT si.InvoiceNumber, si.InvoiceDate, c.CustomerID,
    c.CustomerName, sil.SalesInvoiceLineID, i.ItemCode,
    i.ItemName, sil.Quantity, sil.UnitPrice, sil.LineTotal
FROM SalesInvoice AS si
    INNER JOIN Customer AS c ON c.CustomerID = si.CustomerID
    INNER JOIN SalesInvoiceLine AS sil
        ON sil.SalesInvoiceID = si.SalesInvoiceID
    INNER JOIN Item AS i ON i.ItemID = sil.ItemID
WHERE si.InvoiceNumber = 'SI-2025-007947';  -- Result: 1 rows

-- Requirement (2): the revenue posting joined to its invoice line through SourceLineID
-- Population: GLEntry, SalesInvoice 7947, rows with a SourceLineID; expected: GLEntry 126312 and line 10645
SELECT gl.GLEntryID, gl.SourceLineID, sil.SalesInvoiceLineID,
    i.ItemName, sil.LineTotal, gl.Credit
FROM GLEntry AS gl
    INNER JOIN SalesInvoiceLine AS sil
        ON sil.SalesInvoiceLineID = gl.SourceLineID
    INNER JOIN Item AS i ON i.ItemID = sil.ItemID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND gl.SourceDocumentID = 7947;  -- Result: 1 rows

-- Requirement (3): the fiscal 2026 SalesInvoice postings that carry a SourceLineID
-- Population: GLEntry, SalesInvoice, fiscal 2026; expected: 9,525 postings to test
SELECT COUNT(*) AS PostingsTested
FROM GLEntry
WHERE SourceDocumentType = 'SalesInvoice'
    AND FiscalYear = 2026
    AND SourceLineID IS NOT NULL;  -- Result: 1 row (PostingsTested = 9525)

-- Requirement (3): anti-join, postings whose SourceLineID matches no invoice line
-- Population: the 9,525 postings above; expected: no rows
SELECT gl.GLEntryID, gl.PostingDate, gl.VoucherNumber,
    gl.SourceLineID, gl.Credit
FROM GLEntry AS gl
    LEFT JOIN SalesInvoiceLine AS sil
        ON sil.SalesInvoiceLineID = gl.SourceLineID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND gl.FiscalYear = 2026
    AND gl.SourceLineID IS NOT NULL
    AND sil.SalesInvoiceLineID IS NULL;  -- Result: 0 rows

-- Requirement (3), an added test: postings whose line belongs to another invoice
-- Population: the 9,525 postings above; expected: no rows
SELECT gl.GLEntryID, gl.SourceDocumentID, gl.SourceLineID,
    sil.SalesInvoiceID
FROM GLEntry AS gl
    INNER JOIN SalesInvoiceLine AS sil
        ON sil.SalesInvoiceLineID = gl.SourceLineID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND gl.FiscalYear = 2026
    AND sil.SalesInvoiceID <> gl.SourceDocumentID;  -- Result: 0 rows

-- Requirement (3): the accounts of the postings with no SourceLineID
-- Population: GLEntry, SalesInvoice, fiscal 2026; expected: 1020, 2050 and 4050
SELECT a.AccountNumber, a.AccountName, COUNT(*) AS Postings
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND gl.FiscalYear = 2026
    AND gl.SourceLineID IS NULL
GROUP BY a.AccountID, a.AccountNumber, a.AccountName
ORDER BY a.AccountNumber;  -- Result: 3 rows

/* Model answer (Requirement (1))

   SI-2025-007947 (SalesInvoiceID 7947, dated 2025-03-05, customer 135 Sullivan-Mcdonald) posts four rows on
   2025-03-05: GLEntry 126311 debits 1020 Accounts Receivable 787.48; GLEntry 126312 credits 4010 Sales
   Revenue - Furniture 688.42; GLEntry 126313 credits 4050 Freight Revenue 51.00; GLEntry 126314 credits 2050
   Sales Tax Payable 48.06. The debit records the receivable for the GrandTotal; the credits record the
   revenue (SubTotal), the freight billed, and the sales tax owed. Debits 787.48 equal credits 787.48 and the
   GrandTotal (SubTotal 688.42 + freight 51.00 + tax 48.06). The join must name SourceDocumentType =
   'SalesInvoice' in its ON clause: SourceDocumentID 7947 alone appears in 38 rows of 11 document types.
*/

/* Model answer (Requirement (4), memo)

   Every ledger row records the document that caused it: SourceDocumentType names the table, SourceDocumentID
   the document's key in it, and SourceLineID the line, where the posting comes from one. Joining on the type
   and the ID together moves from a posting to its document, and joining the document's lines and master data
   (customer, item) shows what was sold; the same keys, read the other way, find every posting a document
   made, so an auditor can vouch from the ledger to the documents and trace from the documents to the ledger.

   For SI-2025-007947, the four rows balance and equal the invoice's GrandTotal, and the revenue row's
   SourceLineID 10645 is the invoice's line (Alder Desk Ash Whitewash 84 in, 2 units at 344.21). Requirement
   (3) extends the trace to the whole year: all 9,525 SalesInvoice postings of fiscal 2026 that carry a
   SourceLineID point to an existing invoice line (the anti-join returns no rows), and each line belongs to
   the invoice the posting names. The header-level rows (receivable, freight, tax) carry no SourceLineID by
   design. The test proves that the line-level revenue postings are supported by invoice lines; it does not
   prove that every invoice line was posted, which needs the reverse anti-join, or that the amounts agree.
*/

/* Notes

   Exercise 10.2: Tracing a Sale from the Ledger to Its Documents
   (1) List the ledger rows posted by SI-2025-007947, joining GLEntry to SalesInvoice on the source document
      and to Account for the account numbers and names. Explain what each row records and show that the debits
      equal the credits.
   (2) Join the invoice to its customer and its lines to their items, and identify the line whose
      SalesInvoiceLineID equals the SourceLineID of the revenue posting.
   (3) For every SalesInvoice posting of fiscal 2026 that carries a SourceLineID, use an anti-join to find the
      postings whose SourceLineID matches no invoice line. Report the number of postings tested and the number
      of exceptions.
   (4) Write a short memo (one half page) explaining how the source-document columns let an auditor move from
      the ledger to the documents and back, and what requirement (3) proves.
   Instructor note: SI-2025-007947 (SalesInvoiceID 7947, dated 2025-03-05, customer 135 Sullivan-Mcdonald)
      posts four rows on 2025-03-05: GLEntry 126311 debit 787.48 to 1020 Accounts Receivable; 126312 credit
      688.42 to 4010 Sales Revenue - Furniture with SourceLineID 10645; 126313 credit 51.00 to 4050 Freight
      Revenue; 126314 credit 48.06 to 2050 Sales Tax Payable. Debits 787.48 = credits 787.48 = GrandTotal
      (SubTotal 688.42, freight 51.00, tax 48.06). Line 10645 is the Alder Desk Ash Whitewash 84 in, 2 units
      at 344.21. Requirement (3): 9,525 SalesInvoice postings of fiscal 2026 carry a SourceLineID, and none is
      orphaned (the anti-join returns no rows); the header-level rows (receivable, freight, tax) have no
      SourceLineID. Trap: a join on SourceDocumentID alone returns 38 rows from 11 document types for ID 7947;
      the join must also require SourceDocumentType = 'SalesInvoice'.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   10.2: rows: 4
   10.2: posting dates: ['2025-03-05']
   10.2: GLEntry 126311: (1020, 787.48, 'debit')
   10.2: GLEntry 126312: (4010, 688.42, 'credit')
   10.2: GLEntry 126313: (4050, 51.0, 'credit')
   10.2: GLEntry 126314: (2050, 48.06, 'credit')
   10.2: SourceLineID of the revenue row: 10645
   10.2: debits: 787.48
   10.2: credits: 787.48
   10.2: GrandTotal: 787.48
   10.2: SubTotal: 688.42
   10.2: FreightAmount: 51.00
   10.2: TaxAmount: 48.06
   10.2: rows: 38
   10.2: document types: 11
   10.2: lines: 1
   10.2: invoice date: 2025-03-05
   10.2: customer: (135, 'Sullivan-Mcdonald')
   10.2: line 10645 item: Alder Desk Ash Whitewash 84 in
   10.2: line 10645 quantity: 2.00
   10.2: line 10645 unit price: 344.21
   10.2: rows: 1
   10.2: GLEntryID: 126312
   10.2: SalesInvoiceLineID: 10645
   10.2: LineTotal equals the credit: 688.42
   10.2: credit: 688.42
   10.2: postings tested: 9525
   10.2: orphaned SourceLineIDs: 0
   10.2: lines on another invoice: 0
   10.2: header-level accounts: [1020, 2050, 4050]
*/
