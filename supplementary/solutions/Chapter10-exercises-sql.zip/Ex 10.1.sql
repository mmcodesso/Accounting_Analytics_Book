/* Ex 10.1.sql: reconciling invoice lines to the ledger
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: the join keeps all 27,933 lines; fiscal 2026 lines + 4,582.37 of cutoff invoices = ledger revenue */

-- Requirement (1): the invoice lines with their invoices, items and customers
-- Population: SalesInvoiceLine, every line; expected: 27,933 rows, one per line
SELECT sil.SalesInvoiceLineID, si.InvoiceNumber, si.InvoiceDate,
    c.CustomerName, i.ItemCode, i.ItemGroup, sil.LineTotal
FROM SalesInvoiceLine AS sil
    INNER JOIN SalesInvoice AS si
        ON si.SalesInvoiceID = sil.SalesInvoiceID
    INNER JOIN Item AS i ON i.ItemID = sil.ItemID
    INNER JOIN Customer AS c ON c.CustomerID = si.CustomerID;  -- Result: 27933 rows

-- Requirement (1): the number of invoice lines, to test the join
-- Population: SalesInvoiceLine; expected: 27,933, the rows of the join
SELECT COUNT(*) AS InvoiceLines
FROM SalesInvoiceLine;  -- Result: 1 row (InvoiceLines = 27933)

-- Requirement (2): fiscal 2026 invoice lines by item group
-- Population: lines of invoices dated in 2026; expected: 5 groups, total 29,756,420.08
SELECT i.ItemGroup, COUNT(*) AS Lines,
    ROUND(SUM(sil.LineTotal), 2) AS Revenue
FROM SalesInvoiceLine AS sil
    INNER JOIN SalesInvoice AS si
        ON si.SalesInvoiceID = sil.SalesInvoiceID
    INNER JOIN Item AS i ON i.ItemID = sil.ItemID
WHERE si.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY i.ItemGroup
ORDER BY Revenue DESC;  -- Result: 5 rows

-- Requirement (2): the control total of fiscal 2026 invoice lines
-- Population: as above; expected: 9,522 lines, 29,756,420.08 (Chapter 6)
SELECT COUNT(*) AS Lines,
    ROUND(SUM(sil.LineTotal), 2) AS Revenue
FROM SalesInvoiceLine AS sil
    INNER JOIN SalesInvoice AS si
        ON si.SalesInvoiceID = sil.SalesInvoiceID
WHERE si.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31';  -- Result: 1 row (Lines = 9522, Revenue = 29756420.08)

-- Requirement (3): SalesInvoice postings of fiscal 2026 to the revenue accounts
-- Population: GLEntry, SalesInvoice, fiscal 2026; expected: 5 accounts
SELECT a.AccountNumber, a.AccountName,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Revenue
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND gl.FiscalYear = 2026
    AND a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
GROUP BY a.AccountID, a.AccountNumber, a.AccountName
ORDER BY a.AccountNumber;  -- Result: 5 rows

-- Requirement (3): the ledger total of fiscal 2026
-- Population: as above; expected: 29,761,002.45
SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Revenue
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.SourceDocumentType = 'SalesInvoice'
    AND gl.FiscalYear = 2026
    AND a.AccountNumber IN (4010, 4020, 4030, 4040, 4080);  -- Result: 1 row (Revenue = 29761002.45)

-- Requirement (4): the ledger against the invoice lines, side by side
-- Population: the totals of (2) and (3); expected: a difference of 4,582.37
SELECT t.Ledger, t.InvoiceLines,
    ROUND(t.Ledger - t.InvoiceLines, 2) AS Difference
FROM (
    SELECT
        (SELECT ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2)
         FROM GLEntry AS gl
             INNER JOIN Account AS a ON a.AccountID = gl.AccountID
         WHERE gl.SourceDocumentType = 'SalesInvoice'
             AND gl.FiscalYear = 2026
             AND a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
        ) AS Ledger,
        (SELECT ROUND(SUM(sil.LineTotal), 2)
         FROM SalesInvoiceLine AS sil
             INNER JOIN SalesInvoice AS si
                 ON si.SalesInvoiceID = sil.SalesInvoiceID
         WHERE si.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
        ) AS InvoiceLines
) AS t;  -- Result: 1 row (Ledger = 29761002.45, InvoiceLines = 29756420.08, Difference = 4582.37)

-- Requirement (4): fiscal 2026 revenue postings of invoices dated before 2026-01-01
-- Population: GLEntry, SalesInvoice, fiscal 2026; expected: three invoices, 4,582.37
SELECT si.InvoiceNumber, si.InvoiceDate, gl.PostingDate,
    a.AccountNumber,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS Revenue
FROM GLEntry AS gl
    INNER JOIN SalesInvoice AS si
        ON gl.SourceDocumentType = 'SalesInvoice'
        AND si.SalesInvoiceID = gl.SourceDocumentID
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE gl.FiscalYear = 2026
    AND a.AccountNumber IN (4010, 4020, 4030, 4040, 4080)
    AND si.InvoiceDate < '2026-01-01'
GROUP BY si.SalesInvoiceID, si.InvoiceNumber, si.InvoiceDate,
    gl.PostingDate, a.AccountID, a.AccountNumber
ORDER BY si.InvoiceNumber, a.AccountNumber;  -- Result: 3 rows

-- Requirement (5): freight postings and their invoice lines
-- Population: GLEntry, 4050, SalesInvoice, fiscal 2026; expected: 1,628 postings, none with a SourceLineID
SELECT COUNT(*) AS FreightPostings,
    COUNT(gl.SourceLineID) AS WithSourceLine,
    ROUND(SUM(gl.Credit) - SUM(gl.Debit), 2) AS FreightRevenue
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 4050 AND gl.FiscalYear = 2026
    AND gl.SourceDocumentType = 'SalesInvoice';  -- Result: 1 row (FreightPostings = 1628, WithSourceLine = 0, FreightRevenue = 214616.66)

/* Model answer (Requirement (4))

   The ledger's SalesInvoice revenue of fiscal 2026, 29,761,002.45, exceeds the invoice lines dated in 2026,
   29,756,420.08, by 4,582.37. The difference is three invoices dated in late 2025 and posted on 2026-01-01:
   SI-2026-013741 (dated 2025-11-29, 1,112.23 to 4020); SI-2026-013742 (dated 2025-12-04, 3,233.18 to 4010);
   SI-2026-013743 (dated 2025-12-03, 236.96 to 4040). The lines total selects invoices by InvoiceDate and the
   ledger by PostingDate, so these invoices fall in 2025 on one side and in 2026 on the other; account by
   account, the ledger is the lines plus these invoices. They are the cutoff invoices of Exercises 5.2 and
   6.1.
*/

/* Model answer (Requirement (5))

   Freight is billed on the invoice header (SalesInvoice.FreightAmount), not on the lines, so its postings to
   4050 carry no SourceLineID (1,628 postings in 2026, none with a line) and there is no invoice line to
   reconcile them with. The reconciliation compares the revenue accounts fed by the lines; freight would be
   reconciled to the invoice headers instead.
*/

/* Notes

   Exercise 10.1: Reconciling Invoice Lines to the Ledger in SQL
   (1) Join SalesInvoiceLine to SalesInvoice, Item, and Customer, and confirm that the join returns as many
      rows as SalesInvoiceLine holds.
   (2) Total the LineTotal of the invoices dated in fiscal 2026 by item group, and compare the total with the
      control total you used in Chapter 6.
   (3) Join GLEntry to Account, and total the credits less debits posted by SalesInvoice documents in fiscal
      2026 to each revenue account, 4010 to 4040 and 4080.
   (4) Explain the difference between requirements (2) and (3). Find the invoices responsible for it by
      joining the fiscal 2026 SalesInvoice postings to SalesInvoice and keeping the invoices dated before
      2026-01-01.
   (5) Explain why account 4050 Freight Revenue is not part of the reconciliation.
   Instructor note: the four-table join returns 27,933 rows, one per invoice line. Fiscal 2026 invoice lines
      by group: Furniture 17,395,054.38, Lighting 5,997,536.93, Textiles 3,278,211.11, Accessories
      1,872,273.66, Services 1,213,344.00; total 29,756,420.08, Chapter 6's control total. Ledger,
      SalesInvoice postings in fiscal 2026: 4010 17,398,287.56, 4020 5,998,649.16, 4030 3,278,211.11, 4040
      1,872,510.62, 4080 1,213,344.00; total 29,761,002.45. The difference of 4,582.37 is three invoices dated
      in late 2025 and posted on 2026-01-01: SI-2026-013741 (dated 2025-11-29, adding 1,112.23 to 4020),
      SI-2026-013742 (2025-12-04, 3,233.18 to 4010), and SI-2026-013743 (2025-12-03, 236.96 to 4040) (Exercise
      6.1; Exercise 5.2's cutoff invoices). Freight is billed on the invoice header, not on the lines, so it
      posts to 4050 without a line to match.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   10.1: joined rows: 27933
   10.1: invoice lines in the table: 27933
   10.1: equal to the joined rows: 27933
   10.1: item groups: ['Furniture', 'Lighting', 'Textiles', 'Accessories', 'Services']
   10.1: Furniture revenue: 17,395,054.38
   10.1: Lighting revenue: 5,997,536.93
   10.1: Textiles revenue: 3,278,211.11
   10.1: Accessories revenue: 1,872,273.66
   10.1: Services revenue: 1,213,344.00
   10.1: total of the groups: 29,756,420.08
   10.1: lines: 9522
   10.1: revenue: 29,756,420.08
   10.1: accounts: [4010, 4020, 4030, 4040, 4080]
   10.1: 4010 revenue: 17,398,287.56
   10.1: 4020 revenue: 5,998,649.16
   10.1: 4030 revenue: 3,278,211.11
   10.1: 4040 revenue: 1,872,510.62
   10.1: 4080 revenue: 1,213,344.00
   10.1: ledger revenue: 29,761,002.45
   10.1: ledger: 29,761,002.45
   10.1: invoice lines: 29,756,420.08
   10.1: difference: 4,582.37
   10.1: invoices: ['SI-2026-013741', 'SI-2026-013742', 'SI-2026-013743']
   10.1: their total: 4,582.37
   10.1: posting dates: ['2026-01-01']
   10.1: SI-2026-013741 (dated 2025-11-29): [('2025-11-29', 4020, 1112.23)]
   10.1: SI-2026-013742 (dated 2025-12-04): [('2025-12-04', 4010, 3233.18)]
   10.1: SI-2026-013743 (dated 2025-12-03): [('2025-12-03', 4040, 236.96)]
   10.1: freight postings: 1628
   10.1: with a SourceLineID: 0
   10.1: freight revenue: 214,616.66
*/
