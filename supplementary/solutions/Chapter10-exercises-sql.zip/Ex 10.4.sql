/* Ex 10.4.sql: purchase price variance by supplier
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: fiscal 2026 ledger variance 109,566.58 against 109,566.20 from the lines */

-- Requirement (1): the five suppliers with the largest variance in fiscal 2026
-- Population: GLEntry, 5060, fiscal 2026, purchase variance postings; expected: Bell, Pruitt and David first, 6,158.65
SELECT s.SupplierID, s.SupplierName, COUNT(*) AS Postings,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS PriceVariance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
    INNER JOIN PurchaseInvoice AS pi
        ON gl.SourceDocumentType = 'PurchaseInvoice'
        AND pi.PurchaseInvoiceID = gl.SourceDocumentID
    INNER JOIN Supplier AS s ON s.SupplierID = pi.SupplierID
WHERE a.AccountNumber = 5060 AND gl.FiscalYear = 2026
    AND gl.Description LIKE '%purchase variance'
GROUP BY s.SupplierID, s.SupplierName
ORDER BY PriceVariance DESC
LIMIT 5;  -- Result: 5 rows

-- Requirement (1): the ledger total of the variance postings of fiscal 2026
-- Population: as above, every supplier; expected: 19,659 postings, 109,566.58
SELECT COUNT(*) AS Postings,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS PriceVariance
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 5060 AND gl.FiscalYear = 2026
    AND gl.Description LIKE '%purchase variance';  -- Result: 1 row (Postings = 19659, PriceVariance = 109566.58)

-- Requirement (2): the variance recalculated from invoices dated in 2026
-- Population: invoice lines with a purchase-order line; expected: 19,866 lines, 109,566.20
SELECT COUNT(*) AS InvoiceLines,
    ROUND(SUM(pil.Quantity * (pil.UnitCost - pol.UnitCost)), 2)
        AS PriceVariance
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    INNER JOIN PurchaseOrderLine AS pol
        ON pol.POLineID = pil.POLineID
WHERE pi.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31';  -- Result: 1 row (InvoiceLines = 19866, PriceVariance = 109566.2)

-- Requirement (2): the ledger and the lines by supplier
-- Population: every supplier with variance postings; expected: 103 suppliers, largest difference 0.22
SELECT COUNT(*) AS Suppliers,
    ROUND(SUM(g.Variance), 2) AS Ledger,
    ROUND(SUM(l.Variance), 2) AS Lines,
    ROUND(MAX(ABS(g.Variance - l.Variance)), 2)
        AS LargestDifference
FROM (
    SELECT pi.SupplierID,
        ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Variance
    FROM GLEntry AS gl
        INNER JOIN Account AS a ON a.AccountID = gl.AccountID
        INNER JOIN PurchaseInvoice AS pi
            ON gl.SourceDocumentType = 'PurchaseInvoice'
            AND pi.PurchaseInvoiceID = gl.SourceDocumentID
    WHERE a.AccountNumber = 5060 AND gl.FiscalYear = 2026
        AND gl.Description LIKE '%purchase variance'
    GROUP BY pi.SupplierID
) AS g
    INNER JOIN (
        SELECT pi.SupplierID,
            ROUND(SUM(pil.Quantity
                * (pil.UnitCost - pol.UnitCost)), 2) AS Variance
        FROM PurchaseInvoiceLine AS pil
            INNER JOIN PurchaseInvoice AS pi
                ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
            INNER JOIN PurchaseOrderLine AS pol
                ON pol.POLineID = pil.POLineID
        WHERE pi.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
        GROUP BY pi.SupplierID
    ) AS l ON l.SupplierID = g.SupplierID;  -- Result: 1 rows

-- Requirement (3): fiscal 2026 invoice lines billed above the order price
-- Population: the 19,866 lines of (2); expected: 12,413
SELECT COUNT(*) AS InvoiceLines
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    INNER JOIN PurchaseOrderLine AS pol
        ON pol.POLineID = pil.POLineID
WHERE pi.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
    AND pil.UnitCost > pol.UnitCost;  -- Result: 1 row (InvoiceLines = 12413)

-- Requirement (3): fiscal 2026 invoice lines billed below the order price
-- Population: the 19,866 lines of (2); expected: 7,286
SELECT COUNT(*) AS InvoiceLines
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    INNER JOIN PurchaseOrderLine AS pol
        ON pol.POLineID = pil.POLineID
WHERE pi.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
    AND pil.UnitCost < pol.UnitCost;  -- Result: 1 row (InvoiceLines = 7286)

-- Requirement (3): fiscal 2026 invoice lines billed at the order price
-- Population: the 19,866 lines of (2); expected: 167
SELECT COUNT(*) AS InvoiceLines
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    INNER JOIN PurchaseOrderLine AS pol
        ON pol.POLineID = pil.POLineID
WHERE pi.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31'
    AND pil.UnitCost = pol.UnitCost;  -- Result: 1 row (InvoiceLines = 167)

-- Requirement (3): the range of invoice prices against order prices
-- Population: as (2); expected: 1.5% below to 2.6% above
SELECT ROUND(MIN(pil.UnitCost / pol.UnitCost - 1) * 100, 2)
        AS LowestPct,
    ROUND(MAX(pil.UnitCost / pol.UnitCost - 1) * 100, 2)
        AS HighestPct
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    INNER JOIN PurchaseOrderLine AS pol
        ON pol.POLineID = pil.POLineID
WHERE pi.InvoiceDate BETWEEN '2026-01-01' AND '2026-12-31';  -- Result: 1 row (LowestPct = -1.52, HighestPct = 2.57)

-- Requirement (4): amount invoiced against orders and variance by year, 2024 to 2026
-- Population: invoice lines with a purchase-order line, dated 2024 to 2026; expected: 2024 0.48%, 2025 0.47%, 2026 0.51%
SELECT SUBSTR(pi.InvoiceDate, 1, 4) AS InvoiceYear,
    COUNT(*) AS InvoiceLines,
    ROUND(SUM(pil.Quantity * pil.UnitCost), 2) AS AmountInvoiced,
    ROUND(SUM(pil.LineTotal), 2) AS LineTotals,
    ROUND(SUM(pil.Quantity * (pil.UnitCost - pol.UnitCost)), 2)
        AS PriceVariance,
    ROUND(100.0 * SUM(pil.Quantity * (pil.UnitCost - pol.UnitCost))
        / SUM(pil.Quantity * pil.UnitCost), 2) AS VariancePct
FROM PurchaseInvoiceLine AS pil
    INNER JOIN PurchaseInvoice AS pi
        ON pi.PurchaseInvoiceID = pil.PurchaseInvoiceID
    INNER JOIN PurchaseOrderLine AS pol
        ON pol.POLineID = pil.POLineID
WHERE pi.InvoiceDate BETWEEN '2024-01-01' AND '2026-12-31'
GROUP BY InvoiceYear
ORDER BY InvoiceYear;  -- Result: 3 rows

-- Requirement (5): the rest of account 5060 in fiscal 2026, closes excluded
-- Population: GLEntry, 5060, fiscal 2026; expected: nonrecoverable purchase tax 66,444.78 besides the variances
SELECT gl.Description, COUNT(*) AS Postings,
    ROUND(SUM(gl.Debit) - SUM(gl.Credit), 2) AS Amount
FROM GLEntry AS gl
    INNER JOIN Account AS a ON a.AccountID = gl.AccountID
WHERE a.AccountNumber = 5060 AND gl.FiscalYear = 2026
    AND gl.VoucherNumber NOT IN ('JE-2026-000296', 'JE-2026-000297')
GROUP BY gl.Description
ORDER BY Amount DESC;  -- Result: 3 rows

/* Model answer (Requirement (5), memo to the purchasing manager)

   Which suppliers bill above the order price? In fiscal 2026 the ledger's purchase variance postings net
   109,566.58 unfavorable. The largest come from 65 Bell, Pruitt and David (6,158.65), 56 Velasquez-Baxter
   (5,170.56) and 100 Collins-Johnson (4,931.16), but the five largest hold only 23.2% of the total among 103
   suppliers, so billing above the order price is widespread rather than concentrated. Of 19,866 invoice
   lines, 12,413 are billed above the order price, 7,286 below and 167 at it, within 1.5% below to 2.6% above.
   Recalculated from the documents, the variance is 109,566.20, 0.38 from the ledger because each posting is
   rounded (by supplier, within 0.22).

   Did the account grow because prices rose or because we bought more? The variance is a steady share of what
   we buy: 2024 0.48% of 13,491,998.13, 2025 0.47% of 17,468,202.42, 2026 0.51% of 21,612,260.34. Both the
   amount invoiced and the variance grew each year while the rate stayed near half a percent, so the account
   grew because purchases grew, not because suppliers raised their billing relative to the order price. The
   rest of account 5060 is nonrecoverable purchase tax (66,444.78 in 2026).

   What the comparison cannot show: it measures the invoice against the purchase order, so a price rise
   already built into the purchase-order prices, or a better price negotiated elsewhere, does not appear in
   it. Testing whether we pay too much needs order prices compared with earlier prices, price lists, or the
   standard cost.
*/

/* Notes

   Exercise 10.4: Purchase Price Variance by Supplier
   (1) Join the fiscal 2026 postings to account 5060 whose description records a purchase variance to
      PurchaseInvoice, through the source document, and to Supplier. Total the variance by supplier and list
      the five largest.
   (2) Recalculate the variance from the documents: join PurchaseInvoiceLine to PurchaseInvoice and
      PurchaseOrderLine, and total the quantity times the difference between the invoice unit cost and the
      order unit cost, for the invoices dated in fiscal 2026. Compare the total with the ledger's.
   (3) Count the fiscal 2026 invoice lines billed above, below, and at the order price, with one query for
      each condition.
   (4) Calculate, for each year from 2024 to 2026, the total amount invoiced against purchase orders and the
      price variance, and express the variance as a percentage of the amount invoiced.
   (5) Write a short memo (one half page) to the purchasing manager answering both questions, and explain what
      a comparison of invoice prices with order prices cannot show.
   Instructor note: GL variance postings of fiscal 2026 (descriptions ending in "purchase variance") net
      109,566.58. Largest suppliers: 65 Bell, Pruitt and David 6,158.65; 56 Velasquez-Baxter 5,170.56; 100
      Collins-Johnson 4,931.16; 17 Brooks, Johnson and Olson 4,719.17; 16 Berger, Stanley and Cooper 4,410.07.
      The line-level recalculation for invoices dated in 2026 is 109,566.20, 0.38 from the ledger because each
      posting is rounded; by supplier the two agree to within about 0.22. Of 19,866 fiscal 2026 invoice lines,
      12,413 are billed above the order price, 7,286 below, and 167 at it; the differences range from 1.5%
      below to 2.6% above. Amount invoiced against orders (SUM of Quantity times the invoice UnitCost) and
      variance: 2024 13,491,998 and 64,632 (0.48%); 2025 17,468,202 and 82,377 (0.47%); 2026 21,612,260 and
      109,566 (0.51%); SUM(LineTotal) differs by 0.80 to 1.99 a year (the rounding of each line). The rate is
      steady, so the account grew because purchases grew, not because suppliers raised their billing relative
      to the order price. The measure is an invoice price variance: a price rise already built into the
      purchase-order prices would not show in it. The rest of account 5060 is nonrecoverable purchase tax
      (66,444.78 in 2026).

   Checks (each agreed on dataset release v2026.1 when this file was built):
   10.4: suppliers: [65, 56, 100, 17, 16]
   10.4: supplier 65 Bell, Pruitt and David: 6,158.65
   10.4: supplier 56 Velasquez-Baxter: 5,170.56
   10.4: supplier 100 Collins-Johnson: 4,931.16
   10.4: supplier 17 Brooks, Johnson and Olson: 4,719.17
   10.4: supplier 16 Berger, Stanley and Cooper: 4,410.07
   10.4: postings: 19659
   10.4: ledger variance: 109,566.58
   10.4: invoice lines: 19866
   10.4: recalculated variance: 109,566.20
   10.4: gap to the ledger: 0.38
   10.4: suppliers matched: 103
   10.4: ledger: 109,566.58
   10.4: lines: 109,566.20
   10.4: largest difference by supplier: 0.22
   10.4: lines above: 12413
   10.4: lines below: 7286
   10.4: lines at: 167
   10.4: lowest, percent: -1.52
   10.4: highest, percent: 2.57
   10.4: years: ['2024', '2025', '2026']
   10.4: 2024 amount invoiced: 13,491,998.13
   10.4: 2024 price variance: 64,631.92
   10.4: 2024 variance, percent: 0.48
   10.4: 2024 LineTotal less amount (rounding of each line): 0.80
   10.4: 2025 amount invoiced: 17,468,202.42
   10.4: 2025 price variance: 82,377.43
   10.4: 2025 variance, percent: 0.47
   10.4: 2025 LineTotal less amount (rounding of each line): 1.42
   10.4: 2026 amount invoiced: 21,612,260.34
   10.4: 2026 price variance: 109,566.20
   10.4: 2026 variance, percent: 0.51
   10.4: 2026 LineTotal less amount (rounding of each line): 1.99
   10.4: descriptions: ['Record favorable purchase variance', 'Record nonrecoverable purchase tax', 'Record
      unfavorable purchase variance']
   10.4: nonrecoverable purchase tax: 66,444.78
*/
