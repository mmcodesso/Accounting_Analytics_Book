/* Ex 10.5.sql: testing referential integrity with anti-joins
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: six ledger rows without a payroll payment; 17 labor entries with an orphaned operation key */

-- Requirement (1): a profile of LaborTimeEntry by labor type
-- Population: LaborTimeEntry, every entry; expected: 3 labor types, 51,117 direct entries
SELECT LaborType, COUNT(*) AS Entries,
    COUNT(WorkOrderOperationID) AS WithOperation,
    COUNT(DISTINCT EmployeeID) AS Employees,
    MIN(WorkDate) AS FirstWorkDate,
    MAX(WorkDate) AS LastWorkDate
FROM LaborTimeEntry
GROUP BY LaborType
ORDER BY LaborType;  -- Result: 3 rows

-- Requirement (2): ledger rows that point to no payroll payment
-- Population: GLEntry, PayrollPayment; expected: six rows, three pairs of 7,971.10
SELECT gl.GLEntryID, gl.PostingDate, gl.SourceDocumentID,
    gl.Debit, gl.Credit, gl.Description
FROM GLEntry AS gl
    LEFT JOIN PayrollPayment AS pp
        ON pp.PayrollPaymentID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'PayrollPayment'
    AND pp.PayrollPaymentID IS NULL
ORDER BY gl.GLEntryID;  -- Result: 6 rows

-- Requirement (2): their totals
-- Population: as above; expected: debits and credits 23,913.30 each
SELECT COUNT(*) AS Postings,
    ROUND(SUM(gl.Debit), 2) AS Debits,
    ROUND(SUM(gl.Credit), 2) AS Credits
FROM GLEntry AS gl
    LEFT JOIN PayrollPayment AS pp
        ON pp.PayrollPaymentID = gl.SourceDocumentID
WHERE gl.SourceDocumentType = 'PayrollPayment'
    AND pp.PayrollPaymentID IS NULL;  -- Result: 1 row (Postings = 6, Debits = 23913.3, Credits = 23913.3)

-- Requirement (3): customers that have never placed a sales order
-- Population: Customer; expected: nine customers, all inactive
SELECT c.CustomerID, c.CustomerName, c.CustomerSegment,
    c.IsActive
FROM Customer AS c
    LEFT JOIN SalesOrder AS so ON so.CustomerID = c.CustomerID
WHERE so.SalesOrderID IS NULL
ORDER BY c.CustomerID;  -- Result: 9 rows

-- Requirement (4): work orders with no work order operations
-- Population: WorkOrder; expected: WO-2024-000001, WO-2025-005504 and WO-2026-010075, all Closed
SELECT wo.WorkOrderID, wo.WorkOrderNumber, wo.Status,
    wo.ReleasedDate, wo.ClosedDate
FROM WorkOrder AS wo
    LEFT JOIN WorkOrderOperation AS op
        ON op.WorkOrderID = wo.WorkOrderID
WHERE op.WorkOrderOperationID IS NULL
ORDER BY wo.WorkOrderNumber;  -- Result: 3 rows

-- Requirement (4): the labor time recorded on those work orders
-- Population: LaborTimeEntry; expected: 18 direct entries
SELECT lt.LaborType, COUNT(*) AS Entries,
    ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 2) AS Hours
FROM LaborTimeEntry AS lt
WHERE lt.WorkOrderID IN (
    SELECT wo.WorkOrderID
    FROM WorkOrder AS wo
        LEFT JOIN WorkOrderOperation AS op
            ON op.WorkOrderID = wo.WorkOrderID
    WHERE op.WorkOrderOperationID IS NULL
)
GROUP BY lt.LaborType;  -- Result: 1 row (LaborType = Direct Manufacturing, Entries = 18, Hours = 45.86)

-- Requirement (5): labor time whose WorkOrderOperationID matches no operation
-- Population: LaborTimeEntry with a WorkOrderOperationID; expected: 17 entries, 42.12 hours
SELECT lt.LaborTimeEntryID, lt.LaborType, lt.EmployeeID,
    wo.WorkOrderNumber, lt.WorkOrderOperationID, lt.WorkDate,
    lt.RegularHours + lt.OvertimeHours AS Hours
FROM LaborTimeEntry AS lt
    LEFT JOIN WorkOrderOperation AS op
        ON op.WorkOrderOperationID = lt.WorkOrderOperationID
    LEFT JOIN WorkOrder AS wo ON wo.WorkOrderID = lt.WorkOrderID
WHERE lt.WorkOrderOperationID IS NOT NULL
    AND op.WorkOrderOperationID IS NULL
ORDER BY wo.WorkOrderNumber, lt.WorkDate;  -- Result: 17 rows

-- Requirement (5): the same entries by work order
-- Population: as above; expected: WO-2024-000001 4, WO-2025-005504 6, WO-2026-010075 7
SELECT wo.WorkOrderNumber, COUNT(*) AS Entries,
    ROUND(SUM(lt.RegularHours + lt.OvertimeHours), 2) AS Hours
FROM LaborTimeEntry AS lt
    LEFT JOIN WorkOrderOperation AS op
        ON op.WorkOrderOperationID = lt.WorkOrderOperationID
    LEFT JOIN WorkOrder AS wo ON wo.WorkOrderID = lt.WorkOrderID
WHERE lt.WorkOrderOperationID IS NOT NULL
    AND op.WorkOrderOperationID IS NULL
GROUP BY wo.WorkOrderID, wo.WorkOrderNumber
ORDER BY wo.WorkOrderNumber;  -- Result: 3 rows

/* Model answer (Requirement (1))

   Direct Manufacturing: 51,117 entries, 51,114 with a WorkOrderOperationID, 64 employees, 2024-01-17 to
   2026-12-11; Indirect Manufacturing: 11,702, none with an operation, 65 employees, 2024-01-15 to 2026-12-04;
   NonManufacturing: 6,040, none, 12 employees, 2024-01-01 to 2026-12-11. Expected: indirect and non-
   manufacturing time has no operation by design, and the manufacturing time starts in the January 2024 start-
   up month. Not expected: three direct entries without an operation (Exercise 9.6), and the end on 11
   December 2026, before the year ends (the open pay periods of Tutorial 10.3), a timeliness limit on any test
   of the year's labor. Indirect time ends a week earlier (2026-12-04), so the last records hold only direct
   and non-manufacturing time.
*/

/* Model answer (Requirement (6), findings and dispositions)

   1. Ledger rows without a payroll payment: six GLEntry rows of type PayrollPayment point to no payment:
   GLEntryIDs 7231 and 7232 (2024-01-19, SourceDocumentID 1); GLEntryIDs 12521 and 12522 (2025-01-03,
   SourceDocumentID 2646); GLEntryIDs 18069 and 18070 (2026-01-02, SourceDocumentID 5420); each pair a
   7,971.10 debit "Clear accrued payroll" and credit "Disburse payroll cash", 23,913.30 each side. Integrity
   failure: postings without a supporting document. Follow-up: ask payroll for the payment records and bank
   evidence, and confirm whether cash was disbursed.

   2. Customers without orders: nine, all inactive. Expected condition: customers set up and never used or
   deactivated. Follow-up: none beyond confirming they stay inactive.

   3. Work orders without operations: WO-2024-000001, WO-2025-005504 and WO-2026-010075, all Closed, yet 18
   direct time entries were recorded on them. Process exception: a closed work order should have operations.
   Follow-up: ask production how they were closed without a routing, and what the time recorded on them was
   for.

   4. Orphaned operation keys: 17 Direct Manufacturing entries (42.12 hours) carry a WorkOrderOperationID that
   matches no operation, 4 on WO-2024-000001, 6 on WO-2025-005504, 7 on WO-2026-010075, the work orders of
   finding 3. An orphaned key, not a missing one, so an IS NULL test alone would miss them (the three entries
   with no key at all are Exercise 9.6). Integrity failure. Follow-up: correct the keys or the operations, and
   find out how the time system accepted an operation that does not exist.
*/

/* Notes

   Exercise 10.5: Testing Referential Integrity with Anti-Joins
   (1) Before the tests, profile LaborTimeEntry with the tests of @tbl-10-03: by LaborType, count the entries,
      the entries with a WorkOrderOperationID, and the employees, and find the first and last WorkDate. State
      which results you expected and which you did not.
   (2) Find the GLEntry rows whose SourceDocumentType is PayrollPayment and whose SourceDocumentID matches no
      PayrollPayment. List them with their posting date, amounts, and description, and total their debits and
      credits.
   (3) Find the customers that have never placed a sales order, and check their IsActive flag.
   (4) Find the work orders that have no work order operations, and report their status.
   (5) Find the labor time entries whose WorkOrderOperationID is filled in but matches no work order
      operation, and identify their work orders and hours.
   (6) For each finding, state whether it is an integrity failure, a process exception, or an expected
      condition, and recommend a follow-up.
   Instructor note: (1) Profile by LaborType: Direct Manufacturing 51,117 entries, 51,114 with a
      WorkOrderOperationID, 64 employees, 2024-01-17 to 2026-12-11; Indirect Manufacturing 11,702, none with
      an operation, 65 employees, 2024-01-15 to 2026-12-04; NonManufacturing 6,040, none, 12 employees,
      2024-01-01 to 2026-12-11. Expected: indirect and non-manufacturing time has no operation by design, and
      the manufacturing time starts in the January 2024 start-up month. Not expected: 3 direct entries without
      an operation (Exercise 9.6), and the end on 11 December 2026 (the open pay periods of Tutorial 10.3), a
      timeliness limit. Indirect time ends a week earlier (2026-12-04): the records after it hold only direct
      and non-manufacturing time. (2) six GLEntry rows with SourceDocumentType PayrollPayment point to no
      payment: GLEntryIDs 7231 and 7232 (2024-01-19, SourceDocumentID 1), 12521 and 12522 (2025-01-03,
      SourceDocumentID 2646), 18069 and 18070 (2026-01-02, SourceDocumentID 5420), each pair a 7,971.10 debit
      "Clear accrued payroll" and a 7,971.10 credit "Disburse payroll cash"; debits and credits 23,913.30
      each. They are ledger postings without a supporting document (planted missing payroll payment), an
      integrity failure to investigate. (3) Nine customers have no orders, all with IsActive 0, an expected
      condition. (4) Three work orders have no operations, WO-2024-000001, WO-2025-005504, and WO-2026-010075,
      all Closed (planted), a process exception: a closed work order should have operations. They do have
      labor: 18 direct time entries. (5) 17 Direct Manufacturing entries (42.1 hours) carry a
      WorkOrderOperationID that matches no operation: 4 on WO-2024-000001, 6 on WO-2025-005504, and 7 on
      WO-2026-010075, the work orders of requirement (4). An orphaned key, not a missing one, so an IS NULL
      filter alone would miss them; an integrity failure to correct. (Three more direct entries have no
      WorkOrderOperationID at all, Exercise 9.6.)

   Checks (each agreed on dataset release v2026.1 when this file was built):
   10.5: labor types: ['Direct Manufacturing', 'Indirect Manufacturing', 'NonManufacturing']
   10.5: Direct Manufacturing: (51117, 51114, 64, '2024-01-17', '2026-12-11')
   10.5: Indirect Manufacturing: (11702, 0, 65, '2024-01-15', '2026-12-04')
   10.5: NonManufacturing: (6040, 0, 12, '2024-01-01', '2026-12-11')
   10.5: rows: 6
   10.5: GLEntryIDs: [7231, 7232, 12521, 12522, 18069, 18070]
   10.5: SourceDocumentIDs: [1, 2646, 5420]
   10.5: posting dates: ['2024-01-19', '2025-01-03', '2026-01-02']
   10.5: descriptions: ['Clear accrued payroll', 'Disburse payroll cash']
   10.5: every row's amount: [7971.1]
   10.5: debit rows: 3
   10.5: postings: 6
   10.5: debits: 23,913.30
   10.5: credits: 23,913.30
   10.5: customers: [212, 213, 214, 215, 216, 217, 218, 219, 220]
   10.5: IsActive values: [0]
   10.5: work orders: ['WO-2024-000001', 'WO-2025-005504', 'WO-2026-010075']
   10.5: statuses: ['Closed']
   10.5: labor types: ['Direct Manufacturing']
   10.5: entries: 18
   10.5: entries: 17
   10.5: labor types: ['Direct Manufacturing']
   10.5: hours: 42.12
   10.5: entries by work order: [('WO-2024-000001', 4), ('WO-2025-005504', 6), ('WO-2026-010075', 7)]
   10.5: hours: 42.12
*/
