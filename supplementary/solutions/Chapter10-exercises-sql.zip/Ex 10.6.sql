/* Ex 10.6.sql: suppliers that share an employee's address
   Database: CharlesRiver_Work.sqlite (a copy of CharlesRiver.sqlite)
   Prepared by: instructor solution, built 2026-10-05 on dataset v2026.1
   Checks: six address matches; invoices and payments totaled apart; two shared customer names */

-- Requirement (1): suppliers whose address is an employee's
-- Population: Supplier and Employee; expected: six matches, all approved
SELECT s.SupplierID, s.SupplierName, s.IsApproved,
    e.EmployeeID, e.EmployeeName, e.JobTitle, s.Address
FROM Supplier AS s
    INNER JOIN Employee AS e ON e.Address = s.Address
ORDER BY s.SupplierID;  -- Result: 6 rows

-- Requirement (1): addresses shared by more than one employee
-- Population: Employee; expected: no rows, so each supplier matches one employee
SELECT Address, COUNT(*) AS Employees
FROM Employee
GROUP BY Address
HAVING COUNT(*) > 1;  -- Result: 0 rows

-- Requirement (2): invoices and payments of the matching suppliers through 2026-12-31
-- Population: PurchaseInvoice and DisbursementPayment dated through 2026-12-31; expected: 6 suppliers, each table totaled on its own
SELECT s.SupplierID, s.SupplierName,
    inv.Invoices, inv.Invoiced, pay.Payments, pay.Paid
FROM Supplier AS s
    INNER JOIN Employee AS e ON e.Address = s.Address
    INNER JOIN (
        SELECT SupplierID, COUNT(*) AS Invoices,
            ROUND(SUM(GrandTotal), 2) AS Invoiced
        FROM PurchaseInvoice
        WHERE InvoiceDate <= '2026-12-31'
        GROUP BY SupplierID
    ) AS inv ON inv.SupplierID = s.SupplierID
    INNER JOIN (
        SELECT SupplierID, COUNT(*) AS Payments,
            ROUND(SUM(Amount), 2) AS Paid
        FROM DisbursementPayment
        WHERE PaymentDate <= '2026-12-31'
        GROUP BY SupplierID
    ) AS pay ON pay.SupplierID = s.SupplierID
ORDER BY s.SupplierID;  -- Result: 6 rows

-- Requirement (2): the fan-out of joining invoices to payments, supplier 1
-- Population: supplier 1's invoices and payments through 2026-12-31; expected: 152,880 rows, not 390 or 392
SELECT COUNT(*) AS JoinedRows
FROM PurchaseInvoice AS pi
    INNER JOIN DisbursementPayment AS dp
        ON dp.SupplierID = pi.SupplierID
WHERE pi.SupplierID = 1 AND pi.InvoiceDate <= '2026-12-31'
    AND dp.PaymentDate <= '2026-12-31';  -- Result: 1 row (JoinedRows = 152880)

-- Requirement (2): supplier 5's invoices still open at 2026-12-31
-- Population: supplier 5's invoices through 2026-12-31; expected: 664,053.78 open, including V0005-2024-003160 and V0005-2026-021692
SELECT pi.InvoiceNumber, pi.InvoiceDate, pi.GrandTotal,
    ROUND(pi.GrandTotal - COALESCE(p.Paid, 0), 2) AS OpenAmount
FROM PurchaseInvoice AS pi
    LEFT JOIN (
        SELECT PurchaseInvoiceID, SUM(Amount) AS Paid
        FROM DisbursementPayment
        WHERE PaymentDate <= '2026-12-31'
        GROUP BY PurchaseInvoiceID
    ) AS p ON p.PurchaseInvoiceID = pi.PurchaseInvoiceID
WHERE pi.SupplierID = 5 AND pi.InvoiceDate <= '2026-12-31'
    AND pi.GrandTotal - COALESCE(p.Paid, 0) > 0.005
ORDER BY OpenAmount DESC;  -- Result: 22 rows

-- Requirement (3): customer names shared by more than one CustomerID
-- Population: Customer; expected: Brown LLC and Smith Ltd
SELECT CustomerName, COUNT(*) AS Customers
FROM Customer
GROUP BY CustomerName
HAVING COUNT(*) > 1
ORDER BY CustomerName;  -- Result: 2 rows

-- Requirement (3): those customers with their segments
-- Population: Customer, shared names; expected: 4 customers
SELECT CustomerID, CustomerName, CustomerSegment, City, Region,
    IsActive
FROM Customer
WHERE CustomerName IN (
    SELECT CustomerName
    FROM Customer
    GROUP BY CustomerName
    HAVING COUNT(*) > 1
)
ORDER BY CustomerName, CustomerID;  -- Result: 4 rows

/* Model answer (Requirement (4))

   The join compares every supplier address with every employee address exactly, character for character, so
   it cannot overlook a match the eye would miss in two long lists, and it can be rerun on next year's data.
   It cannot find addresses written differently (an abbreviation, a suite number, a typing error; Chapter 2),
   so a fuzzy comparison of standardized text is the next step, and a match does not prove a relationship: a
   shared address may be a coincidence, an office building, or a family member, and only evidence outside the
   database can tell.
*/

/* Model answer (Requirement (5), memo to the audit senior)

   Findings: six approved suppliers share an address with an employee: supplier 1 Anderson-Noble with employee
   22 (Assembler); supplier 2 Watson, Mitchell and Chen with employee 46 (Machine Operator); supplier 3 Lucas,
   Green and Richardson with employee 33 (Assembler); supplier 4 Stokes, Mann and Keller with employee 119
   (Designer); supplier 5 Nelson-Rocha with employee 65 (Quality Technician); supplier 6 Wright, Sanchez and
   Garza with employee 20 (Assembler). No two employees share an address, so each supplier matches one
   employee. Through 2026-12-31: supplier 1: 390 invoices 377,401.03, 392 payments 354,958.21; supplier 2: 327
   invoices 467,847.58, 322 payments 431,269.26; supplier 3: 392 invoices 400,322.61, 387 payments 366,307.32;
   supplier 4: 208 invoices 703,106.56, 214 payments 690,304.23; supplier 5: 245 invoices 1,227,176.20, 234
   payments 563,122.42; supplier 6: 373 invoices 388,893.73, 368 payments 340,084.99. Invoices and payments
   were totaled separately and then joined by supplier, because joining the two tables directly repeats each
   invoice once per payment (152,880 rows for supplier 1). Supplier 5 has 664,053.78 of invoices still open at
   2026-12-31, including V0005-2024-003160 (360,000.00) and V0005-2026-021692 (280,000.00), the invoices the
   Debt Reclass entries moved to notes payable (Chapter 8). Shared customer names: Brown LLC, customers 5
   (Design Trade) and 173 (Strategic); Smith Ltd, customers 170 (Small Business) and 220 (Small Business,
   inactive, no orders).

   Recommended procedures: obtain the vendor setup records of the six suppliers (who requested and approved
   each, and on what evidence); compare them with the employees' conflict-of-interest declarations; check
   whether the matching employees can request, approve, or receive purchases from these suppliers; vouch a
   sample of the suppliers' invoices to receipts; and confirm whether the shared customer names are different
   customers or duplicates in the master file.
*/

/* Notes

   Exercise 10.6: Suppliers That Share an Employee's Address
   (1) Join Supplier to Employee on Address, and list each matching supplier with the employee, the employee's
      job title, and the supplier's IsApproved flag.
   (2) For each matching supplier, total the number and amount of supplier invoices and of payments dated
      through 2026-12-31. Group by SupplierID, and total the invoices and the payments separately, in two
      queries or two derived tables, so that a join of one to the other does not repeat either.
   (3) Use GROUP BY and HAVING to find the customer names shared by more than one CustomerID, and list those
      customers with their segments.
   (4) Explain why the join in requirement (1) is a stronger test than a visual comparison of the two lists,
      and what it cannot tell you.
   (5) Write a short memo (one half page) to the audit senior with the findings and the next procedures you
      recommend.
   Instructor note: six suppliers share an address with an employee (planted related-party matches): supplier
      1 Anderson-Noble with employee 22 (Assembler), 2 Watson, Mitchell and Chen with 46 (Machine Operator), 3
      Lucas, Green and Richardson with 33 (Assembler), 4 Stokes, Mann and Keller with 119 (Designer), 5
      Nelson-Rocha with 65 (Quality Technician), and 6 Wright, Sanchez and Garza with 20 (Assembler); all six
      are approved. Supplier invoices (all dated through 2026-12-31): 1 390 invoices 377,401.03; 2 327
      467,847.58; 3 392 400,322.61; 4 208 703,106.56; 5 245 1,227,176.20; 6 373 388,893.73. Payments through
      2026-12-31: 1 392 payments 354,958.21; 2 322, 431,269.26; 3 387, 366,307.32; 4 214, 690,304.23; 5 234,
      563,122.42; 6 368, 340,084.99. No two employees share an address, so each supplier matches one employee.
      Joining invoices and payments in one query fans out (152,880 rows for supplier 1, both dated through
      2026-12-31). Supplier 5 has 664,053.78 of invoices still open at 2026-12-31, including V0005-2024-003160
      (360,000) and V0005-2026-021692 (280,000), the invoices that the Debt Reclass entries moved (Chapter 8).
      Shared customer names: Brown LLC (customers 5, Design Trade, and 173, Strategic) and Smith Ltd (170 and
      220, both Small Business). An exact join misses addresses written differently (Chapter 2) and cannot
      prove a relationship; the next steps are vendor setup records, conflict-of-interest declarations, and
      the employees' purchasing roles.

   Checks (each agreed on dataset release v2026.1 when this file was built):
   10.6: matches: [(1, 22), (2, 46), (3, 33), (4, 119), (5, 65), (6, 20)]
   10.6: supplier 1: ('Anderson-Noble', 'Assembler', 1)
   10.6: supplier 2: ('Watson, Mitchell and Chen', 'Machine Operator', 1)
   10.6: supplier 3: ('Lucas, Green and Richardson', 'Assembler', 1)
   10.6: supplier 4: ('Stokes, Mann and Keller', 'Designer', 1)
   10.6: supplier 5: ('Nelson-Rocha', 'Quality Technician', 1)
   10.6: supplier 6: ('Wright, Sanchez and Garza', 'Assembler', 1)
   10.6: shared employee addresses: 0
   10.6: suppliers: [1, 2, 3, 4, 5, 6]
   10.6: supplier 1 invoices: (390, 377401.03)
   10.6: supplier 1 payments: (392, 354958.21)
   10.6: supplier 2 invoices: (327, 467847.58)
   10.6: supplier 2 payments: (322, 431269.26)
   10.6: supplier 3 invoices: (392, 400322.61)
   10.6: supplier 3 payments: (387, 366307.32)
   10.6: supplier 4 invoices: (208, 703106.56)
   10.6: supplier 4 payments: (214, 690304.23)
   10.6: supplier 5 invoices: (245, 1227176.2)
   10.6: supplier 5 payments: (234, 563122.42)
   10.6: supplier 6 invoices: (373, 388893.73)
   10.6: supplier 6 payments: (368, 340084.99)
   10.6: joined rows: 152880
   10.6: invoices times payments: 152880
   10.6: open amount: 664,053.78
   10.6: V0005-2024-003160 open in full: 360,000.00
   10.6: V0005-2026-021692 open in full: 280,000.00
   10.6: names: ['Brown LLC', 'Smith Ltd']
   10.6: customers per name: [2, 2]
   10.6: customers: [(5, 'Brown LLC', 'Design Trade'), (173, 'Brown LLC', 'Strategic'), (170, 'Smith Ltd',
      'Small Business'), (220, 'Smith Ltd', 'Small Business')]
*/
